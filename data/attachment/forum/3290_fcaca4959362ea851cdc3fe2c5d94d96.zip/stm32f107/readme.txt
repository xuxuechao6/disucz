1. support board
# GoldBull debug board
   - 10M/100M ethernet
   - SPI SD Card
   - LCD
