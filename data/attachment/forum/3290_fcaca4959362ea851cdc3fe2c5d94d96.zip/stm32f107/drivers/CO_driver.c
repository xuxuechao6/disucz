/*
 * CAN module object for Microchip STM32F4xx microcontroller.
 *
 * @file        CO_driver.c
 * @version     SVN: \$Id: CO_driver.h 278 2013-03-04 17:11:47Z jani $
 * @author      Janez Paternoster
 * @author      Ondrej Netik
 * @copyright   2004 - 2013 Janez Paternoster, Ondrej Netik
 *
 * This file is part of CANopenNode, an opensource CANopen Stack.
 * Project home page is <http://canopennode.sourceforge.net>.
 * For more information on CANopen see <http://www.can-cia.org/>.
 *
 * CANopenNode is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */


#include <stddef.h>		// for NULL

// Custom
#include "CO_config.h"

#include <stm32f10x_conf.h>
#include "CO_driver.h"
#include "CO_Emergency.h"



void InitCanLeds() {
//    GPIO_InitTypeDef GPIO_InitStructure;
//    RCC_AHB1PeriphClockCmd(LED_GPIO_CLOCK, ENABLE);
//    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_Led_GREEN | GPIO_Pin_Led_RED;
//    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
//    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
//    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
//    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
//    GPIO_Init(GPIO_LEDS, &GPIO_InitStructure);
//    CanLedsOff(eCoLed_Green | eCoLed_Red);
}

void CanLedsSet(eCoLeds led) {
//    if (led & eCoLed_Green)
//        CanLedsOn(eCoLed_Green);
//    else
//        CanLedsOff(eCoLed_Green);
//
//    if (led & eCoLed_Red)
//        CanLedsOn(eCoLed_Red);
//    else
//        CanLedsOff(eCoLed_Red);
}

void CanLedsOn(eCoLeds led) {
//    if (led & eCoLed_Green) {
//#ifdef LED_POSITIVE
//        GPIO_SetBits(GPIO_LEDS, GPIO_Pin_Led_GREEN);
//#else
//        GPIO_ResetBits(GPIO_LEDS, GPIO_Pin_Led_GREEN);
//#endif
//    }
//    if (led & eCoLed_Red) {
//#ifdef LED_POSITIVE
//        GPIO_SetBits(GPIO_LEDS, GPIO_Pin_Led_RED);
//#else
//        GPIO_ResetBits(GPIO_LEDS, GPIO_Pin_Led_RED);
//#endif
//    }
}

void CanLedsOff(eCoLeds led) {
//    if (led & eCoLed_Green) {
//#ifdef LED_POSITIVE
//        GPIO_ResetBits(GPIO_LEDS, GPIO_Pin_Led_GREEN);
//#else
//        GPIO_SetBits(GPIO_LEDS, GPIO_Pin_Led_GREEN);
//#endif
//    }
//    if (led & eCoLed_Red) {
//#ifdef LED_POSITIVE
//        GPIO_ResetBits(GPIO_LEDS, GPIO_Pin_Led_RED);
//#else
//        GPIO_SetBits(GPIO_LEDS, GPIO_Pin_Led_RED);
//#endif
//    }
}

/******************************************************************************/
#ifdef BIG_ENDIAN
void CO_memcpySwap2(uint8_t dest[], const uint8_t src[]){
    dest[0] = src[1];
    dest[1] = src[0];
}

void CO_memcpySwap4(uint8_t dest[], const uint8_t src[]){
    dest[0] = src[3];
    dest[1] = src[2];
    dest[2] = src[1];
    dest[3] = src[0];
}
#else
void CO_memcpySwap2(uint8_t dest[], const uint8_t src[]){
    dest[0] = src[0];
    dest[1] = src[1];
}

void CO_memcpySwap4(uint8_t dest[], const uint8_t src[]){
    dest[0] = src[0];
    dest[1] = src[1];
    dest[2] = src[2];
    dest[3] = src[3];
}
#endif


/*******************************************************************************
   Macro and Constants - CAN module registers
 *******************************************************************************/
void CO_CANsetConfigurationMode(CAN_TypeDef *CANbaseAddress) {
//    unsigned int wait_ack = 0;

    /* Request initialisation */
//    CANbaseAddress->MCR |= CAN_MCR_INRQ;

    /* Wait the acknowledge */
//    while (((CANbaseAddress->MSR & CAN_MSR_INAK) != CAN_MSR_INAK) && (wait_ack != INAK_TIMEOUT))
//        wait_ack++;

    /* Check acknowledge */
//    if ((CANbaseAddress->MSR & CAN_MSR_INAK) != CAN_MSR_INAK) {
        // enter to configuration mode failed

//    }


}

/******************************************************************************/
void CO_CANsetNormalMode(CAN_TypeDef *CANbaseAddress) {
//    unsigned int wait_ack = 0;

    /* Request leave initialisation */
//    CANbaseAddress->MCR &= ~(uint32_t) CAN_MCR_INRQ;

    /* Wait the acknowledge */
//    while (((CANbaseAddress->MSR & CAN_MSR_INAK) == CAN_MSR_INAK) && (wait_ack != INAK_TIMEOUT))
//        wait_ack++;

    /* ...and check acknowledged */
//    if ((CANbaseAddress->MSR & CAN_MSR_INAK) == CAN_MSR_INAK) {
        // leave initialization state failed

//    }

}

static void CO_CanInterruptEnDis(CAN_TypeDef *CANbaseAddress, uint8_t enb) {
    CAN_ITConfig(CANbaseAddress,
    		//CAN_IT_TME | // Tx
            CAN_IT_FMP0  // Rx
            //CAN_IT_ERR |  // Error Interrupt
            //CAN_IT_BOF |  // BusOff interrupt
            //CAN_IT_EPV |  // Error Passive
            //CAN_IT_EWG    // Error Warning
            , enb);
}

/******************************************************************************/
CO_ReturnError_t CO_CANmodule_init(
        CO_CANmodule_t *CANmodule,
        CAN_TypeDef *CANbaseAddress,
        CO_CANrx_t *rxArray,
        uint16_t rxSize,
        CO_CANtx_t *txArray,
        uint16_t txSize,
        uint16_t CANbitRate) {
    CAN_InitTypeDef CAN_InitStruct;
    CAN_FilterInitTypeDef CAN_FilterInitStruct;
    GPIO_InitTypeDef GPIO_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    int i;

    CANmodule->CANbaseAddress = CANbaseAddress;
    CANmodule->rxArray = rxArray;
    CANmodule->rxSize = rxSize;
    CANmodule->txArray = txArray;
    CANmodule->txSize = txSize;
    CANmodule->bufferInhibitFlag = 0;
    CANmodule->firstCANtxMessage = 1;
    CANmodule->CANtxCount = 0;
    CANmodule->errOld = 0;
    CANmodule->em = 0;

// This part is done in board.c
//    CO_CanInterruptEnDis(CANbaseAddress, DISABLE);

    for (i = 0; i < rxSize; i++) {
        CANmodule->rxArray[i].ident = 0;
        CANmodule->rxArray[i].pFunct = 0;
    }
    for (i = 0; i < txSize; i++) {
        CANmodule->txArray[i].bufferFull = 0;
    }

    //This Part is done in board.c
    /* Setting Clock of CAN HW */
//  
//    if (CANbaseAddress == CAN1)
//    {
//	  RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN1, ENABLE);
//	  GPIO_PinRemapConfig(GPIO_Remap2_CAN1,ENABLE);
//          
//          /* Configure CAN1 pin: RX */
//          GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
//          GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//          GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
//          GPIO_Init(GPIOD, &GPIO_InitStructure); 
//          
//          /* Configure CAN1 pin: TX */
//          GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
//          GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//          GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
//          GPIO_Init(GPIOD, &GPIO_InitStructure);    
//    }
//
//	
//    if (CANbaseAddress == CAN2)
//    {
//          RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN2, ENABLE);
//          GPIO_PinRemapConfig(GPIO_Remap_CAN2,ENABLE);
//          
//          /* Configure CAN2 pin: RX */
//          GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
//          GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//          GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
//          GPIO_Init(GPIOB, &GPIO_InitStructure); 
//          /* Configure CAN2 pin: TX */
//          GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
//          GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//          GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
//          GPIO_Init(GPIOB, &GPIO_InitStructure);    
//    }
//
//
//    /* Init CAN controler */
//    CAN_DeInit(CANmodule->CANbaseAddress);
//
////#if 1
////    /* Hard-coded for 125k baudrate */
////    CAN_InitStruct.CAN_Prescaler = 16; // 125k baudrate
////    CAN_InitStruct.CAN_BS1 = CAN_BS1_14tq;
////    CAN_InitStruct.CAN_BS2 = CAN_BS2_6tq;
////#else
////    /* This code is not written for default STM32F4xx bus speed */
////    CAN_StructInit(&CAN_InitStruct);
////    CAN_InitStruct.CAN_BS1 = CAN_BS1_3tq;
////    CAN_InitStruct.CAN_BS2 = CAN_BS2_2tq;
////    switch (CANbitRate) {
////        case 1000: CAN_InitStruct.CAN_Prescaler = 6;
////            break;
////        case 500: CAN_InitStruct.CAN_Prescaler = 12;
////            break;
////        default:
////        case 250: CAN_InitStruct.CAN_Prescaler = 24;
////            break;
////        case 125: CAN_InitStruct.CAN_Prescaler = 48;
////            break;
////        case 100: CAN_InitStruct.CAN_Prescaler = 60;
////            break;
////        case 50: CAN_InitStruct.CAN_Prescaler = 120;
////            break;
////        case 20: CAN_InitStruct.CAN_Prescaler = 300;
////            break;
////        case 10: CAN_InitStruct.CAN_Prescaler = 600;
////            break;
////    }
////#endif
////
//    
//    CAN_StructInit(&CAN_InitStruct);
//
//    /* CAN cell init */
//    CAN_InitStruct.CAN_TTCM = DISABLE; /* ʱ�䴥����ֹ, ʱ�䴥����CANӲ�����ڲ���ʱ����������ұ����ڲ���ʱ��� */
//    CAN_InitStruct.CAN_ABOM = DISABLE; /* �Զ����߽�ֹ���Զ����ߣ�һ��Ӳ����ص�128��11������λ�����Զ��˳�����״̬��������Ҫ�����趨������˳� */
//    CAN_InitStruct.CAN_AWUM = DISABLE; /* �Զ����ѽ�ֹ���б�������ʱ���Զ��˳�����	*/
//    CAN_InitStruct.CAN_NART = DISABLE; /* �����ش�, �������һֱ�����ɹ�ֹ������ֻ��һ�� */
//    CAN_InitStruct.CAN_RFLM = DISABLE; /* ����FIFO����, 1--��������յ��µı���ժ��Ҫ��0--���յ��µı����򸲸�ǰһ����	*/
//    CAN_InitStruct.CAN_TXFP = ENABLE;  /* �������ȼ�  0---�ɱ�ʶ������  1---�ɷ�������˳�����	*/
//    CAN_InitStruct.CAN_Mode = CAN_Mode_Normal; /* ģʽ	*/
//    
//
//    CAN_InitStruct.CAN_SJW=CAN_SJW_1tq;
//    CAN_InitStruct.CAN_BS1=CAN_BS1_8tq;
//    CAN_InitStruct.CAN_BS2=CAN_BS2_7tq;
//    CAN_InitStruct.CAN_Prescaler=9;        //�ҵ�ʱ����PLL 72M,��ôCANӦ����36M�˰�?��������36/((1+8+7)*9)=250K	
//
////    TRACE_DEBUG("CAN_Init ");
//    uint8_t result;
//    if ((result = CAN_Init(CANmodule->CANbaseAddress, &CAN_InitStruct)) != CAN_InitStatus_Success) {
////        TRACE_DEBUG_WP("res=%d\n\r", result);
//        return result;
//    }
//    // nastavime 1 filtr, ktery prijima vse
//    memset(&CAN_FilterInitStruct, 0, sizeof (CAN_FilterInitStruct));
//    
//    CAN_FilterInitStruct.CAN_FilterNumber = 0;     /* �������� */
//    CAN_FilterInitStruct.CAN_FilterMode = CAN_FilterMode_IdMask;//CAN_FilterMode_IdList;//CAN_FilterMode_IdMask;  /* ����ģʽ */
//    CAN_FilterInitStruct.CAN_FilterScale = CAN_FilterScale_32bit; /* 32λ */
//    CAN_FilterInitStruct.CAN_FilterIdHigh = 0;
//    CAN_FilterInitStruct.CAN_FilterIdLow = 0;
//    CAN_FilterInitStruct.CAN_FilterMaskIdHigh = 0x0000;
//    CAN_FilterInitStruct.CAN_FilterMaskIdLow = 0x0000;
//    CAN_FilterInitStruct.CAN_FilterFIFOAssignment = 0;  /* �ܹ�ͨ���ù������ı��Ĵ浽fifo0�� */
//    CAN_FilterInitStruct.CAN_FilterActivation = ENABLE;
// 
//    if (CANbaseAddress == CAN1)
//        CAN_FilterInit(&CAN_FilterInitStruct);
//    
//    if (CANbaseAddress == CAN2)
//    {
//        CAN_FilterInitStruct.CAN_FilterNumber = 14;     /* �������� */
//        CAN_FilterInit(&CAN_FilterInitStruct);
//    }
//    
//    
//    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
//    // povoleni preruseni od CAN1
//    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
//    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
//    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//
//    // Enable CAN1 RX interrupt
//    NVIC_InitStructure.NVIC_IRQChannel = CAN1_RX0_IRQn; // | CAN1_TX_IRQn;
//    NVIC_Init(&NVIC_InitStructure);
//
//    // Enable CAN1 TX interrupt
//    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
//    NVIC_InitStructure.NVIC_IRQChannel = CAN1_TX_IRQn;
//    NVIC_Init(&NVIC_InitStructure);
//    
//
//    // povoleni preruseni od CAN1
//    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
//    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
//    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//
//    // Enable CAN2 RX interrupt
//    NVIC_InitStructure.NVIC_IRQChannel = CAN2_RX0_IRQn; // | CAN2_TX_IRQn;
//    NVIC_Init(&NVIC_InitStructure);
//
//    // Enable CAN2 TX interrupt
//    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
//    NVIC_InitStructure.NVIC_IRQChannel = CAN2_TX_IRQn;
//    NVIC_Init(&NVIC_InitStructure);
//
//
//
//    CAN_OperatingModeRequest(CANmodule->CANbaseAddress, CAN_OperatingMode_Normal);
//
//    CO_CanInterruptEnDis(CANbaseAddress, ENABLE);
////    TRACE_DEBUG_WP("Ok\n\r");

    return CO_ERROR_NO;
}

/******************************************************************************/
void CO_CANmodule_disable(CO_CANmodule_t *CANmodule){
    CAN_DeInit(CANmodule->CANbaseAddress);
}

/******************************************************************************/
uint16_t CO_CANrxMsg_readIdent(const CO_CANrxMsg_t *rxMsg) {
    return (rxMsg->ident >> 2) & 0x7FF;
}

/******************************************************************************/
CO_ReturnError_t CO_CANrxBufferInit(
        CO_CANmodule_t         *CANmodule,
        uint16_t                index,
        uint16_t                ident,
        uint16_t                mask,
        int8_t                  rtr,
        void                   *object,
        void                  (*pFunct)(void *object, const CO_CANrxMsg_t *message)) {
    CO_CANrx_t *rxBuffer;
    uint16_t RXF, RXM;

    //safety
    if (!CANmodule || !object || !pFunct || index >= CANmodule->rxSize) {
        return CO_ERROR_ILLEGAL_ARGUMENT;
    }

    //buffer, which will be configured
    rxBuffer = CANmodule->rxArray + index;

    //Configure object variables
    rxBuffer->object = object;
    rxBuffer->pFunct = pFunct;


    //CAN identifier and CAN mask, bit aligned with CAN module registers
    RXF = (ident & 0x07FF) << 2;
    if (rtr) RXF |= 0x02;
    RXM = (mask & 0x07FF) << 2;
    RXM |= 0x02;

    //configure filter and mask
    if (RXF != rxBuffer->ident || RXM != rxBuffer->mask) {
        rxBuffer->ident = RXF;
        rxBuffer->mask = RXM;
    }

    return CO_ERROR_NO;
}

/******************************************************************************/
CO_CANtx_t *CO_CANtxBufferInit(
        CO_CANmodule_t         *CANmodule,
        uint16_t                index,
        uint16_t                ident,
        int8_t                  rtr,
        uint8_t                 noOfBytes,
        int8_t                  syncFlag) {
    //safety
    if (!CANmodule || CANmodule->txSize <= index) return 0;

    //get specific buffer
    CO_CANtx_t *buffer = &CANmodule->txArray[index];

    //CAN identifier, bit aligned with CAN module registers

    uint32_t TXF = 0;
    TXF = ident << (uint32_t)21;
    TXF &= 0xFFE00000;
    if (rtr) TXF |= 0x02;

    buffer->ident = TXF;

    //write to buffer
    buffer->DLC = noOfBytes;
    buffer->bufferFull = 0;
    buffer->syncFlag = syncFlag ? 1 : 0;

    return buffer;
}

int8_t getFreeTxBuff(CO_CANmodule_t *CANmodule) {
	uint8_t txBuff = 0;
	for (txBuff = 0; txBuff <= 3; txBuff++)
		//if (CAN_TransmitStatus(CANmodule->CANbaseAddress, txBuff) == CAN_TxStatus_Ok)
		switch (txBuff) {
		case (CAN_TXMAILBOX_0 ):
			if (CANmodule->CANbaseAddress->TSR & CAN_TSR_TME0 )
				return txBuff;
			else
				break;
		case (CAN_TXMAILBOX_1 ):
			if (CANmodule->CANbaseAddress->TSR & CAN_TSR_TME1 )
				return txBuff;
			else
				break;
		case (CAN_TXMAILBOX_2 ):
			if (CANmodule->CANbaseAddress->TSR & CAN_TSR_TME2 )
				return txBuff;
			else
				break;
		}
	return -1;
}

/******************************************************************************/
CO_ReturnError_t CO_CANsend(CO_CANmodule_t *CANmodule, CO_CANtx_t *buffer) {
    CO_ReturnError_t err = CO_ERROR_NO;
    
    GPIO_SetBits(GPIOE , GPIO_Pin_2);                           //LED for can send

    /* Verify overflow */
    if(buffer->bufferFull){
        if(!CANmodule->firstCANtxMessage)/* don't set error, if bootup message is still on buffers */
            CO_errorReport((CO_EM_t*)CANmodule->em, CO_EM_CAN_TX_OVERFLOW, CO_EMC_CAN_OVERRUN, 0);
        err = CO_ERROR_TX_OVERFLOW;
    }

    CO_DISABLE_INTERRUPTS();
    //if CAN TB buffer0 is free, copy message to it
    int8_t txBuff = getFreeTxBuff(CANmodule);
    //error change this - use only one buffer for transmission - see also transmit interrupt
    if(txBuff != -1){
        CANmodule->bufferInhibitFlag = buffer->syncFlag;
        CO_CANsendToModule(CANmodule, buffer, txBuff);
    }
    //if no buffer is free, message will be sent by interrupt
    else{
        buffer->bufferFull = 1;
        CANmodule->CANtxCount++;
        // vsechny buffery jsou plny, musime povolit preruseni od vysilace, odvysilat az v preruseni
        CAN_ITConfig(CANmodule->CANbaseAddress, CAN_IT_TME, ENABLE);
    }
    CO_ENABLE_INTERRUPTS();
    
    GPIO_ResetBits(GPIOE , GPIO_Pin_2);                 //LED display for can send

    return err;
}

/******************************************************************************/
void CO_CANclearPendingSyncPDOs(CO_CANmodule_t *CANmodule) {

    /* See generic driver for implemetation. */
}

/******************************************************************************/
void CO_CANverifyErrors(CO_CANmodule_t *CANmodule) {
   uint32_t err;
   CO_EM_t* em = (CO_EM_t*)CANmodule->em;

   err = CANmodule->CANbaseAddress->ESR;
   // if(CAN_REG(CANmodule->CANbaseAddress, C_INTF) & 4) err |= 0x80;

   if(CANmodule->errOld != err){
      CANmodule->errOld = err;

      //CAN RX bus overflow
      if(CANmodule->CANbaseAddress->RF0R & 0x08){
         CO_errorReport(em, CO_EM_CAN_RXB_OVERFLOW, CO_EMC_CAN_OVERRUN, err);
         CANmodule->CANbaseAddress->RF0R &=~0x08;//clear bits
      }

      //CAN TX bus off
      if(err & 0x04) CO_errorReport(em, CO_EM_CAN_TX_BUS_OFF, CO_EMC_BUS_OFF_RECOVERED, err);
      else           CO_errorReset(em, CO_EM_CAN_TX_BUS_OFF, err);

      //CAN TX or RX bus passive
      if(err & 0x02){
         if(!CANmodule->firstCANtxMessage) CO_errorReport(em, CO_EM_CAN_TX_BUS_PASSIVE, CO_EMC_CAN_PASSIVE, err);
      }
      else{
        CO_errorReset(em, CO_EM_CAN_TX_BUS_PASSIVE, err);
        CO_errorReset(em, CO_EM_CAN_TX_OVERFLOW, err);
      }


      //CAN TX or RX bus warning
      if(err & 0x01){
         CO_errorReport(em, CO_EM_CAN_BUS_WARNING, CO_EMC_NO_ERROR, err);
      }
      else{
         CO_errorReset(em, CO_EM_CAN_BUS_WARNING, err);
      }
   }
}

/******************************************************************************/
int CO_CANrecFromModule(CO_CANmodule_t *CANmodule, uint8_t FIFONumber, CO_CANrxMsg_t* RxMessage) {
    if( (CANmodule->CANbaseAddress->RF0R & CAN_RF0R_FMP0) > 0) {  // We really have something
        RxMessage->IDE = (uint8_t) 0x04 & CANmodule->CANbaseAddress->sFIFOMailBox[FIFONumber].RIR;
        if (RxMessage->IDE == CAN_Id_Standard) {
            RxMessage->ident = (uint32_t) 0x000007FF & (CANmodule->CANbaseAddress->sFIFOMailBox[FIFONumber].RIR >> 21);
        } else {
            RxMessage->ExtId = (uint32_t) 0x1FFFFFFF & (CANmodule->CANbaseAddress->sFIFOMailBox[FIFONumber].RIR >> 3);
        }

        RxMessage->RTR = (uint8_t) 0x02 & CANmodule->CANbaseAddress->sFIFOMailBox[FIFONumber].RIR;
        /* Get the DLC */
        RxMessage->DLC = (uint8_t) 0x0F & CANmodule->CANbaseAddress->sFIFOMailBox[FIFONumber].RDTR;
        /* Get the FMI */
        RxMessage->FMI = (uint8_t) 0xFF & (CANmodule->CANbaseAddress->sFIFOMailBox[FIFONumber].RDTR >> 8);
        /* Get the data field */
        RxMessage->data[0] = (uint8_t) 0xFF & CANmodule->CANbaseAddress->sFIFOMailBox[FIFONumber].RDLR;
        RxMessage->data[1] = (uint8_t) 0xFF & (CANmodule->CANbaseAddress->sFIFOMailBox[FIFONumber].RDLR >> 8);
        RxMessage->data[2] = (uint8_t) 0xFF & (CANmodule->CANbaseAddress->sFIFOMailBox[FIFONumber].RDLR >> 16);
        RxMessage->data[3] = (uint8_t) 0xFF & (CANmodule->CANbaseAddress->sFIFOMailBox[FIFONumber].RDLR >> 24);
        RxMessage->data[4] = (uint8_t) 0xFF & CANmodule->CANbaseAddress->sFIFOMailBox[FIFONumber].RDHR;
        RxMessage->data[5] = (uint8_t) 0xFF & (CANmodule->CANbaseAddress->sFIFOMailBox[FIFONumber].RDHR >> 8);
        RxMessage->data[6] = (uint8_t) 0xFF & (CANmodule->CANbaseAddress->sFIFOMailBox[FIFONumber].RDHR >> 16);
        RxMessage->data[7] = (uint8_t) 0xFF & (CANmodule->CANbaseAddress->sFIFOMailBox[FIFONumber].RDHR >> 24);
        /* Release the FIFO */
        /* Release FIFO0 */
        if (FIFONumber == CAN_FIFO0) {
            CANmodule->CANbaseAddress->RF0R |= CAN_RF0R_RFOM0;
        }/* Release FIFO1 */
        else /* FIFONumber == CAN_FIFO1 */ {
            CANmodule->CANbaseAddress->RF1R |= CAN_RF1R_RFOM1;
        }
        return 0;
    }
    return -1;
}

/******************************************************************************/
// Interrupt from Receiver
void CO_CANinterrupt_Rx(CO_CANmodule_t *CANmodule) {
    // Preruseni od prijmu
    CO_CANrxMsg_t rcvMsg;
    
    GPIO_SetBits(GPIOE , GPIO_Pin_3);           //Led display for can receive
    
    if (CO_CANrecFromModule(CANmodule, CAN_FIFO0, &rcvMsg) == 0) {
        //CAN module filters are not used, message with any standard 11-bit identifier
        //has been received. Search rxArray form CANmodule for the same CAN-ID.
        uint16_t index;
        uint8_t msgMatched = 0;
        CO_CANrx_t *msgBuff = CANmodule->rxArray;
        for (index = 0; index < CANmodule->rxSize; index++) {
            uint16_t msg = (rcvMsg.ident << 2) | (rcvMsg.RTR ? 2 : 0);
            if (((msg ^ msgBuff->ident) & msgBuff->mask) == 0) {
                msgMatched = 1;
                break;
            }
            msgBuff++;
        }
        //Call specific function, which will process the message
        if (msgMatched && msgBuff->pFunct)
            msgBuff->pFunct(msgBuff->object, &rcvMsg);
    }
    
    GPIO_ResetBits(GPIOE , GPIO_Pin_3);                 //Led display for can receive
}

/******************************************************************************/
// Interrupt from Transeiver
void CO_CANinterrupt_Tx(CO_CANmodule_t *CANmodule) {
    /* Clear interrupt flag */
    CAN_ITConfig(CANmodule->CANbaseAddress, CAN_IT_TME, DISABLE); // Transmit mailbox empty interrupt
    /* First CAN message (bootup) was sent successfully */
    CANmodule->firstCANtxMessage = 0;
    /* clear flag from previous message */
    CANmodule->bufferInhibitFlag = 0;
    /* Are there any new messages waiting to be send */
    if(CANmodule->CANtxCount > 0){
        uint16_t i;             /* index of transmitting message */

        /* first buffer */
        CO_CANtx_t *buffer = CANmodule->txArray;
        /* search through whole array of pointers to transmit message buffers. */
        for(i = CANmodule->txSize; i > 0; i--){
            /* if message buffer is full, send it. */
            if(buffer->bufferFull){
                buffer->bufferFull = 0;
                CANmodule->CANtxCount--;

                /* Copy message to CAN buffer */
                CANmodule->bufferInhibitFlag = buffer->syncFlag;
                //CO_CANsendToModule(CANmodule, buffer, txBuff);
                break;                      /* exit for loop */
            }
            buffer++;
        }/* end of for loop */

        /* Clear counter if no more messages */
        if(i == 0) CANmodule->CANtxCount = 0;
    }
}

/******************************************************************************/
void CO_CANinterrupt_Status(CO_CANmodule_t *CANmodule) {
  // status is evalved with pooling
}

/******************************************************************************/
void CO_CANsendToModule(CO_CANmodule_t *CANmodule, CO_CANtx_t *buffer, uint8_t transmit_mailbox) {
    if ((transmit_mailbox >= 0) & (transmit_mailbox <= 3)) {
        /* Set up the Id */
        CANmodule->CANbaseAddress->sTxMailBox[transmit_mailbox].TIR &= TMIDxR_TXRQ;
        // RTR is included in ident
        CANmodule->CANbaseAddress->sTxMailBox[transmit_mailbox].TIR |= buffer->ident;
        /* Set up the DLC */
        buffer->DLC &= (uint8_t) 0x0000000F;
        CANmodule->CANbaseAddress->sTxMailBox[transmit_mailbox].TDTR &= (uint32_t) 0xFFFFFFF0;
        CANmodule->CANbaseAddress->sTxMailBox[transmit_mailbox].TDTR |= buffer->DLC;

        /* Set up the data field */
        CANmodule->CANbaseAddress->sTxMailBox[transmit_mailbox].TDLR = (((uint32_t) buffer->data[3] << 24) |
                ((uint32_t) buffer->data[2] << 16) |
                ((uint32_t) buffer->data[1] << 8) |
                ((uint32_t) buffer->data[0]));
        CANmodule->CANbaseAddress->sTxMailBox[transmit_mailbox].TDHR = (((uint32_t) buffer->data[7] << 24) |
                ((uint32_t) buffer->data[6] << 16) |
                ((uint32_t) buffer->data[5] << 8) |
                ((uint32_t) buffer->data[4]));

        // Transmit mailbox empty interrupt
        CAN_ITConfig(CANmodule->CANbaseAddress, CAN_IT_TME, ENABLE);
        /* Request transmission */
        CANmodule->CANbaseAddress->sTxMailBox[transmit_mailbox].TIR |= TMIDxR_TXRQ;
    }
}
