#ifndef __CAN_H__
#define __CAN_H__

#include <rthw.h>
#include <rtthread.h>

void rt_hw_can_init(void);

#endif
