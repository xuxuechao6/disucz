#include "stm32f10x.h"
#include "rtthread.h"
#include "CANopen.h"
#include "key.h"


static unsigned int            Step = 0;
extern struct rt_event		Cyclic_100ms_Event;

/* Global variables */
volatile uint32_t CO_timer1ms = 0;
uint8_t canTimerOff = 1;

uint8_t DataBuf[50];

uint8_t *data = DataBuf;
uint8_t nodeId, sidx;
uint16_t idx;
uint32_t len;

int8_t ret;
uint16_t delay;

uint32_t dataLen = 8;

/* SDO clinet access */
uint32_t SDOabortCode = 0;

void CANOpen_FunctionTest();

void ClearWDT() {

}


void rt_canopen_thread_entry()
{
  
        //rt_uint32_t e;
        CO_NMT_reset_cmd_t reset = CO_RESET_NOT;
        
  while (reset != CO_RESET_APP) {
//        /* CANopen communication reset - initialize CANopen objects *******************/
        CO_ReturnError_t err;
        static uint32_t timer1msPrevious;
//
//        /* disable timer interrupts, turn on red LED */
        canTimerOff = 1;
        
//        /* start Timer */
        canTimerOff = 0;

        reset = CO_RESET_NOT;
        timer1msPrevious = CO_timer1ms;
        
        Step = 1000;

        //TRACE_INFO("CO (re)start\n\r");
        while (reset == CO_RESET_NOT) {
            //saveTime(&tprof);
            /* loop for normal program execution ******************************************/
            uint32_t timer1msDiff;
            
            timer1msDiff = CO_timer1ms - timer1msPrevious;
            timer1msPrevious = CO_timer1ms;
            
            ClearWDT();

            /* CANopen process */
            //GPIO_SetBits(GPIOE , GPIO_Pin_4);
            
            reset = CO_process(CO, timer1msDiff);
            
            //GPIO_ResetBits(GPIOE , GPIO_Pin_4);

            //CanLedsSet((LED_GREEN_RUN(CO->NMT)>0 ? eCoLed_Green : 0) | (LED_RED_ERROR(CO->NMT)>0 ? eCoLed_Red : 0));
            
            CANOpen_FunctionTest();

            ClearWDT();
            
                    
            rt_thread_delay(1000);            

        } /*  while (reset != 0) */
        

    } /*  while (reset != 2) */
    /* program exit ***************************************************************/
    /* save variables to eeprom */
    //CO_DISABLE_INTERRUPTS();

    //CanLedsSet(eCoLed_None);
    /* (not implemented) eeprom_saveAll(&eeprom); */
    //CanLedsSet(eCoLed_Red);
    /* delete CANopen object from memory */
    //CO_delete();
             
}

void CANOpen_FunctionTest()
{
      extern CO_t *CO;
      CO_SDOclient_t *SDO_C = CO->SDOclient;

  
      switch(Step)
      {
        case 1000:
          if (Key_Value() == KEY4_VALUE)
              Step = 2000;
          break;
          
        case 2000:
          CO_sendNMTcommand(CO,0x01,0x00); 
          nodeId = 0x01;
          idx = 0x6083;
          sidx = 0;
          len = 50;
          Step = 3000;
        break;
        
        case 3000:
          CO_SDOclient_setup(SDO_C, 0, 0, nodeId);
          CO_SDOclientUploadInitiate(SDO_C, idx, sidx, &DataBuf[0], len, 0);
          Step = 4000;
        break;
        
        case 4000:
          ret = 0;
          ret = CO_SDOclientUpload(SDO_C, 10, 500, &dataLen, &SDOabortCode);
          delay = 0;
          Step = 4500;
        break;
        
        case 4500:
          if ((delay > 10)||(ret > 0))
          {
              Step = 5000;
          }
          else
          {
              delay ++;
          }
        break;
        
      case 5000:
        Step = 1000;
        
        break;
      }
            

}

/* timer interrupt function executes every millisecond ************************/
void CO_TIMER_ISR() {
  
  //GPIO_SetBits(GPIOE , GPIO_Pin_4);
    CO_timer1ms++;

    CO_process_RPDO(CO);
    /*  TODO: zpracovani RPDO dat */

    /*  TODO: priprava dat pro TPDO */
    CO_process_TPDO(CO);
    
  //GPIO_ResetBits(GPIOE , GPIO_Pin_4);

}

void CO_Period_Process()
{
    if (!canTimerOff)
        CO_TIMER_ISR();
}