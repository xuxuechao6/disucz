#include <rtthread.h>

/* Timer Object Define */
#define  Time_Tick_100ms         10000             //1 tick = 100us
#define  Time_Tick_1ms           10             //1 tick = 100us

void cyctimer_static_init();