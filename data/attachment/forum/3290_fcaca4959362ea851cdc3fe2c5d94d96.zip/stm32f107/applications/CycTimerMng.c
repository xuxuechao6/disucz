#include <CycTimerMng.h>

static rt_timer_t          timer100ms;
static rt_timer_t          timer1ms;

extern struct rt_event		Cyclic_100ms_Event;
extern void CO_Period_Process();

void timeout100ms(void *parameter)
{
      rt_event_send(&Cyclic_100ms_Event, (1 << 1));
      rt_event_send(&Cyclic_100ms_Event, (1 << 2));
}

void timeout1ms(void *parameter)
{
      CO_Period_Process();
}


void cyctimer_static_init()
{
      
      timer100ms = rt_timer_create(
                                   "timer_100ms",
                                   timeout100ms,
                                   RT_NULL,
                                   Time_Tick_100ms,
                                   RT_TIMER_FLAG_PERIODIC
                                   );
      
      if (timer100ms != RT_NULL)
          rt_timer_start(timer100ms);
      
      timer1ms = rt_timer_create(
                                   "timer_1ms",
                                   timeout1ms,
                                   RT_NULL,
                                   Time_Tick_1ms,
                                   RT_TIMER_FLAG_PERIODIC
                                   );
      
      if (timer1ms != RT_NULL)
          rt_timer_start(timer1ms);
      
}