#include "stm32f10x.h"
#include "rtthread.h"
#include "math.h"

static unsigned char            LED1_Sta;
extern struct rt_event		Cyclic_100ms_Event;

int     i,j,cycle;

void rt_led_thread_entry()
{
//	rt_device_t device;
//	CanRxMsg	buffer;
//
//	
//	device = rt_device_find("can1");
//	
//	if (device != RT_NULL)
//	{
//          rt_device_open(device, RT_DEVICE_OFLAG_RDWR);
//	}	
        
        rt_uint32_t e;
        
        LED1_Sta = 0;
  
	while(1)
	{
          
              if (rt_event_recv(&Cyclic_100ms_Event, (1 << 1),
              RT_EVENT_FLAG_OR | RT_EVENT_FLAG_CLEAR,
              RT_WAITING_FOREVER, &e) == RT_EOK)
              {
              
                    if (LED1_Sta == 0)
                    {
//                        GPIO_SetBits(GPIOE , GPIO_Pin_2);
//                        GPIO_SetBits(GPIOE , GPIO_Pin_3);
//                        GPIO_SetBits(GPIOE , GPIO_Pin_4);
                        GPIO_SetBits(GPIOE , GPIO_Pin_5); 
                        LED1_Sta = 1;
                    }
                    else
                    {
//                        GPIO_ResetBits(GPIOE , GPIO_Pin_2);
//                        GPIO_ResetBits(GPIOE , GPIO_Pin_3);
//                        GPIO_ResetBits(GPIOE , GPIO_Pin_4);
                        GPIO_ResetBits(GPIOE , GPIO_Pin_5); 
                        LED1_Sta = 0;
                    }
                    
              
              }
              

       
          
//		if (device != RT_NULL)
//		{		
//			rt_device_write(device, 0, &buffer, sizeof(buffer));
//		}

	}

}
