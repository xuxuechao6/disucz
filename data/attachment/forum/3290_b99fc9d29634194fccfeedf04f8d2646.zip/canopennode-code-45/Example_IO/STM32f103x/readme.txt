Simple example for stm32f103 microcontroler.
