#include <rtthread.h>
#include "board.h"

#ifdef RT_USING_FINSH
#include <finsh.h>

static void list_msp(void)
{
#ifdef __CC_ARM                         /* ARM Compiler */
#   ifdef __MICROLIB
    extern int __initial_sp;
    extern int __stack_base;

    uint32_t stack_size, stack_bottom, stack_top;
    const uint32_t * ptr;

    stack_bottom = (uint32_t)&__stack_base;
    stack_top = (uint32_t)&__initial_sp;
    stack_size = stack_top - stack_bottom;
#else
#   include <rt_misc.h>

    uint32_t stack_size, stack_bottom, stack_top;
    const uint32_t * ptr;
    struct __initial_stackheap stackheap;

    stackheap = __user_initial_stackheap(0, 0, 0, 0);

    stack_top = stackheap.stack_base;
    stack_bottom = stackheap.stack_limit;
    stack_size = stack_top - stack_bottom;
#endif /* __MICROLIB */

    ptr = (const uint32_t *)stack_bottom;

    while (*ptr == 0x00000000)
    {
        ptr ++;
    }
    rt_kprintf("stack bottom: 0x%08X, size: 0x%04X, used: 0x%04X.\r\n",
    stack_bottom,
    stack_size,
    stack_top - (uint32_t)ptr
              );

#elif defined (__IAR_SYSTEMS_ICC__)     /* for IAR Compiler */
#elif defined (__GNUC__)                /* GNU GCC Compiler */
    uint32_t stack_size, stack_bottom, stack_top;
    const uint8_t * ptr;
    {
        extern int _estack;
        extern int _system_stack_size;
        stack_top  = (uint32_t)(&_estack);
        stack_size = (uint32_t)(&_system_stack_size);
        stack_bottom = stack_top - stack_size;
    }

    ptr = (const uint8_t *)stack_bottom;

    while (*ptr == '#')
    {
        ptr ++;
    }
    rt_kprintf("stack bottom: 0x%08X, size: 0x%04X, used: 0x%04X.\r\n",
               stack_bottom,
               stack_size,
               stack_top - (uint32_t)ptr
              );
#endif
}
FINSH_FUNCTION_EXPORT(list_msp, list msp);

#endif /* RT_USING_FINSH */
