/*
 * File      : board.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2006 - 2009 RT-Thread Develop Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://www.rt-thread.org/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2006-08-23     Bernard      first implementation
 */

#include <rthw.h>
#include <serial.h>
#include <rtthread.h>

#include "stm32f10x.h"
#include "board.h"

/*@{*/

/**
  *-------------------------------------------------------------/
  * @brief  ��������RCC_Configuration
            ��  �ܣ�����ϵͳʱ��
  * @param  ��  ������
  * @retval ����ֵ����
  */
void RCC_Configuration(void)
{
  /* ʹ��FSMC��FSMC�ܽ�ʱ�� */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD | RCC_APB2Periph_GPIOE, ENABLE);
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_FSMC, ENABLE);

  /* Enable USART1 and GPIOA clocks */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_GPIOA, ENABLE);

  /* ʹ��DMA1ʱ�� */
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

  /* ʹ��GPIOCʱ�� */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
}

/**
  *-------------------------------------------------------------/
  * @brief  ��������GPIO_Configuration
            ��  �ܣ�����ϵͳ�ܽ�
  * @param  ��  ������
  * @retval ����ֵ����
  */
void GPIO_Configuration(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;

  /* GPIO For the LCD_Bus */	
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14  //D0
                              | GPIO_Pin_15  //D1
                              | GPIO_Pin_0   //D2
                              | GPIO_Pin_1   //D3
                              | GPIO_Pin_8 	 //D13
                              | GPIO_Pin_9   //D14
                              | GPIO_Pin_10  //D15  		
                              | GPIO_Pin_7   //NE1 CS
                              | GPIO_Pin_11  //RS
                              | GPIO_Pin_4   //nRD OE
                              | GPIO_Pin_5;  //nWE
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOD, &GPIO_InitStructure);

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7   //D4
                              | GPIO_Pin_8   //D5
                              | GPIO_Pin_9   //D6
                              | GPIO_Pin_10  //D7
                              | GPIO_Pin_11  //D8
                              | GPIO_Pin_12  //D9
                              | GPIO_Pin_13  //D10
                              | GPIO_Pin_14  //D11
                              | GPIO_Pin_15; //D12  												
  GPIO_Init(GPIOE, &GPIO_InitStructure);

  /* Configure USART1 Tx (PA.09) as alternate function push-pull */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOA, &GPIO_InitStructure);

  /* Configure USART1 Rx (PA.10) as input floating */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOA, &GPIO_InitStructure);

  /* ʹ��PC13��� */
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
  GPIO_Init(GPIOC, &GPIO_InitStructure);
}

/**
  *-------------------------------------------------------------/
  * @brief  ��������USART_Configuration
            ��  �ܣ����ô���
  * @param  ��  ������
  * @retval ����ֵ����
  */
void USART_Configuration(void)
{
  USART_InitTypeDef USART_InitStructure;

  /* ��Ĭ��ֵ��ʼ�� */
  USART_StructInit(&USART_InitStructure);
  USART_Init(USART1, &USART_InitStructure);

  /* ʹ�ý����ж� */
  USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);

  USART_Cmd(USART1, ENABLE);
}

/**
  *-------------------------------------------------------------/
  * @brief  ��������NVIC_Configuration
            ��  �ܣ��ж����ȼ�����
  * @param  ��  ������
  * @retval ����ֵ����
  */
void NVIC_Configuration(void)
{
  NVIC_InitTypeDef NVIC_InitStructure;

#ifdef  VECT_TAB_RAM  
  /* Set the Vector Table base location at 0x20000000 */ 
  NVIC_SetVectorTable(NVIC_VectTab_RAM, 0x0);
#else  /* VECT_TAB_FLASH  */
  /* Set the Vector Table base location at 0x08000000 */ 
  NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0);
#endif

  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);

  /* Enable the USART1 Interrupt */
  NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
}

/*
 * Use UART1 as console output and finsh input
 * interrupt Rx and poll Tx (stream mode)
 */
struct rt_device uart1_device;
struct stm32_serial_int_rx uart1_int_rx;
struct stm32_serial_device uart1 =
{
  USART1,
  &uart1_int_rx,
  RT_NULL
};

/*
 * Init all related hardware in here
 * rt_hw_serial_init() will register all supported USART device
 */
void rt_hw_usart_init()
{
  USART_InitTypeDef USART_InitStructure;

  /* ��Ĭ��ֵ��ʼ�� */
  USART_StructInit(&USART_InitStructure);
  USART_Init(USART1, &USART_InitStructure);

  /* register uart1 */
  rt_hw_serial_register(&uart1_device, "uart1",
    RT_DEVICE_FLAG_RDWR | RT_DEVICE_FLAG_INT_RX | RT_DEVICE_FLAG_STREAM,
    &uart1);

  /* enable interrupt */
  USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
  USART_Cmd(USART1, ENABLE);
}

/**
 * This is the timer interrupt service routine.
 *
 */
void rt_hw_timer_handler(void)
{
    /* enter interrupt */
    rt_interrupt_enter();

    rt_tick_increase();

    /* leave interrupt */
    rt_interrupt_leave();
}

/**
  *-------------------------------------------------------------/
  * @brief  rt_hw_board_init.
  * Ӳ����ʼ��.
  * @param  None
  * @retval None
  */
extern void ILI9325_Configuration(void);
extern void FSMC_Configuration(void);
void rt_hw_board_init(void)
{
  SystemInit();
  RCC_Configuration();
  GPIO_Configuration();
  USART_Configuration();
  NVIC_Configuration();
  FSMC_Configuration();
  ILI9325_Configuration();

  /* ����systick��Ƶ�� */
  /* SystemCoreClockΪϵͳ��ʱ�� �ɿ����ṩ,��system_stm32f10x.c�� */
  /* RT_TICK_PER_SECOND Ϊϵͳ����,��rtconfig.h�ж��� */
  SysTick_Config(SystemCoreClock / RT_TICK_PER_SECOND);

  /*  ��ʼ������ */
  rt_hw_usart_init();
  rt_console_set_device("uart1");
  rt_kprintf("\r\n\r\nSystemInit......\r\n");
}

/*@}*/
