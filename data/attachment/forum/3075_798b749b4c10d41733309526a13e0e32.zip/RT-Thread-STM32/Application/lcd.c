/*
 * File      : lcd.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2006 - 2009 RT-Thread Develop Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://www.rt-thread.org/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2006-08-23     Bernard      first implementation
 */

#include "stm32f10x.h"
#include "rtthread.h"

#include <rtgui.h>
#include <driver.h>
#include <rtgui_server.h>
#include <rtgui_system.h>

#include "LCD_ILI9325.h"


rt_err_t rt_hw_lcd_init(void);
void rt_hw_lcd_update(rtgui_rect_t *rect);
rt_uint8_t * rt_hw_lcd_get_framebuffer(void);
void rt_hw_lcd_set_pixel(rtgui_color_t *c, rt_base_t x, rt_base_t y);
void rt_hw_lcd_get_pixel(rtgui_color_t *c, rt_base_t x, rt_base_t y);
void rt_hw_lcd_draw_hline(rtgui_color_t *c, rt_base_t x1, rt_base_t x2, rt_base_t y);
void rt_hw_lcd_draw_vline(rtgui_color_t *c, rt_base_t x, rt_base_t y1, rt_base_t y2);
void rt_hw_lcd_draw_raw_hline(rt_uint8_t *pixels, rt_base_t x1, rt_base_t x2, rt_base_t y);

struct rtgui_graphic_driver _rtgui_lcd_driver =
{
    "lcd",
    2,
    240,
    320,
    rt_hw_lcd_update,
    rt_hw_lcd_get_framebuffer,
    rt_hw_lcd_set_pixel,
    rt_hw_lcd_get_pixel,
    rt_hw_lcd_draw_hline,
    rt_hw_lcd_draw_vline,
    rt_hw_lcd_draw_raw_hline
};


void rt_hw_lcd_update(rtgui_rect_t *rect)
{
  /* nothing for none-DMA mode driver */
}

rt_uint8_t * rt_hw_lcd_get_framebuffer(void)
{
  return RT_NULL; /* no framebuffer driver */
}

/*  �������ص� ��ɫ,X,Y */
void rt_hw_lcd_set_pixel(rtgui_color_t *c, rt_base_t x, rt_base_t y)
{
  uint16_t p;

  /* get color pixel */
  p = rtgui_color_to_565p(*c);
  LCD_SetCursor(x, y);
  LCD_WriteData(p);
}

/* ��ȡ���ص���ɫ */
void rt_hw_lcd_get_pixel(rtgui_color_t *c, rt_base_t x, rt_base_t y)
{
  uint16_t p;
  p = LCD_BGR2RGB(LCD_ReadGRAM(x, y));
  *c = rtgui_color_from_565p(p);
}

/* ��ˮƽ�� */
void rt_hw_lcd_draw_hline(rtgui_color_t *c, rt_base_t x1, rt_base_t x2, rt_base_t y)
{
  uint16_t p;

  /* get color pixel */
  p = rtgui_color_to_565p(*c);

  /* [5:4]-ID~ID0 [3]-AM-1��ֱ-0ˮƽ */
  LCD_WriteReg(0x0003, 0x1030);

  LCD_SetCursor(x1, y);
  LCD_WriteData_Prepare(); /* Prepare to write GRAM */
  while(x1 < x2)
  {
    LCD_WriteRAM(p);
    x1++;
  }
}

/* ��ֱ�� */
void rt_hw_lcd_draw_vline(rtgui_color_t *c, rt_base_t x, rt_base_t y1, rt_base_t y2)
{
  uint16_t p;

  /* get color pixel */
  p = rtgui_color_to_565p(*c);

  /* [5:4]-ID~ID0 [3]-AM-1��ֱ-0ˮƽ */
  LCD_WriteReg(0x0003, 0x1030);

  LCD_SetCursor(x, y1);
  LCD_WriteData_Prepare(); /* Prepare to write GRAM */
  while(y1 < y2)
  {
    LCD_WriteRAM(p);
    y1++;
  }
}

/* ?? */
void rt_hw_lcd_draw_raw_hline(rt_uint8_t *pixels, rt_base_t x1, rt_base_t x2, rt_base_t y)
{
  rt_uint16_t *ptr;

  /* get pixel */
  ptr = (rt_uint16_t*) pixels;

  /* [5:4]-ID~ID0 [3]-AM-1��ֱ-0ˮƽ */
  LCD_WriteReg(0x0003, 0x1030);

  LCD_SetCursor(x1, y);
  LCD_WriteData_Prepare(); /* Prepare to write GRAM */
  while (x1 < x2)
  {
    LCD_WriteRAM(*ptr);
    x1++;
    ptr++;
  }
}

rt_err_t rt_hw_lcd_init(void)
{
  /* add lcd driver into graphic driver */
  rtgui_graphic_driver_add(&_rtgui_lcd_driver);

  return RT_EOK;
}

void rtgui_entry(void* parameter)
{
  rtgui_rect_t rect;

  /* ��ʼ��RT-Thread/GUI server */
  rtgui_system_server_init();

  /* ע�����1 */
  rect.x1 = 0;
  rect.y1 = 0;
  rect.x2 = 240;
  rect.y2 = 24;
  /* ע������, ���֣��Լ�λ�� */
  rtgui_panel_register("info", &rect);

  /* ע�����2 */
  rect.x1 = 0;
  rect.y1 = 24;
  rect.x2 = 240;
  rect.y2 = 320;
  /* ע������, ���֣��Լ�λ�� */
  rtgui_panel_register("main", &rect);
  rtgui_panel_set_default_focused("main");

  /* ��ʼ��LCD���� */
  rt_hw_lcd_init();
}

void rtgui_init(void)
{
  rt_thread_t tid;

  tid = rt_thread_create("panel_wb", rtgui_entry, RT_NULL, 4096, 18, 5);
  if (tid != RT_NULL) rt_thread_startup(tid);
}


/**
  * @}
  */

/******************* (C) COPYRIGHT 2010 STMicroelectronics *****END OF FILE****/
