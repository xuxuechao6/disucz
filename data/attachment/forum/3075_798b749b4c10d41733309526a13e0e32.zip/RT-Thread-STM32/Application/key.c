/*
 * File      : key.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2006, RT-Thread Development Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://www.rt-thread.org/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2009-01-05     Bernard      the first version
 */

/**
 * @addtogroup STM32
 */
/*@{*/

#include "stm32f10x.h"
#include <rtthread.h>
#include <event.h>
#include <rtgui_server.h>

#define key_left_GETVALUE() GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_3)
#define key_right_GETVALUE() GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_4)
#define key_down_GETVALUE() GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0)
#define key_up_GETVALUE() GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_1)
#define key_enter_GETVALUE() GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_2)

static void GPIO_Configuration(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IPU;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4;
    GPIO_Init(GPIOA,&GPIO_InitStructure);
}

static void key_thread_entry(void *parameter)
{
    rt_time_t next_delay;
    struct rtgui_event_kbd kbd_event;
    GPIO_Configuration();

    /* init keyboard event */
    RTGUI_EVENT_KBD_INIT(&kbd_event);
    kbd_event.mod  = RTGUI_KMOD_NONE;
    kbd_event.unicode = 0;

    while (1)
    {
        next_delay = RT_TICK_PER_SECOND/10;
        kbd_event.key = RTGUIK_UNKNOWN;
        kbd_event.type = RTGUI_KEYDOWN;

        if(key_left_GETVALUE() == 0)
        {
            // rt_kprintf("key_down\n");
            kbd_event.key  = RTGUIK_LEFT;
        }

        if(key_right_GETVALUE() == 0)
        {
            // rt_kprintf("key_down\n");
            kbd_event.key  = RTGUIK_RIGHT;
        }


        if(key_down_GETVALUE() == 0)
        {
            // rt_kprintf("key_down\n");
            kbd_event.key  = RTGUIK_DOWN;
        }

        if ( key_up_GETVALUE() == 0 )
        {
            // rt_kprintf("key_up\n");
            kbd_event.key = RTGUIK_UP;
        }

    if(key_enter_GETVALUE() == 0)
    {
      kbd_event.key = RTGUIK_RETURN;
    }

        if (kbd_event.key != RTGUIK_UNKNOWN)
        {
            /* post down event */
            rtgui_server_post_event(&(kbd_event.parent), sizeof(kbd_event));

            //next_delay = RT_TICK_PER_SECOND/10;
            /* delay to post up event */
            rt_thread_delay(next_delay);

            /* post up event */
            kbd_event.type = RTGUI_KEYUP;
            rtgui_server_post_event(&(kbd_event.parent), sizeof(kbd_event));
        }

        /* wait next key press */
        rt_thread_delay(next_delay);
    }
}

static rt_thread_t key_tid;
void rt_hw_key_init(void)
{
  key_tid = rt_thread_create("key", key_thread_entry, RT_NULL, 384, 30, 5);
  if(key_tid != RT_NULL) rt_thread_startup(key_tid);
}

/*@}*/
