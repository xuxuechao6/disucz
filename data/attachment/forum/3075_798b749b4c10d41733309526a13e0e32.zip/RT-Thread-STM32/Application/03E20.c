#include <rtgui.h>
#include <rtgui_system.h>
#include <view.h>
#include <list_view.h>
#include <workbench.h>

static struct rtgui_list_view* function_view = RT_NULL;
static rtgui_workbench_t* father_workbench = RT_NULL;

static void function_action_return(void* paramter)
{
  rtgui_workbench_remove_view(father_workbench, RTGUI_VIEW(function_view));
  rtgui_view_destroy(RTGUI_VIEW(function_view));
  function_view = RT_NULL;
}

static void function_action(void* parameter) 
{ 
  return; 
}

static const struct rtgui_list_item function_list[] =
{
  {"��ⷽλ���", RT_NULL, function_action, RT_NULL},
  {"��⸩�����", RT_NULL, function_action, RT_NULL},
  {"���������", RT_NULL, function_action, RT_NULL},
  {"����Դ���", RT_NULL, function_action, RT_NULL},
  {"�����ϼ��˵�", RT_NULL, function_action_return, RT_NULL},
};

void tuoluo_ui(rtgui_workbench_t* workbench)
{
  rtgui_rect_t rect;

  father_workbench = workbench;

  /* add function view */
  rtgui_widget_get_rect(RTGUI_WIDGET(workbench), &rect);
  function_view = rtgui_list_view_create(function_list, 5, &rect, RTGUI_LIST_VIEW_LIST);
  rtgui_workbench_add_view(father_workbench, RTGUI_VIEW(function_view));
  rtgui_view_show(RTGUI_VIEW(function_view), RT_FALSE);
}
