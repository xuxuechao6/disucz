/*
 * File      : led.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2009, RT-Thread Development Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://www.rt-thread.org/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2009-01-05     Bernard      the first version
 */

#include <rtthread.h>
#include <stm32f10x.h>

static void led_entry(void* parameter)
{
  while(1)
  {
    /* led1 on */
    GPIO_ResetBits(GPIOC, GPIO_Pin_13);
    rt_thread_delay(50);

    /* led1 off */
    GPIO_SetBits(GPIOC, GPIO_Pin_13);
    rt_thread_delay(50);
  }
}

int led_init(void)
{
  rt_thread_t thread_led;
								   
  /* create led1 thread */
  thread_led = rt_thread_create("led", led_entry, RT_NULL, 256, 20, 5);
  if(thread_led != RT_NULL) rt_thread_startup(thread_led);

  return 0;
}

/*@}*/
