/**
****************** (C) COPYRIGHT 2011 STMicroelectronics ********************
* File Name          : lcd_9325.h
* Author             : MCD Application Team
* Version            : V1.1
* Date               : 02/26/2011
* Description        : This file contains all the functions prototypes for the
*                      lcd firmware driver.
********************************************************************************
*/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef LCD_ILI9325_H_INCLUDED
#define LCD_ILI9325_H_INCLUDED

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"

/* LCD color */
#define White          0xFFFF
#define Black          0x0000
#define Grey           0xF7DE
#define Blue           0x001F
#define Blue2          0x051F
#define Red            0xF800
#define Magenta        0xF81F
#define Green          0x07E0
#define Cyan           0x7FFF
#define Yellow         0xFFE0

/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
void FSMC_Configuration(void);
void ILI9325_Configuration(void);
void LCD_SetCursor(uint16_t x,uint16_t y);
void LCD_Clear(uint16_t Color);

uint16_t LCD_BGR2RGB(uint16_t c);

void LCD_WriteReg(uint16_t LCD_Reg, uint16_t LCD_RegValue);
void LCD_WriteData_Prepare(void);
void LCD_WriteData(uint16_t DataVal);
void LCD_WriteRAM(uint16_t DataVal);
uint16_t LCD_ReadReg(uint16_t LCD_Reg);
uint16_t LCD_ReadGRAM(uint16_t x,uint16_t y);

void LCD_SetPoint(uint16_t x, uint16_t y, uint16_t point);
void Lcd_DrawPic(void);

void LCD_DrawACSiichar(uint16_t Xpos, uint16_t Ypos, uint8_t TXT, uint16_t charColor, uint16_t bkColor);
void LCD_DrawACSiistring(uint16_t XLine, uint16_t Ycolumn, uint8_t *ptr, uint16_t charColor, uint16_t bkColor);
void LCD_DrawHZK16word(uint16_t x, uint16_t y, uint8_t *single_hz, uint16_t charColor, uint16_t bkColor);
void LCD_DrawHZK16string(uint16_t x, uint16_t y, uint8_t *string, uint16_t charColor, uint16_t bkColor);

/* If LCD Display in wrong dirction uncomment this option*/
//#define _ILI_REVERSE_DIRECTION_

/* LCD is connected to the FSMC_Bank1_NOR/SRAM1 and NE1 is used as ship select signal */
/* RS <==> A2 */
#define LCD_Reg_Addr     ((uint32_t)0x60000000)
#define LCD_Data_Addr    ((uint32_t)0x60020000)

#endif

/******************* (C) COPYRIGHT 2007 STMicroelectronics *****END OF FILE****/

