#ifndef __STDDEF_H__
#define __STDDEF_H__

#endif
