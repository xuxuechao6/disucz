/**
 * author: shauew
 * 2017-12-28 00:50:42
 */


#include <stdio.h>
#include <stdlib.h>
#include "diag/Trace.h"

#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"

//��ӳ�䴮��1��rt_kprintf
void rt_hw_console_output(const char *str)
{
    /* empty console output */

    rt_enter_critical();

    while(*str!='\0')
    {
        if(*str=='\n')
        {
            USART_SendData(USART1, '\r');
            while(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
        }
        USART_SendData(USART1, *str++);
        while(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
    }

    rt_exit_critical();
}

int main(void)
{
    rt_kprintf("System clock: %u Hz\n", SystemCoreClock);

    // Infinite loop
    while (1) {

        LED1=~LED1;
        delay_ms(500);
        LED1=~LED1;
        delay_ms(500);

        rt_kprintf("still alive!\r\n");
    }
  // Infinite loop, never return.
}

/* end of file */
