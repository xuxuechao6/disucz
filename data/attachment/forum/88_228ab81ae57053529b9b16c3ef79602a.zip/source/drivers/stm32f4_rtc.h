#ifndef __STM32F4_RTC_H__
#define __STM32F4_RTC_H__

void rt_hw_rtc_init(void);

#endif /* __STM32F4_RTC_H__ */
