/*
 * File      : application.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2006 - 2013, RT-Thread Development Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://www.rt-thread.org/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2009-01-05     Bernard      the first version
 */

/**
 * @addtogroup STM32
 */
/*@{*/

#include <rtthread.h>

#ifdef RT_USING_DFS
#include <dfs_fs.h>
#endif

#ifdef RT_USING_COMPONENTS_INIT
#include <components.h>
#endif /* RT_USING_COMPONENTS_INIT */

#include "board.h"
#include "led.h"


static struct rt_thread g_init_thread;

ALIGN(4)
static rt_uint8_t g_init_thread_stack[2048];

void rt_init_thread_entry(void* parameter)
{
	while(1)
	{
		rt_hw_led_off(0);
		rt_kprintf("led off \n");
		rt_thread_delay(50);		
		rt_hw_led_on(0);
		rt_kprintf("led on \n");
		rt_thread_delay(50);
	}
}

void Delay()
{
	int i = 0;
	for(;i<0xfffff;i++)
	{;}
}

int rt_application_init(void)
{
    rt_thread_t init_thread;
	  rt_err_t    result;
	
	 /* int i = 10;
		while(i--)
		{
			rt_hw_led_off(0);
			rt_kprintf("led off \n");
			Delay();
			rt_hw_led_on(0);
			rt_kprintf("led on \n");
			Delay();
    }*/
		

		result = rt_thread_init(&g_init_thread,
                "init",
                rt_init_thread_entry, RT_NULL,
                &g_init_thread_stack[0], sizeof(g_init_thread_stack),
                1,20);
    
		if (result == RT_EOK)
		{
			result = rt_thread_startup(&g_init_thread);
			if (result == RT_EOK)
				rt_kprintf("start init_thread failed \n");
   	}
    	/*rt_thread_init(&thread_led,
                   "led",
                   rt_thread_entry_led,
                   RT_NULL,
                   &thread_led_stack[0],
                   sizeof(thread_led_stack),11,20);		
		*/

    return 0;
}

/*@}*/
