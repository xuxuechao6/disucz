/*
* File      : led.c
* This file is part of RT-Thread RTOS
* COPYRIGHT (C) 2009, RT-Thread Development Team
*
* The license and distribution terms for this file may be
* found in the file LICENSE in this distribution or at
* http://www.rt-thread.org/license/LICENSE
*
* Change Logs:
* Date           Author       Notes
* 2009-01-05     Bernard      the first version
*/
#include <rtthread.h>
#include <stm32f10x.h>

#define led1_rcc                    RCC_APB2Periph_GPIOE
#define led1_gpio                   GPIOE
#define led1_pin                    (GPIO_Pin_8)

#define led2_rcc                    RCC_APB2Periph_GPIOE
#define led2_gpio                   GPIOE
#define led2_pin                    (GPIO_Pin_9)

void rt_hw_led_init(void)
{
  /* Setup GPIO for LEDs                                                     */
  RCC->APB2ENR |=  1 <<  6;                 /* Enable GPIOE clock            */
  GPIOE->CRH    = 0x33333333;               /* Configure the GPIO for LEDs   */
}

void rt_hw_led_off(rt_uint32_t n)
{
	switch (n)
	{
	case 0:
		GPIO_SetBits(led1_gpio, led1_pin);
		break;
	case 1:
		GPIO_SetBits(led2_gpio, led2_pin);
		break;
	default:
		break;
	}
}

void rt_hw_led_on(rt_uint32_t n)
{
	switch (n)
	{
	case 0:
		GPIO_ResetBits(led1_gpio, led1_pin);
		break;
	case 1:
		GPIO_ResetBits(led2_gpio, led2_pin);
		break;
	default:
		break;
	}
}






void led_toggle(rt_uint32_t n)
{
	switch (n)
	{
	case 0:
		GPIO_WriteBit(led1_gpio, led1_pin, (BitAction)((GPIO_ReadOutputDataBit(led1_gpio,led1_pin))^1) );
		
		break;
	case 1:
		GPIO_WriteBit(led2_gpio, led2_pin, (BitAction)((GPIO_ReadOutputDataBit(led2_gpio,led2_pin))^1) );
		break;
	default:
		break;
	}

}
void rt_led_disp_thread_entry(void* parameter)
{
	rt_uint32_t i=0;
	while(1)
	{
		i=0x50000;

		do{
		i--;
		}while(i>0);

		led_toggle(0);
		i=0x50000;

		do{
		i--;
		}while(i>0);
		led_toggle(1);
		
	}
}

void rt_led_disp_init(void)
{
	rt_thread_t init_led_thread;
	init_led_thread = rt_thread_create("led_disp", rt_led_disp_thread_entry, RT_NULL,
	128, 28, 10);
	if (init_led_thread != RT_NULL)
	rt_thread_startup(init_led_thread);

}




static rt_uint8_t led_inited = 0;
void led(rt_uint32_t led, rt_uint32_t value)
{
	/* init led configuration if it's not inited. */
	if (!led_inited)
	{
		rt_hw_led_init();
		led_inited = 1;
	}

	if ( led == 0 )
	{
		/* set led status */
		switch (value)
		{
		case 0:
			rt_hw_led_off(0);
			break;
		case 1:
			rt_hw_led_on(0);
			break;
		default:
			break;
		}
	}

	if ( led == 1 )
	{
		/* set led status */
		switch (value)
		{
		case 0:
			rt_hw_led_off(1);
			break;
		case 1:
			rt_hw_led_on(1);
			break;
		default:
			break;
		}
	}
}




#ifdef RT_USING_FINSH
#include <finsh.h>
FINSH_FUNCTION_EXPORT(led, set led[0 - 1] on[1] or off[0])
FINSH_FUNCTION_EXPORT(led_toggle, toggle the leds)

#endif

