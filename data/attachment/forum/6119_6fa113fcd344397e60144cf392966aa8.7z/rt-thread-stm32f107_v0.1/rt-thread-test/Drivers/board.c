/*
 * File      : board.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2006 - 2013 RT-Thread Develop Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://www.rt-thread.org/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2009-01-05     Bernard      first implementation
 */

#include <rthw.h>
#include <rtthread.h>
#include "board.h"
#include "led.h"
#include <serial.h>

/**
 * @addtogroup STM32
 */
 
struct stm32_serial_int_rx uart1_int_rx;
struct stm32_serial_device uart1 =
{
	USART1,
	&uart1_int_rx,
	RT_NULL,
};
struct rt_device uart1_device;

/*@{*/
void rt_hw_board_init(void)
{
	/* Configure the SysTick */
	SysTick_Config( SystemCoreClock / RT_TICK_PER_SECOND );

	rt_hw_usart_init();
	rt_console_set_device(RT_CONSOLE_DEVICE_NAME);
	
  rt_hw_led_init();
}

void rt_hw_usart_init(void)
{
  int i;

  /* Configure UART2 for 115200 baud                                         */
  RCC->APB2ENR |=  1 <<  0;            /* Enable AFIO clock                  */
  RCC->APB2ENR |=  1 <<  5;            /* Enable GPIOD clock                 */
  AFIO->MAPR |= 0x00000008;            /* Configure used Pins                */
  GPIOD->CRL &= 0xF00FFFFF;
  GPIOD->CRL |= 0x04B00000;

  RCC->APB1ENR |= 0x00020000;          /* Enable USART#2 clock               */
  USART2->BRR = 0x0135;                /* Configure 115200 baud,             */
  USART2->CR3 = 0x0000;                /*           8 bit, 1 stop bit,       */     
  USART2->CR2 = 0x0000;                /*           no parity                */
  for (i = 0; i < 0x1000; i++) __NOP();/* avoid unwanted output              */
  USART2->CR1 = 0x200C;
	
	/* register uart3 */
	rt_hw_serial_register(&uart1_device, "uart3",
		RT_DEVICE_FLAG_RDWR | RT_DEVICE_FLAG_INT_RX | RT_DEVICE_FLAG_DMA_TX,
		&uart1);
}

/* write one character to serial, must not trigger interrupt */
static void rt_hw_console_putc(const char ch)
{
	/*
		to be polite with serial console add a line feed
		to the carriage return character
	*/

   if (ch == '\n')  
	 {
      while (!(USART2->SR & 0x0080));
      USART2->DR = 0x0D;
   }
	 
   while (!(USART2->SR & 0x0080));
   USART2->DR = (ch & 0xFF);
}

/**
 * This function is used by rt_kprintf to display a string on console.
 *
 * @param str the displayed string
 */
void rt_hw_console_output(const char* str)
{
	while (*str)
	{
		rt_hw_console_putc (*str++);
	}
}

/*@}*/
