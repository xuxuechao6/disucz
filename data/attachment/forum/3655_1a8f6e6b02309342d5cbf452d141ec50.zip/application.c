/*
 * File      : application.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2006, RT-Thread Development Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://www.rt-thread.org/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2009-01-05     Bernard      the first version
 */

/**
 * @addtogroup STM32
 */
/*@{*/

#include <rtthread.h>
#include "led.h"
#include "stm32f10x.h"
#include "ff.h"
#include "diskio.h"

/*********************************************
usart ��ʼ���������߳�
**********************************************/
char thread_usart_stack[128];//����usart�߳�ջ
struct rt_thread thread_usart;//����usart�߳̿��ƿ�
struct rt_semaphore sem;//��̬���������ڳ�ʼ����ʱ��ֵ
extern char rb;

void rt_thread_entry_usart(void* parameter)
{
//����ṹ��������ڳ�ʼ������
  USART_InitTypeDef USART_InitStructure;
  NVIC_InitTypeDef NVIC_InitStructure;
  GPIO_InitTypeDef GPIO_InitStructure;
  //�����ź���
  rt_sem_init(&sem,"sem",0,RT_IPC_FLAG_FIFO);//�����ź�����ʹ��FIFOģʽ
  //ʹ��USARTʱ��
  RCC_APB2PeriphClockCmd (RCC_APB2Periph_USART1|RCC_APB2Periph_AFIO|RCC_APB2Periph_GPIOA, ENABLE);
  //��ʼ��USART
/* USARTx configured as follow:
        - BaudRate = 9600 baud  
        - Word Length = 8 Bits
        - Two Stop Bit
        - Odd parity
        - Hardware flow control disabled (RTS and CTS signals)
        - Receive and transmit enabled
*/
  USART_InitStructure.USART_BaudRate = 9600;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

  USART_Init (USART1, &USART_InitStructure);
  USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);//ʹ�ܽ����ж�
  //�趨NVIC��ʹ���ж�
/* Enable the USARTx Interrupt */
  NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
  //��ʼ��USARTʹ�õ�GIPO�˿�
/* Configure GPIOA10 Rx as input floating */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
/* Configure GPIOA9 Tx as alternate function push-pull */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  //����USART
  USART_Cmd(USART1,ENABLE);

  while(1)
  {
   rt_sem_take(&sem,RT_WAITING_FOREVER);//��ȡ�ź������������õȴ�
   USART1->DR=rb;//���ؽ��յ�������
   //rt_thread_delay(100);
  }
}
char thread_FATFS_stack[1024];//FATFS�߳�ջ
struct rt_thread thread_FATFS;//����FATFS���ƿ�
void rt_thread_entry_FATFSTEST(void* parameter)
{
  FATFS fs;
  FIL file;
  FRESULT res;
  UINT br;


   res = f_mount(0, &fs);
   res = f_open(&file, "1.txt",FA_OPEN_ALWAYS|FA_WRITE);//��1.txt����ĵ������û���򴴽�һ����֮��������ļ�д�����ݡ���д·������ζ�������ļ��ڸ�Ŀ¼��
//   res = f_write(&file,writeindata,sizeof(writeindata),&br);//���趨�õ��ַ���д���ļ���
   while(1)
   {
   	 rt_thread_delay(50);
   }
   		
}

char thread_led1_stack[128];
struct rt_thread thread_led1;
//rt_thread_t thread_led1;
static void rt_thread_entry_led1(void* parameter)
{
    /* init led configuration */
    rt_hw_led_init();

    while (1)
    {
        /* led on */
        //rt_kprintf("led1 on\r\n");
        rt_hw_led_on(0);
        rt_thread_delay(46); /* sleep 0.5 second and switch to other thread */

        /* led off */
        //rt_kprintf("led1 off\r\n");
        rt_hw_led_off(0);
        rt_thread_delay(23);
    }
}

char thread_led2_stack[128];
struct rt_thread thread_led2;
void rt_thread_entry_led2(void* parameter)
{
    unsigned int count=0;
    while (1)
    {
        /* led on */
        //rt_kprintf("led2 on,count : %d\r\n",count);
        count++;
        rt_hw_led_on(1);
        rt_thread_delay(35);

        /* led off */
        //rt_kprintf("led2 off\r\n");
        rt_hw_led_off(1);
        rt_thread_delay(55);
    }
}

int rt_application_init()
{
    /* init led1 thread */
    rt_thread_init(&thread_led1,
                   "led1",
                   rt_thread_entry_led1,
                   RT_NULL,
                   &thread_led1_stack[0],
                   sizeof(thread_led1_stack),10,10);
//    thread_led1=rt_thread_create( "led1",
//	                              rt_thread_entry_led1,
//								  RT_NULL,
//								  512,
//								  10,
//								  10
//	                              );
//	  rt_thread_startup(thread_led1);
    rt_thread_startup(&thread_led1);

    /* init led2 thread */
    rt_thread_init(&thread_led2,
                   "led2",
                   rt_thread_entry_led2,
                   RT_NULL,
                   &thread_led2_stack[0],
                   sizeof(thread_led2_stack),10,10);
    rt_thread_startup(&thread_led2);

//��ʼ��USART�����߳�
	rt_thread_init(
	                &thread_usart,
					"USART_TEST",
					rt_thread_entry_usart,
					RT_NULL,
					&thread_usart_stack[0],
					128,
					9,
					10
	                 );
   rt_thread_startup(&thread_usart);//����USART�����߳�

//��ʼ��FATFS�����߳�
   rt_thread_init(
   				  &thread_FATFS,
				  "FATFS_TEST",
				  rt_thread_entry_FATFSTEST,
				  RT_NULL,
				  &thread_FATFS_stack[0],
				  1024,
				  9,
				  10
                   );
   rt_thread_startup(&thread_FATFS);//�����߳�

    return 0;
}

/*@}*/
