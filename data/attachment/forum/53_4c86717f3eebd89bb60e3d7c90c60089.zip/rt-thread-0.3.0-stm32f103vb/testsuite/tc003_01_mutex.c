/*
 * File      : tc001_thread.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2006, RT-Thread Development Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://openlab.rt-thread.com/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2006-05-29     Bernard      the first version
 */

#include <rtthread.h>

struct rt_thread thread1;
struct rt_thread thread2;

char thread1_stack[512];
char thread2_stack[512];

struct rt_mutex mutex;

void thread1_entry(void *param)
{
	while(1)
	{
		rt_mutex_take(&mutex, RT_WAITING_FOREVER);
		rt_mutex_take(&mutex, RT_WAITING_FOREVER);

		rt_kprintf("thread1: taken mutex\n");
		rt_thread_delay(500);

		rt_mutex_release(&mutex);
		rt_mutex_release(&mutex);
		rt_kprintf("thread1: release mutex\n");
	}
}

void thread2_entry(void *param)
{
	while(1)
	{
		rt_kprintf("thread2: delay 1second\n");
		rt_thread_delay(100);

		rt_kprintf("thread2: taken mutex\n");
		rt_mutex_take(&mutex, RT_WAITING_FOREVER);
		rt_thread_delay(1000);
		rt_mutex_release(&mutex);
	}
}

int rt_application_init()
{
	rt_mutex_init(&mutex, "mutext", RT_IPC_FLAG_FIFO);

	rt_thread_init(&thread1,
		"thread1",
		thread1_entry, RT_NULL,
		&thread1_stack[0], sizeof(thread1_stack),
		250, 100);

	rt_thread_init(&thread2,
		"thread2",
		thread2_entry, RT_NULL,
		&thread2_stack[0], sizeof(thread2_stack),
		200, 75);

	rt_thread_startup(&thread1);
	rt_thread_startup(&thread2);

	return 0;
}
