/*
 * File      : tc001_thread.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2006, RT-Thread Development Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://openlab.rt-thread.com/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2006-06-06     Bernard      the first version
 * 2008-08-31	  Bernard      fix the libc dependence
 */

#include <rtthread.h>

char thread1_stack[512];
char thread2_stack[512];
char thread3_stack[512];

struct rt_thread thread1;
struct rt_thread thread2;
struct rt_thread thread3;

struct rt_messagequeue mq;
char msg_pool[2048];

#if !defined (RT_USING_MINILIBC) || !defined (RT_USING_NEWLIB)
void *memcpy(void * dst, const void *src, rt_size_t count)
{
	return rt_memcpy(dst, src, count);
}
#endif

void thread1_entry(void* parameter)
{
	char buf[128];

	while (1)
	{
		rt_memset(&buf[0], 0, sizeof(buf));

		if (rt_mq_recv(&mq, &buf[0], sizeof(buf), RT_WAITING_FOREVER) == RT_EOK)
		{
			rt_kprintf("thread1: recv msg from message queue, the content:%s\n", buf);
		}

		rt_thread_delay(100);
	}
}

void thread2_entry(void* parameter)
{
	int i, result;
	char buf[] = "this is message No.x";

	while (1)
	{
		for (i = 0; i < 10; i++)
		{
			buf[sizeof(buf) - 2] = '0' + i;

			rt_kprintf("thread2: send message - %s\n", buf);
			result = rt_mq_send(&mq, &buf[0], sizeof(buf));
			if ( result == -RT_EFULL);
			{
				rt_kprintf("message queue full, delay 10s\n");
				rt_thread_delay(1000);
			}
		}

		rt_thread_delay(100);
	}
}

void thread3_entry(void* parameter)
{
	char buf[] = "this is an urgent message!";

	while (1)
	{
		rt_kprintf("thread3: send an urgent message\n");
		rt_mq_urgent(&mq, &buf[0], sizeof(buf));

		rt_thread_delay(250);
	}
}

int rt_application_init()
{
	rt_mq_init(&mq, "mqt", &msg_pool[0], 128 - sizeof(void*), sizeof(msg_pool), RT_IPC_FLAG_FIFO);

	rt_thread_init(&thread1,
		"thread1",
		thread1_entry, RT_NULL,
		&thread1_stack[0], sizeof(thread1_stack),
		200, 100);

	rt_thread_init(&thread2,
		"thread2",
		thread2_entry, RT_NULL,
		&thread2_stack[0], sizeof(thread2_stack),
		250, 75);

	rt_thread_init(&thread3,
		"thread3",
		thread3_entry, RT_NULL,
		&thread3_stack[0], sizeof(thread3_stack),
		220, 50);

	rt_thread_startup(&thread1);
	rt_thread_startup(&thread2);
	rt_thread_startup(&thread3);

	return 0;
}
