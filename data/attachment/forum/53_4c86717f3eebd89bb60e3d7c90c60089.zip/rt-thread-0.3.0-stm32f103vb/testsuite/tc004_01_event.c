/*
 * File      : tc001_thread.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2006, RT-Thread Development Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://openlab.rt-thread.com/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2006-06-06     Bernard      the first version
 */

#include <rtthread.h>

struct rt_thread thread1;
struct rt_thread thread2;
struct rt_thread thread3;

char thread1_stack[512];
char thread2_stack[512];
char thread3_stack[512];

struct rt_event event;

void thread1_entry(void *param)
{
	rt_uint32_t e;

	while (1)
	{
		/* receive first event */
		if (rt_event_recv(&event, ((1 << 3) | (1 << 5)), RT_EVENT_FLAG_AND | RT_EVENT_FLAG_CLEAR, RT_WAITING_FOREVER, &e) == RT_EOK)
		{
			rt_kprintf("thread1: AND recv event 0x%x\n", e);
		}

		rt_kprintf("thread1: delay 1s to prepare second event\n");
		rt_thread_delay(100);

		/* receive second event */
		if (rt_event_recv(&event, ((1 << 3) | (1 << 5)), RT_EVENT_FLAG_OR | RT_EVENT_FLAG_CLEAR, RT_WAITING_FOREVER, &e) == RT_EOK)
		{
			rt_kprintf("thread1: OR recv event 0x%x\n", e);
		}

		rt_thread_delay(50);
	}
}

void thread2_entry(void *param)
{
	while (1)
	{
		rt_kprintf("thread2: send event1\n");
		rt_event_send(&event, (1 << 3));

		rt_thread_delay(100);
	}
}

void thread3_entry(void *param)
{
	while (1)
	{
		rt_kprintf("thread3: send event2\n");
		rt_event_send(&event, (1 << 5));

		rt_thread_delay(200);
	}
}

int rt_application_init()
{
	rt_event_init(&event, "event", RT_IPC_FLAG_FIFO);

	rt_thread_init(&thread1,
		"thread1",
		thread1_entry, RT_NULL,
		&thread1_stack[0], sizeof(thread1_stack),
		200, 100);

	rt_thread_init(&thread2,
		"thread2",
		thread2_entry, RT_NULL,
		&thread2_stack[0], sizeof(thread2_stack),
		220, 75);

	rt_thread_init(&thread3,
		"thread3",
		thread3_entry, RT_NULL,
		&thread3_stack[0], sizeof(thread3_stack),
		230, 50);

	rt_thread_startup(&thread1);
	rt_thread_startup(&thread2);
	rt_thread_startup(&thread3);

	return 0;
}
