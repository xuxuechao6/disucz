/*
 * File      : tc008_02_memp.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2006, RT-Thread Development Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://openlab.rt-thread.com/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2006-06-06     Bernard      the first version
 */

#include <rtthread.h>

char thread1_stack[512];
char thread2_stack[512];

char mempool[4096];

struct rt_thread thread1;
struct rt_thread thread2;

struct rt_mempool mp;
char *ptr[48];

void thread1_entry(void* parameter)
{
	int i;
	char *block;

	while(1)
	{
		for (i = 0; i < 48; i++)

		{
			rt_kprintf("allocate No.%d\n", i);
			ptr[i] = rt_mp_alloc(&mp, RT_WAITING_FOREVER);
		}
		
		block = rt_mp_alloc(&mp, RT_WAITING_FOREVER);
		rt_kprintf("allocate the block mem\n");
		rt_mp_free(block);
		block = RT_NULL;
	}
}

void thread2_entry(void *parameter)
{
	int i;

	while(1)
	{
		rt_kprintf("try to release block\n");

		for (i = 0 ; i < 48; i ++)
		{
			if (ptr[i] != RT_NULL)
			{
				rt_kprintf("release block %d\n", i);

				rt_mp_free(ptr[i]);

				ptr[i] = RT_NULL;

			}
		}

		// rt_thread_delay(100);
	}
}

int rt_application_init()
{
	int i;
	for (i = 0; i < 48; i ++) ptr[i] = RT_NULL;

	rt_mp_init(&mp, "mp1", &mempool[0],
		sizeof(mempool), 80);

	rt_thread_init(&thread1,
		"thread1",
		thread1_entry, RT_NULL,
		&thread1_stack[0], sizeof(thread1_stack),
		200, 100);

	rt_thread_init(&thread2,
		"thread2",
		thread2_entry, RT_NULL,
		&thread2_stack[0], sizeof(thread2_stack),
		250, 75);

	rt_thread_startup(&thread1);
	rt_thread_startup(&thread2);

	return 0;
}
