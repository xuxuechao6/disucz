/*
 * File      : tc008_01_mem.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2006, RT-Thread Development Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://openlab.rt-thread.com/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2006-06-08     Bernard      the first version
 * 2006-08-10     Bernard      reduce the allocated memory size
 */

#include <rtthread.h>

struct rt_thread thread1;
char thread1_stack[512];

void thread1_entry(void* parameter)
{
	int i;
	char *ptr[20];
	
	for (i = 0; i < 20; i ++) ptr[i] = RT_NULL;

	while(1)
	{
		for (i = 0; i < 20; i++)
		{
			ptr[i] = rt_malloc(1 << i);
			
			if (ptr[i] != RT_NULL)
			{
				rt_kprintf("get memory: 0x%x\n", ptr[i]);
				rt_free(ptr[i]);
				
				ptr[i] = RT_NULL;
			}
		}
	}
}

int rt_application_init()
{
	rt_thread_init(&thread1,
		"thread1",
		thread1_entry, RT_NULL,
		&thread1_stack[0], sizeof(thread1_stack),
		200, 100);

	rt_thread_startup(&thread1);
  		  
	return 0;
}
