/*
 * File      : tc001_thread.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2006, RT-Thread Development Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://openlab.rt-thread.com/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2006-05-28     Bernard      the first version
 */

#include <rtthread.h>

char thread1_stack[512];
char thread2_stack[512];

struct rt_thread thread1;
struct rt_thread thread2;

struct rt_mailbox mb;
char mb_pool[128];

char mb_str1[] = "I'm a mail!";
char mb_str2[] = "this is another mail!";

void thread1_entry(void* parameter)
{
	unsigned char* str;
	
	while (1)
	{
		rt_kprintf("thread1: try to recv a mail\n");
		if (rt_mb_recv(&mb, (rt_uint32_t*)&str, RT_WAITING_FOREVER) == RT_EOK)
		{
			rt_kprintf("thread1: get a mail from mailbox, the content:%s\n", str);

			rt_thread_delay(100);
		}
	}
}

void thread2_entry(void* parameter)
{
	rt_uint8_t count;

	count = 0;
	while (1)
	{
		count ++;
		if (count & 0x1)
		{
			rt_mb_send(&mb, (rt_uint32_t)&mb_str1[0]);
		}
		else
		{
			rt_mb_send(&mb, (rt_uint32_t)&mb_str2[0]);
		}

		rt_thread_delay(200);
	}
}

int rt_application_init()
{
	rt_mb_init(&mb, "mbt", &mb_pool[0], 128 / 4, RT_IPC_FLAG_FIFO);

	rt_thread_init(&thread1,
		"thread1",
		thread1_entry, RT_NULL,
		&thread1_stack[0], sizeof(thread1_stack),
		200, 100);
	
	rt_thread_init(&thread2,
		"thread2",
		thread2_entry, RT_NULL,
		&thread2_stack[0], sizeof(thread2_stack),
		250, 75);
	
	rt_thread_startup(&thread1);
	rt_thread_startup(&thread2);

	return 0;
}
