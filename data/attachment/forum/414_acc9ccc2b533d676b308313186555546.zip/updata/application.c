/*
 * File      : app.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2006, RT-Thread Development Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://www.rt-thread.org/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2006-06-05     Bernard      the first version
 */

#include <rtthread.h>
#include "lpc214x.h"
#include "board.h"

/**
 * @addtogroup LPC2148
 */
/*@{*/
#define LED1 ( 1<<16) //P1
#define LED2 ( 1<<17) //P1
#define LED3 ( 1<<18) //P1
#define LED4 ( 1<<19) //P1


char thread1_stack[512];
char thread2_stack[512];
char thread3_stack[512];
char thread4_stack[512];

struct rt_thread thread1;
struct rt_thread thread2;
struct rt_thread thread3;
struct rt_thread thread4;

void thread1_entry(void* parameter)
{
 IO1DIR |= LED1;
 while(1)
 {
 IO1CLR = LED1;
 rt_thread_delay(20);
 IO1SET = LED1;
 rt_thread_delay(20);
 }
}

void thread2_entry(void* parameter)
{
 IO1DIR |= LED2;
 while(1)
 {
 IO1CLR = LED2;
 rt_thread_delay(30);
 IO1SET = LED2;
 rt_thread_delay(30);
 }
}

void thread3_entry(void* parameter)
{
 IO1DIR |= LED3;
 while(1)
 {
 IO1CLR = LED3;
 rt_thread_delay(40);
 IO1SET = LED3;
 rt_thread_delay(40);
 }
}

void thread4_entry(void* parameter)
{
 IO1DIR |= LED4;
 while(1)
 {
 IO1CLR = LED4;
 rt_thread_delay(50);
 IO1SET = LED4;
 rt_thread_delay(50);
 }
}

int rt_application_init()
{
	rt_thread_init(&thread1,
		"thread1",
		thread1_entry, RT_NULL,
		&thread1_stack[0], sizeof(thread1_stack),
		21, 10);

	rt_thread_init(&thread2,
		"thread2",
		thread2_entry, RT_NULL,
		&thread2_stack[0], sizeof(thread2_stack),
		22, 10);

	rt_thread_init(&thread3,
		"thread3",
		thread3_entry, RT_NULL,
		&thread3_stack[0], sizeof(thread3_stack),
		20, 10);

	rt_thread_init(&thread4,
		"thread4",
		thread4_entry, RT_NULL,
		&thread4_stack[0], sizeof(thread4_stack),
		24, 10);

	rt_thread_startup(&thread1);
	rt_thread_startup(&thread2);
	rt_thread_startup(&thread3);
	rt_thread_startup(&thread4);

	return 0;
}

/*@}*/
