/*
 * File      : dm9000a.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2009, RT-Thread Development Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://www.rt-thread.org/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2009-07-01     Bernard      the first version
 */
#include <rtthread.h>
#include "dm9000a.h"

#include <netif/ethernetif.h>
#include "lwipopts.h"
#include "stm32f10x.h"
#include "stm32f10x_fsmc.h"

// #define DM9000_DEBUG		1
#if ( DM9000_DEBUG == 1 )
#define DM9000_TRACE	rt_kprintf
#else
#define DM9000_TRACE(...)
#endif


u8_t InitDM9000(void);	 
/*
 * DM9000 interrupt line is connected to PE4
 */
//--------------------------------------------------------

#define DM9000_PHY          0x40    /* PHY address 0x01 */
//#define RST_1()             GPIO_SetBits(GPIOE,GPIO_Pin_5)
//#define RST_0()             GPIO_ResetBits(GPIOE,GPIO_Pin_5)

#define MAX_ADDR_LEN 6
enum DM9000_PHY_mode
{
    DM9000_10MHD = 0, DM9000_100MHD = 1,
    DM9000_10MFD = 4, DM9000_100MFD = 5,
    DM9000_AUTO  = 8, DM9000_1M_HPNA = 0x10
};

enum DM9000_TYPE
{
    TYPE_DM9000E,
    TYPE_DM9000A,
    TYPE_DM9000B
};

struct rt_dm9000_eth
{
    /* inherit from ethernet device */
    struct eth_device parent;

    enum DM9000_TYPE type;
    enum DM9000_PHY_mode mode;

    rt_uint8_t imr_all;

    rt_uint8_t packet_cnt;                  /* packet I or II */
    rt_uint16_t queue_packet_len;           /* queued packet (packet II) */

    /* interface address info. */
    rt_uint8_t  dev_addr[MAX_ADDR_LEN];		/* hw address	*/
};
static struct rt_dm9000_eth dm9000_device;
static struct rt_semaphore sem_ack, sem_lock;

void rt_dm9000_isr(void);
		 /*����дһ�����ݺ���,CMD=1,����ģʽ*/
#define WR_DATA(data){DM9K_CMD = 1;	DM9K_CS=0;DM9K_IO_W=data;DM9K_WE=0;DM9K_WE = 1;DM9K_CS=1;} 


static void delay_ms(rt_uint32_t ms)
{
   uint16_t i,j; 
	for( i = 0; i < ms; i++ )
	{ 
		for( j = 0; j < 1141; j++ );
	}
}
	   //��ȡһ����
u16 DM9000_inw(void)
{
	u16 data;

    
	DM9K_IO_IN(); //������Ϊ����ģʽ
	DM9K_CMD = 1;
	DM9K_CS=0;
	DM9K_OE = 0;
//	dm9000_delay(1000);
	data = (u16)DM9K_IO_R;  //ע����IDR�Ĵ���
	DM9K_OE = 1;
	DM9K_CS=1;
	DM9K_CMD = 0;
  	return data;
}
//��ȡһ���ֽ�

u8 DM9000_inb(void)
{
	u8 data;

	DM9K_IO_IN(); //������Ϊ����ģʽ
	DM9K_CMD = 1;
	DM9K_CS=0;
	DM9K_OE = 0;
//	dm9000_delay(1000);
	data = (u8)DM9K_IO_R;
	DM9K_OE = 1;
	DM9K_CS=1;
	DM9K_CMD = 0;

  	return data;	
} 
	  //д��һ����
void DM9000_outw(u16 val)
{
	DM9K_IO_OUT();	//������Ϊ���ģʽ
	DM9K_CMD = 1;
	DM9K_CS=0;
	DM9K_IO_W = val;   //ע����ODR�Ĵ���
	DM9K_WE = 0;
	DM9K_WE = 1;
	DM9K_CS=1;	
}

//д��һ���ֽڣ�ע��д����ǵ�ַ�����ǼĴ�����ֵ��CMD=0;
void DM9000_outb(u8 addr)
{	
	DM9K_IO_OUT();
	DM9K_CMD = 0;
	DM9K_CS=0;
	DM9K_IO_W = addr;
	DM9K_WE = 0;
	DM9K_WE = 1;
	DM9K_CS=1;
	DM9K_CMD = 1;	
}

void DM9000_outbyte(u8 data)
{
	DM9K_IO_OUT();	//������Ϊ���ģʽ
	DM9K_CMD = 1;
	DM9K_CS=0;
	DM9K_IO_W = data;   //ע����ODR�Ĵ���
	DM9K_WE = 0;
	DM9K_WE = 1;
	DM9K_CS=1;	
}

void WR_REG(u16 val)
{
	
	DM9K_IO_OUT();	//������Ϊ���ģʽ
	DM9K_CMD = 0;	//д����ǵ�ַ��CMD=0
	DM9K_CS=0;
	DM9K_IO_W = val;   //ע����ODR�Ĵ���
	DM9K_WE = 0;
	DM9K_WE = 1;
	DM9K_CS=1;	
}

/* Read a byte from I/O port */
rt_inline rt_uint8_t dm9000_io_read(rt_uint16_t reg)
{
	rt_uint8_t data;
	
//	DM9K_IO_OUT();	//������Ϊ���ģʽ
//	DM9K_CMD = 0;	//д����ǵ�ַ��CMD=0
//	DM9K_IO_W =(u8)reg;   //ע����ODR�Ĵ���
//	DM9K_WE = 0;
//	DM9K_WE = 1;   //��д��Ĵ����ĵ�ַ
	WR_REG(reg);  //д��Ҫ���ļĴ�����
	DM9K_IO_IN();	//���ö�ȡģʽ

//	DM9K_IO_W=0x0000;
	DM9K_CMD = 1;	 //��ȡ���ݣ�����Ϊ��������ģʽ
	DM9K_CS=0;
	DM9K_OE=0;	
//	dm9000_delay(1000);	
	data=DM9K_IO_R;
//	dm9000_delay(1000);
	DM9K_OE=1;
	DM9K_CS=1;	

//	DM9K_IO_W=0xffff;
	return data;		
}

rt_inline void dm9000_io_write(rt_uint16_t reg, rt_uint16_t value)
{
//	DM9K_IO_OUT();	//������Ϊ���ģʽ
//	DM9K_CMD = 0;	//д����ǵ�ַ��CMD=0
//	DM9K_IO_W =(u8)reg;   //ע����ODR�Ĵ���
//	DM9K_WE = 0;
//	DM9K_WE = 1;	
//
//	DM9K_CMD = 1;	
//	dm9000_delay(10);
//	DM9K_IO_W =(u8)value;
//	DM9K_WE = 0;
//	DM9K_WE = 1;
	WR_REG(reg);  
	WR_DATA(value);
}
///*�޸ĵײ��д�����Ľӿڣ������Ƕ�ȡһ���ֽ�*/
///* Read a byte from I/O port */
//rt_inline rt_uint8_t dm9000_io_read(rt_uint16_t reg)
//{
//    DM9000_IO = reg;   //��д�Ĵ�����ַ��Ȼ���д���ݿھ͵õ��üĴ�����ֵ
//    return (rt_uint8_t) DM9000_DATA;	// ��ȡ����8λ���ݣ�����һ���ֽ�Ϊ��λ
//}
//
///* Write a byte to I/O port */
//rt_inline void dm9000_io_write(rt_uint16_t reg, rt_uint16_t value)
//{
//    DM9000_IO = reg;
//    DM9000_DATA = value;
//}


	  /*�����Ƕ�ȡһ����*/
/* Read a word from phyxcer */
rt_inline rt_uint16_t phy_read(rt_uint16_t reg)
{
    rt_uint16_t val;

    /* Fill the phyxcer register into REG_0C */
    dm9000_io_write(DM9000_EPAR, DM9000_PHY | reg);
    dm9000_io_write(DM9000_EPCR, 0xc);	/* Issue phyxcer read command */

    delay_ms(500);		/* Wait read complete */

    dm9000_io_write(DM9000_EPCR, 0x0);	/* Clear phyxcer read command */
    val = (dm9000_io_read(DM9000_EPDRH) << 8) | dm9000_io_read(DM9000_EPDRL);

    return val;
}

/* Write a word to phyxcer */
rt_inline void phy_write(rt_uint16_t reg, rt_uint16_t value)
{
    /* Fill the phyxcer register into REG_0C */
    dm9000_io_write(DM9000_EPAR, DM9000_PHY | reg);

    /* Fill the written data into REG_0D & REG_0E */
    dm9000_io_write(DM9000_EPDRL, (value & 0xff));
    dm9000_io_write(DM9000_EPDRH, ((value >> 8) & 0xff));
    dm9000_io_write(DM9000_EPCR, 0xa);	/* Issue phyxcer write command */

    delay_ms(1000);		/* Wait write complete */

    dm9000_io_write(DM9000_EPCR, 0x0);	/* Clear phyxcer write command */
}

/* Set PHY operationg mode */
rt_inline void phy_mode_set(rt_uint32_t media_mode)
{
    rt_uint16_t phy_reg4 = 0x01e1, phy_reg0 = 0x1000;
    if (!(media_mode & DM9000_AUTO))
    {
        switch (media_mode)
        {
        case DM9000_10MHD:
            phy_reg4 = 0x21;
            phy_reg0 = 0x0000;
            break;
        case DM9000_10MFD:
            phy_reg4 = 0x41;
            phy_reg0 = 0x1100;
            break;
        case DM9000_100MHD:
            phy_reg4 = 0x81;
            phy_reg0 = 0x2000;
            break;
        case DM9000_100MFD:
            phy_reg4 = 0x101;
            phy_reg0 = 0x3100;
            break;
        }
        phy_write(4, phy_reg4);	/* Set PHY media mode */
        phy_write(0, phy_reg0);	/*  Tmp */
    }

    dm9000_io_write(DM9000_GPCR, 0x01);	/* Let GPIO0 output */
    dm9000_io_write(DM9000_GPR, 0x00);	/* Enable PHY */
}

/* interrupt service routine */
void rt_dm9000_isr()
{
    rt_uint16_t int_status;
//    rt_uint16_t last_io;

//    last_io = DM9000_IO;	   //�������

    /* Disable all interrupts */
    dm9000_io_write(DM9000_IMR, IMR_PAR);

    /* Got DM9000 interrupt status */
    int_status = dm9000_io_read(DM9000_ISR);		/* Got ISR */
    dm9000_io_write(DM9000_ISR, int_status);    	/* Clear ISR status */

    DM9000_TRACE("dm9000 isr: int status %04x\n", int_status);

    if (int_status & ISR_LNKCHGS)
    {
        rt_uint8_t nsr = dm9000_io_read(DM9000_NSR);
//        if( nsr & NSR_LINKST )
//        {
//            rt_kprintf("link up\r\n");
//            netif_set_link_up(dm9000_device.parent.netif);
//        }
//        else
//        {
//            rt_kprintf("link down\r\n");
//            netif_set_link_down(dm9000_device.parent.netif);
//        }
    }

    /* receive overflow */
    if (int_status & ISR_ROS)
    {
        rt_kprintf("overflow\n");
    }

    if (int_status & ISR_ROOS)
    {
        rt_kprintf("overflow counter overflow\n");
    }

    /* Received the coming packet */
    if (int_status & ISR_PRS)
    {
	    /* disable receive interrupt */
	    dm9000_device.imr_all = IMR_PAR | IMR_PTM;

        /* a frame has been received */
        eth_device_ready(&(dm9000_device.parent)); //����һ֡���ݣ��������䷢���ʼ�֪ͨ�ϲ�
    }

    /* Transmit Interrupt check */
    if (int_status & ISR_PTS)
    {
        /* transmit done */
        int tx_status = dm9000_io_read(DM9000_NSR);    /* Got TX status */

        if (tx_status & (NSR_TX2END | NSR_TX1END))
        {
            dm9000_device.packet_cnt --;
            if (dm9000_device.packet_cnt > 0)
            {
                DM9000_TRACE("dm9000 isr: tx second packet\n");

                /* transmit packet II */
                /* Set TX length to DM9000 */
                dm9000_io_write(DM9000_TXPLL, dm9000_device.queue_packet_len & 0xff);
                dm9000_io_write(DM9000_TXPLH, (dm9000_device.queue_packet_len >> 8) & 0xff);

                /* Issue TX polling command */
                dm9000_io_write(DM9000_TCR, TCR_TXREQ);	/* Cleared after TX complete */
            }

            /* One packet sent complete */
            rt_sem_release(&sem_ack);
        }
    }

    /* Re-enable interrupt mask */
    dm9000_io_write(DM9000_IMR, dm9000_device.imr_all);

//    DM9000_IO = last_io;	 //�������
}

/* RT-Thread Device Interface */
/* initialize the interface */
static rt_err_t rt_dm9000_init(rt_device_t dev)
{
    int i, oft, lnk;
    rt_uint32_t value;
    /* RESET device */
    dm9000_io_write(DM9000_NCR, NCR_RST); //д��λ�Ĵ�������оƬ�ȸ�λ
    delay_ms(3000);		/* delay 1ms */

    /* identfy DM9000 */
    value  = dm9000_io_read(DM9000_VIDL);
    value |= dm9000_io_read(DM9000_VIDH) << 8;
    value |= dm9000_io_read(DM9000_PIDL) << 16;
    value |= dm9000_io_read(DM9000_PIDH) << 24;
    rt_kprintf("dm9000 id: 0x%x\n", value);
    if (value != DM9000_ID)
    {
        return -RT_ERROR;
    }

    /* GPIO0 on pre-activate PHY */
    dm9000_io_write(DM9000_GPR, 0x00);	            /* REG_1F bit0 activate phyxcer */
    dm9000_io_write(DM9000_GPCR, GPCR_GEP_CNTL);    /* Let GPIO0 output */
    dm9000_io_write(DM9000_GPR, 0x00);                 /* Enable PHY */

    /* Set PHY */
    phy_mode_set(dm9000_device.mode);

    /* Program operating register */
    dm9000_io_write(DM9000_NCR, 0x0);	/* only intern phy supported by now */
    dm9000_io_write(DM9000_TCR, 0);	    /* TX Polling clear */
    dm9000_io_write(DM9000_BPTR, 0x3f);	/* Less 3Kb, 200us */
    dm9000_io_write(DM9000_FCTR, FCTR_HWOT(3) | FCTR_LWOT(8));	/* Flow Control : High/Low Water */
    dm9000_io_write(DM9000_FCR, 0x0);	/* SH FIXME: This looks strange! Flow Control */
    dm9000_io_write(DM9000_SMCR, 0);	/* Special Mode */
    dm9000_io_write(DM9000_NSR, NSR_WAKEST | NSR_TX2END | NSR_TX1END);	/* clear TX status */
    dm9000_io_write(DM9000_ISR, 0x0f);	/* Clear interrupt status */
    dm9000_io_write(DM9000_TCR2, 0x80);	/* Switch LED to mode 1 */

    /* set mac address */
    for (i = 0, oft = 0x10; i < 6; i++, oft++)
        dm9000_io_write(oft, dm9000_device.dev_addr[i]);
    /* set multicast address */
    for (i = 0, oft = 0x16; i < 8; i++, oft++)
        dm9000_io_write(oft, 0xff);

    /* Activate DM9000 */
    dm9000_io_write(DM9000_RCR, RCR_DIS_LONG | RCR_DIS_CRC | RCR_RXEN);	/* RX enable */
    dm9000_io_write(DM9000_IMR, IMR_PAR);

    if (dm9000_device.mode == DM9000_AUTO)
    {
		i = 0;
        while (!(phy_read(1) & 0x20))
        {
            /* autonegation complete bit */
            rt_thread_delay( RT_TICK_PER_SECOND/10 );
            i++;
            if (i > 30) /* wait 3s */
            {
                rt_kprintf("could not establish link\n");
                break;
            }
        }
    }

    /* see what we've got */
    lnk = phy_read(17) >> 12;
    rt_kprintf("operating at ");
    switch (lnk)
    {
    case 1:
        rt_kprintf("10M half duplex ");
        break;
    case 2:
        rt_kprintf("10M full duplex ");
        break;
    case 4:
        rt_kprintf("100M half duplex ");
        break;
    case 8:
        rt_kprintf("100M full duplex ");
        break;
    default:
        rt_kprintf("unknown: %d ", lnk);
        break;
    }
    rt_kprintf("mode\n");

    dm9000_io_write(DM9000_IMR, dm9000_device.imr_all);	/* Enable TX/RX interrupt mask */

    return RT_EOK;
}

static rt_err_t rt_dm9000_open(rt_device_t dev, rt_uint16_t oflag)
{
    return RT_EOK;
}

static rt_err_t rt_dm9000_close(rt_device_t dev)
{
    /* RESET devie */
    phy_write(0, 0x8000);	/* PHY RESET */
    dm9000_io_write(DM9000_GPR, 0x01);	/* Power-Down PHY */
    dm9000_io_write(DM9000_IMR, 0x80);	/* Disable all interrupt */
    dm9000_io_write(DM9000_RCR, 0x00);	/* Disable RX */

    return RT_EOK;
}

static rt_size_t rt_dm9000_read(rt_device_t dev, rt_off_t pos, void* buffer, rt_size_t size)
{
    rt_set_errno(-RT_ENOSYS);
    return 0;
}

static rt_size_t rt_dm9000_write (rt_device_t dev, rt_off_t pos, const void* buffer, rt_size_t size)
{
    rt_set_errno(-RT_ENOSYS);
    return 0;
}

static rt_err_t rt_dm9000_control(rt_device_t dev, rt_uint8_t cmd, void *args)
{
    switch (cmd)
    {
    case NIOCTL_GADDR:
        /* get mac address */
        if (args) rt_memcpy(args, dm9000_device.dev_addr, 6);
        else return -RT_ERROR;
        break;

    default :
        break;
    }

    return RT_EOK;
}

/* ethernet device interface */
/* transmit packet. */	//��msg.pbuf���ݵ�dm9000tx������Ȼ���ʽ����ת��
rt_err_t rt_dm9000_tx( rt_device_t dev, struct pbuf* p)
{
    DM9000_TRACE("dm9000 tx: %d\n", p->tot_len);

    /* lock DM9000 device */
    rt_sem_take(&sem_lock, RT_WAITING_FOREVER);	//����ͨ���ź��������øú���

    /* disable dm9000a interrupt */
    dm9000_io_write(DM9000_IMR, IMR_PAR);	//��ĳ���Ĵ���д������

    /* Move data to DM9000 TX RAM */
//    DM9000_outb(DM9000_IO_BASE, DM9000_MWCMD); //д������
	DM9000_outb(DM9000_MWCMD);

    {
        /* q traverses through linked list of pbuf's
         * This list MUST consist of a single packet ONLY */
        struct pbuf *q;
        rt_uint16_t pbuf_index = 0;
        rt_uint8_t word[2], word_index = 0;

        q = p;
        /* Write data into dm9000a, two bytes at a time
         * Handling pbuf's with odd number of bytes correctly
         * No attempt to optimize for speed has been made */
        while (q)
        {
            if (pbuf_index < q->len)
            {
                word[word_index++] = ((u8_t*)q->payload)[pbuf_index++];
                if (word_index == 2)
                {
//                    DM9000_outw(DM9000_DATA_BASE, (word[1] << 8) | word[0]);
					  DM9000_outw((word[1] << 8) | word[0]);
                    word_index = 0;
                }
            }
            else
            {
                q = q->next;
                pbuf_index = 0;
            }
        }
        /* One byte could still be unsent */
        if (word_index == 1)
        {
//            DM9000_outw(DM9000_DATA_BASE, word[0]);
			  DM9000_outw(word[0]);
        }
    }

    if (dm9000_device.packet_cnt == 0)
    {
        DM9000_TRACE("dm9000 tx: first packet\n");

        dm9000_device.packet_cnt ++;
        /* Set TX length to DM9000 */
        dm9000_io_write(DM9000_TXPLL, p->tot_len & 0xff);
        dm9000_io_write(DM9000_TXPLH, (p->tot_len >> 8) & 0xff);

        /* Issue TX polling command */
        dm9000_io_write(DM9000_TCR, TCR_TXREQ);	/* Cleared after TX complete */
    }
    else
    {
        DM9000_TRACE("dm9000 tx: second packet\n");

        dm9000_device.packet_cnt ++;
        dm9000_device.queue_packet_len = p->tot_len;
    }

    /* enable dm9000a interrupt */
    dm9000_io_write(DM9000_IMR, dm9000_device.imr_all);

    /* unlock DM9000 device */
    rt_sem_release(&sem_lock);

    /* wait ack */
    rt_sem_take(&sem_ack, RT_WAITING_FOREVER);

    DM9000_TRACE("dm9000 tx done\n");

    return RT_EOK;
}

/* reception packet. */
struct pbuf *rt_dm9000_rx(rt_device_t dev)
{
    struct pbuf* p;
    rt_uint32_t rxbyte;
    rt_uint16_t rx_status, rx_len;
    rt_uint16_t* data;

    /* init p pointer */
    p = RT_NULL;

    /* lock DM9000 device */
    rt_sem_take(&sem_lock, RT_WAITING_FOREVER);

__error_retry:
    /* Check packet ready or not */
    dm9000_io_read(DM9000_MRCMDX);	    		/* Dummy read */
//    rxbyte = DM9000_inb(DM9000_DATA_BASE);		/* Got most updated data */
	  rxbyte = DM9000_inb();
    if (rxbyte)
    {
        if (rxbyte > 1)
        {
            DM9000_TRACE("dm9000 rx: rx error, stop device\n");

            dm9000_io_write(DM9000_RCR, 0x00);	/* Stop Device */
            dm9000_io_write(DM9000_ISR, 0x80);	/* Stop INT request */
        }

        /* A packet ready now  & Get status/length */
//        DM9000_outb(DM9000_IO_BASE, DM9000_MRCMD);
		 DM9000_outb(DM9000_MRCMD);

//        rx_status = DM9000_inw(DM9000_DATA_BASE);//��ȡ״̬
		 rx_status = DM9000_inw();

//        rx_len = DM9000_inw(DM9000_DATA_BASE);	//��ȡ���ĳ���
		rx_len = DM9000_inw();
        DM9000_TRACE("dm9000 rx: status %04x len %d\n", rx_status, rx_len);

        /* allocate buffer */
        p = pbuf_alloc(PBUF_LINK, rx_len, PBUF_RAM); //ע���ڴ���亯��
        if (p != RT_NULL)
        {
            struct pbuf* q;
            rt_int32_t len;

            for (q = p; q != RT_NULL; q= q->next)
            {
                data = (rt_uint16_t*)q->payload;
                len = q->len;

                while (len > 0)	   //��ȡ���ݣ���ַ�ڲ��Զ�����
                {
//                    *data = DM9000_inw(DM9000_DATA_BASE);
					*data = DM9000_inw();
                    data ++;
                    len -= 2;
                }
            }
        }
        else
        {
            rt_uint16_t dummy;

            rt_kprintf("dm9000 rx: no pbuf\n");

            /* no pbuf, discard data from DM9000 */
            data = &dummy;
            while (rx_len)
            {
//                *data = DM9000_inw(DM9000_DATA_BASE);
				*data = DM9000_inw();
                rx_len -= 2;
            }
        }

        if ((rx_status & 0xbf00) || (rx_len < 0x40)
                || (rx_len > DM9000_PKT_MAX))
        {
            rt_kprintf("rx error: status %04x, rx_len: %d\n", rx_status, rx_len);

            if (rx_status & 0x100)
            {
                rt_kprintf("rx fifo error\n");
            }
            if (rx_status & 0x200)
            {
                rt_kprintf("rx crc error\n");
            }
            if (rx_status & 0x8000)
            {
                rt_kprintf("rx length error\n");
            }
            if (rx_len > DM9000_PKT_MAX)
            {
                rt_kprintf("rx length too big\n");

                /* RESET device */
                dm9000_io_write(DM9000_NCR, NCR_RST);
                rt_thread_delay(1); /* delay 5ms */
            }

            /* it issues an error, release pbuf */
            if (p != RT_NULL) pbuf_free(p);
            p = RT_NULL;

            goto __error_retry;
        }
    }
    else
    {
        /* clear packet received latch status */
        dm9000_io_write(DM9000_ISR, ISR_PTS);

        /* restore receive interrupt */
        dm9000_device.imr_all = IMR_PAR | IMR_PTM | IMR_PRM;
        dm9000_io_write(DM9000_IMR, dm9000_device.imr_all);
    }

    /* unlock DM9000 device */
    rt_sem_release(&sem_lock);

    return p;
}

static void RCC_Configuration(void)	  //����������������������
{
    /* enable gpiob port clock */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB , ENABLE);
}

static void NVIC_Configuration(void)//�����ⲿ�жϷ������   PA->3
{
    NVIC_InitTypeDef NVIC_InitStructure;

    /* Enable the EXTI0 Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = EXTI3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

static void GPIO_Configuration(void)	 //PA->3����Ϊ�ⲿ�ж�����
{
//    GPIO_InitTypeDef GPIO_InitStructure;
    EXTI_InitTypeDef EXTI_InitStructure;

//	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);
//    /* configure PE5 as eth RST */
//    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
//    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
//    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//    GPIO_Init(GPIOE,&GPIO_InitStructure);
//    GPIO_SetBits(GPIOE,GPIO_Pin_5);
    //RST_1();

    /* configure PE4 as external interrupt */ //�����ж�����Ϊ����
//    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
//    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
//    GPIO_Init(GPIOA, &GPIO_InitStructure);

    /* Connect DM9000 EXTI Line to GPIOE Pin 4 */
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource3);

    /* Configure DM9000 EXTI Line to generate an interrupt on falling edge */
    EXTI_InitStructure.EXTI_Line = EXTI_Line3;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    /* Clear DM9000A EXTI line pending bit */
    EXTI_ClearITPendingBit(EXTI_Line3);
}
static void JTAG_Set(u8 mode)
{
	u32 temp;
	temp=mode;
	temp<<=25;
	RCC->APB2ENR|=1<<0;     //��������ʱ��	   
	AFIO->MAPR&=0XF8FFFFFF; //���MAPR��[26:24]
	AFIO->MAPR|=temp;       //����jtagģʽ
}
static void FSMC_Configuration()  //�Ѿ���ʹ����RCC_GPIOBʱ������
{
    GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB , ENABLE);
//	GPIO_PinRemapConfig(GPIO_Remap_SWJ_NoJTRST, ENABLE); //�ر�JTAG����
	JTAG_Set(0x02);
	/*** DM9000A ***/
	// CSn1 | WEn | OEn | CMD | nRESET 
/*** DM9000A ***/
	// CSn1 | WEn | OEn | CMD | nRESET 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 \
															| GPIO_Pin_4 | GPIO_Pin_5 ; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP ;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure) ;
	// IRQ_LAN
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 ;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
	GPIO_Init(GPIOA, &GPIO_InitStructure) ;
	// ���ݿ�
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 \
                              | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7 \
                              | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11 \
                              | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15 ; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP ;
	GPIO_Init(GPIOB, &GPIO_InitStructure) ;

//	GPIO_Write(GPIOB,RESET);
//	delay_ms(50);
//	GPIO_Write(GPIOB,SET);

}

void rt_hw_dm9000_init(void)
{  

	RCC_Configuration();
    NVIC_Configuration();
    GPIO_Configuration();
    FSMC_Configuration();

	DM9K_CS=0;//һֱ����Ƭѡ���ţ�ѡ��о
	InitDM9000();

    rt_sem_init(&sem_ack, "tx_ack", 1, RT_IPC_FLAG_FIFO);
    rt_sem_init(&sem_lock, "eth_lock", 1, RT_IPC_FLAG_FIFO);

    dm9000_device.type  = TYPE_DM9000A;
    dm9000_device.mode	= DM9000_AUTO;
    dm9000_device.packet_cnt = 0;
    dm9000_device.queue_packet_len = 0;

    /*
     * SRAM Tx/Rx pointer automatically return to start address,
     * Packet Transmitted, Packet Received
     */
    dm9000_device.imr_all = IMR_PAR | IMR_PTM | IMR_PRM;

    /* set mac address: (only for test) */
    /* oui 00-60-6E DAVICOM SEMICONDUCTOR, INC.*/
    dm9000_device.dev_addr[0] = 0x00;	 //����MAC��ַ
    dm9000_device.dev_addr[1] = 0x60;
    dm9000_device.dev_addr[2] = 0x6E;
#ifdef STM32F10X_HD
    dm9000_device.dev_addr[3] = *(rt_uint8_t*)(0x1FFFF7E8+7);
    dm9000_device.dev_addr[4] = *(rt_uint8_t*)(0x1FFFF7E8+8);
    dm9000_device.dev_addr[5] = *(rt_uint8_t*)(0x1FFFF7E8+9);
#else
    dm9000_device.dev_addr[3] = 0x11;
    dm9000_device.dev_addr[4] = 0x22;
    dm9000_device.dev_addr[5] = 0x33;
#endif

    dm9000_device.parent.parent.init       = rt_dm9000_init;
    dm9000_device.parent.parent.open       = rt_dm9000_open;
    dm9000_device.parent.parent.close      = rt_dm9000_close;
    dm9000_device.parent.parent.read       = rt_dm9000_read;
    dm9000_device.parent.parent.write      = rt_dm9000_write;
    dm9000_device.parent.parent.control    = rt_dm9000_control;
    dm9000_device.parent.parent.user_data    = RT_NULL;

    dm9000_device.parent.eth_rx     = rt_dm9000_rx;
    dm9000_device.parent.eth_tx     = rt_dm9000_tx;

    eth_device_init(&(dm9000_device.parent), "e0");
}

#ifdef RT_USING_FINSH
#include <finsh.h>

void dm9000(void)
{
    rt_kprintf("\n");
    rt_kprintf("NCR   (%02X): %02x\n", DM9000_NCR,  dm9000_io_read(DM9000_NCR));
    rt_kprintf("NSR   (%02X): %02x\n", DM9000_NSR,  dm9000_io_read(DM9000_NSR));
    rt_kprintf("TCR   (%02X): %02x\n", DM9000_TCR,  dm9000_io_read(DM9000_TCR));
    rt_kprintf("TSRI  (%02X): %02x\n", DM9000_TSR1, dm9000_io_read(DM9000_TSR1));
    rt_kprintf("TSRII (%02X): %02x\n", DM9000_TSR2, dm9000_io_read(DM9000_TSR2));
    rt_kprintf("RCR   (%02X): %02x\n", DM9000_RCR,  dm9000_io_read(DM9000_RCR));
    rt_kprintf("RSR   (%02X): %02x\n", DM9000_RSR,  dm9000_io_read(DM9000_RSR));
    rt_kprintf("ORCR  (%02X): %02x\n", DM9000_ROCR, dm9000_io_read(DM9000_ROCR));
    rt_kprintf("CRR   (%02X): %02x\n", DM9000_CHIPR,dm9000_io_read(DM9000_CHIPR));
    rt_kprintf("CSCR  (%02X): %02x\n", DM9000_CSCR, dm9000_io_read(DM9000_CSCR));
    rt_kprintf("RCSSR (%02X): %02x\n", DM9000_RCSSR,dm9000_io_read(DM9000_RCSSR));
    rt_kprintf("ISR   (%02X): %02x\n", DM9000_ISR,  dm9000_io_read(DM9000_ISR));
    rt_kprintf("IMR   (%02X): %02x\n", DM9000_IMR,  dm9000_io_read(DM9000_IMR));
    rt_kprintf("\n");
}
FINSH_FUNCTION_EXPORT(dm9000, dm9000 register dump);

void dm9000_phy_reg(void)
{
    rt_uint32_t i;

    rt_kprintf("dm9000 phy register dump:\r\n");
    for(i=0; i<=30; i++)
    {
        rt_kprintf("%02X : %04X\r\n",i,phy_read(i) );
    }
}
FINSH_FUNCTION_EXPORT(dm9000_phy_reg, dump DM9000 PHY register);

#endif


static void _wait_ms(u16_t count)
{
	u16_t i;

  for ( ; count > 0; count--) {
		for ( i = 10000; i > 0; i--) ;
	}
}

static void _wait_us(u16_t count)
{
	u16_t i;
	while(count--)
		for(i=11; i>0; i--) ;
}


static void write_nicreg(u8_t IOaddr, u8_t val) //io_write
{
	DM9K_IO_OUT();
	DM9K_CMD = 0;
	DM9K_CMD = 1;
	
	_wait_us(10);
	DM9K_IO_W = (u8_t)val;
	DM9K_IO_W = (u8_t)IOaddr;
	DM9K_WE = 0;
	DM9K_WE = 1;
	DM9K_WE = 0;
	DM9K_WE = 1;
}


static void PHY_write(u8_t IOaddr, u16_t val)	  //phy_write
{
	write_nicreg(DM9000_EPCR,0x0a);					// Set EEPROM & PHY Control Reg to write
	write_nicreg(DM9000_EPAR,((IOaddr & 0x3f) | DM9000_PHY));	// Set PHY Address Reg to PHY Address
	write_nicreg(DM9000_EPDRH,(u8_t)(val >> 8));	// write high_byte of PHY data
	write_nicreg(DM9000_EPDRL,(u8_t)(val));			// write low_byte of PHY data
	write_nicreg(DM9000_EPCR,0x00);					// Clear EEPCR
}

static u8 InitDM9000(void)
{
//	int i;
//	/* Ӳ����ʼ�� */
	DM9K_CS = 0;
	DM9K_RES = 0;
	DM9K_WE = 1;
	DM9K_OE = 1;
	DM9K_CMD = 1;
	
	_wait_ms(40);
	DM9K_RES = 1;
	_wait_ms(100);
	DM9K_RES = 0;
	_wait_ms(50);
	DM9K_RES = 1;
	_wait_ms(100);
	

  //1. If the internal PHY is required, the following steps are to active the internal PHY:
  // The default status of the DM9000 is to power down the internal PHY by setting the GPIO0.
  // Since the internal PHY have been powered down, the wakeup procedure will be needed to
  // enable the DM9000.
  dm9000_io_write(DM9000_GPCR, 0x07);    // Power PHY set the GPR to output	//����
  dm9000_io_write(DM9000_GPR,  0x06);	  // Clear the GPIO lines (Led's off)
  _wait_ms(10);

  //2. Program NCR register. Choose normal mode by setting NCR (reg_00h) bit[2:1] = 00h. The
  // system designer can choose the network operation such as setting internal/external PHY,
  // enable wakeup event or choose the full-duplex mode. Please refer to the DM9000 datasheet
  // ch.6.1 about NCR register setting.
  // Reset DM9000 (twice)					 //����
  dm9000_io_write(DM9000_NCR, 0x03);	// Reset  ����λ
  _wait_ms(1);
  dm9000_io_write(DM9000_NCR, 0x00);	// Normal mode ��������ģʽ
  _wait_ms(1);

  dm9000_io_write(DM9000_NCR, 0x03);  //�ڶ�������λ��Ϊ��ȷ������λ��ɳɹ�
  _wait_ms(1);
  dm9000_io_write(DM9000_NCR, 0x00);
  _wait_ms(1);
//
//  //3. Clear TX status by reading NSR register (reg_01h). Bit[2:3] and bit[5] will be automatically
//  // cleared by reading or writing 1. Please refer to the DM9000 datasheet ch.6.2 about NSR
//  // register setting.
  dm9000_io_read(DM9000_NSR);  //����
  _wait_ms(1);

  //4. Read EEPROM (No EEPROM available - use scratchpad instead) data if
  // valid or required. By default, the array will have hard MAC loaded.

  //5. Set Node address 6 bytes from in physical address register (reg_10h~15h).
//  write_nicreg(DM9000_MAC_REG,  MAC_ADDR[0]);
//  write_nicreg(DM9000_MAC_REG+1,MAC_ADDR[1]);
//  write_nicreg(DM9000_MAC_REG+2,MAC_ADDR[2]);
//  write_nicreg(DM9000_MAC_REG+3,MAC_ADDR[3]);
//  write_nicreg(DM9000_MAC_REG+4,MAC_ADDR[4]);
//  write_nicreg(DM9000_MAC_REG+5,MAC_ADDR[5]);
//  //_wait_ms(1);
//
//  //6. Set Hash table 8 bytes from multicast address register (reg_16h~1Dh).
//  dm9000_io_write(DM9000_MLC_REG,  0xff);
//  dm9000_io_write(DM9000_MLC_REG+1,0xff);
//  dm9000_io_write(DM9000_MLC_REG+2,0xff);
//  dm9000_io_write(DM9000_MLC_REG+3,0xff);
//  dm9000_io_write(DM9000_MLC_REG+4,0xff);
//  dm9000_io_write(DM9000_MLC_REG+5,0xff);
//  dm9000_io_write(DM9000_MLC_REG+6,0xff);
//  dm9000_io_write(DM9000_MLC_REG+7,0xff);
  //_wait_ms(1);	

  //7. reset Internal PHY if desired
	PHY_write(DM9000_BMCR, 0x8000);	// PHY reset
	 _wait_ms(1000);
	PHY_write(DM9000_BMCR, 0x1200);	// Auto negotiation
	 _wait_ms(1000);


  //8. Set IMR register (reg_FFh) bit[7]=1 to enable the SRAM read/write pointer which is the
//  // automatic return function of the memory R/W address pointer; also set the receive int mask.
 	dm9000_io_write(DM9000_IMR, 0x81);
        _wait_ms(1);


  if ((dm9000_io_read(DM9000_VID) + (dm9000_io_read(DM9000_VID+1) << 8)) != DM9000_VendID)
	{
		rt_kprintf("\r\nNo chip VID found\r\n");
    return 1;		// No chip found
	}
  // PID is 0x9000
  if ((dm9000_io_read(DM9000_PID) + (dm9000_io_read(DM9000_PID+1) << 8)) != DM9000_ProdID)
	{
		rt_kprintf("\r\nNo chip PID found\r\n");
    return 1;		// No chip found
	}
	
  return 0;
}
