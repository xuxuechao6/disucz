#ifndef __SKELETON_H__
#define __SKELETON_H__

void rt_hw_skeleton_init(void);

#endif
