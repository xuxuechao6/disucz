#ifndef __RTGUI_IMAGE_JPEG_H__
#define __RTGUI_IMAGE_JPEG_H__

#include <rtgui/image.h>

void rtgui_image_jpeg_init(void);

#endif
