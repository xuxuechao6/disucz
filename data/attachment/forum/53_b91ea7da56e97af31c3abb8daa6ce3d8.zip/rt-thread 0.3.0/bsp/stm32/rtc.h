#ifndef __RTC_H__
#define __RTC_H__

void rt_hw_rtc_init(void);

#endif
