#ifndef __DRV_HWTIMER_H__
#define __DRV_HWTIMER_H__


int stm32_hwtimer_init(void);


#endif
