/*
 * File      : application.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2006, RT-Thread Development Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://www.rt-thread.org/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2009-01-05     Bernard      the first version
 * 2014-04-27     Bernard      make code cleanup. 
 */

#include <board.h>
#include <rtthread.h>

#ifdef RT_USING_FINSH
#include <finsh.h>
#endif

#ifdef RT_USING_LWIP
#include <lwip/sys.h>
#include <lwip/api.h>
#include <netif/ethernetif.h>
#include "stm32f4xx_eth.h"
#endif

#ifdef RT_USING_GDB
#include <gdb_stub.h>
#endif
#include "led.h"
#include "user_app.h"
#include "stdio.h"
void rt_init_thread_entry(void* parameter)
{
    /* GDB STUB */
#ifdef RT_USING_GDB
    gdb_set_device("uart6");
    gdb_start();
#endif

    /* LwIP Initialization */
#ifdef RT_USING_LWIP
    {
        extern void lwip_sys_init(void);

        /* register ethernetif device */
        eth_system_device_init();

        rt_hw_stm32_eth_init();

        /* init lwip system */
        lwip_sys_init();
        rt_kprintf("TCP/IP initialized!\n");
		
		
		 dfs_mkfs("elm", "flash0");
    }
#endif
extern void rt_platform_init(void);
	rt_platform_init();	
	
}

static struct rt_thread led1_thread;//�߳̿��ƿ�
ALIGN(RT_ALIGN_SIZE)
static rt_uint8_t rt_led1_thread_stack[1024];//�߳�ջ

static rt_uint32_t led_sw_cnt = 0;  

#ifdef RT_USING_FINSH
FINSH_VAR_EXPORT(led_sw_cnt, finsh_type_uint, led_sw_cnt variable for finsh); 
#endif
static void led1_thread_entry(void* parameter)
{		
	while (1)
	{
		led_sw_cnt++;
		LED1=~LED1;
		LED2=~LED2;
		LED3=~LED3;
		rt_thread_delay(250);
	}
}





int rt_application_init()
{
    rt_thread_t tid;
	/* set idle thread hook */
    rt_thread_idle_sethook(cpu_usage_idle_hook);
	
    tid = rt_thread_create("init",
        rt_init_thread_entry, RT_NULL,
        2048, RT_THREAD_PRIORITY_MAX/3, 20);

    if (tid != RT_NULL)
        rt_thread_startup(tid);
	
	// ������̬�߳�                          
	rt_thread_init(&led1_thread,                 //�߳̿��ƿ�
				  "led1",                        //�߳����֣���shell������Կ���
				  led1_thread_entry,             //�߳���ں���
				  RT_NULL,                       //�߳���ں�������
				  &rt_led1_thread_stack[0],      //�߳�ջ��ʼ��ַ
				  sizeof(rt_led1_thread_stack),  //�߳�ջ��С
				  3,                             //�̵߳����ȼ�
				  20);                                  
  
    rt_thread_startup(&led1_thread);             //�����߳�led1_thread����������
	rt_kprintf("LED initialized!\n");
    return 0;
}

/*@}*/
