/*
 * File      : gpio.h
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2015, RT-Thread Development Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://www.rt-thread.org/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2015-01-05     Bernard      the first version
 */
#ifndef LED_H__
#define LED_H__
#include "sys.h"
/***************LED GPIO����******************/
#define XL_RCC_LED			RCC_AHB1Periph_GPIOE
#define XL_GPIO_LED		GPIOE
#define XL_Pin_LED1		GPIO_Pin_0
#define XL_Pin_LED2		GPIO_Pin_1
#define XL_Pin_LED3		GPIO_Pin_2

#define LED1 PEout(0) 
#define LED2 PDout(8) 
#define LED3 PDout(9) 
void LED_Init(void);
#endif
