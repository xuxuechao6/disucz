/*
 * File      : application.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2006, RT-Thread Development Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://www.rt-thread.org/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2009-01-05     Bernard      the first version
 * 2014-04-27     Bernard      make code cleanup. 
 */

#include <board.h>
#include <rtthread.h>
#include <user_app.h>

#ifdef RT_USING_FINSH
#include <finsh.h>
#endif

#define CPU_USAGE_CALC_TICK	10
#define CPU_USAGE_LOOP		  100

__IO float  cpu_load;
u16 cpu_load_s;
#ifdef RT_USING_FINSH
FINSH_VAR_EXPORT(cpu_load, finsh_type_long, cpu_load variable for finsh); 
FINSH_VAR_EXPORT(cpu_load_s, finsh_type_ushort, cpu_load_s variable for finsh);
#endif
static rt_uint32_t total_count = 0;

void cpu_usage_idle_hook(void)
{
    rt_tick_t tick;
    rt_uint32_t count;
    volatile rt_uint32_t loop;

    if (total_count == 0)
    {
        rt_enter_critical();
			
		/* get total count */
        tick = rt_tick_get();
        while(rt_tick_get() - tick < CPU_USAGE_CALC_TICK)
        {
            total_count ++;
            loop = 0;

            while (loop < CPU_USAGE_LOOP) loop ++;
        }
				
        rt_exit_critical();
    }

    count = 0;
    /* get CPU usage */
    tick = rt_tick_get();
	
    while (rt_tick_get() - tick < CPU_USAGE_CALC_TICK)
    {
        count ++;
        loop  = 0;
        while (loop < CPU_USAGE_LOOP) loop ++;
    }

    /* calculate major and minor */
    if (count < total_count)
    {
		cpu_load = (float)(total_count - count)/(float)total_count*100.0f;	
		cpu_load_s = (u16)(cpu_load*100);
    }
    else
    {
        total_count = count;

        /* no CPU usage */
        cpu_load = 0;
		cpu_load_s = 0;
		 /* no CPU usage */
    }
}


float cpu_load_get(void)
{
    //RT_ASSERT(cpu_load != RT_NULL);
	return cpu_load;
}

