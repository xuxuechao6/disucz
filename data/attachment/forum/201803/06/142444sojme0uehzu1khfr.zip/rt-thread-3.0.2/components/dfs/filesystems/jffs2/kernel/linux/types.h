#ifndef __LINUX_TYPES_H__
#define __LINUX_TYPES_H__

#include "cyg/infra/cyg_type.h"

#define loff_t off_t

#define kvec iovec
#endif /* __LINUX_TYPES_H__ */
