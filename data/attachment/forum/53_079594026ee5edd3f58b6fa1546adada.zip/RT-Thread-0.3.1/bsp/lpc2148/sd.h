#ifndef __SPI_SD_H__
#define __SPI_SD_H__

void rt_hw_sdcard_init(void);

#endif
