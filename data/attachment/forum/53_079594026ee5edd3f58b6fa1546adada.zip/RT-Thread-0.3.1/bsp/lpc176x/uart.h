#ifndef __UART_H__
#define __UART_H__

void rt_hw_uart_init(void);

#endif
