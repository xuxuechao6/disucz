/*
 * File      : startup.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2006, RT-Thread Develop Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://www.rt-thread.org/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2009-02-16     Bernard      first implementation
 */

#include <rthw.h>
#include <rtthread.h>

#include "board.h"

extern void rt_hw_interrupt_init(void);
extern void rt_hw_board_init(void);
extern void rt_serial_init(void);
extern void rt_system_timer_init(void);
extern void rt_system_scheduler_init(void);
extern void rt_thread_idle_init(void);

/**
 * @addtogroup lpc2148
 */

/*@{*/

#ifdef RT_USING_FINSH
extern void finsh_system_init(void);
#endif

extern int  rt_application_init(void);
extern void rt_show_version(void);

/**
 * This function will startup RT-Thread RTOS.
 */
void rtthread_startup(void)
{
	/* init hardware interrupt */
	/* ���������������һ�� ��ʼ���ж�ϵͳ */
	rt_hw_interrupt_init();

	/* init board */
	/* ��ʼ��Ŀ��� */
	rt_hw_board_init();

	/* init hardware serial */
	/* ��ʼ������ */
//	rt_serial_init();

	/* ��ʾ�汾�� */
	//rt_show_version();

	/* init tick */
	rt_system_tick_init();

	/* init kernel object */
	rt_system_object_init();

	/* init timer system */
	rt_system_timer_init();

#ifdef RT_USING_HEAP
	/* init memory system */
	rt_system_heap_init(&__bss_end, 0x40008000);
#endif

	/* init scheduler system */
	rt_system_scheduler_init();

#ifdef RT_USING_HOOK /* if the hook is used */
	/* set idle thread hook */
	rt_thread_idle_sethook(0);
#endif

	/* init application */
	rt_application_init();

#ifdef RT_USING_FINSH /* if finsh is used */
	/* init the finsh input */
	rt_hw_finsh_init();

	/* init finsh */
	finsh_system_init();
#endif

	/* init idle thread */
	rt_thread_idle_init();

	/* start scheduler */
	rt_system_scheduler_start();

	/* never reach here */
	return ;
}

int main (void)
{
	/* invoke rtthread_startup */
	rtthread_startup();

	return 0;
}

/*@}*/
