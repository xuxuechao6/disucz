#include <sc_kernel.h>
#include <sc_types.h>
#include <sc_arch.h>

#include "stm32f10x.h"

/* LED����ض���*/
#define RCC_GPIO_LED RCC_APB2Periph_GPIOD/*LEDʹ�õ�GPIOʱ��*/
#define LEDn 4 /* LED����*/
#define GPIO_LED GPIOD /* LED��ʹ�õ�GPIO��*/

#define DS1_PIN GPIO_Pin_2 /*DS1ʹ�õ�GPIO�ܽ�*/
#define DS2_PIN GPIO_Pin_3 /*DS2ʹ�õ�GPIO�ܽ�*/
#define DS3_PIN GPIO_Pin_4 /*DS3ʹ�õ�GPIO�ܽ�*/
#define DS4_PIN GPIO_Pin_7 /*DS4ʹ�õ�GPIO�ܽ�*/

GPIO_InitTypeDef GPIO_InitStructure;


/*������Ӧ��*/
void Turn_On_LED(u8 LED_NUM)
{
    switch(LED_NUM)
    {
    case 0:
        GPIO_ResetBits(GPIO_LED,DS1_PIN); /*����DS1��*/
        break;
    case 1:
        GPIO_ResetBits(GPIO_LED,DS2_PIN); /*����DS2��*/
        break;
    case 2:
        GPIO_ResetBits(GPIO_LED,DS3_PIN); /*����DS3��*/
        break;
    case 3:
        GPIO_ResetBits(GPIO_LED,DS4_PIN); /*����DS4��*/
        break;
    default:
        GPIO_ResetBits(GPIO_LED,DS1_PIN|DS2_PIN|DS3_PIN|DS4_PIN);
        break;
    }
}

void task_1(void *param)
{
    RCC_APB2PeriphClockCmd(RCC_GPIO_LED, ENABLE);
	GPIO_InitStructure.GPIO_Pin = DS1_PIN|DS2_PIN|DS3_PIN|DS4_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

	GPIO_Init(GPIO_LED, &GPIO_InitStructure); /* LED����ص�GPIO�ڳ�ʼ��*/
	GPIO_SetBits(GPIO_LED,DS1_PIN|DS2_PIN|DS3_PIN|DS4_PIN);

    while (1)
    {
        Turn_On_LED(0);
        Turn_On_LED(1);
        Turn_On_LED(2);
        Turn_On_LED(3);
    }
}

void task_2(void *param)
{
    while (1)
    {
        GPIO_SetBits(GPIO_LED,DS1_PIN|DS2_PIN|DS3_PIN|DS4_PIN);
    }
}

sc_tcb_pst t1_hd;
sc_tcb_pst t2_hd;

/*******************************************************************************
* Function Name  : NVIC_Configuration
* Description    : Configures Vector Table base location.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void NVIC_Configuration(void)
{
#ifdef  VECT_TAB_RAM
	/* Set the Vector Table base location at 0x20000000 */
	NVIC_SetVectorTable(NVIC_VectTab_RAM, 0x0);
#else  /* VECT_TAB_FLASH  */
	/* Set the Vector Table base location at 0x08000000 */
	NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0);
#endif
}

/*******************************************************************************
 * Function Name  : SysTick_Configuration
 * Description    : Configures the SysTick for OS tick.
 * Input          : None
 * Output         : None
 * Return         : None
 *******************************************************************************/
void  SysTick_Configuration(void)
{
	RCC_ClocksTypeDef  rcc_clocks;
	sc_uint32_t         cnts;

	RCC_GetClocksFreq(&rcc_clocks);

	cnts = (sc_uint32_t)rcc_clocks.HCLK_Frequency / SC_TICK_PER_SECOND;

	SysTick_Config(cnts);
	SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK);
}



int main()
{
    sc_interrupt_disable();

    NVIC_Configuration();
    SysTick_Configuration();

    sc_scheduler_init();

    t1_hd = sc_task_new("task1", task_1, SC_NULL, 12, 10, 1024);
    t2_hd = sc_task_new("task2", task_2, SC_NULL, 12, 9, 1024);

    if (t1_hd)
        sc_task_startup(t1_hd);
    if (t2_hd)
        sc_task_startup(t2_hd);

    sc_scheduler_start();
}

