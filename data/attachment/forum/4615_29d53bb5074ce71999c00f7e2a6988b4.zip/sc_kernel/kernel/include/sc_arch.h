#ifndef _ARCH_H_
#define _ARCH_H_

sc_uint32_t sc_interrupt_disable(void);

void sc_interrupt_enable(sc_uint32_t u32Save);

void sc_context_switch(void* old_sp, void* new_sp);

void sc_context_switch_interrupt(void* old_sp, void* new_sp);

void sc_first_context_switch(void);

#endif

