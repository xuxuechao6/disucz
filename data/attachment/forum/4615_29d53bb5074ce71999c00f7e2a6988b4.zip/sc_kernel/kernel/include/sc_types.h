#ifndef _SC_TYPES_H_
#define _SC_TYPES_H_

#include <string.h>
#include <stdlib.h>


/*
**�������Ͷ���
*/
typedef signed      char    sc_int8_t;
typedef unsigned    char    sc_uint8_t;
typedef signed      short   sc_int16_t;
typedef unsigned    short   sc_uint16_t;
typedef signed      long    sc_int32_t;
typedef unsigned    long    sc_uint32_t;
typedef signed      char    sc_bool_t;

struct sc_list_st
{
    struct sc_list_st *prev;
    struct sc_list_st *next;
};
typedef struct sc_list_st* sc_list_pst;

/*
**�ں����Ͷ���
*/
struct sc_tcb_st
{
    void*      stk_point;
    void*      stk_addr;

    void*      task_addr;
    void*      task_param;

    struct sc_list_st      task_list;

    sc_uint32_t     period_tick;
    sc_uint32_t     remain_tick;

    sc_uint8_t      state;
    sc_int8_t       name[8];

    sc_uint8_t      orig_priority;
#if SC_TASK_PRIORITY_MAX > 32
    sc_uint8_t      low_bit;
    sc_uint8_t      high_byte;
#endif
    sc_uint32_t     high_bit;
};
typedef struct sc_tcb_st*  sc_tcb_pst;

/*
 * task state definitions
 */
#define SC_TASK_INIT            0x00              /**< Initialized status   */
#define SC_TASK_READY           0x01              /**< Ready status         */
#define SC_TASK_SUSPEND         0x02              /**< Suspend status       */
#define SC_TASK_RUNNING         0x03              /**< Running status       */

#define SC_NULL                 0

#define SC_OK                   0
#define SC_ERR                  -1

#endif
