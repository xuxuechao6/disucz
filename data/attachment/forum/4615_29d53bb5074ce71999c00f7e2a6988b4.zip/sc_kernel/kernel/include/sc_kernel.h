#ifndef _SC_KERNEL_H_
#define _SC_KERNEL_H_

#include <config.h>
#include <sc_types.h>

extern struct sc_list_st   sc_tcb_list[SC_TASK_PRIORITY_MAX];
extern sc_tcb_pst      sc_running_tcb;

extern sc_uint32_t     sc_ready_group;

void sc_enter_critical(void);

/**
 * This function will unlock the thread scheduler.
 */
void sc_exit_critical(void);

/**
 * This function will be invoked by BSP, when enter interrupt service routine
 *
 * @note please don't invoke this routine in application
 *
 * @see rt_interrupt_leave
 */
void sc_enter_interrupt(void);

/**
 * This function will be invoked by BSP, when leave interrupt service routine
 *
 * @note please don't invoke this routine in application
 *
 * @see rt_interrupt_enter
 */
void sc_exit_interrupt(void);


void sc_scheduler_init(void);

void sc_scheduler_do(void);

void sc_scheduler_start(void);

sc_tcb_pst sc_task_self(void);
sc_tcb_pst sc_task_new(sc_int8_t *name, void (*task)(void *),
                            void *param, sc_uint8_t priority,
                            sc_uint32_t tick, sc_uint32_t stk_size);
sc_int32_t sc_task_startup(sc_tcb_pst task);


void sc_list_init(sc_list_pst l);

#define sc_struct_entry(type, node, member) \
    ((type)((sc_uint8_t*)(node) - (sc_uint32_t)(&(((type)(0))->member))))

void sc_list_detach(sc_list_pst l);

void sc_list_insert_before(sc_list_pst l, sc_list_pst n);

sc_bool_t sc_list_isempty(sc_list_pst l);


#endif
