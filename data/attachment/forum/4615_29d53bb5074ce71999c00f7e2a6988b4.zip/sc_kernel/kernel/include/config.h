#ifndef _CONFIG_H_
#define _CONFIG_H_

#define SC_TASK_PRIORITY_MAX         32
#define SC_TICK_PER_SECOND          100
#endif
