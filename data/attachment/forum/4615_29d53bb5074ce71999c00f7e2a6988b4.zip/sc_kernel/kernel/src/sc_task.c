#include <sc_types.h>
#include <sc_arch.h>
#include <sc_kernel.h>

void* sc_init_task_stack(void *stk_start, void *task_entry,
                                    void *param, void *task_exit)
{
    sc_uint32_t *stk = (sc_uint32_t *)stk_start;

	*(stk)   = 0x01000000L;					/* PSR */
	*(--stk) = (sc_uint32_t)task_entry;		/* entry point, pc */
	*(--stk) = (sc_uint32_t)task_exit;		/* lr */
	*(--stk) = 0x12121212;							/* r12 */
	*(--stk) = 0x03030303;							/* r3 */
	*(--stk) = 0x02020202;							/* r2 */
	*(--stk) = 0x01010101;							/* r1 */
	*(--stk) = (sc_uint32_t)param;	        /* r0 : argument */

	*(--stk) = 0x11111111;							/* r11 */
	*(--stk) = 0x10101010;							/* r10 */
	*(--stk) = 0x09090909;							/* r9 */
	*(--stk) = 0x08080808;							/* r8 */
	*(--stk) = 0x07070707;							/* r7 */
	*(--stk) = 0x06060606;							/* r6 */
	*(--stk) = 0x05050505;							/* r5 */
	*(--stk) = 0x04040404;							/* r4 */

	/* return task's current stack address */
	return stk;
}

sc_tcb_pst sc_task_self(void)
{
    return sc_running_tcb;
}

/*
 * This function will remove a task from system ready queue.
 *
 * @param task the task to be removed
 *
 * @note Please do not invoke this function in user application.
 */
void sc_task_remove(sc_tcb_pst task)
{
	register sc_uint32_t save;

	/* disable interrupt */
	save = sc_interrupt_disable();

    /* remove task from ready list */
    sc_list_detach(&(task->task_list));

	if (sc_list_isempty(&sc_tcb_list[task->orig_priority]))
	{
#if SC_TASK_PRIORITY_MAX > 32
		sc_ready_table[task->high_byte] &= ~(task->low_bit);

        if (!sc_ready_table[task->high_byte])
		{
			sc_ready_group &= ~(task->high_bit);
		}
#else
		sc_ready_group &= ~(task->high_bit);
#endif
	}

	/* enable interrupt */
	sc_interrupt_enable(save);
}

static void sc_task_exit(void)
{
	sc_tcb_pst task;
	register sc_uint32_t save;

	/* get current task */
	task = sc_task_self();

	/* disable interrupt */
	save = sc_interrupt_disable();

	/* remove from schedule */
    sc_task_remove(task);

	/* change stat */
	task->state = SC_TASK_INIT;

	/* enable interrupt */
	sc_interrupt_enable(save);

	/* switch to next task */
	sc_scheduler_do();
}

sc_tcb_pst sc_task_new(sc_int8_t *name, void (*task)(void *),
                            void *param, sc_uint8_t priority,
                            sc_uint32_t tick, sc_uint32_t stk_size)
{
    sc_tcb_pst new_task;

    if (priority >= SC_TASK_PRIORITY_MAX || !task || !tick)
    {
        return SC_NULL;
    }

    new_task = (sc_tcb_pst)malloc(sizeof(struct sc_tcb_st));

    if (!new_task)
        return SC_NULL;

    new_task->stk_addr = malloc(stk_size);

    if (!new_task->stk_addr)
    {
        free(new_task);
        return SC_NULL;
    }

    if (!name)
        strncpy((char *)new_task->name, (char *)name, 8);

    new_task->period_tick   = tick;
    new_task->remain_tick   = tick;
    new_task->task_addr     = task;
    new_task->task_param    = param;

    new_task->orig_priority = priority;
#if SC_TASK_PRIORITY_MAX > 32
    new_task->high_byte = (priority >> 3);
    new_task->high_bit  = 1 << new_task->high_byte;
    new_task->low_bit   = 1 << (priority & 0x07);
#else
    new_task->high_bit  = 1 << new_task->orig_priority;
#endif

    new_task->stk_point
        = sc_init_task_stack(
            (void*)(((char*)(new_task->stk_addr)) + stk_size - 4),
            new_task->task_addr,
            new_task->task_param,
            sc_task_exit);

    sc_list_init(&(new_task->task_list));

    new_task->state     = SC_TASK_INIT;

    return new_task;
}

/**
 * This function will resume a thread and put it to system ready queue.
 *
 * @param thread the thread to be resumed
 *
 * @return the operation status, RT_EOK on OK, -RT_ERROR on error
 *
 */
sc_int32_t sc_task_resume(sc_tcb_pst task)
{
	register sc_int32_t temp;

	/* thread check */
	if (!task || task->state != SC_TASK_SUSPEND)
        return SC_ERR;

	/* disable interrupt */
	temp = sc_interrupt_disable();

	/* remove from suspend list */
    sc_list_detach(&(task->task_list));

    task->state = SC_TASK_READY;

    sc_list_insert_before(&sc_tcb_list[task->orig_priority], &(task->task_list));

#if SC_TASK_PRIORITY_MAX > 32
    sc_ready_table[task->high_byte] |= task->low_bit;
#endif
    sc_ready_group |= task->high_bit;

    /* enable interrupt */
    sc_interrupt_enable(temp);

	return SC_OK;
}

sc_int32_t sc_task_startup(sc_tcb_pst task)
{
    sc_int32_t err = SC_ERR;;

    if (!task || task->state != SC_TASK_INIT)
        return err;

    task->state = SC_TASK_SUSPEND;

    err = sc_task_resume(task);

    if (err != SC_ERR)
    {
        if (sc_task_self() != SC_NULL)
        {
            sc_scheduler_do();
        }
    }

    return err;
}
