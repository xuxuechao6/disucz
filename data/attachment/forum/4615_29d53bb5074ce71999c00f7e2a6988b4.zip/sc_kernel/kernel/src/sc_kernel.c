#include <sc_types.h>
#include <sc_kernel.h>
#include <config.h>
#include <sc_arch.h>

struct sc_list_st   sc_tcb_list[SC_TASK_PRIORITY_MAX];

#if SC_TASK_PRIORITY_MAX > 32
/* maximun priority level, 32 * 8bit = 256 */
sc_uint8_t      sc_ready_table[(SC_TASK_PRIORITY_MAX + 7) >> 3];
#endif

sc_tcb_pst      sc_running_tcb;

sc_uint32_t     sc_ready_group;
sc_uint8_t      sc_running_priority;

/*��������*/
sc_int16_t      sc_scheduler_lock;
/*�ж�Ƕ�ײ���*/
sc_int8_t       sc_interrupt_layer;

/*�л����ڷ���*/
sc_bool_t       sc_switch_interrupt_flag;

/*��old �л��� new*/
void       *sc_old_sp;
void       *sc_new_sp;

const sc_uint8_t sc_lowest_bitmap[] =
{
    /* 00 */ 0, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    /* 10 */ 4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    /* 20 */ 5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    /* 30 */ 4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    /* 40 */ 6, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    /* 50 */ 4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    /* 60 */ 5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    /* 70 */ 4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    /* 80 */ 7, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    /* 90 */ 4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    /* A0 */ 5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    /* B0 */ 4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    /* C0 */ 6, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    /* D0 */ 4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    /* E0 */ 5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
    /* F0 */ 4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0
};

/**
 * This function will lock the thread scheduler.
 */
void sc_enter_critical(void)
{
	register sc_uint32_t save;

	/* disable interrupt */
	save = sc_interrupt_disable();

	/* the maximal number of nest is RT_UINT16_MAX, which is big
	 * enough and does not check here */
	sc_scheduler_lock++;

	/* enable interrupt */
	sc_interrupt_enable(save);
}

/**
 * This function will unlock the thread scheduler.
 */
void sc_exit_critical(void)
{
	register sc_uint32_t save;

	/* disable interrupt */
	save = sc_interrupt_disable();

	sc_scheduler_lock--;

	if (sc_scheduler_lock <= 0)
	{
        sc_scheduler_lock = 0;
		/* enable interrupt */
		sc_interrupt_enable(save);

		sc_scheduler_do();
	}
	else
	{
		/* enable interrupt */
		sc_interrupt_enable(save);
	}
}

/**
 * This function will be invoked by BSP, when enter interrupt service routine
 *
 * @note please don't invoke this routine in application
 *
 * @see rt_interrupt_leave
 */
void sc_enter_interrupt(void)
{
	sc_uint32_t save;

	save = sc_interrupt_disable();
	sc_interrupt_layer++;
	sc_interrupt_enable(save);
}

/**
 * This function will be invoked by BSP, when leave interrupt service routine
 *
 * @note please don't invoke this routine in application
 *
 * @see rt_interrupt_enter
 */
void sc_exit_interrupt(void)
{
	sc_uint32_t save;

	save = sc_interrupt_disable();
	sc_interrupt_layer--;
	sc_interrupt_enable(save);
}

void sc_scheduler_init(void)
{
    sc_uint8_t index;

    sc_running_tcb = SC_NULL;

    sc_scheduler_lock = 0;
    sc_interrupt_layer = 0;
    sc_ready_group = 0;
    sc_switch_interrupt_flag = 0;
    sc_running_priority = SC_TASK_PRIORITY_MAX - 1;
    sc_old_sp = SC_NULL;
    sc_new_sp = SC_NULL;

    for (index=0; index<SC_TASK_PRIORITY_MAX; index++)
        sc_list_init(&sc_tcb_list[index]);

#if SC_TASK_PRIORITY_MAX > 32
    memset(sc_ready_table, 0, sizeof(sc_ready_table));
#endif
}

static sc_uint8_t sc_high_priority(void)
{
    sc_uint8_t  high_priority;

    /* find out the highest priority task */
    if (sc_ready_group & 0xff)
    {
        high_priority = sc_lowest_bitmap[sc_ready_group & 0xff];
    }
    else if (sc_ready_group & 0xff00)
    {
        high_priority = sc_lowest_bitmap[(sc_ready_group >> 8) & 0xff] + 8;
    }
    else if (sc_ready_group & 0xff0000)
    {
        high_priority = sc_lowest_bitmap[(sc_ready_group >> 16) & 0xff] + 16;
    }
    else
    {
        high_priority = sc_lowest_bitmap[(sc_ready_group >> 24) & 0xff] + 24;
    }

#if SC_TASK_PRIORITY_MAX > 32
    high_priority = (high_priority << 3) | sc_lowest_bitmap[sc_ready_table[high_priority]];
#endif

    return high_priority;
}

void sc_scheduler_do(void)
{
    sc_uint32_t save;

    save = sc_interrupt_disable();

    if (!sc_scheduler_lock)
    {
        sc_uint8_t  high_priority = sc_high_priority();
        sc_tcb_pst  new_tcb = sc_struct_entry(sc_tcb_pst,
                sc_tcb_list[high_priority].next, task_list);

        if (new_tcb != sc_running_tcb)
        {
	        sc_tcb_pst old_tcb = sc_running_tcb;

            sc_running_tcb = new_tcb;
            sc_running_priority = high_priority;

            if (!sc_interrupt_layer)
			{
				sc_context_switch(old_tcb->stk_point, new_tcb->stk_point);
			}
			else
			{
				sc_context_switch_interrupt(old_tcb->stk_point, new_tcb->stk_point);
			}
        }

    }

    sc_interrupt_enable(save);
}

void sc_scheduler_start(void)
{
    sc_uint8_t high_priority =  sc_high_priority();

    sc_running_priority = high_priority;

    sc_running_tcb      = sc_struct_entry(sc_tcb_pst,
        sc_tcb_list[high_priority].next, task_list);

    sc_new_sp = sc_running_tcb->stk_point;

    sc_first_context_switch();
}

