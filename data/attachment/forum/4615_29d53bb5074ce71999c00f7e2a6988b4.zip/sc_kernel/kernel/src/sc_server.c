#include <sc_types.h>

void sc_list_init(sc_list_pst l)
{
	l->next = l->prev = l;
}

void sc_list_detach(sc_list_pst l)
{
    l->prev->next = l->next;
    l->next->prev = l->prev;

    l->prev = l->next = l;
}

void sc_list_insert_before(sc_list_pst l, sc_list_pst n)
{
	l->prev->next = n;
	n->prev = l->prev;

	l->prev = n;
	n->next = l;
}

sc_bool_t sc_list_isempty(sc_list_pst l)
{
    return l->next == l->prev;
}
