#ifndef _TIMER_H_
#define _TIMER_H_

#include <sc_types.h>
#include <sc_kernel.h>
#include <sc_arch.h>

void sc_timer_tick(void)
{
    sc_tcb_pst current_task;

    current_task = sc_task_self();
    current_task->remain_tick--;

    if (!current_task->remain_tick)
    {
        sc_uint32_t save;

        current_task->remain_tick = current_task->period_tick;

        save = sc_interrupt_disable();

        if (SC_TASK_READY == current_task->state
            && !sc_list_isempty(&(current_task->task_list)))
        {
#if 0
            /* ��ǰ������Ӿ����б�ͷ��� */
            sc_list_detach(&(current_task->task_list));

            /* ����ǰ�����������е�ĩβ */
            sc_list_insert_before(&sc_tcb_list[current_task->orig_priority],
                current_task->task_list);

            sc_interrupt_enable(save);

            sc_scheduler_do();
#else
            if (current_task->task_list.next
                != &(sc_tcb_list[current_task->orig_priority]))
            {
                sc_running_tcb = sc_struct_entry(sc_tcb_pst,
                    current_task->task_list.next, task_list);
            }
            else
            {
                sc_running_tcb = sc_struct_entry(sc_tcb_pst,
                    current_task->task_list.next->next, task_list);
            }

            sc_context_switch_interrupt(current_task->stk_point, sc_running_tcb->stk_point);
#endif
        }

        sc_interrupt_enable(save);
    }
}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
void SysTick_Handler(void)
{
    sc_enter_interrupt();

    sc_timer_tick();

    sc_exit_interrupt();
}

#endif

