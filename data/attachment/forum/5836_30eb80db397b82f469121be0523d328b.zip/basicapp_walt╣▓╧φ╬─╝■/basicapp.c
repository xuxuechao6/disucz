#include <rtthread.h>

static int a = 0;
static int b = 1000000;
int c = 100;

int add_walt(int a,int b){
	return (a+b);
}

int main(void)
{
	int i;
	int *ptr=&b;
	i=add_walt(b,5);
 	*ptr =5;
	return 0;
}

