/*
 * File      : sd.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2006, 2007, RT-Thread Develop Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://www.rt-thread.org/license/LICENSE
 *
 * Change Logs:
 * Date           Author      Notes
 * 2007-12-02     Yi.Qiu      the first version
 * 2010-01-01     Bernard     Modify for mini2440
 */

#include "cfcard.h"
#include "ep93xx-regs.h"
//__swi (0x2600) unsigned int timeNow (void);

#define CF_WP		0x01
#define CF_MCD1		0x02
#define CF_MCD2		0x04
#define CF_MCBVD1	0x08
#define CF_MCBVD2	0x10
#define CF_VS1		0x20
#define CF_READY 	0x40
#define CF_VS2 		0x80

#define CF_POWER 	0x01 //active low

#define CF_IO_space			PCMCIA_BASE_PHYS+0x0
#define CF_undefined_space	PCMCIA_BASE_PHYS+0x4000000
#define CF_attribute_space	PCMCIA_BASE_PHYS+0x8000000
#define CF_memory_space		PCMCIA_BASE_PHYS+0xC000000

//;memory mapped decoding



#define reg_evendata	0x0
#define reg_feature	0x1 	//
#define reg_error	0x1 	//;feature reg when write
#define reg_sectorcnt	0x2
#define reg_sectorno	0x3
#define reg_cylinderlo	0x4
#define reg_cylinderhi	0x5
#define reg_headno	0x6
#define reg_status	0x7	//;command reg when write
#define reg_command	0x7	//;command reg when write
#define reg_altstat	0xe	//;command reg when write
#define reg_dupevendata	0x8
#define reg_dupodddata	0x9
#define reg_devctrl	0xe	//;command reg when write


//;status reg bit definition
#define status_BUSY	7	//;when set other status bit invalid
#define status_RDY	6	//;cleared at power up until ready
#define status_DWF	5	//;write fault
#define status_DSC	4	//;CF ready
#define status_DRQ	3	//;Data request
#define status_CORR	2	//;Data correction occured
#define status_IDX	1	//;always 0
#define status_ERR	0	//;previous command error


/* ATA command */
#define CMD_RESET		0x08	/* DEVICE RESET */
#define CMD_READ		0x20	/* READ SECTOR(S) */
#define CMD_WRITE		0x30	/* WRITE SECTOR(S) */
#define CMD_IDENTIFY	0xEC	/* DEVICE IDENTIFY */
#define CMD_SETFEATURES	0xEF	/* SET FEATURES */

/* ATA register bit definitions */
#define	LBA				0xE0
#define	BUSY			0x80
#define	DRDY			0x40
#define	DF				0x20
#define	DRQ				0x08
#define	ERR				0x01
#define	SRST			0x40
#define	nIEN			0x20

extern rt_uint32_t PCLK;
volatile rt_uint32_t rd_cnt;
volatile rt_uint32_t wt_cnt;
volatile rt_int32_t RCA;



//===========================Private function==================================
double timeNow (void) 
{
	volatile double counter;
	unsigned long long temp;

	temp = (readl(TIMER4VALUEHIGH)&0xFF);
	temp = (temp<<32);
	temp|= readl(TIMER4VALUELOW);
	counter = ((double)temp)/983.04;
	return counter;
}


static void pcmcia_delay(rt_uint32_t ms)
{
	ms = timeNow()+ms;
	//ms *= 7326;
	while(ms<timeNow());
}

/*----------------------------------------------------------------------------
 *  	Check card present
 *---------------------------------------------------------------------------*/

unsigned int pcmcia_isAttached(void)
{

	if (readl(GPIO_PFDR)&(CF_MCD1|CF_MCD1))
	{

		rt_kprintf("no pcmcia card detected\n");
		return 0;
	}
	else
	{
		//rt_kprintf(KERN_DEBUG "pcmcia card attached\n");
		return 1;
	}


}

/*----------------------------------------------------------------------------
 *  	Check voltage
 *---------------------------------------------------------------------------*/

unsigned int pcmcia_is33v(void)
{
	if (readl(GPIO_PFDR)&(CF_VS1))
	{
		rt_kprintf("CF card is not 3.3v\n");
		return 0;
	}
	else
	{
		//rt_kprintf("is 3.3v\n");
		return 1;
	}	

}


/*----------------------------------------------------------------------------
 *  	Check write protect
 *---------------------------------------------------------------------------*/

 unsigned int pcmcia_isProtected(void)
{
	if (readl(GPIO_PFDR)&(CF_WP))
	{
		rt_kprintf("CF card is Write Protected\n");
		return 1;
	}
	else
	{
		//rt_kprintf(KERN_DEBUG "Write Enabled\n");
		return 0;
	}	

}

/*----------------------------------------------------------------------------
 *  	Turn on card
 *---------------------------------------------------------------------------*/
 unsigned int pcmcia_powerOn(unsigned int on)
{

	if (on && pcmcia_is33v())
	{
		writel((readl(GPIO_PBDDR)|CF_POWER),GPIO_PBDDR);
	    writel((readl(GPIO_PBDR) &~CF_POWER),GPIO_PBDR);
		//rt_kprintf("CF card power on\n");
		return 1;
	}
	else
	{
		if (!pcmcia_is33v())
		{
		 	rt_kprintf("card is not compatible wrong voltage\n");
		}
		writel((readl(GPIO_PBDDR)|CF_POWER),GPIO_PBDDR);
	    writel((readl(GPIO_PBDR)|CF_POWER),GPIO_PBDR);
		//rt_kprintf("CF card power off\n");
		return 0;
	}
	
}


/*----------------------------------------------------------------------------
 *  	poll ready
 *---------------------------------------------------------------------------*/
#define RDY_TIMEOUT		1000 //ms
unsigned int pcmcia_ready(void)
{
	double dTimeout = timeNow()+RDY_TIMEOUT;
	do{
		if(readl(GPIO_PFDR)&(CF_READY))
		{
		//	rt_kprintf(KERN_DEBUG "CF ready\n");
			return 0;
		}

	}while(timeNow()<dTimeout);
	rt_kprintf("CF not Ready\n");
	return 1;
}

/*----------------------------------------------------------------------------
 *       CID info
 *---------------------------------------------------------------------------*/
unsigned int pcmica_CIS(void)
{
//	char *CISinfo;
//	int i;
int test;
	
//	CISinfo = (char)0x48000000;

		test =  (*((volatile unsigned int *) (0x48000000)))	;

	//for(i = 0;i<=168;i++){
		rt_kprintf("%08X\n",test);
	//}
	return 0;


		

}


/*----------------------------------------------------------------------------
 *       pcmcia_debug
 *---------------------------------------------------------------------------*/
unsigned int pcmcia_debug(void)
{
 	if(pcmcia_isAttached())
   	{
   		pcmcia_isProtected();
		pcmcia_powerOn(1);
   		pcmcia_ready();

//		pcmica_CIS();
   	}
	return 0;
}

/*-----------------------------------------------------------------------*/
/*  for Data Ready                                                   */
/*-----------------------------------------------------------------------*/

static unsigned int wait_data (void)
{
	double w;
	char s;

	w= timeNow()+RDY_TIMEOUT;
//	cli(); Timer = 1000; sei();	/* Time out = 10 sec */
	do {

//		cli(); w = Timer; sei();
		if (w<timeNow()) return 0;			/* Abort when timeout occured */
		s = (*((volatile unsigned char*)(CF_memory_space+reg_status))) ;//read_ata(REG_STATUS);		/* Get status */
//rt_kprintf("wait %x\n",s);

	} while ((s & ((1<<status_BUSY)|(1<<status_DRQ))) != (1<<status_DRQ));	/* Wait for BSY goes low and DRQ goes high */

	//read_ata(REG_ALTSTAT);
	s = (*((volatile unsigned char*)(CF_memory_space+ reg_altstat)));
	return 1;
}

//================================= Public Function ================================

void delay(int timeout)
{
	timeout = timeNow()+timeout;
	do
	{
	}while(timeNow()<timeout);
}
/*----------------------------------------------------------------------------
 *       init_pcmcia
 *---------------------------------------------------------------------------*/
 // function to initialize the pcmcia
static rt_uint8_t pcmcia_init(void)
 {
 	int timeout=0; 
	
 	writel( ((0<<31)+(0x20<<16)+(0x4<<8)+(0x7)), SMC_PCAttribute ); 
 	writel( ((0<<31)+(0x20<<16)+(0x4<<8)+(0x7)), SMC_PCCommon ); 
 	writel( ((0<<31)+(0x11<<16)+(0x3<<8)+(0x4)), SMC_PCIO ); 
 	writel( ((1<<4)+(1<<2)+(1)), SMC_PCMCIACtrl ); 
 	
 	
 	if(pcmcia_isAttached())
 	{
		rt_kprintf("CF card attached\n");
	}
	else
	{
		rt_kprintf("Initialize fail\nNo Card assertion\n");
		return RT_ERROR;
	}
 	
 	/*power off*/
 	pcmcia_powerOn(0);
 	delay(1000); /*100ms*/
 	
 	/*power on*/
 	pcmcia_powerOn(1);
 	delay(1000); /*10ms*/
 	
 	/*enable control signals*/
 	writel(0,GPIO_PFDDR); //set all as input
 	delay(50); /*50ms*/
 	
 	/*reset pc card*/
 	writel((1<<2)+(1<<0),SMC_PCMCIACtrl);
 	delay(50);

 	(*((volatile unsigned char*)(CF_memory_space+reg_headno))) = LBA;
 	/*wait for card goes ready*/
 	timeout = timeNow()+2000;
 	do{
 		if (timeNow()>timeout) return RT_ETIMEOUT;
	}while ((*((volatile unsigned char*)(CF_memory_space+reg_status))) & BUSY);

	/*software reset*/
	(*((volatile unsigned char*)(CF_memory_space+reg_devctrl))) = SRST | nIEN;
	delay(20);

	/*release software reset*/
	(*((volatile unsigned char*)(CF_memory_space+reg_devctrl))) = nIEN;
 	delay(20);

 	/*wait for card goes ready*/
 	timeout = timeNow()+2000;
 	do{
 		if (timeNow()>timeout) return RT_ETIMEOUT ;
	}while (((*((volatile unsigned char*)(CF_memory_space+reg_status))) & (DRDY|BUSY)) != DRDY);

	/*select 8bit pio tx mode*/
	(*((volatile unsigned char*)(CF_memory_space+reg_feature))) = 0x01;
	(*((volatile unsigned char*)(CF_memory_space+reg_command))) = CMD_SETFEATURES;

	/*wait for card goes ready*/
 	timeout = timeNow()+1000;
 	do{
 		if (timeNow()>timeout) return RT_ETIMEOUT;
	}while ((*((volatile unsigned char*)(CF_memory_space+reg_status))) & BUSY);


	return RT_EOK;// pcmcia_reset();
 }

 // function to initialize the pcmcia
 unsigned int pcmcia_reset(void)
 {

	if(pcmcia_isAttached())
   	{

	    pcmcia_powerOn(0);
		delay(1000);
		pcmcia_powerOn(1);
   		delay(1000);
   		rt_kprintf("CF reset\n");

   		pcmcia_ready();
	    return 0;
			//		  rt_kprintf("test");
	//	pcmica_CIS();
   	}
	else
	{
		pcmcia_powerOn(0);
		return 1;
	}

 }

//;======================== write sector(s) ===================================

static rt_size_t pcmcia_write_sector (rt_uint32_t drv,const rt_uint8_t *buf, rt_uint32_t sect, rt_size_t cnt)
{
//	char *ptr;
int c;
int dummy;

//if (pcmcia_ready()) return RT_ERROR;

		(*((volatile unsigned char*)(CF_memory_space+reg_sectorcnt))) = cnt;
		(*((volatile unsigned char*)(CF_memory_space+reg_sectorno))) = (sect>>0);
		(*((volatile unsigned char*)(CF_memory_space+reg_cylinderlo))) = (sect>>8);
		(*((volatile unsigned char*)(CF_memory_space+reg_cylinderhi))) = (sect>>16);
		(*((volatile unsigned char*)(CF_memory_space+reg_headno))) = (((sect>>24)&0x0F)|LBA);
		(*((volatile unsigned char*)(CF_memory_space+reg_status))) = CMD_WRITE;
		//	rt_kprintf("write sector %d buff %x cnt %d\n",sect,buf,cnt);
		do {
			if (!wait_data()) return RT_ERROR;
			//wait_data();
			c = 512;//128;
			do {
				(*((volatile unsigned char*)(CF_memory_space))) = *buf++;
			} while (--c);
		} while (--cnt);

	//   	Timer = 100;
	do {
	//	if (!Timer) return RES_ERROR;
	} while (((*((volatile unsigned char*)(CF_memory_space+reg_status))) & (1<<status_BUSY)));

dummy=(*((volatile unsigned char*)(CF_memory_space+ reg_altstat)));
dummy=(*((volatile unsigned char*)(CF_memory_space+ reg_status)));

	return cnt;
}
//;=========================end write sector(s)========================================

//;======================== read sector(s) ===================================
 //read_sector (0, buf, sect, cnt);
static rt_size_t pcmcia_read_sector (rt_uint32_t drv,rt_uint8_t *buf, rt_uint32_t sect, rt_size_t cnt)
{
//	char *ptr;
int c;
int dummy;

//	if (pcmcia_ready()) return RT_ERROR;

		(*((volatile unsigned char*)(CF_memory_space+reg_sectorcnt))) = cnt;
		(*((volatile unsigned char*)(CF_memory_space+reg_sectorno))) = (sect>>0);
		(*((volatile unsigned char*)(CF_memory_space+reg_cylinderlo))) = (sect>>8);
		(*((volatile unsigned char*)(CF_memory_space+reg_cylinderhi))) = (sect>>16);
		(*((volatile unsigned char*)(CF_memory_space+reg_headno))) = (((sect>>24)&0x0F)|LBA);
		(*((volatile unsigned char*)(CF_memory_space+reg_status))) = CMD_READ;
		//rt_kprintf("Read sector %d buff %x cnt %d\n",sect,buf,cnt);
		do {
			if (!wait_data()) return RT_ERROR;
			//wait_data();
			c = 512;//128;
			do {
				*buf++=(*((volatile unsigned char*)(CF_memory_space)));
			//	if(!(c%16))rt_kprintf("\n%X : ",512-c);
			//	rt_kprintf("%02X ",*(buf-1));
			} while (--c);
		} while (--cnt);

	//   	Timer = 100;
	do {
	//	if (!Timer) return RES_ERROR;
	} while (((*((volatile unsigned char*)(CF_memory_space+reg_status))) & (1<<status_BUSY)));

dummy=(*((volatile unsigned char*)(CF_memory_space+ reg_altstat)));
dummy=(*((volatile unsigned char*)(CF_memory_space+ reg_status)));

	return cnt;
}
//;=========================end read sector(s)========================================


//;======================== read drv info ===================================
 //read_sector (0, buf, sect, cnt);
 //drive_ident ( drv, temp);
unsigned char pcmcia_drv_info (rt_uint32_t drv,rt_uint8_t *buf)
{
//	char *ptr;
int c;
unsigned int sect =0;
unsigned int cnt =0;

		if (pcmcia_ready()) return RT_ERROR;

		(*((volatile unsigned char*)(CF_memory_space+reg_sectorcnt))) = cnt;
		(*((volatile unsigned char*)(CF_memory_space+reg_sectorno))) = (sect>>0);
		(*((volatile unsigned char*)(CF_memory_space+reg_cylinderlo))) = (sect>>8);
		(*((volatile unsigned char*)(CF_memory_space+reg_cylinderhi))) = (sect>>16);
		(*((volatile unsigned char*)(CF_memory_space+reg_headno))) = (((sect>>24)&0x0F)|0xE0);
		(*((volatile unsigned char*)(CF_memory_space+reg_status))) = 0xEC;

			if (!wait_data()) return RT_ERROR;
			//wait_data();
			c = 512;//128;
			do {
				*buf++=(*((volatile unsigned char*)(CF_memory_space)));
			} while (--c);


	//   	Timer = 100;
	do {
	//	if (!Timer) return RES_ERROR;

	} while (((*((volatile unsigned char*)(CF_memory_space+reg_status))) & (1<<status_BUSY)));



}
//;=========================end read drv info ========================================



#ifdef RT_USING_DFS
/* RT-Thread Device Driver Interface */
#include <rtthread.h>

#include <dfs_fs.h>

struct rt_device sdcard_device[4];
struct dfs_partition part[4];

static rt_err_t rt_sdcard_init(rt_device_t dev)
{
	return RT_EOK;
}

static rt_err_t rt_sdcard_open(rt_device_t dev, rt_uint16_t oflag)
{
	return RT_EOK;
}

static rt_err_t rt_sdcard_close(rt_device_t dev)
{
	return RT_EOK;
}

static rt_err_t rt_sdcard_control(rt_device_t dev, rt_uint8_t cmd, void *args)
{
	return RT_EOK;
}

static rt_size_t rt_sdcard_read(rt_device_t dev, rt_off_t pos, void* buffer, rt_size_t size)
{
	int i;
	struct dfs_partition *part = (struct dfs_partition *)dev->user_data;

	if ( dev == RT_NULL )
	{
		rt_set_errno(-DFS_STATUS_EINVAL);
		return 0;
	}

	/* read all sectors */
//	for (i = 0; i < size; i ++)
//	{
//		rt_sem_take(part->lock, RT_WAITING_FOREVER);
//		sd_readblock((part->offset + i + pos)*SECTOR_SIZE,
//			(rt_uint8_t*)((rt_uint8_t*)buffer + i * SECTOR_SIZE));
//		rt_sem_release(part->lock);
//	}
	rt_sem_take(part->lock, RT_WAITING_FOREVER);
	pcmcia_read_sector (0,(rt_uint8_t*)buffer, part->offset+pos, size);
	rt_sem_release(part->lock);

	/* the length of reading must align to SECTOR SIZE */
	return size;
}

static rt_size_t rt_sdcard_write (rt_device_t dev, rt_off_t pos, const void* buffer, rt_size_t size)
{
	int i;
	struct dfs_partition *part = (struct dfs_partition *)dev->user_data;

	if ( dev == RT_NULL )
	{
		rt_set_errno(-DFS_STATUS_EINVAL);
		return 0;
	}

	/* read all sectors */
//	for (i = 0; i < size; i++)
//	{
//		rt_sem_take(part->lock, RT_WAITING_FOREVER);
//		sd_writeblock((part->offset + i + pos)*SECTOR_SIZE,
//			(rt_uint8_t*)((rt_uint8_t*)buffer + i * SECTOR_SIZE));
//		rt_sem_release(part->lock);
//	}
	rt_sem_take(part->lock, RT_WAITING_FOREVER);
	pcmcia_write_sector (0,(rt_uint8_t*)buffer,part->offset+pos, size);
	rt_sem_release(part->lock);

	/* the length of reading must align to SECTOR SIZE */
	return size;
}

void rt_hw_sdcard_init(void)
{
	rt_uint8_t i, status;
	rt_uint8_t *sector;
	char dname[4];
	char sname[8];

//	/* Enable PCLK into SDI Block */
//	CLKCON |= 1 << 9;
//
//	/* Setup GPIO as SD and SDCMD, SDDAT[3:0] Pull up En */
//	GPEUP  = GPEUP  & (~(0x3f << 5))   | (0x01 << 5);
//	GPECON = GPECON & (~(0xfff << 10)) | (0xaaa << 10);
//
//	RCA = 0;

	//if (sd_init() == RT_EOK)
	if (pcmcia_init() == RT_EOK)
	{
		/* get the first sector to read partition table */
		sector = (rt_uint8_t*) rt_malloc (512);
		if (sector == RT_NULL)
		{
			rt_kprintf("allocate partition sector buffer failed\n");
			return;
		}
		//status = sd_readblock(0, sector);
		//static rt_uint8_t sd_readblock(rt_uint32_t address, rt_uint8_t* buf)
		status = pcmcia_read_sector(0,sector,0,1);
		//static rt_size_t pcmcia_read_sector (rt_uint32_t drv,rt_uint8_t *buf, rt_uint32_t sect, rt_size_t cnt)
		if (status == RT_EOK)
		{
			for(i=0; i<4; i++)
			{
				/* get the first partition */
				status = dfs_filesystem_get_partition(&part[i], sector, i);
				if (status == RT_EOK)
				{
					rt_snprintf(dname, 4, "sd%d",  i);
					rt_snprintf(sname, 8, "sem_sd%d",  i);
					part[i].lock = rt_sem_create(sname, 1, RT_IPC_FLAG_FIFO);

					/* register sdcard device */
					sdcard_device[i].type  = RT_Device_Class_Block;					
					sdcard_device[i].init = rt_sdcard_init;
					sdcard_device[i].open = rt_sdcard_open;
					sdcard_device[i].close = rt_sdcard_close;
					sdcard_device[i].read = rt_sdcard_read;
					sdcard_device[i].write = rt_sdcard_write;
					sdcard_device[i].control = rt_sdcard_control;
					sdcard_device[i].user_data = &part[i];

					rt_device_register(&sdcard_device[i], dname,
						RT_DEVICE_FLAG_RDWR | RT_DEVICE_FLAG_REMOVABLE | RT_DEVICE_FLAG_STANDALONE);
				}
				else
				{
					if(i == 0)
					{
						/* there is no partition table */
						part[0].offset = 0;
						part[0].size   = 0;
						part[0].lock = rt_sem_create("sem_sd0", 1, RT_IPC_FLAG_FIFO);

						/* register sdcard device */
						sdcard_device[0].type  = RT_Device_Class_Block;								
						sdcard_device[0].init = rt_sdcard_init;
						sdcard_device[0].open = rt_sdcard_open;
						sdcard_device[0].close = rt_sdcard_close;
						sdcard_device[0].read = rt_sdcard_read;
						sdcard_device[0].write = rt_sdcard_write;
						sdcard_device[0].control = rt_sdcard_control;
						sdcard_device[0].user_data = &part[0];

						rt_device_register(&sdcard_device[0], "sd0",
							RT_DEVICE_FLAG_RDWR | RT_DEVICE_FLAG_REMOVABLE | RT_DEVICE_FLAG_STANDALONE);

						break;
					}
				}
			}
		}
		else
		{
			rt_kprintf("read CF card first sector failed\n");
		}

		/* release sector buffer */
		rt_free(sector);

		return;
	}
	else
	{
		rt_kprintf("CF card init failed\n");
	}
}

 /*
 * �N?�M?�G���??�Ҥl
 *
 * ??�Ҥl�t�ܤF�p��??�@?���A�S?�O?��?��??�p��ާ@�C
 */

 #include <rtthread.h>
 #include <dfs_posix.h> /* ?�ݭn�ϥΤ��ާ@?�A�ݭn�]�t???���*/

 #define TEST_FN "/test.dat"

 /* ??�Ϊ�?�u�M??*/
 static char onemb_data[1*1024*1024],test_data[120], buffer[120];

 /* ���????*/
 void readwrite(const char* filename)
 {
 int fd;
 int index, length;
 double timeTaken;
 
  /* �u?& ?�إ�?*/
 fd = open("/test1MB.txt", O_WRONLY| O_CREAT| O_TRUNC, 0);
 if (fd < 0)
 {
 rt_kprintf("open file for write failed\n");
 return;
 }

 /* ��??�J?�u*/
 for (index = 0; index < sizeof(onemb_data); index ++)
 {
 onemb_data[index] = index;
 }


 /* ?�J?�u*/
 timeTaken = timeNow();
 length = write(fd, onemb_data, sizeof(onemb_data));
 timeTaken = timeNow() - timeTaken;
 rt_kprintf("time taken to write 1MB %d ms\n",(unsigned int)timeTaken);
 if (length != sizeof(onemb_data))
 {
 rt_kprintf("write data failed\n");
 close(fd);
 return;
 }

 /* ??���*/
 close(fd);
 

 /* �u?& ?�إ�?*/
 fd = open(TEST_FN, O_WRONLY| O_CREAT| O_TRUNC, 0);
 if (fd < 0)
 {
 rt_kprintf("open file for write failed\n");
 return;
 }

 /* ��??�J?�u*/
 for (index = 0; index < sizeof(test_data); index ++)
 {
 test_data[index] = index + 27;
 }


 /* ?�J?�u*/
 length = write(fd, test_data, sizeof(test_data));
 if (length != sizeof(test_data))
 {
 rt_kprintf("write data failed\n");
 close(fd);
 return;
 }

 /* ??���*/
 close(fd);
 

 /* �u?�}�b�����K�[��?*/
 fd = open(TEST_FN, O_WRONLY | O_CREAT | O_APPEND, 0);
 if (fd < 0)
 {
 rt_kprintf("open file for append write failed\n");
 return;
 }

 length = write(fd, test_data, sizeof(test_data));
 if (length != sizeof(test_data))
 {
 rt_kprintf("append write data failed\n");
 close(fd);
 return;
 }
 /* ??���*/
 close(fd);

 /* �u?��??��?�u��?*/
 fd = open(TEST_FN, O_RDONLY, 0);
 if (fd < 0)
 {
 rt_kprintf("check: open file for read failed\n");
 return;
 }

 /* ?��?�u(???�Ĥ@��?�J��?�u) */
 length = read(fd, buffer, sizeof(buffer));
 if (length != sizeof(buffer))
 {
 rt_kprintf("check: read file failed\n");
 close(fd);
 return;
 }

 /* ?�d?�u�O�_����*/
 for (index = 0; index < sizeof(test_data); index ++)
 {
 if (test_data[index] != buffer[index])
 {
 rt_kprintf("check: check data failed at %d\n", index);
 close(fd);
 return;
 }
 }

 /* ?��?�u(???�ĤG��?�J��?�u) */
 length = read(fd, buffer, sizeof(buffer));
 if (length != sizeof(buffer))
 {
 rt_kprintf("check: read file failed\n");
 close(fd);
 return;
 }

 /* ?�d?�u�O�_����*/
 for (index = 0; index < sizeof(test_data); index ++)
 {
 if (test_data[index] != buffer[index])
 {
 rt_kprintf("check: check data failed at %d\n", index);
 close(fd);
 return;
 }
 }

 /* ?�d?�u��?�A??���*/
 close(fd);
 /* ���L?�G*/
 rt_kprintf("read/write done.\n");
 }

 #ifdef RT_USING_FINSH
 #include <finsh.h>
 /* ?�X��?��finsh shell�R�O�椤*/
 FINSH_FUNCTION_EXPORT(readwrite, perform file read and write test);
 #endif

#endif
