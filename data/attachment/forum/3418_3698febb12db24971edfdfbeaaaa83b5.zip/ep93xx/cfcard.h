#ifndef __SDCARD_H
#define __SDCARD_H

#include  <s3c24x0.h>

#define INICLK	300000
#define SDCLK	24000000	//PCLK=49.392MHz
#define MMCCLK	15000000	//PCLK=49.392MHz

#endif

