#include <rtthread.h>
#include "emac.h"
#include "lwipopts.h"
#include "ep93xx-regs.h"
#include <netif/ethernetif.h>

#define EMAC_PHY_AUTO		0
#define EMAC_PHY_10MBIT		1
#define EMAC_PHY_100MBIT	2

#define MAX_ADDR_LEN 6


/* Local variables */
/*----------------------------------------------------------------------------
 * Some definitions belong to the operation of this driver.
 * You should understand how it affect to driver before any modification.
 *--------------------------------------------------------------------------*/

/****  Interrupt Sources in Use  *******************************************/
#define  Default_IntSrc  (IntEn_RxMIE|IntEn_RxSQIE|IntEn_TxLEIE|IntEn_TIE|IntEn_TxSQIE|IntEn_RxEOFIE|IntEn_RxEOBIE|IntEn_RxHDRIE)

//#define  Default_IntSrc  (IntEn_TxSQIE|IntEn_RxEOFIE|IntEn_RxEOBIE|IntEn_RxHDRIE)

/****  Length of Device Queue in number of entries
       (must be less than or equal to 255)  ********************************/
#define  LEN_QueRxDesc  64             /*length of Rx Descriptor Queue (4 or bigger) Must be power of 2.*/
#define  LEN_QueRxSts   LEN_QueRxDesc  /*length of Rx Status Queue*/
#define  LEN_QueTxDesc  8              /*length of Tx Descriptor Queue (4 or bigger) Must be power of 2.*/
#define  LEN_QueTxSts   LEN_QueTxDesc  /*length of Tx Status Queue*/

/****  Tx Queue fill-up level control  *************************************/
#define  LVL_TxStop    LEN_QueTxDesc - 2    /*level to ask the stack to stop Tx*/
#define  LVL_TxResume  2   /*level to ask the stack to resume Tx*/

/****  Rx Buffer length in bytes  ******************************************/
#define  LEN_RxBuf  (1518+2+16)  /*length of Rx buffer, must be 4-byte aligned*/
#define  LEN_TxBuf   LEN_RxBuf

/*----------------------------------------------------------------------------
 * MACRO for ease
 *--------------------------------------------------------------------------*/
#define  Align32(a)  (((unsigned int)(a)+3)&~0x03)  /*32bit address alignment*/
#define  IdxNext(idxCur,len)  (((idxCur)+1)%(len))  /*calc next array index number*/

/****  malloc/free routine for DMA buffer  **********************************/
 /*use non-cached DMA buffer*/
//#define  MALLOC_DMA(size, pPhyAddr)  dma_alloc_writecombine(NULL, (size), (dma_addr_t*)(pPhyAddr), GFP_KERNEL | GFP_DMA)
//#define  FREE_DMA(size, vaddr, paddr)            dma_free_writecombine(NULL, (size), (vaddr), (paddr))
#define  MALLOC_DMA(size, pPhyAddr)  dmalloc((size), pPhyAddr)

/*----------------------------------------------------------------------------
 * DEBUGGING LEVELS
 *
 * 0 for normal operation
 * 1 for slightly more details
 * >2 for various levels of increasingly useless information
 *    2 for interrupt tracking, status flags
 *    3 for packet dumps, etc.
 *--------------------------------------------------------------------------*/
//#define _DBG_3 
#define _DBG_2
#define _DBG_1
#define _DBG

#ifdef _DBG_3 
#define PRINTK3( fmt, arg... )  printf( fmt, ##arg )
#else
#define PRINTK3( fmt, arg... )
#endif

#ifdef _DBG_2
#define PRINTK2( fmt, arg... )  printf( fmt, ##arg )
#else
#define PRINTK2( fmt, arg... )
#endif

#ifdef _DBG_1
#define PRINTK1( fmt, arg... )  printf( fmt, ##arg )
#else
#define PRINTK1( fmt, arg... )
#endif

#ifdef _DBG
#define PRINTK(x) printf x
#else
#define PRINTK(x)
#endif



#define  _PRTK_ENTRY      PRINTK2   /*to trace function entries*/
#define  _PRTK_SWERR      PRINTK    /*logical S/W error*/
#define  _PRTK_SYSFAIL    PRINTK    /*system service failure*/
#define  _PRTK_HWFAIL     PRINTK    /*H/W operation failure message*/
#define  _PRTK_WARN       PRINTK1   /*warning information*/
#define  _PRTK_INFO       PRINTK2   /*general information*/
#define  _PRTK_ENTRY_ISR  PRINTK3   /*to trace function entries belong to ISR*/
#define  _PRTK_WARN_ISR   PRINTK1   /*warning informations from ISR*/
#define  _PRTK_INFO_ISR   PRINTK3   /*general informations from ISR*/
#define  _PRTK_           PRINTK    /*for temporary print out*/

#if 0
# define  _PRTK_DUMP       PRINTK1   /*to dump large amount of debug info*/
#endif

/*----------------------------------------------------------------------------
 * Custom Data Structures
 *--------------------------------------------------------------------------*/

/****  the information about the buffer passed to device.
       there are matching bufferDescriptor informations
       for each Tx/Rx Descriptor Queue entry to trace
       the buffer within those queues.  ************************************/
typedef  struct bufferDescriptor  {
    void  *vaddr;                /*virtual address representing the buffer passed to device*/
    int(*pFreeRtn)(void *pBuf);  /*free routine*/
}  bufferDescriptor;

/****  device privite informations
       pointed by struct net_device::priv  *********************************/
typedef  struct ep93xxEth_info  {
    /****  static device informations  **********************************/
    struct {
        int                 id;            /*device instance ID (0 for 1st and so on)
                                             must be first element of this structure*/
        receiveDescriptor   *pQueRxDesc;   /*pointer to Rx Descriptor Queue*/
        receiveStatus       *pQueRxSts;    /*pointer to Rx Status Queue*/
        transmitDescriptor  *pQueTxDesc;   /*pointer to Tx Descriptor Queue*/
        transmitStatus      *pQueTxSts;    /*pointer to Tx Status Queue*/
        unsigned char       *pRxBuf;       /*base of Rx Buffer pool*/
        unsigned char       *pTxBuf;       /*base of Tx Buffer pool*/
        unsigned long       phyQueueBase;  /*physical address of device queues*/
        unsigned long       phyQueRxDesc,  /*physical address of Rx Descriptor Queue*/
                            phyQueRxSts,   /*physical address of Rx Status Queue*/
                            phyQueTxDesc,  /*physical address of Tx Descriptor Queue*/
                            phyQueTxSts,   /*physical address of Tx Status Queue*/
                            phyRxBuf,      /*physical address of Rx Buffer pool*/
                            phyTxBuf;      /*physical address of Tx Buffer pool*/
        bufferDescriptor    *pRxBufDesc,   /*info of Rx Buffers*/
                            *pTxBufDesc;   /*info of Tx Buffers*/
        int                 miiIdPhy;      /*MII Bus ID of Ethernet PHY*/
    }  s;
    /****  dynamic information, subject to clear when device open  ******/
    struct {
//        struct net_device_stats  stats;  /*statistic data*/
        int  idxQueRxDesc,       /*next processing index of device queues*/
             idxQueRxSts,
             idxQueTxDescHead,
             idxQueTxDescTail,
             idxQueTxSts;
        int  txStopped;          /*flag for Tx condition*/
    }  d;
}  ep93xxEth_info;




/* EMAC local DMA Descriptors. */
//static            RX_Desc Rx_Desc[NUM_RX_FRAG];
//static __align(8) RX_Stat Rx_Stat[NUM_RX_FRAG]; /* Must be 8-Byte alligned   */
//static            TX_Desc Tx_Desc[NUM_TX_FRAG];
//static            TX_Stat Tx_Stat[NUM_TX_FRAG];

/* EMAC local DMA buffers. */
//static rt_uint32_t rx_buf[NUM_RX_FRAG][ETH_FRAG_SIZE>>2];
//static rt_uint32_t tx_buf[NUM_TX_FRAG][ETH_FRAG_SIZE>>2];


ep93xxEth_info *pP;




struct lpc17xx_emac
{
	/* inherit from ethernet device */
	struct eth_device parent;

	rt_uint8_t phy_mode;

	/* interface address info. */
	rt_uint8_t  dev_addr[MAX_ADDR_LEN];		/* hw address	*/
};
static struct lpc17xx_emac lpc17xx_emac_device;
static struct rt_semaphore sem_slot, sem_lock;

/* Local Function Prototypes */
static void write_PHY (rt_uint32_t PhyReg, rt_uint16_t Value);
static rt_uint16_t read_PHY (rt_uint32_t PhyReg) ;



/* Local Function Prototypes */
void interrupt_ethernet (int irq);
static void rx_descr_init (void);
static void tx_descr_init (void);
struct pbuf * eth_isrRx(ep93xxEth_info *pP);
static int eth_isrTx(ep93xxEth_info *pP);
static int eth_Tx(ep93xxEth_info *pP, struct pbuf* p);
void waitready_PHY (void);
static int eth_indAddrWr(rt_uint32_t afp, rt_uint8_t *pBuf);
static int devQue_init(ep93xxEth_info *pP);
static int devQue_start(ep93xxEth_info *pP);
static int eth_enable(ep93xxEth_info *pP);
static int eth_rxCtl(int sw);
static int eth_reset(ep93xxEth_info *pP);
static int eth_cleanUpTx(ep93xxEth_info *pP);
static void eth_chkTxLvl(struct ep93xxEth_info *pP);
unsigned char *dmalloc(rt_uint32_t size,  unsigned long *pPhyAddr);
static int waitOnReg32(int reg, unsigned long mask, unsigned long expect, int tout);

//void ENET_IRQHandler(void)
//{
//	rt_uint32_t status;
//
//    /* enter interrupt */
//    rt_interrupt_enter();
//
//	status = LPC_EMAC->IntStatus & LPC_EMAC->IntEnable;
//
//	/* Clear the interrupt. */ 
//	LPC_EMAC->IntClear = status; 
// 
//	if (status & INT_RX_DONE)
//	{
//		/* Disable EMAC RxDone interrupts. */
//		LPC_EMAC->IntEnable = INT_TX_DONE;
//
//		/* a frame has been received */
//		eth_device_ready(&(lpc17xx_emac_device.parent));
//	}
//	else if (status & INT_TX_DONE)
//	{
//		/* release one slot */
//		rt_sem_release(&sem_slot);
//	}
//
//    /* leave interrupt */
//    rt_interrupt_leave();
//}
/*--------------------------- int_enable_eth --------------------------------*/
//
//void int_enable_eth (void) {
//   /* Ethernet Interrupt Enable function. */
//   VIC1INTENABLE |= (1<<(IRQ_EP93XX_ETHERNET-32));  	//enable interrupt at core
//}
//
//
///*--------------------------- int_disable_eth -------------------------------*/
//
//void int_disable_eth (void) {
//   /* Ethernet Interrupt Disable function. */
//   VIC0INTENCLEAR = 1 << (IRQ_EP93XX_ETHERNET-32);
//}


/*--------------------------- send_frame ------------------------------------*/

void send_frame (struct pbuf* p) {
   /* Send frame to EMAC ethernet controller */


//	 	 printf("debug TX7 %08X addr %08X\n",pP->s.pTxBufDesc[0].vaddr,&pP->s.pTxBufDesc[0].vaddr);

	   eth_Tx(pP,p);
	 //  	 printf("debug TX8 %08X addr %08X\n",pP->s.pTxBufDesc[0].vaddr,&pP->s.pTxBufDesc[0].vaddr);


#ifdef DEBUG

   rt_uint32_t idx,len;
   rt_uint32_t *sp,*dp;

   idx = MAC_TXPRODUCEINDEX;
   sp  = (rt_uint32_t *)&frame->data[0];
   dp  = (rt_uint32_t *)Tx_Desc[idx].Packet;

   /* Copy frame data to EMAC packet buffers. */
   for (len = (frame->length + 3) >> 2; len; len--) {
      *dp++ = *sp++;
   }
   Tx_Desc[idx].Ctrl = (frame->length-1) | (TCTRL_INT | TCTRL_LAST);

   /* Start frame transmission. */
   if (++idx == NUM_TX_FRAG) idx = 0;
   MAC_TXPRODUCEINDEX = idx;
#endif
}


/*--------------------------- interrupt_ethernet ----------------------------*/

void interrupt_ethernet (int irq){
   /* EMAC Ethernet Controller Interrupt function. */
   //#define  Default_IntSrc  (IntEn_RxMIE|IntEn_RxSQIE|IntEn_TxLEIE|IntEn_TIE|IntEn_TxSQIE|IntEn_RxEOFIE|IntEn_RxEOBIE|IntEn_RxHDRIE)
	//#define  Default_IntSrc  (IntEn_TxSQIE|IntEn_RxEOFIE|IntEn_RxEOBIE|IntEn_RxHDRIE)
	int lpCnt;
	rt_uint32_t intS;
	    /* enter interrupt */
    rt_interrupt_enter();

	lpCnt = 0;
	do {
		intS = MAC_INTSTSC;
		//rt_kprintf("network status : %08X \n", intS);
		if (!intS)
			break;
		if (intS & IntSts_RxSQ)
		{
		//	rt_kprintf("Rx interrupted %08X \n",intS);
			//eth_isrRx(pP);
MAC_INTEN = IntEn_RxMIE|IntEn_TxLEIE|IntEn_TIE|IntEn_TxSQIE|IntEn_RxEOFIE|IntEn_RxEOBIE|IntEn_RxHDRIE;
			/* a frame has been received */
			eth_device_ready(&(lpc17xx_emac_device.parent));
		}
		if (intS & IntSts_TxSQ)
		{
			//rt_kprintf("Tx interrupted %08X \n",intS);
			eth_isrTx(pP);
			/* release one slot */
			rt_sem_release(&sem_slot);
			
		}
		if (intS & IntSts_RxMI)
		{
			rt_kprintf("RX Missed %08X \n",intS);
		//	eth_isrTx(pP);
		}
	   	
		if (intS & IntSts_TxLEI)
		{
			rt_kprintf("TxLEI %08X \n",intS);
		//	eth_isrTx(pP);
		}
		if (intS & IntSts_TI)
		{
			rt_kprintf("TI %08X \n",intS);
		//	eth_isrTx(pP);
		}
		if (intS & IntSts_RxSQI)
		{
			rt_kprintf("RxSQI %08X \n",intS);
		//	eth_isrTx(pP);
		}
	   	
	   	
		
		
	} while (lpCnt++ < 64);
	
//	VIC1VECTADDR   = 0;

//	if (lpCnt)
//		return IRQ_HANDLED;
//	else
//		return IRQ_NONE;
    /* leave interrupt */
    rt_interrupt_leave();

#ifdef DEBUG 
   OS_FRAME *frame;
   rt_uint32_t idx,int_stat,RxLen,info;
   rt_uint32_t *sp,*dp;

   while ((int_stat = (MAC_INTSTATUS & MAC_INTENABLE)) != 0) {
      MAC_INTCLEAR = int_stat;
      if (int_stat & INT_RX_DONE) {
         /* Packet received, check if packet is valid. */
         idx = MAC_RXCONSUMEINDEX;
         while (idx != MAC_RXPRODUCEINDEX) {
            info = Rx_Stat[idx].Info;
            if (!(info & RINFO_LAST_FLAG)) {
               goto rel;
            }

            RxLen = (info & RINFO_SIZE) - 3;
            if (RxLen > ETH_MTU || (info & RINFO_ERR_MASK)) {
               /* Invalid frame, ignore it and free buffer. */
               goto rel;
            }
            /* Flag 0x80000000 to skip sys_error() call when out of memory. */
            frame = alloc_mem (RxLen | 0x80000000);
            /* if 'alloc_mem()' has failed, ignore this packet. */
            if (frame != NULL) {
               dp = (rt_uint32_t *)&frame->data[0];
               sp = (rt_uint32_t *)Rx_Desc[idx].Packet;
               for (RxLen = (RxLen + 3) >> 2; RxLen; RxLen--) {
                  *dp++ = *sp++;
               }
               put_in_queue (frame);
            }
rel:        if (++idx == NUM_RX_FRAG) idx = 0;
            /* Release frame from EMAC buffer. */
            MAC_RXCONSUMEINDEX = idx;
         }
      }

      if (int_stat & INT_TX_DONE) {
         /* Frame transmit completed. */
      }
   }
   /* Acknowledge the interrupt. */
   VICVectAddr = 0;
   #endif
}


/*****************************************************************************
* eth_isrRx()
*
*  Interrupt Service Routines
*
*****************************************************************************/
struct pbuf * eth_isrRx(ep93xxEth_info *pP)
{


//	ep93xxEth_info *pP = pD->priv;
	receiveStatus *pQRxSts;
	int idxQRxStsHead;
	int idxSts;
	int cntStsProcessed, cntDescProcessed;
//	char *pDest;
//	struct sk_buff *pSkb;
	int len;
	unsigned int dt;
	//---
	struct pbuf* p;//OS_FRAME *frame;
//    rt_uint32_t idx,int_stat,RxLen,info;
	rt_uint32_t *sp,*dp;

	dt = MAC_RXSCA; //Rx Status Current Addr
	idxQRxStsHead = (dt - pP->s.phyQueRxSts) / sizeof(pP->s.pQueRxSts[0]);

	if (!(idxQRxStsHead >= 0 && idxQRxStsHead < LEN_QueRxSts)) {
		rt_kprintf("eth_isrRx(): invalid REG_RxSCA:0x%x idx:%d (phyQueRxSts:0x%x Len:%x)\n",
			      dt,idxQRxStsHead, (int)pP->s.phyQueRxSts,
			      LEN_QueRxSts);
		return -1;
	}

	cntStsProcessed = cntDescProcessed = 0;

	if (idxQRxStsHead != pP->d.idxQueRxSts) {

		idxSts = pP->d.idxQueRxSts;
		pP->d.idxQueRxSts = IdxNext(pP->d.idxQueRxSts, LEN_QueRxSts);
		pQRxSts = &pP->s.pQueRxSts[idxSts];

		if (!pQRxSts->f.rfp) {
			rt_kprintf("eth_isrRx(): QueRxSts[%d] is empty; Hd:%d\n",
				      idxSts,idxQRxStsHead);
			return -1;
		}

		pQRxSts->f.rfp = 0;

		if(pQRxSts->f.eob) {

			if(pQRxSts->f.bi == pP->d.idxQueRxDesc) {
			   
			   	pP->d.idxQueRxDesc = IdxNext(pP->d.idxQueRxDesc, LEN_QueRxDesc);
				cntDescProcessed++;

				if (pQRxSts->f.eof && pQRxSts->f.rwe) {
					
					len = pQRxSts->f.fl;
//---
					p = pbuf_alloc(PBUF_LINK, len, PBUF_RAM);
					//p = pbuf_alloc(PBUF_RAW, len, PBUF_POOL);
					//frame = (void*)malloc(len);//alloc_mem (len | 0x80000000);
//					if (frame != NULL) {
//               			dp = (rt_uint32_t *)&frame->data[0];
//               			sp = (rt_uint32_t *)pP->s.pRxBufDesc[pQRxSts->f.bi].vaddr;
//					//	printf("RX %08X %08X\n",&frame->data[0],pP->s.pRxBufDesc[pQRxSts->f.bi].vaddr);
//               			for (len = (len + 3) >> 2; len; len--) {
//                  			*dp++ = *sp++;
//						//	printf("%X",*sp);
//               			}

										if (p != RT_NULL)
										{
											struct pbuf* q;
											rt_uint8_t *ptr;
								
											ptr = (rt_uint8_t*)pP->s.pRxBufDesc[pQRxSts->f.bi].vaddr;//RX_BUF(Index);
											for (q = p; q != RT_NULL; q= q->next)
											{
												memcpy(q->payload, ptr, q->len);
												ptr += q->len;
											}
										}

               			//put_in_queue (frame);
            		//}


//---	

			//	pSkb = dev_alloc_skb(len + 5);

					/*if (pSkb != NULL) {
						
						skb_reserve(pSkb, 2);
						pSkb->dev = pD;
						pDest = skb_put(pSkb, len);

						memcpy(pDest, pP->s.pRxBufDesc[pQRxSts->f.bi].vaddr,len);	****
						pSkb->protocol = eth_type_trans(pSkb,pD);

						netif_rx(pSkb);
						pP->d.stats.rx_packets++;
						
						if(pQRxSts->f.am == 3)
							
							pP->d.stats.multicast++;

					} else
						_PRTK_SYSFAIL(("eth_isrRx(): Low Memory, Rx dropped\n"));
						pP->d.stats.rx_dropped++;
						*/

				} else {

				/*	pP->d.stats.rx_errors++;

					if (pQRxSts->f.oe)
						pP->d.stats.rx_fifo_errors++;

					if (pQRxSts->f.fe)
						pP->d.stats.rx_frame_errors++;

					if (pQRxSts->f.runt || pQRxSts->f.edata)
						pP->d.stats.rx_length_errors++;

					if (pQRxSts->f.crce)
						pP->d.stats.rx_crc_errors++;
				*/
				}

			} else

				rt_kprintf("eth_isrRx(): unmatching QueRxSts[%d].BI:0x%x; idxQueRxDesc:0x%x\n",
					      idxSts, pQRxSts->f.bi,
					      pP->d.idxQueRxDesc);
		}

		cntStsProcessed++;
		
	}
	else
		{
			MAC_INTEN = Default_IntSrc;
			return RT_NULL;
		}

	MAC_RXSEQ = cntStsProcessed;
	MAC_RXDEQ = cntDescProcessed;
 // rt_kprintf("debug RX3 %08X addr %08X\n",pP->s.pRxBufDesc[0].vaddr,&pP->s.pRxBufDesc[0].vaddr);
	return p;//0;
	
}

/*****************************************************************************
* eth_isrTx()
*****************************************************************************/
static int eth_isrTx(ep93xxEth_info *pP)
{
/*
	eth_cleanUpTx(pD);
	eth_chkTxLvl(pD);
*/ 
  eth_cleanUpTx(pP);
	eth_chkTxLvl(pP);
 // 	 printf("debug TX\n");
	return 0;


}


/*****************************************************************************
* eth_Tx()
*****************************************************************************/
static int eth_Tx(ep93xxEth_info *pP, struct pbuf* p)
{
	//struct ep93xxEth_info *pP = pD->priv;
	struct pbuf* q;
	rt_uint8_t *ptr;
	transmitDescriptor *pQTxDesc;
	int idxQTxDescHd;
	int filled;
//	int status;
//	rt_uint32_t idx;
	rt_uint32_t len;
  rt_uint32_t *sp,*dp;


/*
	if (gPhyAutoNegoDone == 0) {
		status = phy_init(pD);
		if (status != 0)
		{
			return 1;
		}
	}
*/
//printf("debug TX5 %08X addr %08X\n",pP->s.pTxBufDesc[0].vaddr,&pP->s.pTxBufDesc[0].vaddr);
//printf("test0\n");
	while(pP->d.txStopped){
		rt_kprintf("stopped/n");
	}	  //may need edit : jack
	idxQTxDescHd = pP->d.idxQueTxDescHead;
	pQTxDesc = &pP->s.pQueTxDesc[idxQTxDescHd];

   
	filled = idxQTxDescHd - pP->d.idxQueTxDescTail;
	if (filled < 0)
		filled += LEN_QueTxDesc;
	filled += 1;


	if(filled >= LVL_TxStop) {
		

//		netif_stop_queue(pD);
		pP->d.txStopped = 1;
		if(filled > LVL_TxStop) {
			rt_kprintf("ep93xxEth_hardStartXmit(): a Tx Request while stop\n");
			return 1;
		}
	}
	

	
//	 printf("test1 %08X addr%08X\n",pP->s.pTxBufDesc[idxQTxDescHd].vaddr,&pP->s.pTxBufDesc[idxQTxDescHd].vaddr);

	//if (frame->length < 60) {
	if (p->tot_len < 60) {
		pQTxDesc->f.bl = 60;
		memset(pP->s.pTxBufDesc[idxQTxDescHd].vaddr, 0, 60);
	} else
		pQTxDesc->f.bl = p->tot_len;//frame->length;//pSkb->len;	 //***

//	 printf("test2 %08X addr%08X\n",pP->s.pTxBufDesc[idxQTxDescHd].vaddr,&pP->s.pTxBufDesc[idxQTxDescHd].vaddr);


	pQTxDesc->f.ba = pP->s.phyTxBuf+(idxQTxDescHd * LEN_TxBuf);//virt_to_bus(pP->s.pTxBufDesc[idxQTxDescHd].vaddr);
	pQTxDesc->f.bi = idxQTxDescHd;
	pQTxDesc->f.af = 0;
	pQTxDesc->f.eof = 1;
//	printf("test3\n");
	//sp  = (rt_uint32_t *)&frame->data[0];
  dp  = (rt_uint32_t *)pP->s.pTxBufDesc[idxQTxDescHd].vaddr;
	//wait(1); // jack need edit
	//printf("tx %08X %08X \n",&frame->data[0],pP->s.pTxBufDesc[idxQTxDescHd].vaddr);
//	memcpy(pP->s.pTxBufDesc[idxQTxDescHd].vaddr, pSkb->data, pSkb->len); //***

	/* copy data to tx buffer */
	q = p;
	ptr = (rt_uint8_t *)pP->s.pTxBufDesc[idxQTxDescHd].vaddr;
	while (q)
	{
	//	rt_kprintf("memcopy from %08X to %08X len %d ",q->payload,ptr,q->len);
		memcpy(ptr, q->payload, q->len);
		ptr += q->len;
		q = q->next;
	//	rt_kprintf("memcopied\n");
	}


//	/* Copy frame data to EMAC packet buffers. */
//   	for (len = (frame->length + 3) >> 2; len; len--) {
//       *dp++ = *sp++;
//   	}
	
//	printf("test5\n");
	pP->s.pTxBufDesc[idxQTxDescHd].pFreeRtn = 0;

//	free_skb(pSkb);

	pP->d.idxQueTxDescHead = IdxNext(pP->d.idxQueTxDescHead, LEN_QueTxDesc);
//   printf("test6\n");
	MAC_TXDEQ = 1;

	return 0;
}



/*--------------------------- write_PHY -------------------------------------*/
/*
9.1.4.11.2 Steps for Writing To the PHY Registers.
1. Read the value from SelfCtl register.
2. Since most PHYs need a Preamble for the MAC to read/write the PHY registers, you
may need to clear the PreambleSuppress bit.
3. Ensure that the PHY is not busy by polling the MIIStatus_Busy bit in MIIStatus register.
4. Put the PHY data into the PHY Data register
5. Issue the write command to write data to the register within the PHY
6. Wait until the write command is completed. Determine this by polling the MIIStatus_Busy
Bit in MIIStatus Register.
7. Restore the old value to SelfCtl register.
*/


static void write_PHY (rt_uint32_t PhyReg, rt_uint16_t Value) {
   /* Write a data 'Value' to PHY register 'PhyReg'. */
//   rt_uint32_t tout;
      rt_uint32_t oldVal;
   	/*
	 * Set MDC clock to be divided by 8 and disable PreambleSuppress bit
	 */
	oldVal = MAC_SELFCTL;
  	MAC_SELFCTL = 0x4E00; //set selfctrl to 0x4e00
  	
  	waitready_PHY();
   	MAC_MIIDATA = Value;
   	MAC_MIICMD= (MIICmd_OP_WR | ((KSZ8001_DEF_ADR & 0x1f) << 5) |((PhyReg & 0x1f) << 0));
   	waitready_PHY();


	MAC_SELFCTL = oldVal;
}


/*--------------------------- read_PHY --------------------------------------*/

/*

9.1.4.11.1 Steps for Reading From the PHY Registers.
1. Read the value from the SelfCtl Register.
2. Since most PHYs need a Preamble for the MAC to read/write the PHY registers, you
may need to clear the PreambleSuppress bit.
3. Ensure that the PHY is not busy by polling the MIIStatus_Busy Bit in MIIStatus register.
4. Issue the command to read the register within the PHY.
5. Wait until the read command is completed. Determine this by polling the MIIStatus_Busy
bit in MIIStatus register.
6. Get the PHY data from the MII Data register.
7. Restore the old value to SelfCtl register.
Note: Steps 1, 2, and 7 are not required if the PHY doesn't need a preamble for access to the
PHY's registers.

*/

static rt_uint16_t read_PHY (rt_uint32_t PhyReg) {
   /* Read a PHY register 'PhyReg'. */
   rt_uint32_t oldVal;
   	/*
	 * Set MDC clock to be divided by 8 and disable PreambleSuppress bit
	 */
   oldVal = MAC_SELFCTL;
   //printf("oldVal = %08X\n",oldVal);
   MAC_SELFCTL = 0x4E00; //set selfctrl to 0x4e00
   waitready_PHY();
   MAC_MIICMD = (MIICmd_OP_RD | ((KSZ8001_DEF_ADR & 0x1f) << 5) | ((PhyReg & 0x1f) << 0));
   waitready_PHY();
   MAC_SELFCTL = oldVal;
   return (MAC_MIIDATA);
}

void waitready_PHY (void){
   rt_uint32_t tout;
	/* Wait until operation completed */
   	for (tout = 0; tout < MII_RD_TOUT; tout++) {
      if ((MAC_MIISTS & MIISts_Busy) == 0) {
         break;
      }
   }	
}


///* phy write */
//static void write_PHY (rt_uint32_t PhyReg, rt_uint32_t Value)
//{
//	unsigned int tout;
//
//	LPC_EMAC->MADR = DP83848C_DEF_ADR | PhyReg;
//	LPC_EMAC->MWTD = Value;
//
//	/* Wait utill operation completed */
//	tout = 0;
//	for (tout = 0; tout < MII_WR_TOUT; tout++)
//	{
//		if ((LPC_EMAC->MIND & MIND_BUSY) == 0)
//		{
//			break;
//		}
//	}
//}
//
///* phy read */
//static rt_uint16_t read_PHY (rt_uint8_t PhyReg)
//{
//	rt_uint32_t tout;
//
//	LPC_EMAC->MADR = DP83848C_DEF_ADR | PhyReg;
//	LPC_EMAC->MCMD = MCMD_READ;
//
//	/* Wait until operation completed */
//	tout = 0;
//	for (tout = 0; tout < MII_RD_TOUT; tout++)
//	{
//		if ((LPC_EMAC->MIND & MIND_BUSY) == 0)
//		{
//			break;
//		}
//	}
//	LPC_EMAC->MCMD = 0;
//	return (LPC_EMAC->MRDD);
//}




/*****************************************************************************
* eth_indAddrWr()
*****************************************************************************/
static int eth_indAddrWr(rt_uint32_t afp, rt_uint8_t *pBuf)
{
	rt_uint32_t rxctl;
//	int i, len;
//    rt_uint32_t test;
//	char msg [32];
//	printf("HASH MAC %02X %02X %02X %02X %02X %02X\n",pBuf[0],pBuf[1],pBuf[2],pBuf[3],pBuf[4],pBuf[5]);
	afp &= 0x07;
	if (afp == 4 || afp == 5) {
//		_PRTK_SWERR(("eth_indAddrWr(): invalid afp value\n"));
		rt_kprintf("eth_indAddrWr():invalid afp value\n");
		return -1;
	}

//	len = (afp == AFP_AFP_HASH) ? 8 : 6;

	rxctl = MAC_RXCTL;
	MAC_RXCTL = (~RxCTL_SRxON & rxctl);
	MAC_AFP = afp;
	
//	for (i = 0; i < len; i++)

	MAC_INDAD = (rt_uint32_t)pBuf[0] | (rt_uint32_t)pBuf[1]<<8 | (rt_uint32_t)pBuf[2]<<16 | (rt_uint32_t)pBuf[3]<<24;
	MAC_INDAD_UPPER = (rt_uint32_t)pBuf[4] | (rt_uint32_t)pBuf[5]<<8;
// 	RegWr8(REG_IndAD + i, pBuf[i]);
	
//	test = MAC_INDAD_UPPER;

//	sprintf(msg,"READ %08X",test );
//	writestringBuffer (msg);
   	
//  MAC_SA0 = ((rt_uint32_t)own_hw_adr[5] << 8) | (rt_uint32_t)own_hw_adr[4];
//  MAC_SA1 = ((rt_uint32_t)own_hw_adr[3] << 8) | (rt_uint32_t)own_hw_adr[2];
//  MAC_SA2 = ((rt_uint32_t)own_hw_adr[1] << 8) | (rt_uint32_t)own_hw_adr[0];
	
	MAC_RXCTL = rxctl;

	return 0;
}


/*****************************************************************************
* devQue_init()
  init device descriptor queues at system level
  device access is not recommended at this point
*
*****************************************************************************/
static int devQue_init(ep93xxEth_info *pP)
{
	//struct ep93xxEth_info *pP = pD->priv;
	void *pBuf;
	int size;
	char msg[32];

	if (sizeof(receiveDescriptor) != 8) {
		rt_kprintf(("devQue_init(): size of receiveDescriptor is not 8 bytes!!!\n"));
		return -1;
	} else if (sizeof(receiveStatus) != 8) {
		rt_kprintf(("devQue_init(): size of receiveStatus is not 8 bytes!!!\n"));
		return -1;
	} else if (sizeof(transmitDescriptor) != 8) {
		rt_kprintf(("devQue_init(): size of transmitDescriptor is not 8 bytes!!!\n"));
		return -1;
	} else if (sizeof(transmitStatus) != 4) {
		rt_kprintf(("devQue_init(): size of transmitStatus is not 4 bytes!!!\n"));
		return -1;
	}

	size = sizeof(receiveDescriptor) * (LEN_QueRxDesc + 1) +
		sizeof(receiveStatus) * (LEN_QueRxSts + 1) +
		sizeof(transmitDescriptor) * (LEN_QueTxDesc + 1) +
		sizeof(transmitStatus) * (LEN_QueTxSts + 1) +
		sizeof(unsigned long) * 4;
	

	pBuf = MALLOC_DMA(size, &pP->s.phyQueueBase);
	rt_kprintf("DMA %08X %08X %08X\n",pBuf,pP->s.phyQueueBase,&pP->s.phyQueueBase);

	if(!pBuf)
		return -1;

	rt_kprintf("pBuffer %08X OK1\n",pBuf);

	pP->s.pQueRxDesc = (void *)Align32(pBuf);
	pBuf = (char *)pBuf + sizeof(receiveDescriptor) * (LEN_QueRxDesc + 1);

	pP->s.pQueRxSts = (void *)Align32(pBuf);
	pBuf = (char *)pBuf + sizeof(receiveStatus) * (LEN_QueRxSts + 1);

	pP->s.pQueTxDesc = (void *)Align32(pBuf);
	pBuf = (char *)pBuf + sizeof(transmitDescriptor) * (LEN_QueTxDesc + 1);

	pP->s.pQueTxSts = (void *)Align32(pBuf);
	pBuf = (char *)pBuf + sizeof(transmitStatus) * (LEN_QueTxSts + 1);

	pP->s.phyQueRxDesc = Align32(pP->s.phyQueueBase);
	pP->s.phyQueRxSts = pP->s.phyQueRxDesc + ((rt_uint32_t)pP->s.pQueRxSts - (rt_uint32_t)pP->s.pQueRxDesc);
	pP->s.phyQueTxDesc = pP->s.phyQueRxDesc + ((rt_uint32_t)pP->s.pQueTxDesc - (rt_uint32_t)pP->s.pQueRxDesc);
	pP->s.phyQueTxSts = pP->s.phyQueRxDesc + ((rt_uint32_t)pP->s.pQueTxSts - (rt_uint32_t)pP->s.pQueRxDesc);

	memset(pP->s.pQueRxDesc, 0, sizeof(receiveDescriptor) * LEN_QueRxDesc);
	memset(pP->s.pQueRxSts, 0, sizeof(receiveStatus) * LEN_QueRxSts);
	memset(pP->s.pQueTxDesc, 0, sizeof(transmitDescriptor) * LEN_QueTxDesc);
	memset(pP->s.pQueTxSts, 0, sizeof(transmitStatus) * LEN_QueTxSts);

	pP->s.pRxBuf = MALLOC_DMA(((LEN_RxBuf + 3) & ~0x03) * LEN_QueRxDesc, &pP->s.phyRxBuf);
	if (!pP->s.pRxBuf) {
		pP->s.pRxBuf = 0;
		rt_kprintf("devQue_init(): fail to allocate memory for RxBuf\n");
		return -1;
	}

	rt_kprintf("pBuffer %08X OK2\n",pP->s.pRxBuf);



        pP->s.pTxBuf = MALLOC_DMA(((LEN_TxBuf + 3) & ~0x03) * LEN_QueTxDesc, &pP->s.phyTxBuf);
        if (!pP->s.pTxBuf) {
                pP->s.pTxBuf = 0;
                rt_kprintf(("devQue_init(): fail to allocate memory for TxBuf\n"));
                return -1;
        }


	rt_kprintf("pBuffer %08X OK3\n",pP->s.pTxBuf);



	size = sizeof(bufferDescriptor) * (LEN_QueRxDesc + LEN_QueTxDesc);
//	pBuf = kmalloc(size, GFP_KERNEL); jack
	pBuf = malloc(size);
	if(!pBuf) {
		rt_kprintf("devQue_initAll(): fail to allocate memory for buf desc\n");
		return -1;
	}

	rt_kprintf("pBuffer %08X OK4\n",pBuf);
	

	memset(pBuf, 0x0, size);
	pP->s.pRxBufDesc = (bufferDescriptor*)pBuf;
	pP->s.pTxBufDesc = (bufferDescriptor*)pBuf + sizeof(bufferDescriptor) * LEN_QueRxDesc;

	return 0;
}


/*****************************************************************************
* devQue_start()
*
  make descriptor queues active
  allocate queue entries if needed
  and set device registers up to make it operational
  assume device has been initialized
*
*****************************************************************************/
static int devQue_start(ep93xxEth_info *pP)
{
	int err;
	//struct ep93xxEth_info *pP = pD->priv;
	int i;
	void *pBuf;
	rt_uint32_t phyA;

	MAC_BMCTL = (BMCtl_RxDis | BMCtl_TxDis | MAC_BMCTL);

	err = waitOnReg32(REG_BMSts, BMSts_TxAct, ~BMSts_TxAct, 1);
	err |= waitOnReg32(REG_BMSts, BMSts_RxAct, ~BMSts_RxAct, 1);
	if (err)
		rt_kprintf("devQue_start(): BM does not stop\n");
 
	memset(pP->s.pQueTxSts, 0, sizeof(pP->s.pQueTxSts[0]) * LEN_QueTxSts);
	pP->d.idxQueTxSts = 0;
	MAC_TXSBA = pP->s.phyQueTxSts;
	MAC_TXSCA = pP->s.phyQueTxSts;
	MAC_TXSBL = (sizeof(pP->s.pQueTxSts[0]) * LEN_QueTxSts);
	MAC_TXSCL = (sizeof(pP->s.pQueTxSts[0]) * LEN_QueTxSts);

	memset(pP->s.pQueTxDesc, 0, sizeof(pP->s.pQueTxDesc[0]) * LEN_QueTxDesc);
	pP->d.idxQueTxDescHead = pP->d.idxQueTxDescTail = 0;
	MAC_TXDBA = pP->s.phyQueTxDesc;
	MAC_TXDCA = pP->s.phyQueTxDesc;
	MAC_TXDBL = (sizeof(pP->s.pQueTxDesc[0]) * LEN_QueTxDesc);
	MAC_TXDCL = (sizeof(pP->s.pQueTxDesc[0]) * LEN_QueTxDesc);

	memset(pP->s.pQueRxSts, 0, sizeof(pP->s.pQueRxSts[0]) * LEN_QueRxSts);
	pP->d.idxQueRxSts = 0;
	MAC_RXSBA = pP->s.phyQueRxSts;
	MAC_RXSCA = pP->s.phyQueRxSts;
	MAC_RXSBL = (sizeof(pP->s.pQueRxSts[0]) * LEN_QueRxSts);
	MAC_RXSCL = (sizeof(pP->s.pQueRxSts[0]) * LEN_QueRxSts);

	memset(pP->s.pQueRxDesc, 0, sizeof(pP->s.pQueRxDesc[0]) * LEN_QueRxDesc);
	phyA = pP->s.phyRxBuf;
	for (i = 0; i < LEN_QueRxDesc; i++) {
		pP->s.pQueRxDesc[i].f.bi = i;
		pP->s.pQueRxDesc[i].f.ba = phyA;
		pP->s.pQueRxDesc[i].f.bl = LEN_RxBuf;
		phyA += (LEN_RxBuf + 3) & ~0x03;
	}

	pP->d.idxQueRxDesc = 0;
	MAC_RXDBA = pP->s.phyQueRxDesc;
	MAC_RXDCA = pP->s.phyQueRxDesc;
	MAC_RXDBL = (sizeof(pP->s.pQueRxDesc[0]) * LEN_QueRxDesc);
	MAC_RXDCL = (sizeof(pP->s.pQueRxDesc[0]) * LEN_QueRxDesc);

	pBuf = pP->s.pRxBuf;
	for (i = 0; i < LEN_QueRxDesc; i++) {
		pP->s.pRxBufDesc[i].vaddr = pBuf;
		pP->s.pRxBufDesc[i].pFreeRtn = 0;
		pBuf = (char*)pBuf + ((LEN_RxBuf + 3) & ~0x03);
		//rt_kprintf("debug RX %08X\n",pP->s.pRxBufDesc[i].vaddr);
	}

	memset(pP->s.pTxBufDesc, 0x0, sizeof(*pP->s.pTxBufDesc) * LEN_QueTxDesc);
	pBuf = pP->s.pTxBuf;// = &gTxDataBuff[0][0];
	for (i = 0; i < LEN_QueTxDesc; i++) {
		pP->s.pTxBufDesc[i].vaddr =  (char*)pBuf + (i*LEN_TxBuf);//&gTxDataBuff[i][0];
		pP->s.pTxBufDesc[i].pFreeRtn = 0;
		//rt_kprintf("debug TX %08X\n",pP->s.pTxBufDesc[i].vaddr);
	}

	MAC_BMCTL = (BMCtl_TxEn | BMCtl_RxEn | MAC_BMCTL);
	err = waitOnReg32(REG_BMSts, BMSts_TxAct | BMSts_TxAct,BMSts_TxAct | BMSts_TxAct, 1);
	if(err)
		rt_kprintf("devQue_start(): BM does not start\n");

	MAC_RXSEQ = LEN_QueRxSts;
	MAC_RXDEQ = LEN_QueRxDesc;

	return 0;
}


unsigned char *dmalloc(rt_uint32_t size,  unsigned long *pPhyAddr)
{
	unsigned char *pVirAddr;

	pVirAddr = malloc(size);


	
	if (pVirAddr ==NULL)
	{
		rt_kprintf("dmalloc(): error allocating memmory\n");
		*pPhyAddr = NULL;
	}
	else
	{
		*pPhyAddr =  (unsigned long)pVirAddr-0x00000000; //was 0x10000000
	}
	
	rt_kprintf("dmalloc %08X . %08X\n",*pPhyAddr,pVirAddr);
	
	return pVirAddr+0xc0000000;
}

/*****************************************************************************
*  eth_enable()

  Purpose:
        Turn on device interrupt for interrupt driven operation.
        Also turn on Rx but no Tx.
*
*****************************************************************************/
static int eth_enable(ep93xxEth_info *pP)
{
	MAC_INTEN = Default_IntSrc;
	MAC_FERMASK = GIntMsk_IntEn;
	eth_rxCtl(1);

	return 0;
}


/*****************************************************************************
* eth_rxCtl()
*****************************************************************************/
static int eth_rxCtl(int sw)
{
	/*
	 * Workaround for MAC lost 60-byte-long frames: must enable
	 * Runt_CRC_Accept bit
	 */
	MAC_RXCTL = sw ? (MAC_RXCTL | RxCTL_SRxON | RxCTL_RCRCA) : (MAC_RXCTL & ~RxCTL_SRxON);

	return 0;
}


/*****************************************************************************
* eth_reset()
*****************************************************************************/
static int eth_reset(ep93xxEth_info *pP)
{
	int err;

	MAC_SELFCTL = SelfCTL_RESET;
	err = waitOnReg32(REG_SelfCTL, SelfCTL_RESET, ~SelfCTL_RESET, 1);
	if (err)
		rt_kprintf("eth_reset(): Soft Reset does not self-clear\n");

	//phy_reset(pD);

	return 0;
}


/*****************************************************************************
* eth_cleanUpTx()
*****************************************************************************/
static int eth_cleanUpTx(ep93xxEth_info *pP)
{
//	struct ep93xxEth_info *pP = pD->priv;
	transmitStatus *pQTxSts;
	int idxSts, bi;

	while (pP->s.pQueTxSts[pP->d.idxQueTxSts].f.txfp) {
		idxSts = pP->d.idxQueTxSts;

		pP->d.idxQueTxSts = IdxNext(pP->d.idxQueTxSts,LEN_QueTxSts);
		pQTxSts = &pP->s.pQueTxSts[idxSts];
		if (!pQTxSts->f.txfp) {
			rt_kprintf("eth_cleanUpTx(): QueTxSts[%d]:x%08x is empty\n", idxSts, (int)pQTxSts->w.e0);
			return -1;
	}

		pQTxSts->f.txfp = 0;

		bi = pQTxSts->f.bi;
#if 0
		if (pP->d.idxQueTxDescTail != bi) {
			rt_kprintf("eth_cleanUpTx(): unmatching QTxSts[%d].BI:%d idxQTxDTail:%d\n",
				      idxSts,bi, pP->d.idxQueTxDescTail);
		}
#endif

		if (pP->s.pTxBufDesc[bi].pFreeRtn) {
			(*pP->s.pTxBufDesc[bi].pFreeRtn)(pP->s.pTxBufDesc[bi].vaddr);
			pP->s.pTxBufDesc[bi].pFreeRtn = 0;
		}
	  /*
		if (pQTxSts->f.txwe) {
			pP->d.stats.tx_packets++;
		} else {
			pP->d.stats.tx_errors++;
			if (pQTxSts->f.lcrs)
				pP->d.stats.tx_carrier_errors++;
			if(pQTxSts->f.txu)
				pP->d.stats.tx_fifo_errors++;
			if(pQTxSts->f.ecoll)
				pP->d.stats.collisions++;
		}
	   */
		pP->d.idxQueTxDescTail = IdxNext(pP->d.idxQueTxDescTail,
						 LEN_QueTxDesc);
	}

	return 0;
}

/*****************************************************************************
* eth_chkTxLvl()
*****************************************************************************/
static void eth_chkTxLvl(struct ep93xxEth_info *pP)
{
//	struct ep93xxEth_info *pP = pD->priv;
	int idxQTxDescHd;
	int filled;

	idxQTxDescHd = pP->d.idxQueTxDescHead;

	filled = idxQTxDescHd - pP->d.idxQueTxDescTail;
	if (filled < 0)
		filled += LEN_QueTxDesc;

	if (pP->d.txStopped && filled <= (LVL_TxResume + 1)) {
		pP->d.txStopped = 0;
	//	pD->trans_start = jiffies;
	//	netif_wake_queue(pD);
		}
}



/*****************************************************************************
* waitOnReg32()
*****************************************************************************/
static int waitOnReg32(int reg, unsigned long mask, unsigned long expect, int tout)
{
	int  i;
	int  dt;

	for (i = 0; i < 10000; ) {
		dt = (*((volatile rt_uint32_t *) (reg|MAC_BASE)));
		dt = (dt ^ expect) & mask;
		if (dt == 0)
			break;
		if (tout)
			i++;
	}

	return dt;
}

//
//
//
///* init rx descriptor */
//rt_inline void rx_descr_init (void)
//{
//	rt_uint32_t i;
//
//	for (i = 0; i < NUM_RX_FRAG; i++)
//	{
//		RX_DESC_PACKET(i)  = RX_BUF(i);
//		RX_DESC_CTRL(i)    = RCTRL_INT | (ETH_FRAG_SIZE-1);
//		RX_STAT_INFO(i)    = 0;
//		RX_STAT_HASHCRC(i) = 0;
//	}
//
//	/* Set EMAC Receive Descriptor Registers. */
//	LPC_EMAC->RxDescriptor    = RX_DESC_BASE;
//	LPC_EMAC->RxStatus        = RX_STAT_BASE;
//	LPC_EMAC->RxDescriptorNumber = NUM_RX_FRAG-1;
//
//	/* Rx Descriptors Point to 0 */
//	LPC_EMAC->RxConsumeIndex  = 0;
//}
//
///* init tx descriptor */
//rt_inline void tx_descr_init (void)
//{
//	rt_uint32_t i;
//
//	for (i = 0; i < NUM_TX_FRAG; i++)
//	{
//		TX_DESC_PACKET(i) = TX_BUF(i);
//		TX_DESC_CTRL(i)   = (1ul<<31) | (1ul<<30) | (1ul<<29) | (1ul<<28) | (1ul<<26) | (ETH_FRAG_SIZE-1);
//		TX_STAT_INFO(i)   = 0;
//	}
//
//	/* Set EMAC Transmit Descriptor Registers. */
//	LPC_EMAC->TxDescriptor    = TX_DESC_BASE;
//	LPC_EMAC->TxStatus        = TX_STAT_BASE;
//	LPC_EMAC->TxDescriptorNumber = NUM_TX_FRAG-1;
//
//	/* Tx Descriptors Point to 0 */
//	LPC_EMAC->TxProduceIndex  = 0;
//}

static rt_err_t lpc17xx_emac_init(rt_device_t dev)
{
	/* Initialize the EMAC ethernet controller. */
	rt_uint32_t regv, tout, id1, id2, rept;
	
	 pP = malloc(sizeof(ep93xxEth_info));
   if (pP==NULL)
   {
   		rt_kprintf("init_ethernet() : Failed to allocate pP\n");
   }
   else
   { 
   		memset(pP,0,sizeof(ep93xxEth_info));
   		rt_kprintf("pointer address = %08X\n",pP);
   }
   devQue_init(pP);
	 eth_reset(pP);

//	/* Power Up the EMAC controller. */
//	LPC_SC->PCONP |= 0x40000000;
//
//	/* Enable P1 Ethernet Pins. */
//	LPC_PINCON->PINSEL2 = 0x50150105;
//	LPC_PINCON->PINSEL3 = (LPC_PINCON->PINSEL3 & ~0x0000000F) | 0x00000005;
//
//	/* Reset all EMAC internal modules. */
//	LPC_EMAC->MAC1 = MAC1_RES_TX | MAC1_RES_MCS_TX | MAC1_RES_RX | MAC1_RES_MCS_RX |
//				 MAC1_SIM_RES | MAC1_SOFT_RES;
//	LPC_EMAC->Command = CR_REG_RES | CR_TX_RES | CR_RX_RES;
//
//	/* A short delay after reset. */
//	for (tout = 100; tout; tout--);
//
//	/* Initialize MAC control registers. */
//	LPC_EMAC->MAC1 = MAC1_PASS_ALL;
//	LPC_EMAC->MAC2 = MAC2_CRC_EN | MAC2_PAD_EN;
//	LPC_EMAC->MAXF = ETH_MAX_FLEN;
//	LPC_EMAC->CLRT = CLRT_DEF;
//	LPC_EMAC->IPGR = IPGR_DEF;
//
//	/* PCLK=18MHz, clock select=6, MDC=18/6=3MHz */
//	/* Enable Reduced MII interface. */
//	LPC_EMAC->MCFG = MCFG_CLK_DIV20 | MCFG_RES_MII;
//	for (tout = 100; tout; tout--);
//	LPC_EMAC->MCFG = MCFG_CLK_DIV20;
//
//	/* Enable Reduced MII interface. */
//	LPC_EMAC->Command = CR_RMII | CR_PASS_RUNT_FRM | CR_PASS_RX_FILT;
//
//	/* Reset Reduced MII Logic. */
//	LPC_EMAC->SUPP = SUPP_RES_RMII | SUPP_SPEED;
//	for (tout = 100; tout; tout--);
//	LPC_EMAC->SUPP = SUPP_SPEED;
//----------------------------start init PHY -------------------------------------


	/*
	 * read BM status Reg; Link Status Bit remains cleared until the Reg is
	 * read.
	 */
	read_PHY(1);

	/*
	 * read BMStaReg again to get the current link status
	 */
//	val = read_PHY(1);
//	if (val & 0x0004) //capable to autonNegotiation
//		//status = phy_autoNegotiation(pD);
//		printf("val %X\n", val);
	


//---------------------------------------------------------------------------------	

   rept = 10;
rpt:
//	/* Put the PHY in reset mode */
//	write_PHY (PHY_REG_BMCR, 0x8000);
//	for (tout = 1000; tout; tout--);
//
//	/* Wait for hardware reset to end. */
//	for (tout = 0; tout < 0x100000; tout++)
//	{
//		regv = read_PHY (PHY_REG_BMCR);
//		if (!(regv & 0x8000))
//		{
//			/* Reset complete */
//			break;
//		}
//	}
//	if (tout >= 0x100000) return -RT_ERROR; /* reset failed */
//
//	/* Check if this is a DP83848C PHY. */
//	id1 = read_PHY (PHY_REG_IDR1);
//	id2 = read_PHY (PHY_REG_IDR2);
//
//	if (((id1 << 16) | (id2 & 0xFFF0)) != DP83848C_ID)
//		return -RT_ERROR;

   /* Check if this is a KSZ8001 PHY. */
   id1 = read_PHY (PHY_REG_IDR1);
   id2 = read_PHY (PHY_REG_IDR2);
   //printf("PHY ID = %x,%x\n", id1,id2);
   if ((id1 == 0xFFFF) || (id2 == 0xFFFF)) {
      /* Chip Reset problem, retry several times. */
      for (tout = 0; tout < 0x100000; tout++);
      if (--rept) goto rpt;
   }

   if (((id1 << 16) | (id2 & 0xFFF0)) != KSZ8001_ID)
   	return -RT_ERROR;
   	 
   rt_kprintf("Found PHY Micrel KSZ8732\nManufacturer ID = %05X \nChip ID = %05X\n", id1,id2);

	/* Configure the PHY device */
	/* Configure the PHY device */
	switch (lpc17xx_emac_device.phy_mode)
	{
	case EMAC_PHY_AUTO:
		/* Use autonegotiation about the link speed. */
		write_PHY (PHY_REG_BCR, PHY_AUTO_NEG);
		/* Wait to complete Auto_Negotiation. */
		for (tout = 0; tout < 0x100000; tout++)
		{
			regv = read_PHY (PHY_REG_BSR);
			if (regv & 0x0020)
			{
				/* Autonegotiation Complete. */
				rt_kprintf("Auto Negotiation Complete\n");
				break;
			}
		}
			if (tout >= 0x100000) rt_kprintf("Auto Negotiation Failed\n");//return -RT_ERROR; // auto_neg failed
	//	write_PHY (PHY_REG_BCR, PHY_FULLD_100M);
		break;
	case EMAC_PHY_10MBIT:
		/* Connect at 10MBit */
		write_PHY (PHY_REG_BCR, PHY_FULLD_10M);
		break;
	case EMAC_PHY_100MBIT:
		/* Connect at 100MBit */
		write_PHY (PHY_REG_BCR, PHY_FULLD_100M);
		break;
	}

  rt_kprintf("Checking Link status...\n");
	/* Check the link status. */
	for (tout = 0; tout < 0x10000; tout++)
	{
      regv = read_PHY (PHY_REG_100TPCR);
      if (regv & 0x001C) { // not in autonegotiation
         /* Link is on. */
		 rt_kprintf("Link is up\n");
         break;
		}
	}
	if (tout >= 0x10000) rt_kprintf("Link is down\n");//return -RT_ERROR;

	/* Configure Full/Half Duplex mode. */
	   if (regv & 0x0010) {
   rt_uint32_t oldVal;
      /* Full duplex is enabled. */
	  rt_kprintf("Full duplex on\n");
	  oldVal = MAC_TESTCTL;
	  MAC_TESTCTL = oldVal|TestCTL_MFDX;
//	if (regv & 0x0004)
//	{
//		/* Full duplex is enabled. */
//		LPC_EMAC->MAC2    |= MAC2_FULL_DUP;
//		LPC_EMAC->Command |= CR_FULL_DUP;
//		LPC_EMAC->IPGT     = IPGT_FULL_DUP;
	}
	else
	{
		rt_uint32_t oldVal;
		/* Half duplex mode. */
			  rt_kprintf("Half duplex on\n");
	  oldVal = MAC_TESTCTL;
	  MAC_TESTCTL = oldVal&(~TestCTL_MFDX);
//		LPC_EMAC->IPGT = IPGT_HALF_DUP;
	}

	/* Configure 100MBit/10MBit mode. */
   if (regv & 0x0004) {
      /* 10MBit mode. */
	  rt_kprintf("10MBit mode\n");
//      MAC_SUPP = 0;
   }
   else {
      /* 100MBit mode. */
	  	rt_kprintf("100MBit mode\n");
//      MAC_SUPP = SUPP_SPEED;
   }


	MAC_SELFCTL = 0x0f00;
	MAC_FERMASK, 0x00;
	MAC_RXCTL = (RxCTL_BA | RxCTL_IA0);
	MAC_TXCTL = 0x00;
	MAC_GT = 0x00;
	MAC_BMCTL = 0x00;
	MAC_RXBTH = ((0x80 << 16) | (0x40 << 0));
	MAC_TXBTH = ((0x80 << 16) | (0x40 << 0));
	MAC_RXSTH = ((4 << 16) | (2 << 0));
	MAC_TXSTH = ((4 << 16) | (2 << 0));
	MAC_RXDTH = ((4 << 16) | (2 << 0));
	MAC_TXDTH = ((4 << 16) | (2 << 0));
	MAC_MAXFL = (((1518 + 1) << 16) | (944 << 0));

	MAC_TXCOLLCNT;
	MAC_RXMISSCNT;
	MAC_RXRUNTCNT;

	MAC_INTSTSC; 

	MAC_TXCTL = (TxCTL_STxON | MAC_TXCTL);

	//eth_indAddrWr(pD, AFP_AFP_IA0, &pD->dev_addr[0]);
	//eth_indAddrWr(AFP_AFP_IA0, own_hw_adr);
eth_indAddrWr(AFP_AFP_IA0, lpc17xx_emac_device.dev_addr);
//	/* Set the Ethernet MAC Address registers */
//	LPC_EMAC->SA0 = (lpc17xx_emac_device.dev_addr[1]<<8) | lpc17xx_emac_device.dev_addr[0];
//	LPC_EMAC->SA1 = (lpc17xx_emac_device.dev_addr[3]<<8) | lpc17xx_emac_device.dev_addr[2];
//	LPC_EMAC->SA2 = (lpc17xx_emac_device.dev_addr[5]<<8) | lpc17xx_emac_device.dev_addr[4];
//
//	/* Initialize Tx and Rx DMA Descriptors */
//	rx_descr_init ();
//	tx_descr_init ();

	devQue_start(pP);
	//printf("debug TX1 %08X addr %08X\n",pP->s.pTxBufDesc[0].vaddr,&pP->s.pTxBufDesc[0].vaddr);
	eth_enable(pP);
//	printf("debug TX2 %08X addr %08X\n",pP->s.pTxBufDesc[0].vaddr,&pP->s.pTxBufDesc[0].vaddr);

//	/* Receive Broadcast and Perfect Match Packets */
//	LPC_EMAC->RxFilterCtrl = RFC_BCAST_EN | RFC_PERFECT_EN;
//
//	/* Reset all interrupts */
//	LPC_EMAC->IntClear  = 0xFFFF;
//
//	/* Enable EMAC interrupts. */
//	LPC_EMAC->IntEnable = INT_RX_DONE | INT_TX_DONE;
//
//	/* Enable receive and transmit mode of MAC Ethernet core */
//	LPC_EMAC->Command  |= (CR_RX_EN | CR_TX_EN);
//	LPC_EMAC->MAC1     |= MAC1_REC_EN;
//
//	/* Enable the ENET Interrupt */
//	NVIC_EnableIRQ(ENET_IRQn);

	/* setup interrupt */
	rt_hw_interrupt_install(IRQ_EP93XX_ETHERNET, interrupt_ethernet, RT_NULL);
	rt_hw_interrupt_umask(IRQ_EP93XX_ETHERNET);

	return RT_EOK;
}

static rt_err_t lpc17xx_emac_open(rt_device_t dev, rt_uint16_t oflag)
{
	return RT_EOK;
}

static rt_err_t lpc17xx_emac_close(rt_device_t dev)
{
	return RT_EOK;
}

static rt_size_t lpc17xx_emac_read(rt_device_t dev, rt_off_t pos, void* buffer, rt_size_t size)
{
	rt_set_errno(-RT_ENOSYS);
	return 0;
}

static rt_size_t lpc17xx_emac_write (rt_device_t dev, rt_off_t pos, const void* buffer, rt_size_t size)
{
	rt_set_errno(-RT_ENOSYS);
	return 0;
}

static rt_err_t lpc17xx_emac_control(rt_device_t dev, rt_uint8_t cmd, void *args)
{
	switch (cmd)
	{
	case NIOCTL_GADDR:
		/* get mac address */
		if (args) rt_memcpy(args, lpc17xx_emac_device.dev_addr, 6);
		else return -RT_ERROR;
		break;

	default :
		break;
	}

	return RT_EOK;
}

/* EtherNet Device Interface */
/* transmit packet. */
rt_err_t lpc17xx_emac_tx( rt_device_t dev, struct pbuf* p)
{
	rt_uint32_t Index, IndexNext;
	struct pbuf *q;
	rt_uint8_t *ptr;

	/* take a slot */
	rt_sem_take(&sem_slot, RT_WAITING_FOREVER);

	/* lock EMAC device */
	rt_sem_take(&sem_lock, RT_WAITING_FOREVER);
//	rt_kprintf("lpc17xx_emac_tx\n");
	eth_Tx(pP, p);
//	/* get produce index */
//	Index = LPC_EMAC->TxProduceIndex;
//
//	/* calculate next index */
//	IndexNext = LPC_EMAC->TxProduceIndex + 1;
//	if(IndexNext > LPC_EMAC->TxDescriptorNumber)
//		IndexNext = 0;
//
//	/* copy data to tx buffer */
//	q = p;
//	ptr = (rt_uint8_t*)TX_BUF(Index);
//	while (q)
//	{
//		memcpy(ptr, q->payload, q->len);
//		ptr += q->len;
//		q = q->next;
//	}
//
//	TX_DESC_CTRL(Index) &= ~0x7ff;
//	TX_DESC_CTRL(Index) |= (p->tot_len - 1) & 0x7ff;
//
//	/* change index to the next */
//	LPC_EMAC->TxProduceIndex = IndexNext;

	/* unlock EMAC device */
	rt_sem_release(&sem_lock);

	return RT_EOK;
}

/* reception packet. */
struct pbuf *lpc17xx_emac_rx(rt_device_t dev)
{
	struct pbuf* p;
	rt_uint32_t size;
	rt_uint32_t Index;


	/* init p pointer */
	p = RT_NULL;

	/* lock EMAC device */
	rt_sem_take(&sem_lock, RT_WAITING_FOREVER);
//	rt_kprintf("lpc17xx_emac_rx\n");
	p=eth_isrRx(pP);
//	Index = LPC_EMAC->RxConsumeIndex;
//	if(Index != LPC_EMAC->RxProduceIndex)
//	{
//		size = (RX_STAT_INFO(Index) & 0x7ff)+1;
//		if (size > ETH_FRAG_SIZE) size = ETH_FRAG_SIZE;
//
//		/* allocate buffer */
//		p = pbuf_alloc(PBUF_LINK, size, PBUF_RAM);
//		if (p != RT_NULL)
//		{
//			struct pbuf* q;
//			rt_uint8_t *ptr;
//
//			ptr = (rt_uint8_t*)RX_BUF(Index);
//			for (q = p; q != RT_NULL; q= q->next)
//			{
//				memcpy(q->payload, ptr, q->len);
//				ptr += q->len;
//			}
//		}
//		
//		/* move Index to the next */
//		if(++Index > LPC_EMAC->RxDescriptorNumber)
//			Index = 0;
//
//		/* set consume index */
//		LPC_EMAC->RxConsumeIndex = Index;
//	}
//	else
//	{
//		/* Enable RxDone interrupt */
//		LPC_EMAC->IntEnable = INT_RX_DONE | INT_TX_DONE;
//	}

	/* unlock EMAC device */
	rt_sem_release(&sem_lock);

	return p;
}

void lpc17xx_emac_hw_init(void)
{
	rt_err_t result;
	rt_sem_init(&sem_slot, "tx_slot", NUM_TX_FRAG, RT_IPC_FLAG_FIFO);
	rt_sem_init(&sem_lock, "eth_lock", 1, RT_IPC_FLAG_FIFO);

	/* set autonegotiation mode */
	lpc17xx_emac_device.phy_mode = EMAC_PHY_AUTO;

	/* set mac address: (only for test) */
	lpc17xx_emac_device.dev_addr[0] = 0x1E;
	lpc17xx_emac_device.dev_addr[1] = 0x30;
	lpc17xx_emac_device.dev_addr[2] = 0x6C;
	lpc17xx_emac_device.dev_addr[3] = 0xA2;
	lpc17xx_emac_device.dev_addr[4] = 0x45;
	lpc17xx_emac_device.dev_addr[5] = 0x5E;

	lpc17xx_emac_device.parent.parent.init		= lpc17xx_emac_init;
	lpc17xx_emac_device.parent.parent.open		= lpc17xx_emac_open;
	lpc17xx_emac_device.parent.parent.close		= lpc17xx_emac_close;
	lpc17xx_emac_device.parent.parent.read		= lpc17xx_emac_read;
	lpc17xx_emac_device.parent.parent.write		= lpc17xx_emac_write;
	lpc17xx_emac_device.parent.parent.control	= lpc17xx_emac_control;
	lpc17xx_emac_device.parent.parent.user_data	= RT_NULL;

	lpc17xx_emac_device.parent.eth_rx			= lpc17xx_emac_rx;
	lpc17xx_emac_device.parent.eth_tx			= lpc17xx_emac_tx;

	result = eth_device_init(&(lpc17xx_emac_device.parent), "e0");
	RT_ASSERT(result == RT_EOK);
}
