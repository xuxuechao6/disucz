/*
 * File      : InfoNES_Main.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2006 - 2010, RT-Thread Development Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://www.rt-thread.org/license/LICENSE
 *
 * Change Logs:
 * Date           Author		Notes
 * 2010-10-01      yi.qiu	first version
 */
 
#include <rtthread.h>
#include <rtgui/driver.h>
#include <rtgui/rtgui_system.h>
#include <rtgui/rtgui_server.h>
#include <rtgui/widgets/workbench.h>
#include <rtgui/widgets/filelist_view.h>
#include <rtgui/widgets/button.h>
#include <dfs_posix.h>
#include "InfoNES.h"
#include "InfoNES_System.h"
#include "InfoNES_pAPU.h"

/*-------------------------------------------------------------------*/
/*  ROM image file information                                       */
/*-------------------------------------------------------------------*/

#define VBOX_SIZE    7 
#define VERSION      "InfoNES v0.96J"

char szRomName[ 256 ];
char szSaveName[ 256 ];
int nSRAM_SaveFlag;

/* Pad state */
DWORD dwKeyPad1;
DWORD dwKeyPad2;
DWORD dwKeySystem;

/* Emulation thread */
rt_thread_t emulation_tid;
int bThread;
rtgui_view_t* home_view;

static void InfoNES_ui_entry(void* parameter);
static void InfoNES_emulation_entry(void *parameter);

/* Palette data */
WORD NesPalette[ 64 ] =
{
  0x39ce, 0x1071, 0x0015, 0x2013, 0x440e, 0x5402, 0x5000, 0x3c20,
  0x20a0, 0x0100, 0x0140, 0x00e2, 0x0ceb, 0x0000, 0x0000, 0x0000,
  0x5ef7, 0x01dd, 0x10fd, 0x401e, 0x5c17, 0x700b, 0x6ca0, 0x6521,
  0x45c0, 0x0240, 0x02a0, 0x0247, 0x0211, 0x0000, 0x0000, 0x0000,
  0x7fff, 0x1eff, 0x2e5f, 0x223f, 0x79ff, 0x7dd6, 0x7dcc, 0x7e67,
  0x7ae7, 0x4342, 0x2769, 0x2ff3, 0x03bb, 0x0000, 0x0000, 0x0000,
  0x7fff, 0x579f, 0x635f, 0x6b3f, 0x7f1f, 0x7f1b, 0x7ef6, 0x7f75,
  0x7f94, 0x73f4, 0x57d7, 0x5bf9, 0x4ffe, 0x0000, 0x0000, 0x0000
};

int InfoNES_start( void)
{
	rt_thread_t tid;

	tid = rt_thread_create("InfoNES", InfoNES_ui_entry, RT_NULL, 2048, 0xa0, 5);
	if (tid != RT_NULL) rt_thread_startup(tid);
	return 0;
}

void InfoNES_panel_init(void)
{
	rtgui_rect_t rect;

	/* register main panel */
	rect.x1 = 0;
	rect.y1 = 0;
	rect.x2 = NES_DISP_WIDTH;
	rect.y2 = 320;
	rtgui_panel_register("main", &rect);
	rtgui_panel_set_default_focused("main");
}

static void InfoNES_emulation_entry(void *parameter)
{
	bThread = RT_TRUE;
	InfoNES_Main();
}

static rt_bool_t home_view_event_handler(rtgui_widget_t *widget, rtgui_event_t *event)
{
	if (event->type == RTGUI_EVENT_PAINT)
	{
		struct rtgui_dc* dc;
		rtgui_rect_t rect;

		rtgui_view_event_handler(widget, event);
		dc = rtgui_dc_begin_drawing(widget);
		if (dc == RT_NULL)
			return RT_FALSE;

		rect.x1 = 0;
		rect.y1 = 0;
		rect.x2 = NES_DISP_WIDTH;
		rect.y2 = NES_DISP_HEIGHT;
		RTGUI_DC_BC(dc) = white;
	    	rtgui_dc_fill_rect(dc, &rect);
		
		rect.x1 = 150;
		rect.y1 = 180;
		rect.x2 = 210;
		rect.y2 = 260;
		
		RTGUI_DC_TEXTALIGN(dc) = RTGUI_ALIGN_BOTTOM | RTGUI_ALIGN_CENTER_HORIZONTAL;
		demo_view_get_rect(RTGUI_VIEW(widget), &rect);
		rtgui_dc_draw_text(dc, "RT-Thread/GUI��׼�汾", &rect);
		rtgui_dc_end_drawing(dc);

		return RT_FALSE;
	}
	
	return rtgui_view_event_handler(widget, event);
}

static rt_bool_t workbench_event_handler(rtgui_widget_t *widget, rtgui_event_t *event)
{	
	if (event->type == RTGUI_EVENT_KBD)
	{
		struct rtgui_event_kbd* ekbd = (struct rtgui_event_kbd*)event;

		if (ekbd->type == RTGUI_KEYDOWN)
		{
			switch ( ekbd->key )
			{
				case RTGUIK_RIGHT:
					dwKeyPad1 |= ( 1 << 7 );
				break;

				case RTGUIK_LEFT:
					dwKeyPad1 |= ( 1 << 6 );
				break;

				case RTGUIK_DOWN:
					dwKeyPad1 |= ( 1 << 5 );
				break;

				case RTGUIK_UP:
					dwKeyPad1 |= ( 1 << 4 );
				break;

				case 's':
				case 'S':
					/* Start */
					dwKeyPad1 |= ( 1 << 3 );
				break;

				case 'a':
				case 'A':
					/* Select */
					dwKeyPad1 |= ( 1 << 2 );
				break;

				case 'z':                     
				case 'Z':                     
					/* 'A' */
					dwKeyPad1 |= ( 1 << 1 );
				break;

				case 'x': 
				case 'X': 
					/* 'B' */
				dwKeyPad1 |= ( 1 << 0 );
				break;

				case 'c':
				case 'C':   
					/* Toggle up and down clipping */
					PPU_UpDown_Clip = ( PPU_UpDown_Clip ? 0 : 1 );
				break;

				case 'q':
				case 'Q':
					dwKeySystem |= PAD_SYS_QUIT;
					if(bThread == RT_TRUE )
					{	
						rt_thread_delete(emulation_tid);
						rtgui_widget_update(RTGUI_WIDGET(home_view));
						bThread = RT_FALSE;
					}	
				break;

				case 'r':
				case 'R':
					/* Reset the application */
				break;

				case 'l':
				case 'L':  
				break;

				case 'm':
				case 'M':
					/* Toggle of sound mute */
				break;

				case 'i':
				case 'I':
				break;

				case 'v':
				case 'V':
					/* Version Infomation */
				break;

				default:  
				break;
			}
		}
		else
		{
			switch ( ekbd->key )
			{
				case RTGUIK_RIGHT:
					dwKeyPad1 &= ~( 1 << 7 );
				break;

				case RTGUIK_LEFT:
					dwKeyPad1 &= ~( 1 << 6 );
				break;

				case RTGUIK_DOWN:
					dwKeyPad1 &= ~( 1 << 5 );
				break;

				case RTGUIK_UP:
					dwKeyPad1 &= ~( 1 << 4 );
				break;

				case 's':
				case 'S':
					/* Start */
					dwKeyPad1 &= ~( 1 << 3 );
				break;

				case 'a':
				case 'A':
					/* Select */
					dwKeyPad1 &= ~( 1 << 2 );
				break;

				case 'z':
				case 'Z': 
					/* 'A' */
					dwKeyPad1 &= ~( 1 << 1 );
				break;

				case 'x': 
				case 'X': 
					/* 'B' */
					dwKeyPad1 &= ~( 1 << 0 );
				break;		
			}
		}	
	}
	return rtgui_workbench_event_handler(widget, event);
}	

static void open_btn_onbutton(rtgui_widget_t* widget, struct rtgui_event* event)
{
	rtgui_filelist_view_t *view;
	rtgui_workbench_t *workbench;
	rtgui_rect_t rect;

	/* ��ö����workbench */
	workbench = RTGUI_WORKBENCH(rtgui_widget_get_toplevel(widget));
	rtgui_widget_get_rect(RTGUI_WIDGET(workbench), &rect);
	view = rtgui_filelist_view_create(workbench, "/", "*.*", &rect);

	if (rtgui_view_show(RTGUI_VIEW(view), RT_TRUE) == RTGUI_MODAL_OK)
	{
		char path[32];

		rtgui_filelist_view_get_fullpath(view, path, sizeof(path));

		if (rt_strstr(path, ".nes") != RT_NULL)
		{
			/* Initialize a pad state */
			dwKeyPad1   = 0;
			dwKeyPad2   = 0;
			dwKeySystem = 0;
			FrameSkip = 5;
			
			bThread = RT_FALSE;
			strcpy( szRomName, path );
			InfoNES_Load(szRomName);

			emulation_tid = rt_thread_create("emu", InfoNES_emulation_entry, RT_NULL, 2048,0xa0 , 5); //was 20
			if (emulation_tid != RT_NULL) rt_thread_startup(emulation_tid);
		}	
	}

	rtgui_view_destroy(RTGUI_VIEW(view));
}

static void InfoNES_ui_entry(void* parameter)
{
	rt_mq_t mq;
	struct rtgui_workbench* workbench;
	rtgui_button_t* open_btn;	
	rtgui_rect_t rect;
	
	mq = rt_mq_create("InfoNES", 256, 4, RT_IPC_FLAG_FIFO);
	rtgui_thread_register(rt_thread_self(), mq);

	workbench = rtgui_workbench_create("main", "InfoNES");
	if (workbench == RT_NULL) 
	{
		rt_kprintf("can't find panel 'main'\n");
		return;
	}	
	rtgui_widget_set_event_handler(RTGUI_WIDGET(workbench), workbench_event_handler);
	/* add home view */
	home_view = rtgui_view_create("Home");
	rtgui_widget_set_event_handler(RTGUI_WIDGET(home_view), home_view_event_handler);

	rtgui_workbench_add_view(workbench, home_view);
	/* this view can be focused */
	RTGUI_WIDGET(home_view)->flag |= RTGUI_WIDGET_FLAG_FOCUSABLE;
	/* set widget focus */
	rtgui_widget_focus(RTGUI_WIDGET(home_view));

	demo_view_get_rect(home_view, &rect);
	rect.x1 = 5; rect.x2 = rect.x1 + 120;
	rect.y1 = 5; rect.y2 = rect.y1 + 20;
	open_btn = rtgui_button_create("��NES ��Ϸ�ļ�");
	rtgui_container_add_child(RTGUI_CONTAINER(home_view), RTGUI_WIDGET(open_btn));
	rtgui_widget_set_rect(RTGUI_WIDGET(open_btn), &rect);
	rtgui_button_set_onbutton(open_btn, open_btn_onbutton);
	rtgui_view_show(home_view, RT_FALSE);
	
	rtgui_workbench_event_loop(workbench);
	rtgui_workbench_destroy(workbench);

	rtgui_thread_deregister(rt_thread_self());
	rt_mq_delete(mq);	 
}	

int InfoNES_Menu()
{

	/* Nothing to do here */
	return 0;
}

int InfoNES_ReadRom( const char *pszFileName )
{
/*
 *  Read ROM image file
 *
 *  Parameters
 *    const char *pszFileName          (Read)
 *
 *  Return values
 *     0 : Normally
 *    -1 : Error
 */
	int fd;
	struct stat s;

	stat(pszFileName, &s);
	fd = open(pszFileName, O_RDONLY, 0);
	if(fd < 0) 
	{
		rt_kprintf("open %s error\n", pszFileName);
		return -1;
	}	
	read(fd, (char*)&NesHeader, sizeof NesHeader);
	if ( rt_memcmp( NesHeader.byID, "NES\x1a", 4 ) != 0 )
	{
		rt_kprintf("Unrecognize NesHeader\n");
		/* not .nes file */
		close( fd );
		return -1;
	}

	/* Clear SRAM */
	rt_memset( SRAM, 0, SRAM_SIZE );

	/* If trainer presents Read Triner at 0x7000-0x71ff */
	if ( NesHeader.byInfo1 & 4 )
	{
		read(fd, &SRAM[ 0x1000 ], 512);
	}

	/* Allocate Memory for ROM Image */
	ROM = (BYTE *)rt_malloc( NesHeader.byRomSize * 0x4000 );

	/* Read ROM Image */
	read( fd, ROM, 0x4000*NesHeader.byRomSize);

	if ( NesHeader.byVRomSize > 0 )
	{
		/* Allocate Memory for VROM Image */
		VROM = (BYTE *)rt_malloc( NesHeader.byVRomSize * 0x2000 );

		/* Read VROM Image */
		read( fd, VROM, 0x2000*NesHeader.byVRomSize);
	}

	/* File close */
	close( fd );

	/* Successful */
	return 0;
}

void InfoNES_ReleaseRom()
{
/*
 *  Release a memory for ROM
 *
 */
	if ( ROM )
	{
		rt_free( ROM );
		ROM = NULL;
	}

	if ( VROM )
	{
		rt_free( VROM );
		VROM = NULL;
	}
}

void *InfoNES_MemoryCopy( void *dest, const void *src, int count )
{
/*
 *  memcpy
 *
 *  Parameters
 *    void *dest                       (Write)
 *      Points to the starting address of the copied block's destination
 *
 *    const void *src                  (Read)
 *      Points to the starting address of the block of memory to copy
 *
 *    int count                        (Read)
 *      Specifies the size, in bytes, of the block of memory to copy
 *
 *  Return values
 *    Pointer of destination
 */
	rt_memcpy( dest, src, count );
	return dest;
}

void *InfoNES_MemorySet( void *dest, int c, int count )
{
/*
 *  memset
 *
 *  Parameters
 *    void *dest                       (Write)
 *      Points to the starting address of the block of memory to fill
 *
 *    int c                            (Read)
 *      Specifies the byte value with which to fill the memory block
 *
 *    int count                        (Read)
 *      Specifies the size, in bytes, of the block of memory to fill
 *
 *  Return values
 *    Pointer of destination
 */

	rt_memset( dest, c, count);  
	return dest;
}

void InfoNES_LoadFrame(void)
{
	WORD* framebuffer;
	const struct rtgui_graphic_driver* gd;
	register WORD wColor;
	rtgui_rect_t rect;
	//static int temp; 
	
	int i = 0;
	int j = 0;
	int k = 0;
	int l = 0;

	rect.x1 = 0;
	rect.x2 = NES_DISP_WIDTH;
	rect.y1 = 0;
	rect.y2 = NES_DISP_HEIGHT;
	

//	temp = rt_tick_get();
	
	gd = rtgui_graphic_driver_get_default();
	//framebuffer = (WORD *)gd->get_framebuffer();
	framebuffer = (WORD *)rtgui_graphic_driver_get_framebuffer(gd);

	for (i = 0; i < NES_DISP_HEIGHT ; i++)
	{
		for(j = 0; j < NES_DISP_WIDTH ; j++)
		{
			wColor = WorkFrame[k++];
			wColor = ((wColor & 0x7fe0)<<1) | (wColor & 0x001f);
//			framebuffer[l+800] = wColor;
//		framebuffer[l++] = wColor;
//		framebuffer[l+800] = wColor;
		framebuffer[l++] = wColor;
		}
		l=l+800-NES_DISP_WIDTH;
	}
	rtgui_graphic_driver_screen_update(gd, &rect);
	//	temp = rt_tick_get() - temp;
	//rt_kprintf("tick %d\n",temp);
	//gd->screen_update(&rect);
}

void InfoNES_PadState( DWORD *pdwPad1, DWORD *pdwPad2, DWORD *pdwSystem )
{
	/* Transfer joypad state */
	*pdwPad1   = dwKeyPad1;
	*pdwPad2   = dwKeyPad2;
	*pdwSystem = dwKeySystem;
}

void InfoNES_SoundInit( void ) 
{

}

int InfoNES_SoundOpen( int samples_per_sync, int sample_rate ) 
{
	/* Successful */
	return 1;
}

void InfoNES_SoundClose( void ) 
{

}

void InfoNES_SoundOutput( int samples, BYTE *wave1, BYTE *wave2, BYTE *wave3, BYTE *wave4, BYTE *wave5 )
{
 
}

void InfoNES_Wait(void) 
{

}

void InfoNES_MessageBox( char *pszMsg, ... )
{

}

#if defined(RT_USING_FINSH)
#include <finsh.h>

void start_nes(void)
{
	InfoNES_panel_init();
	InfoNES_start();
}

FINSH_FUNCTION_EXPORT(start_nes, start nes emulator);
#endif

