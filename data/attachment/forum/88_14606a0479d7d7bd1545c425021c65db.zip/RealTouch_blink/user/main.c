#include "led.h"

int main(void)
{
    led_init();

    TIM7_Configuration();

    while(1);
}
