/*
 * File      : led.c
 * RT-Thread evaluation board RealTouch sample with no os
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2006 - 2012, RT-Thread Development Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://www.rt-thread.org/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2012-08-06     bloom5       first  version.
 */


#include "stm32f4xx.h"
#include "led.h"


void TIM7_Configuration(void)
{
    NVIC_InitTypeDef NVIC_InitStructure;
	  TIM_TimeBaseInitTypeDef  TIM_TimeBaseInitStruct;
	
    /* 操作定时器前先使能输入时钟 */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM7, ENABLE);

	
    /**** Time base configuration ****/
	
	  /* 设置自动重装载周期,计数到5000为1000ms */
    TIM_TimeBaseInitStruct.TIM_Period = 5000;
	  /* 设置预分频值,即定时器计数频率为10Khz */
    TIM_TimeBaseInitStruct.TIM_Prescaler =(8400-1);
    TIM_TimeBaseInitStruct.TIM_ClockDivision = 0; 
	  /* 向上计数模式 */
    TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up; 

    /* 根据TIM_TimeBaseInitStruct中指定的参数初始化TIM7的时基单位 */
    TIM_TimeBaseInit(TIM7, &TIM_TimeBaseInitStruct); 

    /* 使能TIM7更新中断 */
    TIM_ITConfig(TIM7, TIM_IT_Update, ENABLE);

    /* Configure the NVIC Preemption Priority Bits */
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    /* Enable the TIM7 global Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = TIM7_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    /* 启动定时器 */		
		TIM_Cmd(TIM7, ENABLE);  
}


void led_init()
{
    GPIO_InitTypeDef  GPIO_InitStructure;

    /* 使能GPIOD时钟 */
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);

    /* 配置GPIO_LED引脚 */
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_3;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_OUT; 		  
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz; 
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_NOPULL; 

    GPIO_Init(GPIOD, &GPIO_InitStructure);
}

void led_on(void)
{
    /* 设置PD3为低电平 */
    GPIO_ResetBits(GPIOD, GPIO_Pin_3);
}

void led_off(void)
{
	  /* 设置PD3为高电平 */
    GPIO_SetBits(GPIOD, GPIO_Pin_3);
}

void led_toggle()
{
	  /* 切换PD3电平状态 */
    GPIO_ToggleBits(GPIOD, GPIO_Pin_3);
}
