
/*	Includes -------------------------------------------------------*/
#include <rtthread.h>
#include "wifi_module.h"
#include <board.h>


ALIGN(RT_ALIGN_SIZE)
static char wifi_module_stack[1024];
struct rt_thread wifi_module_thread;
static void wifi_module_thread_entry(void *param)
{
    
    while(1)
    {
		
        rt_thread_delay(100);
    }
}

int cmb_hw_wifi_module_init(void)
{

    rt_thread_init(&wifi_module_thread,"wifi_module",
                   wifi_module_thread_entry,RT_NULL,
                   &wifi_module_stack[0],
                   sizeof(wifi_module_stack),5,10);
    rt_thread_startup(&wifi_module_thread);    
    
    return 0;
}

