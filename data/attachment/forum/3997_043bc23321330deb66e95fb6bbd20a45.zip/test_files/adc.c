
#include <rtthread.h>
#include "adc.h"

ALIGN(RT_ALIGN_SIZE)
static char adc_thread_stack[1024];
static struct rt_thread adc_thread;

static void adc_thread_entry(void *parameter)
{
    rt_time_t	next_delay;
	uint16_t press_val_data=0;
	float press_val_in_mmHg=0.0;

    while(1)
    {	

	press_val_data=(uint16_t)(press_val_in_mmHg*10);

        next_delay=100;//10ms update
        rt_thread_delay(next_delay); 
    }
}

int cmb_hw_adc_init(void)
{    
    rt_thread_init(&adc_thread,
                    "adc",
                    adc_thread_entry,
                    RT_NULL,
                    &adc_thread_stack[0],
                    sizeof(adc_thread_stack),16,20);
    rt_thread_startup(&adc_thread);
		
	return 0;
}

