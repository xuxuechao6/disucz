
#include <rtthread.h>
#include "stm32f4xx.h"
#include "stdio.h"


/*	Global variables -----------------------------------------------*/

extern int cmb_hw_adc_init(void);
extern int cmb_hw_wifi_module_init(void);

void cmb_platform_init(void)
{
	cmb_hw_wifi_module_init();//5
	cmb_hw_adc_init();//16

}

