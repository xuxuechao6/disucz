/*
*******************************************Copyright (c)****************************************************************
*                                     Wynlink Technologies Co., Ltd
* File    : rt_startup.c
* By      : xyou
* Version : V1.00.00
* Note(s) : 
************************************************************************************************************************
*/


/*
*********************************************************************************************************
*                                             include files
*********************************************************************************************************
*/
#include <rthw.h>
#include <rtthread.h>


#ifdef __CC_ARM
extern int Image$$RW_IRAM1$$ZI$$Limit;
#elif __ICCARM__
#pragma section="HEAP"
#else
extern int __bss_end;
#endif



#include "s3c6410.h"


/**
 * This function will handle rtos timer
 */
static void rt_timer_handler(int vector)
{
    register rt_base_t regv;

    /* clear timer4 interrupt status bit */
    regv = s3c_readl(TINT_CSTAT);
    regv |= (1 << 9);
    s3c_writel(regv, TINT_CSTAT);

    rt_tick_increase();
}

/**
 * This function will init timer4 for system ticks
 */
static void rt_hw_timer_init()
{
    rt_uint32_t pclk;
    register rt_base_t regv;

    pclk = s3c_get_pclk();

    /* timer4, pre = 15+1 */
    regv = s3c_readl(TCFG0);
    regv &= (0xff << 8);
    regv |= (15 << 8);
    s3c_writel(regv, TCFG0);
    /* all are interrupt mode,set Timer 4 MUX 1/4 */
    regv = s3c_readl(TCFG1);
    regv &= ~(0x0f << 16);
    regv |= (2 << 16);
    s3c_writel(regv, TCFG1);

    regv = (rt_int32_t)(pclk / (4 * 16 * RT_TICK_PER_SECOND)) - 1;
    s3c_writel(regv, TCNTB4);
    /* manual update */
    regv = s3c_readl(TCON);
    regv &= ~(0x0f << 20);
    regv |= (0x02 << 20);
    s3c_writel(regv, TCON);
    /* install interrupt handler */
    rt_hw_interrupt_install(IRQ_TIMER4, rt_timer_handler, RT_NULL);
    rt_hw_interrupt_umask(IRQ_TIMER4);

    /* enable timer4 interrupt */
    regv = s3c_readl(TINT_CSTAT);
    regv |= (1 << 4);
    s3c_writel(regv, TINT_CSTAT);

    /* start timer4, reload */
    regv = s3c_readl(TCON);
    regv &= ~(0x0f << 20);
    regv |= (0x05 << 20);
    s3c_writel(regv, TCON);
}


#define rGPKCON0        (*(volatile unsigned *)(0x7F008800))
#define rGPKCON1        (*(volatile unsigned *)(0x7F008804))
#define rGPKDAT         (*(volatile unsigned *)(0x7F008808))
#define rGPKPUD         (*(volatile unsigned *)(0x7F00880C))

#define rGPFCON         (*(volatile unsigned *)(0x7F0080A0))
#define rGPFDAT         (*(volatile unsigned *)(0x7F0080A4))
#define rGPFPUD         (*(volatile unsigned *)(0x7F0080A8))

//�˿ڳ�ʼ��
void Port_Init(void)
{
//LED
    //32b����:rGPKCON = (rGPKCON & 0x0000ffff) | 0x11110000��GPK4--GPK7Ϊ���ģʽ
    rGPKCON0 = (rGPKCON0 & ~(0xffffU<<16))|(0x1111U<<16);
    //��ֹ������
    rGPKPUD  = (rGPKPUD  & ~(0xffU << 8))|(0x00U<<8);
//������
    //���ģʽ
    rGPFCON = (rGPFCON & ~(0x3U<<28))|(0x1U<<28);
    //��ֹ������
    rGPFPUD = (rGPFPUD  & ~(0x3U<<28));
    //�˿�����Ϊ0
    rGPFDAT = rGPFDAT & ~(0x1U<<14);
}

//LED��ʾ
void Led_Display(int data)
{
    rGPKDAT = (rGPKDAT & ~(0xf<<4)) | ((data & 0xf)<<4);
}


//��������
void Beep_On(void)
{

    rGPFDAT = rGPFDAT | (0x1U<<14);
}

//�������ر�
void Beep_Off(void)
{

    rGPFDAT = (rGPFDAT & ~(0x1U<<14));
}


void rt_init_thread_entry(void* parameter)
{
    rt_uint8_t  led_index = 0x01;
    rt_uint8_t  beep_index = 0;

    Port_Init();


    while(1)
    {
        beep_index ++;

        if(beep_index >= 4)
        {
            beep_index = 0;
            Beep_On();
        }
        else
        {
            Beep_Off();
        }


        Led_Display(led_index);
        led_index <<= 1;
        if(led_index > 0x08)
        {
            led_index = 0x01;
        }
        rt_thread_delay(RT_TICK_PER_SECOND);



    }
}

int rt_application_init()
{
    rt_thread_t init_thread;

    init_thread = rt_thread_create("init",
                                rt_init_thread_entry, RT_NULL,
                                1024, 8, 20);

    if (init_thread != RT_NULL)
        rt_thread_startup(init_thread);


    return 0;
}

/**
 * This function will startup RT-Thread RTOS.
 */
void rtthread_startup(void)
{
    /* initialize timer4 */
    rt_hw_timer_init();

    /* show version */
    rt_show_version();

    /* init tick */
    rt_system_tick_init();

    /* init kernel object */
    rt_system_object_init();

    /* init timer system */
    rt_system_timer_init();

#ifdef RT_USING_HEAP
#   ifdef __CC_ARM
        rt_system_heap_init((void*)&Image$$RW_IRAM1$$ZI$$Limit, (void*)0x51000000);
#   elif __ICCARM__
        rt_system_heap_init(__segment_end("HEAP"), (void*)0x51000000);
#   else
        /* init memory system */
        rt_system_heap_init((void*)&__bss_end, (void*)0x51000000);
#   endif
#endif

    /* init scheduler system */
    rt_system_scheduler_init();

#ifdef RT_USING_DFS
    /* init sdcard driver */
#if STM32_USE_SDIO
    rt_hw_sdcard_init();
#else
    rt_hw_msd_init();
#endif
#endif

//    rt_hw_rtc_init();

    /* init all device */
    rt_device_init_all();

    /* init application */
    rt_application_init();

#ifdef RT_USING_FINSH
    /* init finsh */
    finsh_system_init();
    finsh_set_device("uart1");
#endif

    /* init timer thread */
    rt_system_timer_thread_init();

    /* init idle thread */
    rt_thread_idle_init();

    /* start scheduler */
    rt_system_scheduler_start();

    /* never reach here */
    return ;
}

/*
*********************************************************************************************************
*                                            main()
* Description : rt-thread startup entry
* Argument(s) : void
* Return(s)   : int
* Caller(s)   : startup.s
* Note(s)     : none
*********************************************************************************************************
*/
int main(void)
{
    /* disable interrupt first */
    rt_hw_interrupt_disable();

    /* startup RT-Thread RTOS */
    rtthread_startup();

    return 0;
} /*** mian ***/




