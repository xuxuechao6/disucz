#!/bin/bash

gcc -D_REENTRANT cpu_port.c -o cpu_port -lpthread
