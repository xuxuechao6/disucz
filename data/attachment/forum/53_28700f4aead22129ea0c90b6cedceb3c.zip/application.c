#include <rtthread.h>
#include <rtgui/rtgui_server.h>
#include <rtgui/rtgui_system.h>
#include <rtgui/widgets/label.h>
#include <rtgui/widgets/workbench.h>

rtgui_label_t* _label;
void rtc_timeout(struct rtgui_timer* timer, void* parameter)
{
	static int second = 0;
	char text[32];

	rt_snprintf(text, 30, "%d", second++);
	rtgui_label_set_text(_label, text);
}

void workbench_panel1(void* parameter)
{
	rt_mq_t mq;
	rtgui_rect_t rect;
	rtgui_view_t* view;
	struct rtgui_workbench* workbench;
	rtgui_timer_t* timer;

	mq = rt_mq_create("wmq", 256, 8, RT_IPC_FLAG_FIFO);
	/* ע�ᵱǰ�߳�ΪGUI�߳� */
	rtgui_thread_register(rt_thread_self(), mq);
	/* ����һ������̨ */
	workbench = rtgui_workbench_create("main", "workbench #1");
	if (workbench == RT_NULL) return;

	view = rtgui_view_create("test");
	/* ���ӵ���workbench�� */
	rtgui_workbench_add_view(workbench, view);

	rtgui_widget_get_rect(RTGUI_WIDGET(view), &rect);
	rect.x1 += 5;
	rect.x2 -= 5;
	rect.y1 += 5;
	rect.y2 = rect.y1 + 20;
	/* ����һ��label�ؼ� */
	_label = rtgui_label_create("0");
	/* ���ñ�ǩλ����Ϣ */
	rtgui_widget_set_rect(RTGUI_WIDGET(_label), &rect);
	/* ���ӱ�ǩ����ͼ�� */
	rtgui_container_add_child(RTGUI_CONTAINER(view), RTGUI_WIDGET(_label));

	/* ����һ����ʱ�� */
	timer = rtgui_timer_create(100, RT_TIMER_FLAG_PERIODIC, rtc_timeout, RT_NULL);
	rtgui_timer_start(timer);

	rtgui_view_show(view, RT_FALSE);
	/* ִ�й���̨�¼�ѭ�� */
	rtgui_workbench_event_loop(workbench);

	/* ȥע��GUI�߳� */
	rtgui_thread_deregister(rt_thread_self());

	/* delete message queue */
	rt_mq_delete(mq);
}

/* ��ʼ��workbench */
static void workbench_init()
{
	rt_thread_t tid;

	tid = rt_thread_create("wb", workbench_panel1, RT_NULL, 2048, 20, 5);
	if (tid != RT_NULL) rt_thread_startup(tid);
}

int rt_application_init()
{
	panel_init();
	workbench_init();

	return 0;
}
