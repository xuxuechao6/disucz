int bbb = 0;

void setbbb(int b)
{
    bbb = b;
}