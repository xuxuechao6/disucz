# -*- coding: utf-8 -*-

###########################################################################
## Python code generated with wxFormBuilder (version May  4 2010)
## http://www.wxformbuilder.org/
##
## PLEASE DO "NOT" EDIT THIS FILE!
###########################################################################

import wx
import binascii

###########################################################################
## Class FontDialog
###########################################################################

class FontDialog ( wx.Dialog ):

    def __init__( self, parent ):
        wx.Dialog.__init__ ( self, parent, id = wx.ID_ANY, title = u"Font Generator", pos = wx.DefaultPosition, size = wx.Size( 329,255 ), style = wx.DEFAULT_DIALOG_STYLE )

        self.SetSizeHintsSz( wx.DefaultSize, wx.DefaultSize )

        bSizer1 = wx.BoxSizer( wx.VERTICAL )

        bSizer3 = wx.BoxSizer( wx.VERTICAL )

        bSizer4 = wx.BoxSizer( wx.HORIZONTAL )

        self.m_staticText2 = wx.StaticText( self, wx.ID_ANY, u"Choose Font", wx.DefaultPosition, wx.DefaultSize, 0 )
        self.m_staticText2.Wrap( -1 )
        bSizer4.Add( self.m_staticText2, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )

        self.m_fontPicker = wx.FontPickerCtrl( self, wx.ID_ANY, wx.NullFont, wx.DefaultPosition, wx.DefaultSize, wx.FNTP_FONTDESC_AS_LABEL )
        self.m_fontPicker.SetMaxPointSize( 100 )
        bSizer4.Add( self.m_fontPicker, 1, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )

        bSizer3.Add( bSizer4, 0, wx.EXPAND, 5 )

        sbSizer1 = wx.StaticBoxSizer( wx.StaticBox( self, wx.ID_ANY, u"Preview" ), wx.VERTICAL )

        self.m_staticTextFont = wx.StaticText( self, wx.ID_ANY, u"This is a font viewer!", wx.DefaultPosition, wx.DefaultSize, 0 )
        self.m_staticTextFont.Wrap( -1 )
        sbSizer1.Add( self.m_staticTextFont, 0, wx.ALL, 5 )

        bSizer3.Add( sbSizer1, 1, wx.EXPAND, 5 )

        bSizer1.Add( bSizer3, 1, wx.EXPAND, 5 )

        bSizer2 = wx.BoxSizer( wx.HORIZONTAL )


        bSizer2.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )

        self.m_button1 = wx.Button( self, wx.ID_ANY, u"Generator", wx.DefaultPosition, wx.DefaultSize, 0 )
        bSizer2.Add( self.m_button1, 0, wx.ALL, 5 )

        self.m_button2 = wx.Button( self, wx.ID_CANCEL, u"Exit", wx.DefaultPosition, wx.DefaultSize, 0 )
        bSizer2.Add( self.m_button2, 0, wx.ALL, 5 )

        bSizer1.Add( bSizer2, 0, wx.EXPAND, 5 )

        self.SetSizer( bSizer1 )
        self.Layout()

        self.Centre( wx.BOTH )

        # Connect Events
        self.m_fontPicker.Bind( wx.EVT_FONTPICKER_CHANGED, self.OnFontChanged )
        self.m_button1.Bind( wx.EVT_BUTTON, self.OnFontMake )

        self.fixed = False
        self.buffer = wx.EmptyBitmap(320,240)
        self.dc = wx.BufferedDC(None,self.buffer)
        self.dc.SetPen(wx.Pen("WHITE", 1))
        self.dc.SetBackground(wx.Brush((0,0,0,255),wx.SOLID))
        self.dc.SetTextBackground((255,255,255,255))
        self.dc.SetTextForeground((255,255,255,255))

        self.ShowModal()
        self.Destroy()

    def __del__( self ):
        pass

    # Virtual event handlers, overide them in your derived class
    def OnFontChanged( self, event ):
        w = h = 0
        self.font = event.GetFont()
        if not self.font.IsFixedWidth():
            self.fixed = False
        else:
            self.fixed = True

        self.height = self.font.GetPointSize()
        self.face = self.font.GetFaceName()
        self.face = self.face.lower()
        self.dc.SetFont(self.font)
        self.font.SetFamily(wx.TELETYPE)
        font_height = self.font.GetPointSize()
        while True:
            (w, h) = self.dc.GetTextExtent('W')
            if h > self.height:
                self.font.SetPointSize(font_height - 0.5)
                self.dc.SetFont(self.font)
                font_height = font_height - 0.1
            else:
                break
        self.width = w
        self.height = h

        # reset font
        self.font.SetFamily(wx.TELETYPE)
        self.dc.SetFont(self.font)
        self.m_staticTextFont.SetFont(self.font)
        self.m_staticTextFont.Refresh()

    def GetCharPixel(self ,chr,width,height):
        """get the pixels of a given char"""
        self.dc.Clear()
        # print chr,
        #print "getting char ",chr#,self.charheight,width
        self.dc.DrawText(chr,0,0)
        (width, height) = self.dc.GetTextExtent(chr)
        #self.screen.Blit(0,0,319,239,self.dc,0,0)
        pixel=[]
        width = ((width + 7)/8) * 8
        word = width/8
        for i in range(0, height):
            for m in range(0, word):
                k=7
                dot = 0
                for j in range(0, 8) :
                    clr=self.dc.GetPixel(m * 8 + j,i)
                    if(clr[0]!=0):
                        dot = dot|(1<<k)

                    k = k - 1

                pixel.append(dot)

        return pixel

    def WriteFile(self, name, charlist, charpixeldic, charWidth, charOffset):
        name = name.lower()
        name = name.replace(' ', '_')
        headerFile=open(name + '.c','w')
        headerFile.write("/* RT-Thread/GUI Font */\n")
        headerFile.write("#include <rtgui/font.h>\n\n")
        headerFile.write("static const unsigned char font_data[]={\n")
        result=""
        ct=0
        for i in charlist[0:-1]:
            result=result+"    /*---char: "+i+" ---*/\n    "
            s=["0x"+binascii.b2a_hex(chr(j)) for j in charpixeldic[i]]
            for j in s[0:-1] :
                result=result+j+","
            result=result+s[-1]+",\n"
            ct=ct+1
            if(ct>1000):
                print "writing, please wait"
                headerFile.write(result)
                headerFile.flush()
                result=""
        #add the last char
        result=result+"    /*---char: "+charlist[-1]+" ---*/\n    "
        s=["0x"+binascii.b2a_hex(chr(j)) for j in charpixeldic[charlist[-1]]]
        for j in s[0:-1] :
            result=result+j+","
        result=result+s[-1]+"\n};\n\n"
        headerFile.write(result)

        if not self.fixed:
            # write width array
            headerFile.write("const static rt_uint8_t font_width[] = {\n")
            result = ''
            for char in charlist:
                result += ('\t%d,\n' % charWidth[char])
            headerFile.write(result)
            headerFile.write("};\n\n")
            
            # write offset array
            headerFile.write("const static rt_uint32_t font_offset[] = {\n")
            result = ''
            for char in charlist:
                result += ('\t%d,\n' % charOffset[char])
            headerFile.write(result)
            headerFile.write("};\n\n")

        headerFile.write("struct rtgui_font_bitmap " + name + " =\n")
        headerFile.write("{\n")
        headerFile.write("	(const rt_uint8_t*)font_data, 		/* bmp */\n")
        if self.fixed:
            headerFile.write("\tRT_NULL,      /* font width */\n")
            headerFile.write("\tRT_NULL,       /* offset for each character */\n")            
        else:
            headerFile.write("\t(const rt_uint8_t*)font_width,      /* font width */\n")
            headerFile.write("\t(const rt_uint32_t*)font_offset,       /* offset for each character */\n")
            
        headerFile.write("\t" + str(self.width) + ",                     /* width */\n")
        headerFile.write("\t" + str(self.height) + ", 				/* height */\n")
        headerFile.write("\t32, 					/* first char */\n")
        headerFile.write("\t127					/* last char */\n};\n\n")

        headerFile.write("struct rtgui_font " + name + "_font =\n{\n")
        headerFile.write("\t\"" + self.face + "\", 				/* family */\n")
        headerFile.write("\t" + str(self.height) + ", 				/* height */\n")
        headerFile.write("\t1, 					/* refer count */\n")
        headerFile.write("\t&bmp_font_engine, 	/* font engine */\n")
        headerFile.write("\t&" + name + ",				/* font private data */\n};\n")
        headerFile.close()

    def OnFontMake( self, event ):
        "generate the ascii char library"
        charList=[]
        charDic={}
        charWidth = {}
        charOffset = {}
        offset = 0
        # self.height = self.font.GetPointSize()
        for i in range(32,127):
            charList.append(chr(i))
            charDic[chr(i)]=self.GetCharPixel(chr(i), self.width, self.height)
            (w, h) = self.dc.GetTextExtent(chr(i))
            # print (w, h, ((w+7)/8)*h)
            charWidth[chr(i)] = w
            charOffset[chr(i)] = offset
            offset = offset + (((w+7)/8)*h)

        self.WriteFile(self.face + str(self.width) + "_"+ str(self.height), charList,charDic, charWidth, charOffset)
        print "\nfont made done!"

if __name__ == '__main__':
    app = wx.App(0)
    FontDialog(None)
    app.MainLoop()
