#include <string.h>

#include <rtthread.h>


#ifdef RT_USING_RTGUI

#include <rtgui/event.h>
#include <rtgui/rtgui_server.h>
#include <rtgui/kbddef.h>

#define RETURN_KEY_SIZE        5
#define KEYCODE_MAX_LEN        5

static struct rt_thread    * virtual_key_thread = RT_NULL;
static struct rt_semaphore * key_rx_sem         = RT_NULL;

static const rt_int16_t key_return[RETURN_KEY_SIZE]=
{
    RTGUIK_F1, RTGUIK_F2, RTGUIK_F3, RTGUIK_F4, RTGUIK_ESCAPE,
//    RTGUIK_UP, RTGUIK_UP, RTGUIK_UP, RTGUIK_UP, RTGUIK_DOWN,
};

struct keycode
{
    char keycode[KEYCODE_MAX_LEN];
    rt_uint16_t key;
};

static const struct keycode keycode_table[] =
{
//    {{0x00, 0x00, 0x00, 0x00, 0x00}, RTGUIK_UNKNOWN},
    {{0x1B, 0x5B, 0x41, 0x00, 0x00}, RTGUIK_UP},
    {{0x1B, 0x5B, 0x42, 0x00, 0x00}, RTGUIK_DOWN},
    {{0x1B, 0x5B, 0x44, 0x00, 0x00}, RTGUIK_LEFT},
    {{0x1B, 0x5B, 0x43, 0x00, 0x00}, RTGUIK_RIGHT},

    /* Function keys */
    {{0x1B, 0x5B, 0x31, 0x31, 0x7E}, RTGUIK_F1},
    {{0x1B, 0x5B, 0x31, 0x32, 0x7E}, RTGUIK_F2},
    {{0x1B, 0x5B, 0x31, 0x33, 0x7E}, RTGUIK_F3},
    {{0x1B, 0x5B, 0x31, 0x34, 0x7E}, RTGUIK_F4},
};

static rt_err_t key_rx_ind(rt_device_t dev, rt_size_t size)
{
    /* release semaphore */
    rt_sem_release(key_rx_sem);

    return RT_EOK;
}

static rt_uint16_t _get_key(char * key_value)
{
    rt_uint32_t i,j;

    for(i=0; i<sizeof(keycode_table)/sizeof(struct keycode); i++)
    {
        rt_bool_t match = RT_TRUE;

        for(j=0; j<KEYCODE_MAX_LEN; j++)
        {
            if( keycode_table[i].keycode[j] != key_value[j] )
            {
                match = RT_FALSE;
                break;
            }
        }
        if( match == RT_TRUE )
        {
            return keycode_table[i].key;
        }
    }

    return RTGUIK_UNKNOWN;
}

static rt_bool_t is_return(rt_int16_t * key_history, rt_uint32_t key_history_index)
{
    rt_bool_t result = RT_TRUE;
    rt_uint32_t i,j;

    for(i=0; i<RETURN_KEY_SIZE; i++)
    {
        j = key_history_index + i;
        if( j >= RETURN_KEY_SIZE )
        {
            j -= RETURN_KEY_SIZE;
        }
        if( key_history[j] != key_return[i] )
        {
            result = RT_FALSE;
            break;
        }
    }

    return result;
}

static void virtual_key_thread_entry(void *parameter)
{
    struct rt_device * key_device = RT_NULL;
    rt_err_t (*rx_indicate)(rt_device_t dev, rt_size_t size);
    rt_int32_t wait_time = RT_WAITING_FOREVER;

    static char key_value[KEYCODE_MAX_LEN];
    rt_int32_t key_index = 0;
    struct rtgui_event_kbd kbd_event;

    rt_int16_t key_history[RETURN_KEY_SIZE];
    rt_uint32_t key_history_index = 0;

    key_device = (struct rt_device *)parameter;
    RT_ASSERT( key_device != RT_NULL );

    /* save old rx_indicate	*/
    rx_indicate = key_device->rx_indicate;
    /* set new rx_indicate */
    rt_device_set_rx_indicate(key_device, key_rx_ind);

    {
        char str_buffer[129];

        rt_thread_delay(RT_TICK_PER_SECOND/10);
        rt_sprintf(str_buffer, "\r\nRT-Thread virtual keyboard.\r\n");
        rt_device_write(key_device, 0, str_buffer, strlen(str_buffer));
        rt_sprintf(str_buffer, "press F1 F2 F3 F4 and ESC to quit.\r\n");
        rt_device_write(key_device, 0, str_buffer, strlen(str_buffer));
    }

    /* init keyboard event */
    RTGUI_EVENT_KBD_INIT(&kbd_event);
    kbd_event.mod  = RTGUI_KMOD_NONE;
    kbd_event.unicode = 0;

    while(1)
    {
        /* wait receive */
        if (rt_sem_take(key_rx_sem, wait_time) == RT_EOK)
        {
            /* read one character from device */
            while (rt_device_read(key_device, 0, &key_value[key_index], 1) == 1)
            {
                key_index++;
                if(key_index >= KEYCODE_MAX_LEN)
                {
                    key_index = 0;
                }

                wait_time = 2;
            }
        }
        else
        {
            kbd_event.key = RTGUIK_UNKNOWN;

            if( key_index == 1 )
            {
                if( ( key_value[0] >= 0x08 )
                        && ( key_value[0] <= 0x7F ) )
                {
                    kbd_event.key = key_value[0];
                }
            }
            else
            {
                kbd_event.key = _get_key(key_value);
            }

            key_history[key_history_index] = kbd_event.key;
            key_history_index++;
            if( key_history_index >= RETURN_KEY_SIZE )
            {
                key_history_index = 0;
            }
            if( is_return(key_history, key_history_index) == RT_TRUE )
            {
                char str_buffer[129];
                rt_sprintf(str_buffer, "match return key, bye!\r\n");
                rt_device_write(key_device, 0, str_buffer, strlen(str_buffer));
                goto _virtual_key_returen;
            }

            if( kbd_event.key != RTGUIK_UNKNOWN )
            {
                kbd_event.type = RTGUI_KEYDOWN;
                /* post down event */
                rtgui_server_post_event(&(kbd_event.parent), sizeof(kbd_event));
                /* post up event */
                kbd_event.type = RTGUI_KEYUP;
                rtgui_server_post_event(&(kbd_event.parent), sizeof(kbd_event));
            }

            key_index = 0;
            memset(key_value, 0, sizeof(key_value));
            wait_time = RT_WAITING_FOREVER;
        }
    }

_virtual_key_returen:
    /* recovery old rx_indicate	*/
    rt_device_set_rx_indicate(key_device, rx_indicate);
    virtual_key_thread = RT_NULL;
}

void rt_hw_virtual_key_init(struct rt_device * key_device)
{
    if( virtual_key_thread != RT_NULL )
    {
        rt_kprintf("virtual_key_thread is Already exist!\r\n");
        return;
    }

    RT_ASSERT( key_device != RT_NULL );

    if( key_rx_sem == RT_NULL )
    {
        key_rx_sem = rt_sem_create("key_rx", 0, 0);
        if( key_rx_sem == RT_NULL )
        {
            rt_kprintf("create sem key_rx error\r\n");
            return;
        }
    }

    virtual_key_thread = rt_thread_create("V-KEY",
                                          virtual_key_thread_entry,
                                          key_device,
                                          512,
                                          RT_THREAD_PRIORITY_MAX-2,
                                          1);

    if( virtual_key_thread != RT_NULL )
    {
        rt_thread_startup(virtual_key_thread);
    }
}

#ifdef RT_USING_FINSH
#include <finsh.h>
#include <shell.h>

void virtual_key(void)
{
    const char* device_name = finsh_get_device();
    struct rt_device * device = rt_device_find(device_name);

    if( device != RT_NULL )
    {
        rt_hw_virtual_key_init(device);
    }
}
FINSH_FUNCTION_EXPORT(virtual_key, start virtual key);

#endif /**< #ifdef RT_USING_FINSH */

#endif /**< #ifdef RT_USING_RTGUI */
