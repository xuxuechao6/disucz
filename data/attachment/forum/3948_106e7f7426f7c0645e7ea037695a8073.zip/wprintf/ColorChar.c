
#include <rtgui/dc.h>
#include <rtgui/widgets/widget.h>
#include "ColorChar.h"


extern struct rtgui_font rtgui_font_asc12;
extern struct rtgui_font rtgui_font_asc16;

static void colorchar_init(struct rtgui_colorchar* colorchar)
{
	int i;
	struct oneline* header;
	rtgui_rect_t rect;
	int height,width;
	
	rtgui_font_get_metrics(RTGUI_WIDGET_FONT(RTGUI_WIDGET(colorchar)), "W", &rect);
	height = rtgui_rect_height(rect);
	width = rtgui_rect_width(rect);
	rtgui_widget_get_rect(RTGUI_WIDGET(colorchar), &rect);
	
	colorchar->maxline = rtgui_rect_height(rect) / (height + 1);
	colorchar->maxcpl = rtgui_rect_width(rect) / width;
	colorchar->height = height;
	colorchar->lines = RT_NULL;
	colorchar->header = RT_NULL;
	colorchar->currline = RT_NULL;
	colorchar->line = 0;
	colorchar->flag = 0;
	colorchar->select = -1;
	rt_mutex_init(&(colorchar->lock), "cc", RT_IPC_FLAG_FIFO);
	colorchar->tid = rt_thread_self();
	
	if(colorchar->header == RT_NULL)
	{
		header = (struct oneline*)rt_malloc(colorchar->maxline * sizeof(struct oneline));
		colorchar->lines = header;
		colorchar->header = header;
		colorchar->currline = header;
		colorchar->line = 0;
		for(i = 0; i < colorchar->maxline - 1 ; i++)
		{
			header->next = header + 1 ;
			header->header = RT_NULL;
			header->unnum = 0;
			header->cnum = 0;
			header->num = 0;
			header ++;
		}
		header->next = colorchar->header;
		header->header = RT_NULL;
		header->unnum = 0;
		header->cnum = 0;
		header->num = 0;
	}
}
static void cc_lock(struct rtgui_colorchar* cc)
{
	rt_mutex_take(&(cc->lock), RT_WAITING_FOREVER);
}
static void cc_unlock(struct rtgui_colorchar* cc)
{
	rt_mutex_release(&(cc->lock));
}
static void cc_display(struct rtgui_colorchar* cc)
{
	struct rtgui_event_command ecmd;
	RTGUI_EVENT_COMMAND_INIT(&ecmd);
	ecmd.type = RTGUI_CMD_USER_INT;
	ecmd.command_id = 0;
	rtgui_thread_send(cc->tid, &ecmd.parent, sizeof(ecmd)); 
}
static void _cc_printf(struct rtgui_colorchar* cc, int flag, rtgui_color_t color, const char *buf, int strlen)
{
	int i,len;
	struct oneline* header;
	struct oneline* oneline;
	struct string* string;
	struct string* strheader;
	struct string* strprev;
	
	header = cc->header;
	oneline = cc->currline;
	if(flag == COLORCHAR_NEWLINE)
	{
		if(oneline->header)
		{
			oneline = oneline->next;
		}
		if(oneline->header)
		{
			for(i = 0 ; i < oneline->num ; i++)
			{
				string = oneline->header;
				oneline->header = string->next;
				rt_free(string);
			}
			oneline->header = RT_NULL;
			oneline->unnum = 0;
			oneline->cnum = 0;
			oneline->num = 0;
			header = header->next;
		}
		else
		{
			cc->line ++;
		}
		COLORCHAR_CURLINE_CLR(cc);   //��������Ҫȫ�����»���
	}
	else if(flag == COLORCHAR_DELLINE)
	{
		if(oneline->header && oneline->num>0)
		{
			for(i = 0 ; i < oneline->num ; i++)
			{
				string = oneline->header;
				oneline->header = string->next;
				rt_free(string);
			}
			oneline->header = RT_NULL;
			oneline->unnum = 0;
			oneline->cnum = 0;
			oneline->num = 0;
		}
		if(!IS_COLORCHAR_DIRTY(cc))  //ֻ�е�ǰû�����־�Ż�ֻ���Ƶ�ǰ��
			COLORCHAR_CURLINE(cc);
	}
	else if(flag == COLORCHAR_ENDLINE)
	{ //������β����0���ַ�ʱ,�����ǰ�в������򴴽�һ������
		if(oneline->header == RT_NULL) cc->line ++;
		else if(strlen == 0)  //��ǰ�д���,��ֱ�ӷ���
		{
			return ;
		}
		if(!IS_COLORCHAR_DIRTY(cc))  //ֻ�е�ǰû�����־�Ż�ֻ���Ƶ�ǰ��
			COLORCHAR_CURLINE(cc);
	}
	else if(flag == COLORCHAR_DELCHAR)
	{
		if(oneline->header && oneline->cnum > 0) 
		{
			strprev = RT_NULL;
			string = oneline->header;
			while(string->next) 
			{
				strprev = string;
				string = string->next;
			}
			len = rt_strlen(string->str) - 1;
			if(len >= 0) string->str[len] = 0;
			if(len == 0 && strprev)
			{
				rt_free(string);
				strprev->next = RT_NULL;
				oneline->num --;
			}
			oneline->cnum--;
			if(oneline->cnum < oneline->unnum)
				oneline->unnum = oneline->cnum;
			if(!IS_COLORCHAR_DIRTY(cc))  //ֻ�е�ǰû�����־�Ż�ֻ���Ƶ�ǰ��
				COLORCHAR_CURLINE(cc);
			COLORCHAR_DIRTY(cc);
		}
		return; 
	}
	cc->header = header;
	cc->currline = oneline;
	COLORCHAR_DIRTY(cc);
	
	string = (struct string*)rt_malloc(sizeof(struct string) + strlen + 1);
	string->str = (char *)string + sizeof(struct string);
	string->str[strlen] = '\0';
	if(strlen != 0) rt_memcpy(string->str, buf, strlen);
	string->color = color;
	string->next = RT_NULL;
	
	oneline->num ++;
	oneline->cnum += strlen;
	strprev = strheader = oneline->header;
	if(strheader == RT_NULL)
	{
		oneline->header = string;
	}
	else
	{
		while(strheader->next != RT_NULL)
		{
			strprev = strheader;
			strheader = strheader->next;
		}
		if(strheader->color == string->color)
		{
			oneline->num --;
			len = rt_strlen(strheader->str);
			if(len != 0)
			{
				rt_free(string);
				string = rt_malloc(sizeof(struct string) + len + strlen + 1);
				string->str = (char *)string + sizeof(struct string);
				string->str[len + strlen] = '\0';
				rt_memcpy(string->str, strheader->str, len);
				rt_memcpy(string->str + len, buf, strlen);
				string->color = color;
				string->next = RT_NULL;
			}
			if(strprev == strheader) oneline->header = string;
			else strprev->next = string;
			rt_free(strheader);
		}
		else
			strheader->next = string;
	}
}
int cc_printf(struct rtgui_colorchar* cc, rtgui_color_t color, const char *fmt, va_list args)
{
	int strlen,len,n;
	rt_bool_t dirty;
	char buf[RT_CONSOLEBUF_SIZE];
	char *cp = buf;
	char *c  = buf;
	
	if(cc->lines == RT_NULL)
	{
		return -1;
	}
	rt_memset(buf, 0, sizeof(buf));
	n = rt_vsprintf(buf, fmt, args);
	
	cc_lock(cc);
	dirty = IS_COLORCHAR_DIRTY(cc);
	while(*c != '\0')
	{
		cp = c;
		while(*cp >= 0x20) cp++;
		strlen = cp-c;
		len = cc->maxcpl - cc->currline->cnum ;
		len = strlen > len ? len : strlen;
		_cc_printf(cc,COLORCHAR_ENDLINE,color,c,len);
		strlen -= len;
		c += len;
		while(strlen > 0)
		{
			len = strlen > cc->maxcpl ? cc->maxcpl : strlen ;
			_cc_printf(cc,COLORCHAR_NEWLINE,color,c,len);
			strlen -= len;
			c += len;
		}
		switch(*cp)
		{
		case '\n': _cc_printf(cc,COLORCHAR_NEWLINE,color,cp,0); break;
		case '\r': _cc_printf(cc,COLORCHAR_DELLINE,color,cp,0); break;
		case '\b': _cc_printf(cc,COLORCHAR_DELCHAR,color,cp,0); break;
		}  
		c = cp+1; 
	}
	cc_unlock(cc);
	if(!dirty)
	{
		cc_display(cc);
	}
	return n;
}
int cc_printf_dot(struct rtgui_colorchar* cc, rtgui_color_t color, const char *fmt, ...)
{
	int num;
	va_list args;
	va_start(args,fmt);
	num = cc_printf(cc, color, fmt, args);
	va_end(args);
	return num; 
}
/**/
void cc_select(struct rtgui_colorchar* cc,rt_bool_t state)
{
	if(state)
		cc->select = cc->line - 1;
	else
		cc->select = -1;  
}

/*
* �����Ļ
*/
void cc_clear(struct rtgui_colorchar* cc)
{
	struct oneline* oneline;
	struct string* string;
	int i,j;
	
	cc_lock(cc);
	oneline = cc->header;
	for(i = 0 ; i < cc->line ; i++)
	{
		for(j = 0 ; j < oneline->num ; j++)
		{
			string = oneline->header;
			oneline->header = string->next;
			rt_free(string);
		}
		oneline->header = RT_NULL;
		oneline->unnum = 0;
		oneline->cnum = 0;
		oneline->num = 0;
		oneline = oneline->next;
	}
	cc->header = cc->lines;
	cc->currline = cc->lines;
	cc->line = 0;
	cc->flag = 0;
	cc->select = -1;
	cc_unlock(cc); 
}
void cc_exit(struct rtgui_colorchar* cc)
{
	struct oneline* oneline;
	struct string* string;
	int i,j;
	
	cc_lock(cc);
	oneline = cc->header;
	for(i = 0 ; i < cc->line ; i++)
	{
		for(j = 0 ; j < oneline->num ; j++)
		{
			string = oneline->header;
			oneline->header = string->next;
			rt_free(string);
		}
		oneline = oneline->next;
	}
	rt_free(cc->lines);
	cc->lines = RT_NULL;
	cc_unlock(cc);
	rt_mutex_detach(&(cc->lock));
}



/*
* �ڿؼ��ϵĻ��Ʋ���
*/
static void cc_paint(struct rtgui_colorchar* cc)
{
	int i,x1,x2,y1,cnum;
	int height;
	rt_bool_t iscurrline;
	struct rtgui_dc* dc;
	rtgui_color_t bc;
	struct rtgui_rect rect,srect;
	struct oneline* oneline;
	struct string* string;
	
	
	dc = rtgui_dc_begin_drawing(RTGUI_WIDGET(cc));
	if (dc == RT_NULL) return ;
	rtgui_widget_get_rect(RTGUI_WIDGET(cc), &rect);
	bc = RTGUI_DC_BC(dc);
	
	cc_lock(cc);
	if(!IS_COLORCHAR_DIRTY(cc))
	{
		goto _end;
	}
	if(!IS_COLORCHAR_PAINTED(cc)) 
	{
		COLORCHAR_PAINTED(cc);
		rtgui_dc_fill_rect(dc, &rect);
	}  
	rect.x1 += 1;
	x1 = rect.x1;
	x2 = rect.x2;
	y1 = rect.y1;
	height = cc->height;
	iscurrline = IS_COLORCHAR_CURLINE(cc);
	
	if(iscurrline) {
		oneline = cc->currline;
		i = cc->line - 1 ;
	}else{
		oneline = cc->header;
		i = 0;
	}
	for(  ; i < cc->line ; i++)
	{
		//rect.x1 = x1;
		//rect.x2 = x2;
		rect.y1 = y1 + i * (height + 1);
		rect.y2 = rect.y1 + height ;
		string = oneline->header;
		if(!iscurrline) oneline->unnum = 0;
		
		if(i == cc->select) RTGUI_DC_BC(dc) = blue;
		else RTGUI_DC_BC(dc) = bc;
		if(iscurrline && oneline->unnum > 0)
		{
			rtgui_font_get_metrics(RTGUI_WIDGET_FONT(RTGUI_WIDGET(cc)), "h", &srect); 
			rect.x1 += oneline->unnum * rtgui_rect_width(srect);
			rect.x2 = cc->llrect.x2; 
		}
		rtgui_dc_fill_rect(dc, &rect);
		rect.x2 = x2;
		cnum = 0; 
		do{
			int len = rt_strlen(string->str);
			cnum += len;
			if(cnum > oneline->unnum)
			{
				char *str = string->str;
				str += len - (cnum - oneline->unnum); 
				RTGUI_DC_FC(dc) = string->color;
				rtgui_dc_draw_text(dc, str, &rect);
				rtgui_font_get_metrics(RTGUI_WIDGET_FONT(RTGUI_WIDGET(cc)), str, &srect);
				rect.x1 += rtgui_rect_width(srect);
				oneline->unnum = cnum;
			}
			string = string->next;
		}while(string);
		oneline = oneline->next;
		rect.x2 = rect.x1;
		rect.x1 = x1;
		cc->llrect = rect;
		rect.x2 = x2;
	}
	
	COLORCHAR_DIRTY_CLR(cc);   
_end:
	cc_unlock(cc);
	RTGUI_DC_BC(dc) = bc;
	rtgui_dc_end_drawing(dc);
}
static void cc_set_repaint(struct rtgui_colorchar* cc)
{
	COLORCHAR_DIRTY(cc);
	COLORCHAR_CURLINE_CLR(cc);  
}




void cc_timeout(struct rtgui_timer* timer, void* parameter)
{
	struct rtgui_colorchar* colorchar;
	colorchar = parameter;
	if(colorchar->caret)
	{
		colorchar->caret = 0;
		cc_printf_dot(colorchar,white,"\b");
	}
	else 
	{
		colorchar->caret = 1;
		cc_printf_dot(colorchar,white,"_");
	}
}

static rt_bool_t cc_onfocus (struct rtgui_widget* widget, struct rtgui_event* event)
{
	struct rtgui_colorchar* colorchar;
	colorchar = (struct rtgui_colorchar*)widget;
	if(colorchar->caret_timer) rtgui_timer_start(colorchar->caret_timer);
	return RT_TRUE; 
}

static rt_bool_t cc_onunfocus (struct rtgui_widget* widget, struct rtgui_event* event)
{
	struct rtgui_colorchar* colorchar;
	colorchar = (struct rtgui_colorchar*)widget;
	if(colorchar->caret_timer) rtgui_timer_stop(colorchar->caret_timer);
	return RT_TRUE; 
}

static void _rtgui_colorchar_constructor(struct rtgui_colorchar* colorchar)
{
	RTGUI_WIDGET(colorchar)->flag |= RTGUI_WIDGET_FLAG_FOCUSABLE;
	RTGUI_WIDGET_FOREGROUND(RTGUI_WIDGET(colorchar)) = white;
	RTGUI_WIDGET_BACKGROUND(RTGUI_WIDGET(colorchar)) = black;
	RTGUI_WIDGET_FONT(RTGUI_WIDGET(colorchar)) = &rtgui_font_asc12;
	rtgui_widget_set_onfocus(RTGUI_WIDGET(colorchar), cc_onfocus);
	rtgui_widget_set_onunfocus(RTGUI_WIDGET(colorchar), cc_onunfocus);
	rtgui_widget_set_event_handler(RTGUI_WIDGET(colorchar), rtgui_colorchar_event_handler);
	
	colorchar->caret_timer = rtgui_timer_create(70, 
		RT_TIMER_FLAG_PERIODIC | RT_TIMER_FLAG_SOFT_TIMER,
		cc_timeout, colorchar);
	colorchar->caret = 0;
}
static void _rtgui_colorchar_destructor(struct rtgui_colorchar* colorchar)
{
	if(colorchar->caret_timer)
	{
		rtgui_timer_stop(colorchar->caret_timer);
		rtgui_timer_destory(colorchar->caret_timer);
		colorchar->caret_timer = RT_NULL;
	}
	cc_exit(colorchar);
}

DEFINE_CLASS_TYPE(colorchar, "colorchar",
				  RTGUI_WIDGET_TYPE,
				  _rtgui_colorchar_constructor,
				  _rtgui_colorchar_destructor,
				  sizeof(struct rtgui_colorchar));

rt_bool_t rtgui_colorchar_event_handler(struct rtgui_widget* widget,struct rtgui_event* event)
{
	struct rtgui_colorchar* colorchar = (struct rtgui_colorchar*)widget;
	switch (event->type)
	{
	case RTGUI_EVENT_PAINT:  
		cc_set_repaint(colorchar);
		/* No break */
	case RTGUI_EVENT_COMMAND:
		cc_paint(colorchar);
		break;
	}
	return RT_FALSE;
}

struct rtgui_colorchar* rtgui_colorchar_create(rtgui_rect_t* rect)
{
	struct rtgui_colorchar* colorchar;
	
	colorchar = (struct rtgui_colorchar*) rtgui_widget_create (RTGUI_COLORCHAR_TYPE);
	if (colorchar != RT_NULL && rect != RT_NULL)
	{
		rtgui_widget_set_rect(RTGUI_WIDGET(colorchar), rect);
		colorchar_init(colorchar);
	}
	return colorchar;
}

void rtgui_colorchar_destroy(struct rtgui_colorchar* colorchar)
{
	rtgui_widget_destroy(RTGUI_WIDGET(colorchar));
}

int rtgui_colorchar_printf(struct rtgui_colorchar* colorchar, rtgui_color_t color, const char *fmt, va_list args)
{
	int size;
	if(colorchar->caret_timer) rtgui_timer_stop(colorchar->caret_timer);
	if(colorchar->caret) 
	{ 
		colorchar->caret = 0;
		cc_printf_dot(colorchar,white,"\b");
	}
	size = cc_printf(colorchar, color, fmt, args);
	if(colorchar->caret_timer) rtgui_timer_start(colorchar->caret_timer);
	return size;
}

void rtgui_colorchar_cleanup(struct rtgui_colorchar* colorchar)
{
	struct rtgui_event_win event;
	RTGUI_EVENT_WIN_CLOSE_INIT(&event);
	rtgui_thread_send(colorchar->tid, &event.parent, sizeof(event));  
}
