
#include <rtthread.h>
#include <rtgui/dc.h>
static void thread_entry1(void* parameter)
{
	int i;
	extern int wprintf(rtgui_color_t color, const char *fmt, ...);
	wprintf(red," \\ | /\n");rt_thread_delay(10);
	wprintf(green,"- RT -     Thread Operating System\n");rt_thread_delay(10);
	wprintf(blue," / | \\     %d.%d.%d build %s\n", RT_VERSION, RT_SUBVERSION, RT_REVISION, __DATE__);rt_thread_delay(10);
	wprintf(white," 2006 - 2012 Copyright by rt-thread team\n");rt_thread_delay(10); 
	wprintf(red,"quit ");
	for(i=3;i>0;i--)
	{
		wprintf(white,"%d",i);
		rt_thread_delay(100);
		wprintf(white,"\b");
	}
}
static void thread_entry0(void* parameter)
{
	int i;
	rt_thread_t thread;
	extern int wprintf(rtgui_color_t color, const char *fmt, ...);
	
	wprintf(white," \\ | /\n");rt_thread_delay(10);
	wprintf(white,"- RT -     Thread Operating System\n");rt_thread_delay(10);
	wprintf(white," / | \\     %d.%d.%d build %s\n", RT_VERSION, RT_SUBVERSION, RT_REVISION, __DATE__);rt_thread_delay(10);
	wprintf(white," 2006 - 2012 Copyright by rt-thread team\n");rt_thread_delay(10);
	rt_thread_delay(100);
	
	
	thread = rt_thread_create("test-1",
		thread_entry1, RT_NULL,
		512, 20, 5);
	if (thread != RT_NULL)
	{
        rt_thread_startup(thread);
	}
	
	rt_thread_delay(600);
	i=0;
	while(1)
	{
		if(i%2)
			wprintf(white,"i=%d",i++);
		else
			wprintf(red,"i=%d",i++);
		rt_thread_delay(5);
		if(i>50) break;
	}
	wprintf(green,"\ntest quit!");
	while(1) rt_thread_delay(100);
}





void wp_test_init(void)
{
	rt_thread_t thread;
	thread = rt_thread_create("test-0",
		thread_entry0, RT_NULL,
		512, 20, 5);
	if (thread != RT_NULL)
	{
        rt_thread_startup(thread);
	} 
}
