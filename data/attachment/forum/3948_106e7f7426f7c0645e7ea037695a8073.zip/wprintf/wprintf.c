#include <rtthread.h>
#include <rtgui/rtgui.h>
#include <rtgui/rtgui_system.h>
#include <rtgui/widgets/window.h>
#include <rtgui/driver.h>
#include "ColorChar.h"

static rt_bool_t on_activate(struct rtgui_widget* widget, struct rtgui_event* event)
{
	rtgui_widget_focus(rtgui_container_get_first_child(RTGUI_CONTAINER(widget)));
	return RT_TRUE; 
}
static rt_bool_t on_deactivate(struct rtgui_widget* widget, struct rtgui_event* event)
{
	rtgui_widget_unfocus(rtgui_container_get_first_child(RTGUI_CONTAINER(widget)));
	return RT_TRUE; 
}
static rt_bool_t on_close(struct rtgui_widget* widget, struct rtgui_event* event)
{
	rtgui_win_close(RTGUI_WIN(widget));
	return RT_TRUE; 
}
static void win_entry(void* parameter)
{
	rt_mq_t mq;
	rtgui_win_t* win;
	rtgui_rect_t rect;
	rtgui_colorchar_t* cc;
	struct {
		struct rt_mailbox mb;
		char name[RT_NAME_MAX];
	}*args;
	args = parameter;
	
#ifdef RTGUI_USING_SMALL_SIZE
	mq = rt_mq_create("cmd", 32, 16, RT_IPC_FLAG_FIFO);
#else
	mq = rt_mq_create("cmd", 256, 16, RT_IPC_FLAG_FIFO);
#endif
	rtgui_thread_register(rt_thread_self(), mq);
	
	rect.x1 = rect.y1 = 0;
	rect.x2 = rtgui_graphic_driver_get_default()->width;
	rect.y2 = rtgui_graphic_driver_get_default()->height;
	rtgui_rect_inflate(&rect,-20);
	rect.y1 += 10;
	
	win = rtgui_win_create(RT_NULL, args->name, &rect, RTGUI_WIN_STYLE_CLOSEBOX);
	rtgui_win_set_onactivate(win,on_activate);
	rtgui_win_set_ondeactivate(win,on_deactivate);
	rtgui_win_set_onclose(win,on_close);
	rtgui_rect_inflate(&rect,-1);
	cc = rtgui_colorchar_create(&rect);
	rtgui_container_add_child(RTGUI_CONTAINER(win), RTGUI_WIDGET(cc));
	rtgui_win_show(win,RT_FALSE);
	rt_mb_send_wait(&args->mb, (rt_uint32_t)cc, 10);
	rtgui_win_event_loop(win);
	
	rtgui_thread_deregister(rt_thread_self());
	rt_mq_delete(mq);
}
/*cleanup�������������߳��˳�ʱ�˳�gui����*/
static void cleanup(rt_thread_t tid)
{
	rtgui_colorchar_t* cc;
	
	cc = (rtgui_colorchar_t*)tid->user_data;
	if(RTGUI_IS_COLORCHAR(cc))
	{
		rtgui_colorchar_cleanup(cc);  
	}
}
/*���gui��ʾ����*/
static void* win_get(void)
{
	rt_thread_t thread;
	rt_err_t err = RT_EOK;
	rtgui_colorchar_t* cc;
	struct {
		struct rt_mailbox mb;
		char name[RT_NAME_MAX];
	}args;
	
	if(rt_thread_self()->cleanup)
	{
		return RT_NULL;
	}
	rt_strncpy(args.name, rt_thread_self()->name, RT_NAME_MAX);
	rt_mb_init(&args.mb, "printf", &cc, sizeof(&cc), RT_IPC_FLAG_FIFO);
	
	thread = rt_thread_create("printf",
		win_entry, &args,
		RTGUI_APP_THREAD_STACK_SIZE,
		RTGUI_APP_THREAD_PRIORITY,
		RTGUI_APP_THREAD_TIMESLICE);
	if (thread != RT_NULL) 
		err = rt_thread_startup(thread);
	if(err == RT_EOK)
	{ 
		err = rt_mb_recv(&args.mb, (void*)&cc, 40);
	}
	rt_mb_detach(&args.mb);
	
	if(err != RT_EOK)
		return RT_NULL;
	else
	{
		rt_thread_self()->cleanup = cleanup;
		return cc;
	}
}


static int _wprintf(rtgui_colorchar_t* cc, rtgui_color_t color, const char *fmt, va_list args)
{
	return rtgui_colorchar_printf(cc, color, fmt, args); 
}

int wprintf(rtgui_color_t color, const char *fmt, ...)
{
	void* cc;
	int num = -1;
	rt_thread_t thread = rt_thread_self();
	if(thread->user_data == 0)
	{
		thread->user_data = (rt_uint32_t)win_get();
	}
	if(thread->user_data == 0) return -1;
	cc = (void*)thread->user_data;
	if(RTGUI_IS_COLORCHAR(cc))
	{
		va_list args;
		va_start(args,fmt);
		num = _wprintf(cc, color, fmt, args);
		va_end(args);
	}
	return num;
}
