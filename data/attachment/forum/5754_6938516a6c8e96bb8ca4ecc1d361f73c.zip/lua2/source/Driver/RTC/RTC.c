#include "RTC.h"

void RTC_Init()
{
	RTCCON = 0;
}

void RTC_Get(TIME_T * pstTime)
{
	pstTime->nYear =  RTC_BCD2INT(BCDYEAR) + 2000;
	pstTime->nMon =  RTC_BCD2INT(BCDMON);
	pstTime->nDay =  RTC_BCD2INT(BCDDATE);
	pstTime->nHour =  RTC_BCD2INT(BCDHOUR);
	pstTime->nMin =  RTC_BCD2INT(BCDMIN);
	pstTime->nSec =  RTC_BCD2INT(BCDSEC);
}

void RTC_Set(TIME_T * pstTime)
{
	RTCCON = (1 << 0);
	BCDYEAR = RTC_INT2BCD(pstTime->nYear - 2000);
	BCDMON =  RTC_INT2BCD(pstTime->nMon);
	BCDDATE =  RTC_INT2BCD(pstTime->nDay);
	BCDHOUR =  RTC_INT2BCD(pstTime->nHour);
	BCDMIN =  RTC_INT2BCD(pstTime->nMin);
	BCDSEC =  RTC_INT2BCD(pstTime->nSec);
	RTCCON = (0 << 0);
}
