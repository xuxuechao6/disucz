#ifndef _RTC_H_
#define _RTC_H_
#include <stdlib.h>
#include <string.h>
#include <S3C2440.h>

#define RTC_BCD2INT(X) (((((X) & 0xF0) >> 4) * 10) + ((X) & 0xF))
#define RTC_INT2BCD(X) ((((X) / 10) << 4) + ((X) % 10))

typedef struct TIME_T
{
	int nYear;
	int nMon;
	int nDay;
	int nHour;
	int nMin;
	int nSec;

}TIME_T;

void RTC_Init(void);
void RTC_Get(TIME_T * pstTime);
void RTC_Set(TIME_T * pstTime);

#endif
