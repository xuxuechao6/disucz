#ifndef _TOUCH_H_
#define _TOUCH_H_
#include "../Lcd/lcd.h"

typedef struct findxy_t
{
	int x;					
	int y;					
	int num;			
}findxy_t;

int TOUCH_AD2X(int nAdxValue);
int TOUCH_AD2Y(int nAdyValue);
void TOUCH_WaitPenUp(void);
void TOUCH_WaitPenDown(void);
void TOUCH_findXY(void);
void TOUCH_GetXY(void);
void TOUCH_Timer(void);
void TOUCH_Start(void);
void TOUCH_Stop(void);
void TOUCH_IRQEntry(void);
void TOUCH_Init(void);

#endif
