#include <stdio.h>
#include "touch.h"
#include "../../usr/global.h"

#define GUI_TOUCH_XSIZE LCD_WIDTH
#define GUI_TOUCH_YSIZE LCD_HEIGHT

#define GUI_TOUCH_AD_LEFT (1185)
#define GUI_TOUCH_AD_RIGHT (99)
#define GUI_TOUCH_AD_TOP (168)
#define GUI_TOUCH_AD_BOTTOM (1120)

#define STATE_PEN_DOWN (1)
#define STATE_PEN_UP (2)

static int s_nPenState = STATE_PEN_UP;
static int timerID = -1;
static int xynum = 0;
static int cx = 0;
static int cy = 0;

static int fx = 0;
static int fy = 0;

int front_key_id;

int file_line_id;

int timer_file_bechoice_id;
int is_file_bechoice;
int timer_id_hand_write_sleep;

int is_hand_write;
int is_have_start_hand_sleep;

findxy_t chfindxy[20]={0};

int TOUCH_AD2X(int nAdxValue)
{
	int nTempVal = 0;
	
	nTempVal = (nAdxValue - GUI_TOUCH_AD_LEFT) * (GUI_TOUCH_XSIZE -1);
	nTempVal = nTempVal / (GUI_TOUCH_AD_RIGHT - GUI_TOUCH_AD_LEFT);
		
	return nTempVal;
}

int TOUCH_AD2Y(int nAdyValue)
{
	int nTempVal = 0;
	
	nTempVal = (nAdyValue - GUI_TOUCH_AD_TOP) * (GUI_TOUCH_YSIZE -1);
	nTempVal = nTempVal / (GUI_TOUCH_AD_BOTTOM - GUI_TOUCH_AD_TOP);
		
	return nTempVal;
}

void TOUCH_WaitPenUp()
{
	ADCCON = (1<<14)+(9<<6);
	ADCTSC = 0x1d3;
	ADCUPDN = 0;
}

void TOUCH_WaitPenDown()
{
	ADCCON = (1<<14)+(9<<6);
	ADCTSC = 0xd3;
	ADCUPDN = 0;
}

void TOUCH_findXY()
{
	int nIndex = 0;
	int nX = 0;
	int nY = 0;
	int nXCount = 0;
	int nYCount = 0;

	int nXMin = 2000;
	int nXMax = -1;
	int nYMin = 2000;
	int nYMax = -1;


	for(nIndex =0 ; nIndex < 5; nIndex++)
	{
		nX = chfindxy[nIndex].x;
		nY = chfindxy[nIndex].y;

		//��¼��Сֵ
		if(nX < nXMin)
			nXMin = nX;
		if(nY < nYMin)
			nYMin = nY;

		//��¼���ֵ
		if(nX < nXMax)
			nXMax = nX;
		if(nY < nYMax)
			nYMax = nY;

		//ͳ�Ʋ���ֵ
		nXCount += nX;
		nYCount += nY;
	}

	nX = (nXCount - nXMin -nXMax) / 3;
	nY = (nYCount - nYMin -nYMax) / 3;
	cx = nX;
	cy = nY;
	//LCD_PutPixel(nY,nX,RGB(0,0,0));
}

void TOUCH_GetXY()
{
	int nIndex = 0;
	int nX = 0;
	int nY = 0;
	int nXCount = 0;
	int nYCount = 0;

	int nXMin = 2000;
	int nXMax = -1;
	int nYMin = 2000;
	int nYMax = -1;

	//char xch[20] = {0};
	//char ych[20] = {0};

	int tfront_key_id = -1;

	if(is_show_system == 1 || is_show_file_list == 1)
	{
		for(nIndex =0 ; nIndex < 6; nIndex++)
		{
			//��ʼ����
			ADCTSC = ((1<<3)|(1<<2));
			ADCCON |= 0x1;
			//�ȴ���������
			while(ADCCON & 0x1);
			while(!(ADCCON & 0x8000));
			//��ȡ����ֵ
			nX = (ADCDAT0 & 0x3FF);
			nY = (ADCDAT1 & 0x3FF);
	
			//��¼��Сֵ
			if(nX < nXMin)
				nXMin = nX;
			if(nY < nYMin)
				nYMin = nY;
	
			//��¼���ֵ
			if(nX < nXMax)
				nXMax = nX;
			if(nY < nYMax)
				nYMax = nY;
	
			//ͳ�Ʋ���ֵ
			nXCount += nX;
			nYCount += nY;
		}
	
		nX = (nXCount - nXMin -nXMax) / 4;
		nY = (nYCount - nYMin -nYMax) / 4;
		
		/*�����ѹ��ӡ
		sprintf(xch,"%d",nX);
		sprintf(ych,"%d",nY);
		
		LCD_DrawText(70,40,xch,4,RGB(255,255,255),RGB(0,0,0));
		LCD_DrawText(100,40,ych,4,RGB(255,255,255),RGB(0,0,0));	
		*/
		/*��������*/
		if(nX > GUI_TOUCH_AD_LEFT)
			nX = GUI_TOUCH_AD_LEFT;
		if(nX < GUI_TOUCH_AD_RIGHT)
			nX = GUI_TOUCH_AD_RIGHT;
		if(nY < GUI_TOUCH_AD_TOP)
			nY = GUI_TOUCH_AD_TOP;
		if(nY > GUI_TOUCH_AD_BOTTOM)
			nY = GUI_TOUCH_AD_BOTTOM;
		
		//����ѹת��Ϊ����	�����ú�����Ӧ�Ĵ���
		nX = TOUCH_AD2X(nX);
		nY = TOUCH_AD2Y(nY);
		
		/*X����*/
		if(nX<230 && nX>189)
			nX+=3;
		else if(nX<=54 && nX>5)
			nX+=3;
		else if(nX<=189 && nX>54)
			nX+=3;
		else if(nX<=5 && nX>0)
			nX+=3;
		//Y����
		if(nY<=240 && nY>170)
			nY-=3;
	
		/*�����ӡ
		memset(xch,0,sizeof(xch));
		memset(ych,0,sizeof(ych));
		sprintf(xch,"%d",nX);
		sprintf(ych,"%d",nY);
		
		LCD_DrawText(70,80,xch,3,RGB(255,255,255),RGB(0,0,0));
		LCD_DrawText(100,80,ych,3,RGB(255,255,255),RGB(0,0,0));
		*/
		//ȥ����һ�������һ��	
		if(xynum > 1 && xynum <= 6)
		{
			chfindxy[xynum].x=nX;
			chfindxy[xynum].y=nY;
			chfindxy[xynum].num=xynum;
		}
		xynum++;
		//���ֵ�һ��
		if(xynum == 6)
		{	
			TOUCH_findXY();
			//xynum=0;
			//memset(chfindxy,0,sizeof(chfindxy));	
		}
		else if(xynum > 6)
		{
			if(abs(nX-cx) >= 0 && abs(nX-cx) <= 7 && abs(nY-cy) >= 0 && abs(nY-cy) <= 7)
			{
				//LCD_PutPixel(nY,nX,RGB(0,0,0));
				//��д��
				if(nX >= 261 && nX <= 317 && nY >= 130 && nY <= 208 && cx >= 261 && cx <= 317 && cy >= 130 && cy <= 208 )
				{
					is_have_start_hand_sleep = 0;
					is_hand_write = 1;
					if(xynum == 7)
					{
						fx = nX;
						fy = nY;
						event_start(event_state_pit_hand);
					}
					if( fx >= 261 && fx <= 317 && fy >= 130 && fy <= 208)
					{
						LCD_Line(cy,cx,nY,nX,RGB(0,0,0));
					}
				}
				//������
				else if(nX >= 0 && nX <=260 && nY >= 130 && nY <= 210 && cx >= 0 && cx <=260 && cy >= 130 && cy <= 210)
				{
					//LCD_Line(cy,cx,nY,nX,RGB(0,0,0));
					if(xynum == 7)
					{									
						tfront_key_id = choice_key(nX,nY,1);	
					}
					else
					{
						tfront_key_id = choice_key(nX,nY,0);
					}
					if( tfront_key_id != front_key_id && tfront_key_id != -1)
					{
						//event_start(event_pit_board);
						front_key_id = tfront_key_id;
					}
					event_start(event_key_board);
				}
				//�ļ������
				else if(nX >= 0 && nX <= 317 && nY >= 31 && nY <= 110 && cx >= 0 && cx <=317 && cy >= 31 && cy <= 110)
				{					
					if(is_show_file_list == 1 && xynum == 7)
					{
						file_line_id = 0;
						//��һ��
						if(nY > 31 && nY < 51)
						{
							file_line_id = 1;
						}
						//�ڶ���
						else if(nY > 51 && nY < 71)
						{
							file_line_id = 2;
						}
						//������
						else if(nY > 71 && nY < 91)
						{
							file_line_id = 3;
						}
						//������
						else if(nY > 91 && nY < 111)
						{
							file_line_id = 4;
						}
						event_start(event_file_line);	
					}	
				}
				cx = nX;
				cy = nY;	
			}
		}
	}
	//�ȴ��ж�����
	TOUCH_WaitPenUp();
					 
}

void TOUCH_Timer()
{
	if(s_nPenState == STATE_PEN_DOWN)
	{
		TOUCH_GetXY(); 	
	}
}

void TOUCH_Start()
{
	s_nPenState = STATE_PEN_DOWN;
	
	TIMER_TS_Start(timerID);
	//�ȴ�̧��
	TOUCH_WaitPenUp();
	is_file_bechoice = 1;

	is_reshow_pit = 0;//�ر�˯��

	//���ʰ��½���ϵͳ����
	if(is_show_system != 1 && is_show_file_list != 1)
	{
		done_show_pit();
		event_start(event_pit_system);		
		//show_system_box();
	}		
}

void TOUCH_Stop()
{
	s_nPenState = STATE_PEN_UP;
	//�ȴ�����
	TOUCH_WaitPenDown();
	TIMER_TS_Stop(timerID);
	is_file_bechoice = 2;

	xynum=0;
	memset(chfindxy,0,sizeof(chfindxy));
	cx=0;
	cy=0;
	fx = 0;
	fy = 0;

	if(is_show_system == 1 || is_show_file_list == 1)
	{
		key_board_clear();
		if(now_keyboard_id == 2)
			LCD_draw(130,0,80,260,RES_key_board2_BIN);//����
		else if(now_keyboard_id == 1)
			LCD_draw(130,0,80,260,RES_key_board1_BIN);//����
		else if(now_keyboard_id == 3)
			LCD_draw(130,0,80,260,RES_key_board3_BIN);//����
	
		is_hand_write = 0;
		if(is_have_start_hand_sleep != 1)
		{
			is_have_start_hand_sleep = 1;
			TIMER_TS_Start(timer_id_hand_write_sleep);
		}
		
	}

	is_reshow_pit = 1;//����˯��
	TIMER_TS_ResetTimeout(timer_id_sleep,10000);
	TIMER_TS_Start(timer_id_sleep);
	
	event_start(event_state_pit_ldle);
	
}

void TOUCH_IRQEntry()
{
	if(SUBSRCPND & BIT_SUB_TC)
	{
		if(ADCUPDN & STATE_PEN_DOWN)
		{
			TOUCH_Start();//���¿�ʼ����
		}
		else if(ADCUPDN & STATE_PEN_UP)
		{
			TOUCH_Stop();//̧���������	
		}
		SUBSRCPND |= BIT_SUB_TC;
	}
}

void TOUCH_Init()
{
	xynum=0;
	cx=0;
	cy=0;
	front_key_id = 49;
	file_line_id = 0;
	is_file_bechoice = 0;

	event_add(event_pit_board,pit_board_work);
	event_add(event_pit_system,show_system_work);
	event_add(event_file_line,file_line_work);

	memset(chfindxy,0,sizeof(chfindxy));
	IRQ_SetMask(INT_TYPE_INT_ADC,0); //����һ���ж�
	//IRQ_SetMask(INT_TYPE_INT_ADC_S,0);
	IRQ_SetMask(INT_TYPE_INT_TC,0);

	//INTMSK &= ~BIT_ADC;
	//INTSUBMSK &= ~BIT_SUB_TC;

	ADCDLY = 30000;

	ADCCON = (1 << 14) + (9 << 6);
	ADCTSC = 0xd3; //�жϵȴ�ģʽ

	IRQ_Install(INT_TYPE_INT_TC,TOUCH_IRQEntry);
	//��������ʱ
	timerID = TIMER_TS_Create(10,1,TOUCH_Timer);
	//�����ļ�ѡ�в��Ŷ�ʱ
	timer_file_bechoice_id = TIMER_TS_Create(20,1,timer_file_bechoice);
	timer_id_hand_write_sleep = TIMER_TS_Create(3000,0,timer_hand_write);		
}
