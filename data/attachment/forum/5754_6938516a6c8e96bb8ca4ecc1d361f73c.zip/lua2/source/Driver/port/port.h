#ifndef _PORT_H_
#define _PORT_H_

#include <stdlib.h>
#include <string.h>
#include <S3C2440.h>
#include "../irq/irq.h"
#include "../../sys/select_data_buf.h"


#define PCLK 50000000
#define fifo_send_size	1024
#define fifo_recv_size	1024
#define fifo_recv_file_size	230456

#define my_raw_start	(*(volatile unsigned long *) 0x32000004)
#define my_raw_stop		(*(volatile unsigned long *) 0x32ffffff)

extern select_data_t my_select_data[100];

int UART_Init(int nPort, int nBaudRate, int nDatabits, int nStopbits, int nParity);//���ں� ������ ��λ ֹͣλ �Ƿ���ż

int UART_SendBuff(int nPort, unsigned char *pcBuff, int nLength);
int UART_RecvBuff(int nPort, unsigned char *pcBuff, int nSize);
void read_work(void);
void send_work(void);

int select_portdata(void);
int	switch_data(void);

int UART_Open(int nPort);
int UART_Close(int nPort);

#endif
