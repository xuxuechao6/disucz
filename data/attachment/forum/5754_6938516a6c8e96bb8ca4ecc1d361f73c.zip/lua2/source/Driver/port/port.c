#include "port.h"
#include "../../usr/global.h"
#include <stdio.h> 
#include <stdlib.h>
#include <string.h>

extern nand_control_t my_nand_control;
extern control_t my_control; //ͼƬ���ʹ��

//ȫ������
fifobuf_t send_fifobuf_t;
fifobuf_t recv_fifobuf_t;
fifobuf_t recv_file_fifobuf_t;
unsigned char send_fifobuf_data[fifo_send_size];
unsigned char recv_fifobuf_data[fifo_recv_size];
unsigned char recv_file_fifobuf_data[fifo_recv_file_size];

int isfile;
int timer_id_getfile;
int timer_id_check_getfile;
char file_name[50];

void read_work(void)
{

	done_show_pit();
	while((UFSTAT0 &0x7f))
	{
		if(isfile != 1)//��������
		{
			fifobuf_datain(&recv_fifobuf_t,URXH0);
		}
		else//���ڽ����ļ���BMP��
		{
			fifobuf_datain(&recv_file_fifobuf_t,URXH0);			
		}
	}
	if(isfile != 1)
	{
		event_start(event_port0_recv);
	}
	else
	{
		//event_start(event_port0_recv_file);	
	}	
	//LCD_DrawText(0,0,(char *)(recv_fifobuf_t.pdata),40,RGB(255,255,255),RGB(0,0,0));
	//UART_SendBuff(0,recv_fifobuf_t.pdata,recv_fifobuf_t.now_size);
}

void send_work(void)
{
	unsigned char tempdata;
	while(!(UFSTAT0 & (1 << 14)))
	{
		tempdata = fifobuf_dataout(&send_fifobuf_t);
		if(tempdata == 0)//����ȡ����
		{
			IRQ_UnInstall(INT_TYPE_INT_TXD0);
			//UTXH0 = tempdata;
			return;
		}
		UTXH0 = tempdata;
	}
}

int UART_Init(int nPort, int nBaudRate, int nDatabits, int nStopbits, int nParity)
{
	int temp_bit = 0;
	if(nPort < 0 || nPort > 2 || nStopbits < 0 || nStopbits > 2|| nDatabits < 5 || nDatabits > 8)
	{
		return -1;
	}	
	GPHCON = 0xAAA0;//�������
	GPHUP = 0xf0;
	if(nPort == 0)//��0�Ŵ��ڽ��г�ʼ
	{		  
	  //UCON0 = 0x3c5;//�п����쳣�ж�
	  UCON0 = (0<<12)|(2<<10)|(1<<9)|(1<<8)|(1<<7)|(0<<6)|(0<<5)|(0<<4)|(1<<2)|(1<<0);//�޿����쳣�ж�
	  temp_bit = (int)(PCLK/(nBaudRate*16))-1;
	  UBRDIV0 = temp_bit;//���ò�����
	  if(nStopbits == 1 && nDatabits == 5)
	  {
	  	ULCON0 = 0x0;//����֡��ʽ���ֳ�5λ ֹͣ1λ ����ż��
	  }
	  else if(nStopbits == 1 && nDatabits == 6)
	  {
	  	ULCON0 = 0x1;//����֡��ʽ���ֳ�6λ ֹͣ1λ ����ż��
	  }
	  else if(nStopbits == 1 && nDatabits == 7)
	  {
	  	ULCON0 = 0x2;//����֡��ʽ���ֳ�7λ ֹͣ1λ ����ż��
	  }
	  else if(nStopbits == 1 && nDatabits == 8)
	  {
	  	ULCON0 = 0x3;//����֡��ʽ���ֳ�8λ ֹͣ1λ ����ż��
	  }
	  else if(nStopbits == 2 && nDatabits == 8 )
	  {
	  	ULCON0 = 0x7;//����֡��ʽ���ֳ�8λ ֹͣ2λ ����ż��
	  }
	  else if(nStopbits == 2 && nDatabits == 7)
	  {
	  	ULCON0 = 0x6;//����֡��ʽ���ֳ�7λ ֹͣ2λ ����ż��
	  }
	  else if(nStopbits == 2 && nDatabits == 6)
	  {
	  	ULCON0 = 0x5;//����֡��ʽ���ֳ�6λ ֹͣ2λ ����ż��
	  }
	  else if(nStopbits == 2 && nDatabits == 5)
	  {
	  	ULCON0 = 0x4;//����֡��ʽ���ֳ�5λ ֹͣ2λ ����ż��
	  }
	  UMCON0 = 0;//����������
	  UFCON0 = (2<<6)|(3<<4)|(0<<3)|(0<<2)|(0<<1)|(1<<0);//����FIFO	   ������ȶ�Ϊ 32K
	  
	  fifobuf_init(&send_fifobuf_t,send_fifobuf_data,fifo_send_size);	//�������ͻ�����
	  fifobuf_init(&recv_fifobuf_t,recv_fifobuf_data,fifo_recv_size);	//�������ջ�����
	  fifobuf_init(&recv_file_fifobuf_t,recv_file_fifobuf_data,fifo_recv_file_size);	//�������ջ�����
	  isfile = 0;
	  select_data_buf_init();											//�����������ʼ��	
	}					   
	else if(nPort == 1)
	{
	  //UCON1 = 0x3c5;//�п����쳣�ж�
	  UCON1 = (0<<12)|(2<<10)|(0<<9)|(0<<8)|(1<<7)|(0<<6)|(0<<5)|(0<<4)|(1<<2)|(1<<0);//�޿����쳣�ж�
	  temp_bit = (int)(PCLK/(nBaudRate*16))-1;
	  UBRDIV1 = temp_bit;//���ò�����
	  if(nStopbits == 1 && nDatabits == 5)
	  {
	  	ULCON1 = 0x0;//����֡��ʽ���ֳ�5λ ֹͣ1λ ����ż��
	  }
	  else if(nStopbits == 1 && nDatabits == 6)
	  {
	  	ULCON1 = 0x1;//����֡��ʽ���ֳ�6λ ֹͣ1λ ����ż��
	  }
	  else if(nStopbits == 1 && nDatabits == 7)
	  {
	  	ULCON1 = 0x2;//����֡��ʽ���ֳ�7λ ֹͣ1λ ����ż��
	  }
	  else if(nStopbits == 1 && nDatabits == 8)
	  {
	  	ULCON1 = 0x3;//����֡��ʽ���ֳ�8λ ֹͣ1λ ����ż��
	  }
	  else if(nStopbits == 2 && nDatabits == 8 )
	  {
	  	ULCON1 = 0x7;//����֡��ʽ���ֳ�8λ ֹͣ2λ ����ż��
	  }
	  else if(nStopbits == 2 && nDatabits == 7)
	  {
	  	ULCON1 = 0x6;//����֡��ʽ���ֳ�7λ ֹͣ2λ ����ż��
	  }
	  else if(nStopbits == 2 && nDatabits == 6)
	  {
	  	ULCON1 = 0x5;//����֡��ʽ���ֳ�6λ ֹͣ2λ ����ż��
	  }
	  else if(nStopbits == 2 && nDatabits == 5)
	  {
	  	ULCON1 = 0x4;//����֡��ʽ���ֳ�5λ ֹͣ2λ ����ż��
	  }
	  UMCON1 = 0;//����������
	  UFCON1 = (2<<6)|(3<<4)|(0<<3)|(0<<2)|(0<<1)|(1<<0);//����FIFO	������ȶ�Ϊ 32K
	}
	else if(nPort == 2)
	{
	  //UCON2 = 0x3c5;//�п����쳣�ж�
	  UCON2 = (0<<12)|(2<<10)|(0<<9)|(0<<8)|(1<<7)|(0<<6)|(0<<5)|(0<<4)|(1<<2)|(1<<0);//�޿����쳣�ж�
	  temp_bit = (int)(PCLK/(nBaudRate*16))-1;
	  UBRDIV2 = temp_bit;//���ò�����
	  if(nStopbits == 1 && nDatabits == 5)
	  {
	  	ULCON2 = 0x0;//����֡��ʽ���ֳ�5λ ֹͣ1λ ����ż��
	  }
	  else if(nStopbits == 1 && nDatabits == 6)
	  {
	  	ULCON2 = 0x1;//����֡��ʽ���ֳ�6λ ֹͣ1λ ����ż��
	  }
	  else if(nStopbits == 1 && nDatabits == 7)
	  {
	  	ULCON2 = 0x2;//����֡��ʽ���ֳ�7λ ֹͣ1λ ����ż��
	  }
	  else if(nStopbits == 1 && nDatabits == 8)
	  {
	  	ULCON2 = 0x3;//����֡��ʽ���ֳ�8λ ֹͣ1λ ����ż��
	  }
	  else if(nStopbits == 2 && nDatabits == 8 )
	  {
	  	ULCON2 = 0x7;//����֡��ʽ���ֳ�8λ ֹͣ2λ ����ż��
	  }
	  else if(nStopbits == 2 && nDatabits == 7)
	  {
	  	ULCON2 = 0x6;//����֡��ʽ���ֳ�7λ ֹͣ2λ ����ż��
	  }
	  else if(nStopbits == 2 && nDatabits == 6)
	  {
	  	ULCON2 = 0x5;//����֡��ʽ���ֳ�6λ ֹͣ2λ ����ż��
	  }
	  else if(nStopbits == 2 && nDatabits == 5)
	  {
	  	ULCON2 = 0x4;//����֡��ʽ���ֳ�5λ ֹͣ2λ ����ż��
	  }
	  UMCON2 = 0;//����������
	  UFCON2 = (2<<6)|(3<<4)|(0<<3)|(0<<2)|(0<<1)|(1<<0);//����FIFO	������ȶ�Ϊ 32K	
	}

	return 1;
}

int UART_Open(int nPort)//װ�ػص� ���ж�
{
	if(nPort < 0 || nPort > 2)
	{
		return -1;
	}
	if(nPort == 0)
	{
		IRQ_SetMask(28,0);//��������0һ���ж�
		IRQ_Install(INT_TYPE_INT_RXD0,read_work);//ע�ᴮ��0���ݽ���
		event_add(event_port0_recv,select_portdata);//ע���¼�
		event_add(event_switch_data,switch_data);//ע���¼�
		event_add(event_port0_recv_file,get_file);//ע���¼�

		timer_id_check_getfile = TIMER_TS_Create(5000,0,timer_check_isget_file);
		timer_id_getfile = TIMER_TS_Create(22000,0,timer_get_pit);
	}
	else if(nPort == 1)
	{
	
	}
	else if(nPort == 2)
	{
	
	}	
	return 1;
}

int UART_Close(int nPort)//�ص�ж�� ���ж�
{
	if(nPort < 0 || nPort > 2)
	{
		return -1;
	}
	if(nPort == 0)
	{
		IRQ_SetMask(28,1);
		IRQ_UnInstall(INT_TYPE_INT_RXD0);
	}
	else if(nPort == 1)
	{
	
	}
	else if(nPort == 2)
	{
	
	}
	return 1;
}

int UART_SendBuff(int nPort, unsigned char *pcBuff, int nLength)
{
	int i,index;
	index=0;
	if(nPort < 0 || nPort > 2 || pcBuff == NULL)
	{
		return -1;
	}
	if(nPort == 0 )
	{	
		index=0;
		for(i = 0;i < nLength ; i++)
		{
			if(fifobuf_datain(&send_fifobuf_t,*(pcBuff+index))==0)
			{
				IRQ_Install(INT_TYPE_INT_TXD0,send_work);	
				return -1;
			}
			index++;
		}
		IRQ_Install(INT_TYPE_INT_TXD0,send_work);	 	
	}
	else if(nPort == 1 )
	{
	
	}
	else if(nPort == 2 )
	{
	
	}
	
	return 1;
}

int UART_RecvBuff(int nPort, unsigned char *pcBuff, int nSize)
{
	int i,index;
	unsigned char tempdata;
	index=0;
	if(nPort < 0 || nPort > 2 || pcBuff == NULL|| nSize == 0)
	{
		return -1;
	}
	if(nPort == 0)
	{
		for(i = 0 ; i< nSize; i++)
		{
			tempdata = fifobuf_dataout(&recv_fifobuf_t);
			if(tempdata == 0)
			{
			   return -1;
			}
			*(pcBuff + index) = tempdata;
			index ++ ;
		}
	}
	else if(nPort == 1)
	{
	
	}
	else if(nPort == 2)
	{
	
	}
	
	return 1;
}


int select_portdata()
{
	int flag=0;
	int is_start=0;
	int passdata_len=0;
	int i=0;
	unsigned char temp_buffer[1024]={0};
	unsigned char passdata[fifo_recv_size]={0};

	if(is_show_system != 1 && is_show_file_list != 1)
	{
		show_system_box();		
	}
	LCD_DrawText(215,1,"����ͨ��",8,RGB(131,223,231),RGB(0,0,0));
	
	delay(300);
	flag=UART_RecvBuff(0,passdata,recv_fifobuf_t.now_size);
	//LCD_DrawText(40,0,(char *)(passdata),40,RGB(255,255,255),RGB(0,0,0));
		
	if(flag != -1)
	{
		passdata_len=strlen((const char *)passdata);
		for(i=0;i<passdata_len;i++)
		{
			if(strncmp((const char *)(passdata+i),"<",1)==0 || strncmp((const char *)(passdata+i),">",1)==0)
			{
					if(strncmp((const char *)(passdata+i),"<",1)==0)
					{
						is_start=1;	
					}
					else
					{
						//LCD_DrawText(40,0,(char *)(temp_buffer),40,RGB(255,255,255),RGB(0,0,0));
						add_select_data((char *)(temp_buffer));//���뵽����������
						memset((char *)temp_buffer,0,sizeof(temp_buffer));
						is_start=0;	
					}
			}
			else
			{
				if(is_start == 1)
				{
					strncat((char *)temp_buffer,(char *)(passdata+i),1);	
				}
			}			
		}	
	}
	event_start(event_switch_data);

	return 1;	
}

int	switch_data()
{
	int n;		 
	int	i;
	int flag;
	int flag2;
	int get_file_flag;
	char cdata[100] = {0};
	TIME_T pstTime;
	char chtime[100] = {0};
	char rtc_data[60] = {0};
	char rtc_time[60] = {0};
	char mem_addr[60] = {0};
	char read_length[60] = {0};
	//char ch[100] = {0};
	long long_addr = 0;
	char read_mem_buf[10240] = {0};
	char write_mem_buf[10240] = {0};
	unsigned long * plong_addr;

	get_file_flag = 0;
	for(n = 0; n < 50;n++ )
	{
		if(my_select_data[n].is_create == 1 )
		{
			strcpy(cdata,my_select_data[n].data);
			if(strncmp(cdata,"SendFile",8) == 0 || strncmp(cdata,"sendfile",8) ==0 || strncmp(cdata,"SENDFILE",8) ==0)
			{	
				get_file_flag = 1;
				LCD_DrawText(111,0,cdata,strlen(cdata),RGB(14,235,157),RGB(0,0,0));
				
				memset(file_name,0,sizeof(file_name));
				flag = 0;
				for(i = 8; i < strlen(cdata); i++)
				{
					if(cdata[i] == ',')
					{
						flag = 1;
						continue;
					}
					if(flag == 1 && cdata[i] != ' ')
					{
						strncat(file_name,cdata+i,1);
					}	
				}
				if(strlen(file_name) != 0)
				{
					UART_SendBuff(0,"\r\nREADY\r\n",9);
					//����2����ʱ�� �ı��־λ
					isfile = 1;
					TIMER_TS_Start(timer_id_check_getfile);
					TIMER_TS_Start(timer_id_getfile);
				}
				else
				{
					UART_SendBuff(0,"\r\nERROR\r\n",9);
				}
			}
			else if(strcmp(cdata,"Reset") == 0 || strcmp(cdata,"reset") == 0 || strcmp(cdata,"RESET") == 0)
			{									  
				LCD_DrawText(111,0,cdata,strlen(cdata),RGB(14,235,157),RGB(0,0,0));
				
				LCD_ClearScreen(RGB(131,223,231));//����
				LCD_DrawText(110,100,"ϵͳ3�������",13,RGB(131,223,231),RGB(0,0,0));
				UART_SendBuff(0,"\r\nOK\r\n",6);
				IRQ_SetMask(INT_TYPE_INT_ADC,1); //�رմ������ж�
				IRQ_SetMask(INT_TYPE_INT_TC,1);
				delay(3000);	
				WTCON = 0X8021;
				WTDAT = 0X8000;			
			}
			else if(strcmp(cdata,"GetTime") == 0 || strcmp(cdata,"gettime") == 0 || strcmp(cdata,"GETTIME") == 0)
			{		
				LCD_DrawText(111,0,cdata,strlen(cdata),RGB(14,235,157),RGB(0,0,0));
			
				memset(&pstTime,0,sizeof(pstTime));
				RTC_Get(&pstTime);
				sprintf(chtime,"%d-%02d-%02d %02d:%02d:%02d",pstTime.nYear,pstTime.nMon,pstTime.nDay,pstTime.nHour,pstTime.nMin,pstTime.nSec);
				UART_SendBuff(0,(unsigned char *)chtime,strlen(chtime));
				UART_SendBuff(0,"\r\nOK\r\n",6);	
			}
			else if(strncmp(cdata,"SetTime",7) == 0 || strncmp(cdata,"settime",7) == 0 || strncmp(cdata,"SETTIME",7) == 0)
			{
				LCD_DrawText(111,0,cdata,strlen(cdata),RGB(14,235,157),RGB(0,0,0));				

				memset(rtc_data,0,sizeof(rtc_data));
				memset(rtc_time,0,sizeof(rtc_time));
				flag = 0;
				for(i = 7; i < strlen(cdata); i++)
				{
					if(flag == 1 && cdata[i] == ',')
					{
						i--;
						break;	
					}
					if(cdata[i] == ',')
					{
						flag = 1;
						i++;
					}
					if(flag == 1 && cdata[i] != ' ')
					{
						strncat(rtc_data,cdata+i,1);
					}	
				}
				flag = 0;
				for(;i < strlen(cdata); i++)
				{
					if(cdata[i] == ',')
					{
						flag = 1;
						continue;
					}
					if(flag == 1 && cdata[i] != ' ')
					{
						strncat(rtc_time,cdata+i,1);
					}
				}
				memset(&pstTime,0,sizeof(pstTime));
				flag = 0;
				if(VALIDATION_isDate(rtc_data,&pstTime) == 1 && strlen(rtc_data) != 0)
				{
					//LCD_DrawText(20,0,rtc_data,strlen(rtc_data),RGB(0,255,0),RGB(0,0,0));	
					flag ++ ;
				}
				if(VALIDATION_isTime(rtc_time,&pstTime) == 1 && strlen(rtc_time) != 0)
				{
					//LCD_DrawText(40,0,rtc_time,strlen(rtc_time),RGB(0,255,0),RGB(0,0,0));	
					flag ++;
				}
				if(flag == 2)
				{	
					RTC_Set(&pstTime);
					UART_SendBuff(0,"\r\nOK\r\n",6);
				}
				else
				{
					UART_SendBuff(0,"\r\nERROR\r\n",9);	
				}
			}
			else if(strncmp(cdata,"ReadMem",7) == 0 || strncmp(cdata,"readmem",7) == 0 || strncmp(cdata,"READMEM",7) == 0)
			{
				LCD_DrawText(111,0,cdata,strlen(cdata),RGB(14,235,157),RGB(0,0,0));
				
				memset(mem_addr,0,sizeof(mem_addr));
				memset(read_length,0,sizeof(read_length));
				flag = 0;
				for(i = 7; i < strlen(cdata); i++)
				{
					if(flag == 1 && cdata[i] == ',')
					{
						i--;
						break;	
					}
					if(cdata[i] == ',')
					{
						flag = 1;
						i++;
					}
					if(flag == 1 && cdata[i] != ' ')
					{
						strncat(mem_addr,cdata+i,1);
					}	
				}
				flag = 0;
				for(;i < strlen(cdata); i++)
				{
					if(cdata[i] == ',')
					{
						flag = 1;
						continue;
					}
					if(flag == 1 && cdata[i] != ' ')
					{
						strncat(read_length,cdata+i,1);
					}
				}
				//LCD_DrawText(0,0,mem_addr,strlen(mem_addr),RGB(0,255,0),RGB(0,0,0));
				//LCD_DrawText(20,0,read_length,strlen(read_length),RGB(0,255,0),RGB(0,0,0));	
				flag = 0;
				if(select_0x(mem_addr) == 1 && strlen(mem_addr) != 0)
				{
					//LCD_DrawText(40,0,mem_addr,strlen(mem_addr),RGB(0,255,0),RGB(0,0,0));
					flag++;
				}
				if(select_num(read_length) == 1 && strlen(read_length) != 0)
				{	
					//LCD_DrawText(60,0,read_length,strlen(read_length),RGB(0,255,0),RGB(0,0,0));
					flag++;
				}
				if(flag == 2)
				{	
					long_addr = UART_HextoDec(mem_addr);
					 
					if(long_addr < 0x32000004 || long_addr > 0x32ffffff || long_addr + my_atoi(read_length) > 0x32ffffff)
					{
						UART_SendBuff(0,"\r\nERROR\r\n",9);		
					}
					else
					{
						memset(read_mem_buf,0,sizeof(read_mem_buf));

						plong_addr = (unsigned long * )long_addr;
						memcpy(read_mem_buf,plong_addr,my_atoi(read_length));
						strto0x(long_addr,read_mem_buf,my_atoi(read_length));			
						UART_SendBuff(0,"\r\nOK\r\n",6);
					}
				}
				else
				{
					UART_SendBuff(0,"\r\nERROR\r\n",9);	
				}
			}
			else if(strncmp(cdata,"WriteMem",8) == 0 || strncmp(cdata,"writemem",8) == 0 || strncmp(cdata,"WRITEMEM",8) == 0)
			{
				LCD_DrawText(111,0,cdata,strlen(cdata),RGB(14,235,157),RGB(0,0,0));
				
				memset(mem_addr,0,sizeof(mem_addr));
				memset(write_mem_buf,0,sizeof(write_mem_buf));
				flag = 0;
				flag2 = 0;
				for(i = 8; i < strlen(cdata); i++)
				{
					if(flag == 1 && cdata[i] == ',')
					{
						i--;
						break;	
					}
					if(cdata[i] == ',')
					{
						flag = 1;
						i++;
					}
					if(flag == 1 && cdata[i] != ' ')
					{
						strncat(mem_addr,cdata+i,1);
					}	
				}
				flag = 0;
				for(;i < strlen(cdata); i++)
				{
					if(cdata[i] == ',')
					{
						flag = 1;
						continue;
					}
					if(cdata[i] == '"')
					{
						flag2 = 1;
						continue;
					}
					if(flag == 1 && flag2 == 1)
					{
						strncat(write_mem_buf,cdata+i,1);
					}
				}
				//LCD_DrawText(0,0,mem_addr,strlen(mem_addr),RGB(0,255,0),RGB(0,0,0));
				//LCD_DrawText(20,0,write_mem_buf,strlen(write_mem_buf),RGB(0,255,0),RGB(0,0,0));	
				flag = 0;
				if(select_0x(mem_addr) == 1 && strlen(mem_addr) != 0 && strlen(write_mem_buf) != 0)
				{
					//LCD_DrawText(40,0,mem_addr,strlen(mem_addr),RGB(0,255,0),RGB(0,0,0));
					flag++;
				}
				if(flag == 1)
				{	
					long_addr = UART_HextoDec(mem_addr);
					 
					if(long_addr < 0x32000004 || long_addr > 0x32ffffff || long_addr + strlen(write_mem_buf) > 0x32ffffff)
					{
						UART_SendBuff(0,"\r\nERROR\r\n",9);		
					}
					else
					{
						plong_addr = (unsigned long * )long_addr;
						memcpy(plong_addr,write_mem_buf,strlen(write_mem_buf));
						UART_SendBuff(0,"\r\nOK\r\n",6);
					}
					/**/
				}
				else
				{
					UART_SendBuff(0,"\r\nERROR\r\n",9);	
				}
			}
			else
			{
				UART_SendBuff(0,"\r\nERROR\r\n",9);	
			}
			my_select_data[n].is_create = 0;	
		}
	}

	delay(300);
	if(get_file_flag == 0)
	{
		LCD_switch_Screen(0,111,19,320,RGB(14,235,157));//������Ϣ��ʾ��
		LCD_DrawText(215,1,"����    ",8,RGB(131,223,231),RGB(0,0,0));
	}
	is_reshow_pit = 1;//����˯��
	TIMER_TS_ResetTimeout(timer_id_sleep,10000);
	TIMER_TS_Start(timer_id_sleep);
	return 1;		

}

