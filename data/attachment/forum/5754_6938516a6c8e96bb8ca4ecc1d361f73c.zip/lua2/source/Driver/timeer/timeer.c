#include "timeer.h"
/*
Ӳ��ʱ
*/
int TIMER_Init(int nTimerID,int nDiv0,int nDiv1)//����Ԥ��Ƶ��
{
	
	if(nTimerID > 4 || nTimerID <0 || nDiv0 > 255 || nDiv0 < 0 || nDiv1 < 0 || nDiv1 > 3)
	{
		return -1;
	}
	if(nTimerID >=0 && nTimerID <= 1)
	{
		TCFG0 |= nDiv0 <<0;
	}
	else if(nTimerID >=2 && nTimerID <= 4)
	{
		TCFG0 |= nDiv0 <<8;
	}
	TCFG1 |= (nDiv1 << nTimerID*4);
	return 1;
}

int TIMER_Create(int nTimerID, int base_time, F_INTERRUPT_ISR ISR) //���ö�ʱ��
{
	if(nTimerID > 4 || nTimerID <0 || ISR == NULL || base_time <= 0 || base_time > 65535)
	{
		return -1;
	}
	if(nTimerID == 0)
	{
		TCNTB0=base_time;
		TCON |= 1<<1;//�ֶ�����
		TCON |= 1<<3;//�Զ�����
		TCON &= ~(1<<1);//����ֶ�����
		IRQ_Install(INT_TYPE_INT_TIMER0,ISR);
	}
	else if(nTimerID == 1)
	{
		TCNTB1=base_time;
		TCON |= 1<<9;//�ֶ�����
		TCON |= 1<<11;//�Զ�����
		TCON &= ~(1<<9);//����ֶ�����
		IRQ_Install(INT_TYPE_INT_TIMER1,ISR);
	}
	else if(nTimerID == 2)
	{
		TCNTB2=base_time;
		TCON |= 1<<13;//�ֶ�����
		TCON |= 1<<15;//�Զ�����
		TCON &= ~(1<<13);//����ֶ�����
		IRQ_Install(INT_TYPE_INT_TIMER2,ISR);
	}
	else if(nTimerID == 3)
	{
		TCNTB3=base_time;
		TCON |= 1<<17;//�ֶ�����
		TCON |= 1<<19;//�Զ�����
		TCON &= ~(1<<17);//����ֶ�����
		IRQ_Install(INT_TYPE_INT_TIMER3,ISR);
	}
	else if(nTimerID == 4)
	{
		TCNTB4=base_time;
		TCON |= 1<<21;//�ֶ�����
		TCON |= 1<<22;//�Զ�����
		TCON &= ~(1<<21);//����ֶ�����
		IRQ_Install(INT_TYPE_INT_TIMER4,ISR);
	}
	return 1;
}

int TIMER_Destory(int nTimerID)//ע����ʱ���ж�
{
 	if(nTimerID > 4 || nTimerID <0 )
	{
		return -1;
	}
	if(0 == nTimerID)
	{
		IRQ_UnInstall(INT_TYPE_INT_TIMER0);
	}
	else if(1 == nTimerID)
	{
	 	IRQ_UnInstall(INT_TYPE_INT_TIMER1);
	}
	else if(2 == nTimerID)
	{
	 	IRQ_UnInstall(INT_TYPE_INT_TIMER2);
	}
	else if(3 == nTimerID)
	{
	 	IRQ_UnInstall(INT_TYPE_INT_TIMER3);
	}
	else if(4 == nTimerID)
	{
	 	IRQ_UnInstall(INT_TYPE_INT_TIMER4);
	}
	return 1;
}

int TIMER_Start(int nTimerID)//������ʱ��
{
	if(nTimerID > 4 || nTimerID <0 )
	{
		return -1;
	}
	if(0 == nTimerID)
	{
		TCON |= 1<<0;
	}
	else if(1 == nTimerID)
	{
		TCON |= 1<<8;
	}
	else if(2 == nTimerID)
	{
		TCON |= 1<<12;
	}
	else if(3 == nTimerID)
	{
		TCON |= 1<<16;
	}
	else if(4 == nTimerID)
	{
		TCON |= 1<<20;
	}

	//TCON |=0X01 << (nTimerID*4+((nTimerID == 0) ? 0:4));
	return 1;
}

int TIMER_Stop(int nTimerID)//ֹͣ��ʱ��
{
	if(nTimerID > 4 || nTimerID <0 )
	{
		return -1;
	}
	if(0 == nTimerID)
	{
		TCON &=~(1<<0);
	}
	else if(1 == nTimerID)
	{
		TCON &=~(1<<8);
	}
	else if(2 == nTimerID)
	{
		TCON &=~(1<<12);
	}
	else if(3 == nTimerID)
	{
		TCON &=~(1<<16);
	}
	else if(4 == nTimerID)
	{
		TCON &=~(1<<20);
	}
	return 1;	
}

/*
����ʱ
*/
TIMER_TS_t  timer_ts[TIMER_TS_NUM]={0};//����ʱ����

void TIMER_TS_Manger(void)//����ʱ��ҪӲ��ʱ�Ļص�
{
	int nTimerId;
	for(nTimerId = 0; nTimerId < TIMER_TS_NUM ; nTimerId++)
	{
	  if( timer_ts[nTimerId].isCreate == 1 && timer_ts[nTimerId].isAble ==1)
	  {
	  	if(timer_ts[nTimerId].Tcnt > 0)
		{
			timer_ts[nTimerId].Tcnt--;
			if(timer_ts[nTimerId].Tcnt == 0 && timer_ts[nTimerId].TIMER_TS_ISR !=NULL)
			{
				timer_ts[nTimerId].TIMER_TS_ISR();	
			
				if(timer_ts[nTimerId].isAutoload == 1)
				{
					timer_ts[nTimerId].Tcnt = timer_ts[nTimerId].Tcntb; 	
				}
			}
		}
	  }
	}
}

int TIMER_TS_Init(int nTimerID,int nDiv0,int nDiv1, int base_time, F_INTERRUPT_ISR ISR ,char is_ts)
{
	//������ʱ�����г�ʼ��
	if(is_ts == 1)
	{
		memset(timer_ts,0,sizeof(timer_ts));
	}
	//����Ӳ��ʱ
	TIMER_Init(nTimerID,nDiv0,nDiv1);
	TIMER_Create(nTimerID,base_time,ISR);
   	TIMER_Start(nTimerID);
	return 1;
}

int TIMER_TS_Create( int Tcntb, int isAutoload, F_INTERRUPT_ISR ts_ISR)
{
	int nTimerId;
	for(nTimerId = 0; nTimerId < TIMER_TS_NUM ; nTimerId++)
	{
	  if(timer_ts[nTimerId].isCreate == 0)
	  {
       	 timer_ts[nTimerId].isCreate = 1;
		 timer_ts[nTimerId].Tcntb = Tcntb;
		 timer_ts[nTimerId].Tcnt = timer_ts[nTimerId].Tcntb;
		 timer_ts[nTimerId].isAutoload = isAutoload;
		 timer_ts[nTimerId].TIMER_TS_ISR = ts_ISR;
		 timer_ts[nTimerId].isAble = 0;
		 return nTimerId; 
	  }
	}
	return -1;
}
int TIMER_TS_Start(int ts_nTimerID)
{
	if((ts_nTimerID >= 0 && ts_nTimerID < TIMER_TS_NUM) && timer_ts[ts_nTimerID].isCreate ==1)
	{
	   timer_ts[ts_nTimerID].isAble = 1;
	   timer_ts[ts_nTimerID].Tcnt = timer_ts[ts_nTimerID].Tcntb;
	   return 1;
	}
	else
		return -1;
}

int TIMER_TS_Destory(int ts_nTimerID)
{
	if((ts_nTimerID >= 0 && ts_nTimerID < TIMER_TS_NUM) && timer_ts[ts_nTimerID].isCreate ==1)
	{
	   memset(&timer_ts[ts_nTimerID],0,sizeof(TIMER_TS_t));
	   return 1;
	}
	else
		return -1;
}

int TIMER_TS_Stop(int ts_nTimerID)
{
	if((ts_nTimerID >= 0 && ts_nTimerID < TIMER_TS_NUM) && timer_ts[ts_nTimerID].isCreate ==1 && timer_ts[ts_nTimerID].isAble ==1)
	{
	   timer_ts[ts_nTimerID].isAble = 0;
	   return 1;
	}
	else
		return -1;
}

int TIMER_TS_ResetTimeout(int ts_nTimerID, int nTimerOut)
{
	if((ts_nTimerID >= 0 && ts_nTimerID < TIMER_TS_NUM) && timer_ts[ts_nTimerID].isCreate ==1)
	{
	   timer_ts[ts_nTimerID].Tcntb = nTimerOut;
	   return 1;
	}
	else
		return -1;
}

