#include "MyEvent.h"

event_t event_ch[event_num]={0};

int event_init()
{
	memset(event_ch,0,sizeof(event_ch));
	return 1;
}

int event_add(int id,F_EVENT_ISR Event_ISR)
{
	int event_id;
	if(Event_ISR == NULL && id == 0)
	{
		return -1;
	}

	event_id = 0;
	for(event_id = 0; event_id < event_num ; event_id++)
	{
		if(event_ch[event_id].id == 0)
		{
			event_ch[event_id].id = id;
			event_ch[event_id].Event_ISR = Event_ISR;
			event_ch[event_id].is_start = 0;
			return id;  				
		}	
	}

	return -1;
}

int event_start(int event_id)
{
	int n;

	for(n = 0;n < event_num; n++)
	{
		if(event_ch[n].id == event_id)
		{
			event_ch[n].is_start = 1;
			return 1;
		}
	}

	return -1;
}

int event_stop(int event_id)
{
	int n;

	for(n = 0;n < event_num; n++)
	{
		if(event_ch[n].id == event_id)
		{
			event_ch[n].is_start = 0;
			return 1;
		}
	}

	return -1;
}

int event_del(int event_id)
{
	int n;

	for(n = 0;n < event_num; n++)
	{
		if(event_ch[n].id == event_id)
		{
			event_ch[n].id = 0;
			event_ch[n].Event_ISR = NULL;
			event_ch[n].is_start = 0;
			return 1;
		}
	}

	return -1;
}

int event_del_all()
{
	memset(event_ch,0,sizeof(event_ch));
	return 1;
}

int event_listen(void)
{
	int n;
	n=0;
	while(1)
	{
		if(event_ch[n].id != 0 && event_ch[n].Event_ISR != NULL && event_ch[n].is_start == 1)
		{
			event_ch[n].is_start = 0;
			event_ch[n].Event_ISR();		
		}
		n++;
		if(n == event_num)
		{
			n=0;
		}
	} 	
}

