#include "../usr/global.h"
#include <stdio.h> 
#include <stdlib.h>
#include <string.h>

my_text_t my_text_data[text_size];
int now_text_row;
int now_text_col;

int my_text_init()
{
	int n;
	int i;
	
	now_text_row = 0;
	now_text_col = 0;

	memset(my_text_data,0,sizeof(my_text_data));
	event_add(event_show_text,show_text_work);

	for(n = 0; n < 40;n++)
	{
		my_text_data[n].row = 0;
		my_text_data[n].col = n;	
	}
	for(n = 0,i = 40; n < 40;n++,i++)
	{
		my_text_data[i].row = 1;
		my_text_data[i].col = n;	
	}
	for(n = 0,i = 80; n < 40;n++,i++)
	{
		my_text_data[i].row = 2;
		my_text_data[i].col = n;	
	}
	for(n = 0,i = 120; n < 40;n++,i++)
	{
		my_text_data[i].row = 3;
		my_text_data[i].col = n;	
	}	

	return 1;
}

int text_clear()
{
	int n;

	for(n = 0;n < text_size;n++)
	{
		my_text_data[n].is_create = 0;
		my_text_data[n].data = 0;		
	}

	return 1;
}

int add_text_data(char data)
{
	int n;

	if(now_text_row == 4)
	{
		now_text_row = 0;
		now_text_col = 0;
		text_clear();
		//ִ������
		LCD_switch_Screen(0,31,80,320,RGB(255,255,255));

	}
	n = now_text_row * 40 + now_text_col;
	if(my_text_data[n].is_create == 0)
	{
		my_text_data[n].is_create = 1;
		my_text_data[n].data = data;
		now_text_col ++ ;
		if(now_text_col > 39)
		{
			now_text_row++;
			now_text_col = 0;
		}	
	}

	return 1;
}

int do_enter()
{
	now_text_row++;
	now_text_col = 0;
	if(now_text_row == 4)
	{
		now_text_row = 0;
		now_text_col = 0;
		text_clear();
		//ִ������
		LCD_switch_Screen(0,31,80,320,RGB(255,255,255));
	}
	return 1;
}

int do_del()
{
	int n;

	for(n = text_size - 1; n>=0; n--)
	{
		if(my_text_data[n].is_create == 1)
		{
			my_text_data[n].is_create = 0;
			now_text_row = my_text_data[n].row;
			now_text_col = my_text_data[n].col;
			//����λ���
			LCD_switch_Screen(my_text_data[n].col*8,my_text_data[n].row*20+31,20,8,RGB(255,255,255));
			return 1;	 	
		}
	}

	return 1;
}
int do_tab()
{
	int n;

	if(now_text_row == 4)
	{
		now_text_row = 0;
		now_text_col = 0;
		text_clear();
		//ִ������
		LCD_switch_Screen(0,31,80,320,RGB(255,255,255));

	}
	n = now_text_row * 40 + now_text_col;
	if(my_text_data[n].is_create == 0)
	{
		my_text_data[n].is_create = 1;
		my_text_data[n].data = 32;
		now_text_col ++ ;
		if(now_text_col > 39)
		{
			now_text_row++;
			now_text_col = 0;
		}

		n = now_text_row * 40 + now_text_col;
		my_text_data[n].is_create = 1;
		my_text_data[n].data = 32;
		now_text_col ++ ;
		if(now_text_col > 39)
		{
			now_text_row++;
			now_text_col = 0;
		}	
	}

	return 1;
}

int do_clear()
{
	now_text_row = 0;
	now_text_col = 0;
	text_clear();
	//ִ������
	LCD_switch_Screen(0,31,80,320,RGB(255,255,255));
	return 1;
}

int do_board_turn()
{
	if(now_keyboard_id == 1)
	{
		now_keyboard_id = 2;
		LCD_draw(130,0,80,260,RES_key_board2_BIN);//����	
	}
	else if(now_keyboard_id == 2 || now_keyboard_id == 3)
	{
		now_keyboard_id = 1;
		LCD_draw(130,0,80,260,RES_key_board1_BIN);//����	
	}
	return 1;
}

int do_letter_turn()
{
	if(now_keyboard_id !=1 )
	{
		if(now_keyboard_id == 2)
		{
			now_keyboard_id = 3;
			LCD_draw(130,0,80,260,RES_key_board3_BIN);//����
		}
		else if(now_keyboard_id == 3)
		{
			now_keyboard_id = 2;
			LCD_draw(130,0,80,260,RES_key_board2_BIN);//����
		}
	}
	return 1;
}

int show_text()
{
	int n;
	char ch[2] = {0};	
	
	for(n = 0;n < text_size;n++)
	{
		if(my_text_data[n].is_create == 1)
		{
			memset(ch,0,sizeof(ch));
			ch[0] = my_text_data[n].data;
			//ch[1] = '\0';
			LCD_DrawText(my_text_data[n].row*20+31,my_text_data[n].col*8,ch,1,RGB(255,255,255),RGB(0,0,0));
		}
	}

	return 1;
}

