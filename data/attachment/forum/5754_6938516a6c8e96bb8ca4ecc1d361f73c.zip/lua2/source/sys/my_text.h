#ifndef _MY_TEXT_H_
#define _MY_TEXT_H_

#define text_size 				(160)

typedef struct my_text_t
{
	int is_create;		//�õ�Ԫ�Ƿ����
	int row;			//�ĵ���
	int col;			//�ĵ���
	char data;
}my_text_t;

int my_text_init(void);
int text_clear(void);
int add_text_data(char data);
int do_enter(void);
int do_del(void);
int do_tab(void);
int do_clear(void);
int do_board_turn(void);
int do_letter_turn(void);
int show_text(void);

#endif
