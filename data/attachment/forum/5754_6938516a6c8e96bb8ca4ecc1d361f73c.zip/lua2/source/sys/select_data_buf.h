#ifndef _SELECT_DATA_BUF_H_
#define _SELECT_DATA_BUF_H_

typedef struct select_data_t
{
	int is_create;			//�Ƿ񴴽�
	char data[100];			//��������
}select_data_t;

int select_data_buf_init(void);
int add_select_data(char * data);
int get_select_data(char * data);

#endif
