#include "fifobuf.h"
#include <string.h>

int fifobuf_init(fifobuf_t * pfifobuf,unsigned char * cdata,int len)
{
	pfifobuf->front = 0;
	pfifobuf->rear = 0;
	pfifobuf->pdata = cdata;
	pfifobuf->buf_size = len;
	pfifobuf->now_size = 0;
	memset(pfifobuf->pdata,0,len);
	return 1;
}

unsigned char fifobuf_datain(fifobuf_t * pfifobuf,unsigned char cdata)
{
	if(pfifobuf->now_size == pfifobuf->buf_size)
	{
		return 0;//��������
	}	
	pfifobuf->pdata[pfifobuf->rear] = cdata;
	pfifobuf->rear++;
	pfifobuf->now_size++;
	if(pfifobuf->rear == pfifobuf->buf_size)
	{
		pfifobuf->rear=0;
	}

	return cdata;
}

unsigned char fifobuf_dataout(fifobuf_t * pfifobuf)
{
	
	unsigned char cTempData;
	if(pfifobuf->now_size == 0)
	{
		return 0;//����Ϊ��û����ȡ
	}
	cTempData = pfifobuf->pdata[pfifobuf->front];
	pfifobuf->pdata[pfifobuf->front]=0;
	pfifobuf->now_size--;
	pfifobuf->front++;
	if(pfifobuf->front == pfifobuf->buf_size)
	{
		pfifobuf->front = 0;
	}

	return cTempData;
}

int fifobuf_isEmpty(fifobuf_t * pfifobuf)
{
	if(pfifobuf->now_size == 0)
		return 1;
	else
		return 0;
}

int fifobuf_isFull(fifobuf_t * pfifobuf)
{
	if(pfifobuf->now_size == pfifobuf->buf_size)
		return 1;
	else
		return 0;
}

