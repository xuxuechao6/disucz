#ifndef _MYEVENT_H_
#define _MYEVENT_H_
#include <string.h>

#define event_num 					(20)
#define event_port0_recv 			1
#define event_switch_data 			2
#define event_port0_recv_file 		3
#define event_dida 					4
#define event_system_sleep 			5
#define event_key_board 			6
#define event_pit_board 			7
#define event_pit_system 			8
#define event_show_text 			9
#define event_file_line 			10
#define event_state_pit_keyboard 	11
#define event_state_pit_hand	 	12
#define event_state_pit_ldle 		13


typedef int (* F_EVENT_ISR)();

typedef struct event_t
{
	int id;					  					//�¼�ID
	F_EVENT_ISR Event_ISR;						//�¼��ص�
	int is_start;								//�Ƿ�����1���� ����������
}event_t;

int event_init(void);
int event_add(int id,F_EVENT_ISR Event_ISR);
int event_start(int event_id);
int event_stop(int event_id);
int event_del(int event_id);
int event_del_all(void);
int event_listen(void);

#endif
