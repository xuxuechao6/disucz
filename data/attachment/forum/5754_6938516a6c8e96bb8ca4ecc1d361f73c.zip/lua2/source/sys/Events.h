#ifndef _EVENTS_H_
#define _EVENTS_H_
#include <S3C2440.H>

int get_file(void);
int dida_work(void);
int system_sleep_work(void);
int show_system_work(void);
int key_board_work(void);
int show_text_work(void);
int pit_board_work(void);
int file_line_work(void);
int state_pit_idle_work(void);
int state_pit_keyboard_work(void);
int state_pit_hand_work(void);

void timer_check_isget_file(void);
void timer_get_pit(void);
void timer_dida_work(void);
void timer_system_sleep(void);
void timer_file_bechoice(void);
void timer_hand_write(void);

#endif
