#ifndef _FIFOBUF_H_
#define _FIFOBUF_H_

typedef struct fifobuf_t
{
	int buf_size;					//��С
	int now_size;					//��ǰ��С
	int front;						//ͷָ��
	int rear;						//βָ��
	unsigned char * pdata;					//����ָ��
}fifobuf_t;

int fifobuf_init(fifobuf_t * pfifobuf,unsigned char * cdata,int len);
unsigned char fifobuf_datain(fifobuf_t * pfifobuf,unsigned char cdata);
unsigned char fifobuf_dataout(fifobuf_t * pfifobuf);
int fifobuf_isEmpty(fifobuf_t * pfifobuf);
int fifobuf_isFull(fifobuf_t * pfifobuf);

#endif
