#include "Events.h"
#include "../usr/global.h"
#include "Bmp.h"
#include <stdio.h> 
#include <stdlib.h>
#include <time.h>

int is_front_bad;
int is_reshow_pit;
int is_sending_file_now ;

int get_file()
{
	int count = 0;
	int iblock1 = 0;
	int iblock2 = 0;
	unsigned char temp_buffer[230456]={0};


	if(is_show_system != 1 && is_show_file_list != 1)
	{
		show_system_box();		
	}

	LCD_DrawText(215,1,"����ͨ��",8,RGB(131,223,231),RGB(0,0,0));

	get_nand_control();
	count = my_atoi(my_nand_control.pit_count);
	
	iblock1 = (2 * count) + 1;
	while(show_me_isbadblock(iblock1) == -1)
	{
		is_front_bad++;
	}
	if(is_front_bad != 0)
	{
		iblock1+=is_front_bad;
	}
	iblock2 = iblock1 + 1;
	while(show_me_isbadblock(iblock2) == -1)
	{
		iblock2++;
		is_front_bad++;
	}
		
	nand_control_add(file_name,iblock1,iblock2);

	bmp2bin(recv_file_fifobuf_t.pdata,temp_buffer);

	NF_EreaseBlock(iblock1);
	NF_EreaseBlock(iblock2);

	nand_write(iblock1*64,0,(char *)temp_buffer,131072);
	nand_write(iblock2*64,0,((char *)temp_buffer)+131072,99384);

	fifobuf_init(&recv_file_fifobuf_t,recv_file_fifobuf_data,fifo_recv_file_size);
	isfile = 0;
	UART_SendBuff(0,"OK",2);

	LCD_switch_Screen(0,111,19,320,RGB(14,235,157));//������Ϣ��ʾ��
	LCD_DrawText(215,1,"����    ",8,RGB(131,223,231),RGB(0,0,0));

	is_sending_file_now = 0;

	is_reshow_pit = 1;//����˯��
	TIMER_TS_ResetTimeout(timer_id_sleep,10000);
	TIMER_TS_Start(timer_id_sleep);

	//IRQ_SetMask(INT_TYPE_INT_ADC,0); //�����������ж�
	//IRQ_SetMask(INT_TYPE_INT_TC,0);

	return 1;
}

int dida_work()
{
	TIME_T pstTime;
	char chtime[50] = {0};
	
	memset(&pstTime,0,sizeof(pstTime));
	RTC_Get(&pstTime);
	
	sprintf(chtime,"%d/%02d/%02d %02d:%02d:%02d",pstTime.nYear,pstTime.nMon,pstTime.nDay,pstTime.nHour,pstTime.nMin,pstTime.nSec);
	if(is_show_system == 1 || is_show_file_list == 1)
	{
		LCD_DrawText(5,165,chtime,strlen(chtime),RGB(131,223,231),RGB(0,0,0));
	}
	return 1;
}

int system_sleep_work()
{
	if(is_reshow_pit == 1 && is_show_pit != 1 && is_sending_file_now != 1)///////
	{
		get_nand_control();
		updata_cmy_control(my_atoi(my_nand_control.pit_count));
		show_pit();		
	}
	return 1;
}

int show_system_work()
{
	done_show_pit();
	show_system_box();
	return 1;
}

int show_text_work()
{
	show_text();
	return 1;
}

int key_board_work()
{
	int n;

	for(n = 0; n < 50; n++)
	{
		//����
		//��ͨ��
		if(my_key_board[n].is_create == 1 && n != 25 && n != 42 && n!= 46 && my_key_board[n].is_had_pit == 0)
		{			
			my_key_board[n].is_had_pit = 1;
			LCD_ShowRectangle(my_key_board[n].y,my_key_board[n].x,my_key_board[n].y+20,my_key_board[n].x+20,RGB(227,230,225));
			LCD_ShowRectangle(my_key_board[n].y+1,my_key_board[n].x+1,my_key_board[n].y+20-1,my_key_board[n].x+20-1,RGB(227,230,225));
			LCD_ShowRectangle(my_key_board[n].y+2,my_key_board[n].x+2,my_key_board[n].y+20-2,my_key_board[n].x+20-2,RGB(227,230,225));	
			LCD_ShowRectangle(my_key_board[n].y+3,my_key_board[n].x+3,my_key_board[n].y+20-3,my_key_board[n].x+20-3,RGB(227,230,225));
			LCD_ShowRectangle(my_key_board[n].y+4,my_key_board[n].x+4,my_key_board[n].y+20-4,my_key_board[n].x+20-4,RGB(227,230,225));
			
		}
		//ת����
		else if(my_key_board[25].is_create == 1 && my_key_board[25].is_had_pit == 0)
		{
			my_key_board[25].is_had_pit = 1;
			LCD_ShowRectangle(150,240,180,260,RGB(227,230,225));
			LCD_ShowRectangle(151,241,179,259,RGB(227,230,225));
			LCD_ShowRectangle(152,242,178,258,RGB(227,230,225));
			LCD_ShowRectangle(153,243,177,257,RGB(227,230,225));		
		}
		//�ո�
		else if(my_key_board[42].is_create == 1&& my_key_board[42].is_had_pit == 0)
		{
			my_key_board[42].is_had_pit = 1;
			LCD_ShowRectangle(190,80,210,160,RGB(227,230,225));
			LCD_ShowRectangle(191,81,209,159,RGB(227,230,225));
			LCD_ShowRectangle(192,82,208,158,RGB(227,230,225));
			LCD_ShowRectangle(193,83,207,157,RGB(227,230,225));
			LCD_ShowRectangle(194,84,206,156,RGB(227,230,225));	
		}
		//enter
		else if(my_key_board[46].is_create == 1  && my_key_board[46].is_had_pit == 0)
		{
			my_key_board[46].is_had_pit = 1;
			LCD_Line(190,220,190,240,RGB(227,230,225));
			LCD_Line(191,220,191,240,RGB(227,230,225));
			LCD_Line(192,220,192,240,RGB(227,230,225));
			LCD_Line(190,240,180,240,RGB(227,230,225));
			LCD_Line(190,241,180,241,RGB(227,230,225));
			LCD_Line(190,242,180,242,RGB(227,230,225));
			LCD_Line(180,240,180,260,RGB(227,230,225));
			LCD_Line(181,240,181,260,RGB(227,230,225));
			LCD_Line(182,240,182,260,RGB(227,230,225));
			LCD_Line(180,260,210,260,RGB(227,230,225));
			LCD_Line(180,259,210,259,RGB(227,230,225));
			LCD_Line(180,258,210,258,RGB(227,230,225));
			LCD_Line(210,220,210,260,RGB(227,230,225));
			LCD_Line(209,220,209,260,RGB(227,230,225));
			LCD_Line(208,220,208,260,RGB(227,230,225));
			LCD_Line(190,220,210,220,RGB(227,230,225));
			LCD_Line(190,221,210,221,RGB(227,230,225));
			LCD_Line(190,222,210,222,RGB(227,230,225));
		}
		
		//��������
		if(my_key_board[n].is_create == 1 && my_key_board[n].is_be_choice == 1 )
		{
			event_start(event_state_pit_keyboard);
			if(n == 46 && is_show_system == 1)
			{
				do_enter();
			}
			else if(n == 45 && is_show_system == 1)
			{
				do_del();
			}
			else if(n == 44 && is_show_system == 1)
			{
				do_tab();
			}
			else if(n == 43 && is_show_system == 1)
			{
				do_clear();
			}
			else if(n == 25)
			{
				do_board_turn();
			}
			else if(n == 41)
			{
				do_letter_turn();	
			}
			else if(n == 0)
			{
				show_file_box();
			}
			else if(n == 1)
			{
				if(is_show_file_list == 1)
				{
					done_show_pit();
					event_start(event_pit_system);
				}
			}
			else if(n == 2)
			{
				if(is_show_file_list == 1)
				{
					page_up();
				}
			}
			else if(n == 3)
			{
				if(is_show_file_list == 1)
				{
					page_down();
				}					
			}
			else
			{
				if(is_show_system == 1)
				{
					if(now_keyboard_id == 2)
						add_text_data(my_key_board[n].data2);
					else if(now_keyboard_id == 3)
						add_text_data(my_key_board[n].data3);
					else if(now_keyboard_id == 1)
						add_text_data(my_key_board[n].data1);
				}
			}
			if(is_show_system == 1)
			{			
				event_start(event_show_text);
			}
			my_key_board[n].is_be_choice = 0;
		}
	
	}
	return 1;
}

int pit_board_work()
{
	LCD_draw(130,0,80,260,RES_key_board2_BIN);//����
	return 1;
}

int file_line_work()
{
	char ch[50] = {0};
	int n;
	int i;
	int page_num;
	int flag;

	flag = 0;
	page_num = (file_pit_id - 1) / 4;

	n = file_pit_id  - (file_pit_id  - file_line_id) + page_num * 4  ;
	if( n > file_pit_id)
	{
		n = file_pit_id;
		flag = 1;
	}
	i = file_line_id - 1;
					 
	sprintf(ch,"(%d) %-16s%-20s",n,cmy_control[n].pit_name,cmy_control[n].pit_time);
	if(flag != 1 && i != -1)
	{
		LCD_DrawText(20*(i)+31,0,ch,strlen(ch),RGB(0,0,0),RGB(255,255,255));
		now_pit_id = n;
		TIMER_TS_Start(timer_file_bechoice_id);	
	}	  
	/*
	memset(ch,0,sizeof(ch));
	sprintf(ch,"%d",file_pit_id);
	LCD_DrawText(20*(4)+31,0,ch,strlen(ch),RGB(0,0,0),RGB(255,255,255));
	*/
		
	return 1;
}

int state_pit_idle_work(void)
{	
	LCD_DrawText(215,1,"����    ",8,RGB(131,223,231),RGB(0,0,0));
	return 1;
}

int state_pit_keyboard_work(void)
{	
	LCD_DrawText(215,1,"��������",8,RGB(131,223,231),RGB(0,0,0));
	return 1;
}

int state_pit_hand_work(void)
{	
	LCD_DrawText(215,1,"��д����",8,RGB(131,223,231),RGB(0,0,0));
	return 1;
}

//���º���Ϊ����ʱ�ص�
void timer_check_isget_file()
{
	if( strlen((char *)(recv_file_fifobuf_t.pdata)) == 0 || strncmp((char *)(recv_file_fifobuf_t.pdata),"BM",2) != 0)
	{
		isfile = 0;
		UART_SendBuff(0,"\r\nERROR\r\n",9);
		TIMER_TS_Stop(timer_id_getfile);
		LCD_switch_Screen(0,111,19,320,RGB(14,235,157));//������Ϣ��ʾ��
		LCD_DrawText(215,1,"����    ",8,RGB(131,223,231),RGB(0,0,0));			
	}
	else
	{
		is_sending_file_now = 1;/////////////////
		//IRQ_SetMask(INT_TYPE_INT_ADC,1); //�رմ������ж�
		//IRQ_SetMask(INT_TYPE_INT_TC,1);
	}
}

void timer_get_pit()
{
	event_start(event_port0_recv_file);
}

void timer_dida_work()
{
	event_start(event_dida);
}

void timer_system_sleep()
{
	event_start(event_system_sleep);
}

void timer_file_bechoice()
{
	if(is_file_bechoice == 2)
	{
		is_reshow_pit = 1;
		event_start(event_system_sleep);
		TIMER_TS_Stop(timer_file_bechoice_id);
	}
}

void timer_hand_write()
{
	if(is_hand_write != 1 && is_show_pit != 1)
	{
		LCD_switch_Screen(262,131,77,55,RGB(168,168,168));//��д��
	}
}

