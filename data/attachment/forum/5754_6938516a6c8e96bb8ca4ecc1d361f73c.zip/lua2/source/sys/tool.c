#include "../usr/global.h"
#include <stdio.h> 
#include <stdlib.h>
#include <string.h>

nand_control_t my_nand_control;
control_t my_control; 				//ͼƬ���ʹ��
control_t cmy_control[1023]; 		//ͼƬ��ʱ����

int is_show_pit;					//�жϵ�ǰ�����Ƿ�ΪͼƬ����
int is_show_system;					//�жϵ�ǰ�����Ƿ�Ϊϵͳ����
int is_show_file_list;				//�жϵ�ǰ�����Ƿ�Ϊ�ļ�����

int now_pit_id;						//��ǰͼƬID

int file_pit_id;					//���ڷ�ҳ

void delay(int times)//��ʱ����
{
    int i;

    for(;times>0;times--)
      for(i=0;i<400;i++);
}

/********************************************************************** 

  *  �������ƣ� UART_HextoDec 
  
	*  ����������
	*	  ��ʮ�����Ƶ��ַ���ת��ʮ���������� 
	*  ����˵����
	*	   hex ʮ�������ַ���
	*  ����ֵ 
	*     ת�����ʮ����������  
******************************************************************/
unsigned long UART_HextoDec(const char *hex) 
{ 
    int i, j = 0;
//	char ch;
	unsigned long val = 0;
	unsigned long tempval;
	unsigned char length = strlen(hex);
	for(i = 0; i < length; i++)
	{
		if( !( (hex[i] >= '0' && hex[i] <= '9' ) || ((hex[i] >= 'a' && hex[i] <= 'f' )) \
			|| (hex[i] >= 'A' && hex[i] <= 'F' ) || (hex[i] == 'x' || hex[i] == 'X')))
		return 0;
	}

	for(i = length - 1; i > 1; i--, j++)
	{
		if ( (hex[i] >= 'a' && hex[i] <= 'f')  \
			|| (hex[i] >= 'A' && hex[i] <= 'F') )
		{
			switch(hex[i])
			{
				case 'a':
				case 'A': tempval = 10; break;
				case 'b':
				case 'B': tempval = 11; break;
				case 'c':
				case 'C': tempval = 12; break;
				case 'd':
				case 'D': tempval = 13; break;
				case 'e':
				case 'E': tempval = 14; break;
				case 'f':
				case 'F': tempval = 15; break;
				default:break; 
			}
		}
		else if (hex[i] >= '0' && hex[i] <= '9')
		{
			switch(hex[i])
			{
				case '0': tempval = 0; break;
				case '1': tempval = 1; break;
				case '2': tempval = 2; break;
				case '3': tempval = 3; break;
				case '4': tempval = 4; break;
				case '5': tempval = 5; break;
				case '6': tempval = 6; break;
				case '7': tempval = 7; break;
				case '8': tempval = 8; break;
				case '9': tempval = 9; break;
				default:break; 
			}
		}
		//	tempval = my_atoi(&hex[i]);
		val += tempval * pow(16, j);		
	}
	return val;
}

/********************************************************************** 

  *  �������ƣ� my_atoi 
  
	*  ����������
	*	  �ַ���ת��int�� 
	*  ����˵����
	*	   hex �ַ���
	*  ����ֵ 
	*     ת�����ʮ����������  
******************************************************************/
unsigned int my_atoi(const char *hex) 
{ 
    int i, j = 0;

	unsigned int val = 0;
	unsigned int tempval;
	unsigned char length = strlen(hex);
	for(i = 0; i < length; i++)
	{
		if( !((hex[i] >= '0' && hex[i] <= '9')))
			return 0;
	}

	for(i = length - 1; i >= 0; i--, j++)
	{
		if (hex[i] >= '0' && hex[i] <= '9')
		{
			switch(hex[i])
			{
				case '0': tempval = 0; break;
				case '1': tempval = 1; break;
				case '2': tempval = 2; break;
				case '3': tempval = 3; break;
				case '4': tempval = 4; break;
				case '5': tempval = 5; break;
				case '6': tempval = 6; break;
				case '7': tempval = 7; break;
				case '8': tempval = 8; break;
				case '9': tempval = 9; break;
				default:break; 
			}
		}
		//	tempval = atoi(&hex[i]);
		val += tempval * pow(10, j);		
	}
	return val;
} 

/********************************************************************** 

  *  �������ƣ� UART_DectoHex 
  
	*  ����������
	*	  ��(0-255)ʮ���Ƶ�����ת��ʮ�������ַ��� 
	*  ����˵����
	*	    decimal ��ת����ʮ������
	*		hex		���ʮ�������ַ���
	*  ����ֵ 
	*     1 �ɹ� 0 ʧ��  
******************************************************************/
int UART_DectoHex(unsigned char decimal,  char *hex)
{
	int ret = 0;
	ret = sprintf(hex, "0x%02x", decimal);

	if(ret == 4)
	{
		return 1;
	}
	else
	{
		return 0;
	}

}

/********************************************************************** 

  *  �������ƣ� UART_DecaddrtoHexaddr 
  
	*  ����������
	*	  ��ʮ�������ε�ַת��ʮ�����Ƶ�ַ�ַ��� 
	*  ����˵����
	*	    decimaladdr ��ת����ʮ�������ε�ַ
	*		hexaddr		���ʮ�����Ƶ�ַ�ַ���
	*  ����ֵ 
	*     1 �ɹ� 0 ʧ��  
******************************************************************/
int UART_DecaddrtoHexaddr(unsigned int decimaladdr,  char *hexaddr)
{	
	int ret = 0;
	ret = sprintf(hexaddr, "0x%08x", decimaladdr);

	if(ret == 10)
	{
		return 1;
	}
	else
	{
		return 0;
	}	
}

int set_my_control(int now_pit_num,int now_pit_block1,int now_pit_block2)
{
	memset(&my_control,0,sizeof(my_control));
	my_control.now_pit_num = now_pit_num;
	my_control.now_pit_block1 = now_pit_block1;
	my_control.now_pit_block2 = now_pit_block2;
	
	return 1;
}

int nand_control_count_updata(int pit_count)
{
	char ch[20]={0};

	if(NF_EreaseBlock(0) == -1)
	{
		LED4_ON();
		return -1;	
	}

	memset(ch,0,sizeof(ch));
	strcpy(ch,"had create");
	nand_write(0,have_create_start,ch,have_create_size);
	

	memset(ch,0,sizeof(ch));
	sprintf(ch,"%d",pit_count);
	//LCD_DrawText(60,0,ch,strlen(ch),RGB(0,0,0),RGB(255,255,255));
	
	nand_write(0,pit_count_start,ch,pit_count_size);

	return 1;
}

int get_nand_control()
{
	char ch[20] = {0};
	memset(&my_nand_control,0,sizeof(my_nand_control));

	memset(ch,0,sizeof(ch));
	nand_read(0,pit_count_start,ch,pit_count_size);
	strcpy(my_nand_control.pit_count,ch);
	//LCD_DrawText(20,0,my_nand_control.pit_count,strlen(my_nand_control.pit_count),RGB(0,0,0),RGB(255,255,255));
	return 1;
}

int nand_control_add(char * pit_name,int now_pit_block1,int now_pit_block2)
{
	nand_pit_t temp_nand_pit[1023] = {0};
	char ch[60];
	int n = 0;
	int i = 0;
	int upcount = 0;
	TIME_T pstTime;
	char chtime[60] = {0};

	i = 1;
	memset(temp_nand_pit,0,sizeof(temp_nand_pit));
	
	get_nand_control();
	//ԭʼ���ݽ��б���
	for(n = 0;n < my_atoi(my_nand_control.pit_count);n++)
	{
		memset(ch,0,sizeof(ch));
		if( (n) % 40 == 0 && n != 0)
		{
			i++;
		}
		nand_read(i,0+(n * nand_pit_size),ch,nand_pit_size);
		strncpy(temp_nand_pit[n].pit_name,ch,18);
		strncpy(temp_nand_pit[n].pit_time,ch + 18,20);
		strncpy(temp_nand_pit[n].pit_num,ch + 38,4);
		strncpy(temp_nand_pit[n].now_pit_block1,ch + 42,4);
		strncpy(temp_nand_pit[n].now_pit_block2,ch + 46,4);
												
	}

	//��ʼ�������ݸ���

	upcount = my_atoi(my_nand_control.pit_count);
	upcount++;
	if(upcount >1023)
		return -1;

	//�����µ�������Ԫ
	strcpy(temp_nand_pit[n].pit_name,pit_name);

	memset(&pstTime,0,sizeof(pstTime));
	RTC_Get(&pstTime);
	sprintf(chtime,"%d/%02d/%02d %02d:%02d:%02d",pstTime.nYear,pstTime.nMon,pstTime.nDay,pstTime.nHour,pstTime.nMin,pstTime.nSec);	
	strcpy(temp_nand_pit[n].pit_time,chtime);

	memset(ch,0,sizeof(ch));
	sprintf(ch,"%d",n);
	strcpy(temp_nand_pit[n].pit_num,ch);

	memset(ch,0,sizeof(ch));
	sprintf(ch,"%d",now_pit_block1);
	strcpy(temp_nand_pit[n].now_pit_block1,ch);
	memset(ch,0,sizeof(ch));
	sprintf(ch,"%d",now_pit_block2);
	strcpy(temp_nand_pit[n].now_pit_block2,ch);

	//������������������д��NAND
	nand_control_count_updata(upcount);
	i=1;
	for(n = 0;n < upcount;n++)
	{
		
		if( (n) % 40 == 0 && n != 0)
		{
			i++;
		}
		memset(ch,0,sizeof(ch));
		strcpy(ch,temp_nand_pit[n].pit_name);
		nand_write(i,0+(n * nand_pit_size),ch,sizeof(temp_nand_pit[n].pit_name));
		
		memset(ch,0,sizeof(ch));
		strcpy(ch,temp_nand_pit[n].pit_time);
		nand_write(i,0+(n * nand_pit_size)+sizeof(temp_nand_pit[n].pit_name),ch,sizeof(temp_nand_pit[n].pit_time));

		memset(ch,0,sizeof(ch));
		strcpy(ch,temp_nand_pit[n].pit_num);
		nand_write(i,0+(n * nand_pit_size)+sizeof(temp_nand_pit[n].pit_name)+sizeof(temp_nand_pit[n].pit_time),ch,sizeof(temp_nand_pit[n].pit_num));

		memset(ch,0,sizeof(ch));
		strcpy(ch,temp_nand_pit[n].now_pit_block1);
		nand_write(i,0+(n * nand_pit_size)+sizeof(temp_nand_pit[n].pit_name)+sizeof(temp_nand_pit[n].pit_num)+sizeof(temp_nand_pit[n].pit_time),ch,sizeof(temp_nand_pit[n].now_pit_block1));

		memset(ch,0,sizeof(ch));
		strcpy(ch,temp_nand_pit[n].now_pit_block2);
		nand_write(i,0+(n * nand_pit_size)+sizeof(temp_nand_pit[n].pit_name)+sizeof(temp_nand_pit[n].pit_num)+sizeof(temp_nand_pit[n].now_pit_block1)+sizeof(temp_nand_pit[n].pit_time),ch,sizeof(temp_nand_pit[n].now_pit_block2));
										
	}
	updata_cmy_control(upcount);	

	return 1;	
}

int updata_cmy_control(int count)
{
	int n = 0;
	int i = 0;
	char ch_all[60] = {0};//һ��ͼƬ��Ϣ
	char ch[30] = {0};

	cmy_control[0].now_pit_num = count;
	i = 1;
	for(n = 1; n <= count ; n++)
	{
		memset(ch_all,0,sizeof(ch_all));
		if( (n) % 40 == 0 && n != 0)//һ�д�40��
		{
			i++;
		}
		nand_read(i,0+(( n - 1) * nand_pit_size),ch_all,nand_pit_size);

		memset(ch,0,sizeof(ch));
		strncpy(ch,ch_all,18);
		strcpy(cmy_control[n].pit_name,ch);

		memset(ch,0,sizeof(ch));
		strncpy(ch,ch_all+18,20);
		strcpy(cmy_control[n].pit_time,ch);

		memset(ch,0,sizeof(ch));
		strncpy(ch,ch_all + 38,4);
		cmy_control[n].now_pit_num = my_atoi(ch);

		memset(ch,0,sizeof(ch));		
		strncpy(ch,ch_all + 42,4);
		cmy_control[n].now_pit_block1 = my_atoi(ch);
		
		memset(ch,0,sizeof(ch));
		strncpy(ch,ch_all + 46,4);
		cmy_control[n].now_pit_block2 = my_atoi(ch);	
	}
	return 1;
}

int nand_control_init()
{
	char ch[20]={0};
		
	memset(cmy_control,0,sizeof(cmy_control));
	now_pit_id = 1;
	set_my_control(0,1,0);

	is_show_pit = 0;					//�жϵ�ǰ�����Ƿ�ΪͼƬ����
	is_show_system = 0;					//�жϵ�ǰ�����Ƿ�Ϊϵͳ����
	is_show_file_list = 0;				//�жϵ�ǰ�����Ƿ�Ϊ�ļ�����

	//�Ƚ����Զ���nand�����Ƿ���ͼƬ
	memset(ch,0,sizeof(ch));
	nand_read(0,have_create_start,ch,have_create_size);
	if(strcmp(ch,"had create") == 0)
	{
		//LCD_DrawText(0,0,ch,strlen(ch),RGB(255,255,255),RGB(0,0,0));
	}
	else
	{
		nand_control_count_updata(0);		
	}

	get_nand_control();

	if(strcmp(my_nand_control.pit_count,"0") == 0)
	{
		LCD_draw(0,0,240,320,local_pit);	
	}
	else
	{
		//show_system_box();
		get_nand_control();
		updata_cmy_control(my_atoi(my_nand_control.pit_count));
		show_pit();	
	}
	return 1;
}

int done_show_pit()
{
	is_show_pit = 0;
	return 1;
}

int show_pit()
{
	unsigned char temp_buffer[230456]={0};
	int count;

	count = cmy_control[0].now_pit_num;
	is_reshow_pit = 0;
	is_show_file_list = 0;
	is_show_pit = 1;
	is_show_system = 0;
	
	if(count == 0)
	{
		LCD_draw(0,0,240,320,local_pit);
		return 2;
	}
	 
	while(is_show_pit == 1)
	{
		memset(temp_buffer,0,sizeof(temp_buffer));
		nand_read(64*cmy_control[now_pit_id].now_pit_block1,0,(char *)temp_buffer,131072);
		nand_read(64*cmy_control[now_pit_id].now_pit_block2,0,(char *)temp_buffer+131072,99384);
		if(is_show_pit != 1)
			break;
		LCD_draw(0,0,240,320,temp_buffer);
		if(is_show_pit != 1)
			break;
		delay(3000);
		now_pit_id++;
		if(now_pit_id > count)
			now_pit_id = 1;
	}
			
	return 1; 	
}

int show_me_isbadblock(int item)
{
	int n;
	for(n = 1;n < bad_block[0]  ;n++)
	{
		if( item == bad_block[n])
		{
			return -1;
		}	
	}  
	return 1;
}

int show_system_box()
{
	if(is_show_file_list == 1)
	{
		LCD_switch_Screen(0,31,80,320,RGB(255,255,255));
	}
	if(is_show_file_list != 1)
	{
		LCD_ClearScreen(RGB(255,255,255));//������
		if(now_keyboard_id == 2)
		{	
			LCD_draw(130,0,80,260,RES_key_board2_BIN);//����
		}
		else if(now_keyboard_id == 1)
		{
			LCD_draw(130,0,80,260,RES_key_board1_BIN);//����
		}
		else if(now_keyboard_id == 3)
		{
			LCD_draw(130,0,80,260,RES_key_board3_BIN);//����
		}
	
		LCD_switch_Screen(0,211,29,320,RGB(131,223,231));//״̬��
		LCD_ShowRectangle(211,0,240,320,RGB(0,0,0));//״̬����
	
		LCD_switch_Screen(0,0,30,320,RGB(131,223,231));//������
		LCD_ShowRectangle(0,0,30,320,RGB(0,0,0));//��������
	
		LCD_switch_Screen(261,130,78,57,RGB(168,168,168));//��д��
		LCD_ShowRectangle(130,317,208,261,RGB(0,0,0));//��д����
	
		LCD_switch_Screen(0,111,19,320,RGB(14,235,157));//������Ϣ��ʾ��

		LCD_DrawText(5,1," �³��� NF120305",16,RGB(131,223,231),RGB(0,0,0));
	}

	LCD_DrawText(215,1,"����    ",8,RGB(131,223,231),RGB(0,0,0));

	is_show_file_list = 0;
	is_show_pit = 0;
	is_show_system = 1;

	TIMER_TS_Start(timer_id_dida);	
	event_start(event_show_text);

	return 1;
}

int show_file_box()
{
	int n;
	int i;
	char ch[50]={0};
	
	file_pit_id = 0;

	is_show_file_list = 1;
	is_show_pit = 0;
	is_show_system = 0;
		
	LCD_switch_Screen(0,31,80,320,RGB(255,255,255));
	
	for(n = 1,i = 0; n <= cmy_control[0].now_pit_num; n++,i++)
	{
		file_pit_id = n;
		sprintf(ch,"(%d) %-16s%-20s",n,cmy_control[n].pit_name,cmy_control[n].pit_time);
		LCD_DrawText(20*(i)+31,0,ch,strlen(ch),RGB(255,255,255),RGB(0,0,0));		
		if(n == 4)
		{
			break;
		}
	}

	return 1;
}

int page_down()
{
	int n;
	int i;
	char ch[50]={0};

	if(cmy_control[0].now_pit_num - (file_pit_id) != 0 )
	{
		LCD_switch_Screen(0,31,80,320,RGB(255,255,255));
		for(n = file_pit_id+1,i = 0;n <= cmy_control[0].now_pit_num; n++,i++)
		{
			file_pit_id = n;
			sprintf(ch,"(%d) %-16s%-20s",n,cmy_control[n].pit_name,cmy_control[n].pit_time);
			LCD_DrawText(20*(i)+31,0,ch,strlen(ch),RGB(255,255,255),RGB(0,0,0));		
			if(i == 3)
			{
				break;
			}
		}
		//file_pit_id++;
	}
	return 1;
}

int page_up()
{
	int n;
	int i;
	char ch[50]={0};

	if((file_pit_id - 4 ) > 0 )
	{
		LCD_switch_Screen(0,31,80,320,RGB(255,255,255));

		n = file_pit_id + 1 - 4 - cmy_control[0].now_pit_num % 4;
		if(file_pit_id / 4 >= 1 && file_pit_id % 4 == 0)
		{
			n -= 4;	
		}
		if(n <= 1)
			n = 1;
		for(i = 0;n <= cmy_control[0].now_pit_num; n++,i++)
		{
			file_pit_id = n;
			memset(ch,0,sizeof(ch));
			sprintf(ch,"(%d) %-16s%-20s",n,cmy_control[n].pit_name,cmy_control[n].pit_time);
			LCD_DrawText(20*(i)+31,0,ch,strlen(ch),RGB(255,255,255),RGB(0,0,0));		
			if(i == 3)
			{
				break;
			}
		}
		//file_pit_id--;
	}
	return 1;
}

int close_dida()
{
	TIMER_TS_Stop(timer_id_dida);		
	return 1;
}


/*****************************************************
�������ƣ� int VALIDATION_isLeapYear(int year)
��	  �ܣ� �ж��Ƿ�����
��    ���� year ��
�� �� ֵ�� 1-ͨ�� 0-��ͨ��
*****************************************************/
int VALIDATION_isLeapYear(int year)
{
	return (year%4 == 0 && year%100 != 0 || year%400 == 0);
}

/*****************************************************
�������ƣ�int VALIDATION_isDate(char *pDate,TIME_T * pSysDate)
��    �ܣ����ڸ�ʽУ��
��    ����pDate		����
�� �� ֵ��1-��Ч 0-���Ϸ�
����ʱ�䣺 2012-09-24
*****************************************************/
int VALIDATION_isDate(char *pDate,TIME_T * pSysDate)
{
	char cYear[10] = {0};
	char cMonth[10] = {0};
	char cDay[10] = {0};
	int i = 0,nYear,nMonth,nDay;
	if(pDate[10] != '\0')
		return 0;
	for(i = 0; i < 10; i++)		//�ж������Ƿ�Ϸ�
	{
		if(i == 4 || i == 7)
		{
			if(pDate[i] != '-')
				return 0;
		}else if(pDate[i] >= '0' && pDate[i] <= '9')
		{
			if(i < 4)
				cYear[i] = pDate[i];
			else if(i>4 && i<7)
				cMonth[i-5] = pDate[i];
			else
				cDay[i-8] = pDate[i];	
		}else
			return 0;
	}
	i = 0;
	nYear = my_atoi(cYear);
	nMonth = my_atoi(cMonth);
	nDay = my_atoi(cDay);
	switch(nMonth)
	{
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			if(nDay > 31 || nDay < 0)
				return 0;
			break;
		case 4:
		case 6:
		case 9:
		case 11:
			if(nDay > 30 || nDay < 0)
				return 0;
			break;
		case 2:
			{
				if(VALIDATION_isLeapYear(nYear)) //�ж�����2�·ݵ������Ƿ�Ϸ�
				{
					if(nDay > 29 || nDay < 0)
						return 0;
				}else  							 //�жϷ�����2�·ݵ������Ƿ�Ϸ�
					if(nDay > 28 || nDay < 0)
						return 0;
			}
			break;
		default:
			return 0;
	}
	pSysDate->nYear = nYear;
	pSysDate->nMon =  nMonth;
	pSysDate->nDay =  nDay;
	return 1;
}

/*****************************************************************
�������ƣ�int VALIDATION_isTime(char *pTime,TIME_T * pSysTime)
��    �ܣ�ʱ���ʽУ��
��    ����pTime		ʱ��
�� �� ֵ��1-��Ч 0-���Ϸ�
����ʱ�䣺 2012-09-24
*****************************************************************/
int VALIDATION_isTime(char *pTime,TIME_T * pSysTime)
{
	char cHour[3] = {0};
	char cMin[3] = {0};
	char cSec[3] = {0};
	int i = 0,nHour,nMin,nSec;

	if(pTime[8] != '\0')
		return 0;
	for(i = 0; i < 8; i++)		//�ж������Ƿ�Ϸ�
	{
		if(i == 2 || i == 5)
		{
			if(pTime[i] != ':')
				return 0;
		}else if(pTime[i] >= '0' && pTime[i] <= '9')
		{
			if(i < 2)
				cHour[i] = pTime[i];
			else if(i>2 && i<5)
				cMin[i-3] = pTime[i];
			else
				cSec[i-6] = pTime[i];	
		}else
			return 0;
	}
	i = 0;
	nHour = my_atoi(cHour);
	nMin = my_atoi(cMin);
	nSec = my_atoi(cSec);

	if(nHour>23 || nHour<0 || nMin>59 || nMin<0 || nSec>59 || nSec<0)
		return 0;
	else
	{
		pSysTime->nHour = nHour;
		pSysTime->nMin =  nMin;
		pSysTime->nSec =  nSec;
		return 1;
	}
}

/*****************************************************************
�������ƣ�int select_num(char *temp)
��    �ܣ�����У��
��    ����temp	
�� �� ֵ��1-��Ч 0-���Ϸ�
����ʱ�䣺 2012-09-24
*****************************************************************/
int select_num(char *temp)
{
	int n;

	for(n = 0;n < strlen(temp);n++)
	{
		if(!((temp[n] >= 48 && temp[n] <= 57) ))
			return 0;
	}

	return 1;
}

/*****************************************************************
�������ƣ�int select_0x(char *temp)
��    �ܣ�����У��
��    ����temp	
�� �� ֵ��1-��Ч 0-���Ϸ�
����ʱ�䣺 2012-09-24
*****************************************************************/
int select_0x(char *temp)
{
	int n;

	for(n = 0;n < strlen(temp);n++)
	{
		if(!((temp[n] >= 48 && temp[n] <= 57) || (temp[n] >= 65 && temp[n] <= 70) || (temp[n] >= 97 && temp[n] <= 102 ) || temp[n] == 120 || temp[n] == 88))
			return 0;
	}

	return 1;
}


/*****************************************************************
�������ƣ�int strto0x(char *temp)
��    �ܣ����ַ���ת��Ϊ16���Ʋ����ڷ���
��    ����temp	
�� �� ֵ��1-��Ч 0-���Ϸ�
����ʱ�䣺 2012-09-24
*****************************************************************/
int strto0x(unsigned long addr,char *temp,int num)
{
	int n;
	char ch[20] = {0};

	memset(ch,0,sizeof(ch));
	sprintf(ch,"0x%x: ",addr);
	UART_SendBuff(0,(unsigned char *)ch,strlen(ch));

	for(n = 0;n < num; n++)
	{
		if(n != 0 && n % 8 == 0)
		{
			memset(ch,0,sizeof(ch));
			sprintf(ch,"\r\n0x%x: ",addr+n);
			UART_SendBuff(0,(unsigned char *)ch,strlen(ch));	
		}
		memset(ch,0,sizeof(ch));
		sprintf(ch,"%02x ",temp[n]);
		UART_SendBuff(0,(unsigned char *)ch,strlen(ch));	
	}
	return 1;
}	 

