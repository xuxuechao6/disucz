#include "Bmp.h"
#include "../Driver/Lcd/Lcd.h"
/********************************************************************** 

  *  �������ƣ� bmp2raw 
  
	*  ���������� 
	*	  ��Ҫ��ת���ļ�
	*  ����˵��

	*  ����ֵ 
	*     �ɹ���ת���ֽ�����ʧ�ܣ�0  	  
******************************************************************/
int bmp2bin(unsigned char *bmpcashe, unsigned char *bincashe) 
{
	long  w,h,w_bytes;
	unsigned char *p1;
	int size;
	long allsize = 0;
	int	iCount = 0;
	int nIndexArray = 0; 

	BITMAPFILEHEADER bmp_head; 
	BITMAPINFOHEADER bmp_info; 
	char r,g,b;				

	bmp_head.bfType = bmpcashe[0]|bmpcashe[1] << 8;
	bmp_head.bfSize = bmpcashe[2]|bmpcashe[3]<<8|bmpcashe[4]<<16|bmpcashe[5]<<24;
	bmp_head.bfOffBits = bmpcashe[10]|bmpcashe[11]<<8|bmpcashe[12]<<16|bmpcashe[13]<<24;
	bmp_info.biWidth = bmpcashe[18]|bmpcashe[19]<<8|bmpcashe[20]<<16|bmpcashe[21]<<24;
	bmp_info.biHeight = bmpcashe[22]|bmpcashe[23]<<8|bmpcashe[24]<<16|bmpcashe[25]<<24;
	bmp_info.biBitCount = bmpcashe[28]|bmpcashe[29]<<8;

	if(bmp_head.bfType!=0x4d42) 
    {  
		return 0; 
    }


	if(bmp_info.biBitCount==24)
	{
		size = 0x3;//Դͼ��ÿһ�е��ֽ��� 	
	}
	else if(bmp_info.biBitCount==32)
	{
		size = 0x4;//Դͼ��ÿһ�е��ֽ���
	}

	w_bytes=bmp_info.biWidth * size;

    p1=bmpcashe+bmp_head.bfOffBits+(bmp_info.biHeight-1)*w_bytes;

	for(h=0;h<bmp_info.biHeight;h++) 
    { 
		iCount = 0;		
		for(w = 0; w < bmp_info.biWidth; w++)
		{
			b = p1[iCount++];
			g = p1[iCount++];
			r = p1[iCount++];
			bincashe[nIndexArray++] = (r & 0xf8)|((g & 0xfc) >> 5);
			bincashe[nIndexArray++] = ((b & 0xf8) >> 3)|((g & 0xfc) << 3);	
			allsize	+= 2;			
		}

		p1 -= w_bytes;
	}
	return allsize;
}



