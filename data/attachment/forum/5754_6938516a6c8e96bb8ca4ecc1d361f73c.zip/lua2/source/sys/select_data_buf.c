#include "select_data_buf.h"
#include <string.h>

select_data_t my_select_data[50];


int select_data_buf_init()
{
	memset(my_select_data,0,sizeof(my_select_data));
	return 1;
}

int add_select_data(char * data)
{
	int n;

	for(n = 0; n < 50;n++ )
	{
		if(my_select_data[n].is_create != 1 )
		{
			my_select_data[n].is_create = 1;
			memset(my_select_data[n].data,0,sizeof(my_select_data[n].data));
			strcpy(my_select_data[n].data,data);
			return 1;	
		}	
	}	
	if( n == 50)
	{
		return -1;
	}

	return 1;
}

int get_select_data(char * data)
{
	int n;

	for(n = 0; n < 50;n++ )
	{
		if(my_select_data[n].is_create == 1 )
		{
			strcpy(data,my_select_data[n].data);
			my_select_data[n].is_create = 0;
			return 1;	
		}
	}
	if( n == 50)
	{
		return -1;
	}	
	return 1;
}
