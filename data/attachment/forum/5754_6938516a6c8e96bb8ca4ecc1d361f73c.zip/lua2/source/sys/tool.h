#ifndef _TOOL_H_
#define _TOOL_H_
#include <math.h>

#define have_create_start 		0
#define have_create_size 		20
#define pit_count_start 		20
#define pit_count_size 			20

#define nand_pit_size 			50

typedef struct nand_control_t
{
	char pit_count[8];	 				//��Ƭ����				    

}nand_control_t;

typedef struct control_t
{
	char pit_name[18];					//ͼƬ����
	char pit_time[20];					//ͼƬʱ��
	int now_pit_num; 				//��ǰͼƬ����
	int now_pit_block1; 			//��ǰͼƬ����NANDFLASH�еĿ�1
	int now_pit_block2; 			//��ǰͼƬ����NANDFLASH�еĿ�2				    

}control_t;

typedef struct nand_pit_t
{
	char pit_name[18];					//ͼƬ����
	char pit_time[20];					//ͼƬʱ��
	char pit_num[4];					//ͼƬ���
	char now_pit_block1[4];				//ͼƬ�������ڿ�
	char now_pit_block2[4];				//ͼƬ�������ڿ�
					    
}nand_pit_t;

void delay(int times);					//��ʱ���������ף�
unsigned long UART_HextoDec(const char *hex);
int UART_DectoHex(unsigned char decimal,  char *hex);
int UART_DecaddrtoHexaddr(unsigned int decimaladdr,  char *hexaddr);
unsigned int my_atoi(const char *hex);

int set_my_control(int now_pit_num,int now_pit_block1,int now_pit_block2);
int nand_control_count_updata(int pit_count);
int get_nand_control(void);
int nand_control_add(char * pit_name,int now_pit_block1,int now_pit_block2);
int updata_cmy_control(int count);
int done_show_pit(void);
int show_pit(void);
int show_system_box(void);
int nand_control_init(void);

int show_me_isbadblock(int item);
int show_file_box(void);
int page_up(void);
int page_down(void);
int close_dida(void);

int VALIDATION_isLeapYear(int year);
int VALIDATION_isDate(char *pDate,TIME_T * pSysDate);
int VALIDATION_isTime(char *pTime,TIME_T * pSysTime);
int select_num(char *temp);
int select_0x(char *temp);
int strto0x(unsigned long addr,char *temp,int num);

#endif
