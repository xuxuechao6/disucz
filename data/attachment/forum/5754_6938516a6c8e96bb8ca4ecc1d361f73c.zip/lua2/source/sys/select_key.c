#include "select_key.h"
#include "MyEvent.h"
#include "Events.h"
#include "../usr/my_draw/my_draw.h"
#include "../Driver/Lcd/Lcd.h"
#include <stdio.h> 
#include <stdlib.h>
#include <string.h>

key_data_t my_key_board[50];
int now_keyboard_id;

int key_board_init(void)
{	
	int n;
	int i;
	
	now_keyboard_id = 2;

	memset(&my_key_board,0,sizeof(my_key_board));
	//��һ��
	for(n = 0,i = 0; n <= 12 ; n++,i++)
	{
		my_key_board[n].x = i*20;
		my_key_board[n].y = 130;	
	}
	//�ڶ���
	for(n = 13,i = 0; n <= 25 ; n++,i++)
	{
		my_key_board[n].x = i*20;
		my_key_board[n].y = 150;	
	}
	//������
	for(n = 26,i = 0; n <= 37 ; n++,i++)
	{
		my_key_board[n].x = i*20;
		my_key_board[n].y = 170;	
	}
	//������ǰ4��
	for(n = 38,i = 0; n <= 41 ; n++,i++)
	{
		my_key_board[n].x = i*20;
		my_key_board[n].y = 190;	
	}
	//�ո�
	my_key_board[42].x = 80;
	my_key_board[42].y = 190;
	//������ʣ��
	for(n = 43,i = 0; n <= 46 ; n++,i++)
	{
		my_key_board[n].x = i*20 + 160;
		my_key_board[n].y = 190;	
	}
	//�����̸�ֵ
	for(n = 4,i = 0; n <= 13 ; n++,i++)
	{
		my_key_board[n].data1 = 48 + i;
		my_key_board[n].data2 = 48 + i;
		my_key_board[n].data3 = 48 + i;  	
	}
	for(n = 14,i = 0;n <= 24; n++,i++)
	{
		my_key_board[n].data2 = 65 + i;
		my_key_board[n].data3 = 97 + i;
	}
	for(n = 26,i = 0;n <= 40; n++,i++)
	{
		my_key_board[n].data2 = 76 + i;
		my_key_board[n].data3 = 108 + i;
	}
	my_key_board[14].data1 = 44;	//,
	my_key_board[15].data1 = 46;	//.
	my_key_board[16].data1 = 59;	//;
	my_key_board[17].data1 = 33;	//!
	my_key_board[18].data1 = 63;	//?
	my_key_board[19].data1 = 43;	//+
	my_key_board[20].data1 = 45;	//-
	my_key_board[21].data1 = 42;	//*
	my_key_board[22].data1 = 37;	//%
	my_key_board[23].data1 = 61;	//=
	my_key_board[24].data1 = 124;	//|
	my_key_board[26].data1 = 92;	//\//
	my_key_board[27].data1 = 47;	///
	my_key_board[28].data1 = 58;	//:
	my_key_board[29].data1 = 64;	//@
	my_key_board[30].data1 = 36;	//$
	my_key_board[31].data1 = 38;	//&
	my_key_board[32].data1 = 35;	//#
	my_key_board[33].data1 = 40;	//(
	my_key_board[34].data1 = 41;	//&
	my_key_board[35].data1 = 60;	//<
	my_key_board[36].data1 = 62;	//>
	my_key_board[37].data1 = 123;	//{
	my_key_board[38].data1 = 125;	//}
	my_key_board[39].data1 = 91;	//[
	my_key_board[40].data1 = 93;	//]

	my_key_board[42].data1 = 32;	
	my_key_board[42].data2 = 32;	
	my_key_board[42].data3 = 32;	

	event_add(event_key_board,key_board_work);
		
	return 1;
}

int key_board_clear()
{
	int n;

	for(n = 0;n < 50;n++)
	{
		my_key_board[n].is_create = 0;
		my_key_board[n].is_be_choice = 0;
		my_key_board[n].is_had_pit = 0;			
	}

	return 1;
}

int key_board_be_create(int num)
{
	my_key_board[num].is_create = 1;
	return 1;
}

int key_board_be_choice(int num)
{
	my_key_board[num].is_be_choice = 1;
	return 1;
}

int choice_key(int x, int y,int is_frist)
{
	int n;
	int i;
	
	if(y >= 130 + 2 && y <= 150 - 2)
	{
		for(n = 0,i = 0; n <= 12; n++,i++)
		{
			if(x >= i*20 + 2 && x <= (i+1)*20 - 2  )
			{
				key_board_be_create(n);
				if(is_frist == 1)
				{
					key_board_be_choice(n);	
				}
				return n;
			}
		}
	}
	else if(y >= 150 + 2 && y <= 170 - 2)
	{
		for(n = 13,i = 0; n <= 24; n++,i++)
		{
			if(x >= i*20 + 2 && x <= (i+1)*20 - 2 )
			{
				key_board_be_create(n);
				if(is_frist == 1)
				{
					key_board_be_choice(n);	
				}
				return n;
			}	
		}
	}
	else if(y >= 170 + 2 && y <= 190 - 2)
	{	
		for(n = 26,i = 0; n <= 37; n++,i++)
		{
			if(x >= i*20 + 2 && x <= (i+1)*20 - 2  )
			{
				key_board_be_create(n);
				if(is_frist == 1)
				{
					key_board_be_choice(n);	
				}
				return n;
			}
		}
	}
	else if(y >= 190 + 2 && y <= 210 - 2)
	{
		for(n = 38,i = 0; n <= 41; n++,i++)
		{
			if(x >= i*20 + 2 && x <= (i+1)*20 - 2 )
			{
				key_board_be_create(n);
				if(is_frist == 1)
				{
					key_board_be_choice(n);	
				}
				return n;
			}
		}
		for(n = 43,i = 8; n <= 45; n++,i++)
		{
			if(x >= i*20 + 2 && x <= (i+1)*20 - 2 && y >= 190 + 2 && y <= 210 - 2)
			{
				key_board_be_create(n);
				if(is_frist == 1)
				{
					key_board_be_choice(n);	
				}
				return n;
			}
		}
	}
	//ת����
	if(x >= 240 + 2 && x <= 260 - 2 && y >= 150 + 2 && y <= 180 - 2)
	{
		key_board_be_create(25);
		if(is_frist == 1)
		{
			key_board_be_choice(25);	
		}
		return 25;	
	}
	//�ո�
	else if(x >= 80 + 2 && x <= 160 - 2 && y >= 190 + 2 && y <= 210 - 2)
	{
		key_board_be_create(42);
		if(is_frist == 1)
		{
			key_board_be_choice(42);	
		}
		return 42;
	}
	//enter
	else if(x >= 220 + 2 && x <= 260 - 2 && y >= 190 + 2 && y <= 210 - 2)
	{
		key_board_be_create(46);
		if(is_frist == 1)
		{
			key_board_be_choice(46);	
		}
		return 46;
	}
	else if(x >= 240 + 2 && x <= 260 - 2 && y >= 170 + 2 && y <= 190)
	{
		key_board_be_create(46);
		if(is_frist == 1)
		{
			key_board_be_choice(46);	
		}
		return 46;
	}
		
	return -1;
}
