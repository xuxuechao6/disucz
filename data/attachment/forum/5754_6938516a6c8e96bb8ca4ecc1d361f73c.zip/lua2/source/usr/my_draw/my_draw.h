// BMP2RAW generated include file.
#ifndef _MYDRAW_H_
#define _MYDRAW_H_

extern unsigned char RES_key_board1_BIN[];
extern unsigned char RES_key_board2_BIN[];
extern unsigned char RES_key_board3_BIN[];

#endif //IMGLST_RESOURCE_H__INCLUDED_
