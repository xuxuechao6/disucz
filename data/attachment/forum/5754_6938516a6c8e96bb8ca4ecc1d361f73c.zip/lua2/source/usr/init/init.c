#include "../global.h"
#include <stdio.h> 
#include <stdlib.h>
#include <string.h>

int bad_block[2048];
int timer_id_dida;
int timer_id_sleep;

void LED_INIT(void)
{
	 EXTINT1 = 0x22202002;//����EINT8��11��13��14��15�½��ش���
	 EXTINT2 = 0x2000;//EINT19�½��ش���
	 GPGCON = 0x80A882;
	 GPBCON	|= (1  << 10)  ;
	 GPBCON	|= (1  << 12)  ;
	 GPBCON	|= (1  << 14)  ;
	 GPBCON	|= (1  << 16)  ;
	 GPBCON	|= (1  << 0)  ;
	 GPBDAT = 0xfffe;
}

int checkmem()
{
	char ch[1] = {0};
	char * ctemp =NULL;
	int n; 	

	ch[0] = 0x55;
	ctemp = ch;
	if( *ctemp != 0x55)
	{
		for(n = 0;n < 3;n++)
		{
			//beep_ON();
			delay(500);
		//	beep_OFF();
			delay(500);
		}

		return -1;
	}
	ch[0] = 0xaa;
	if( *ctemp != 0xaa)
	{
		for(n = 0;n < 3;n++)
		{
			//beep_ON();
			delay(500);
			//beep_OFF();
			delay(500);
		}
		return -1;
	}

	//beep_ON();
	delay(500);
	//beep_OFF();
	return 1;
}

int check_system_mes()
{	
	char ch[200]={0};	
	char th2,th3,th4,th5;
	unsigned int nand_id;

	memset(ch,0,sizeof(ch));
	strcpy(ch,"ϵͳ��Ƶ�� = 400MHZ");
	LCD_DrawText(0,0,ch,19,RGB(0,0,0),RGB(255,255,255));
	delay(500);

	nand_id = NAND_ReadId(&th2,&th3,&th4,&th5);
	sprintf(ch,"NandFlash_ID = 0x%x",nand_id);
	LCD_DrawText(20,0,ch,25,RGB(0,0,0),RGB(255,255,255));
	delay(500);

	memset(ch,0,sizeof(ch));
	strcpy(ch,"NandFlash_size = 256M");
	LCD_DrawText(40,0,ch,21,RGB(0,0,0),RGB(255,255,255));
	delay(500);

	memset(ch,0,sizeof(ch));
	strcpy(ch,"NandFlash_page = 2K");
	LCD_DrawText(60,0,ch,19,RGB(0,0,0),RGB(255,255,255));
   	delay(500);

	memset(ch,0,sizeof(ch));
	strcpy(ch,"ϵͳ��Ƶ�� = 400MHZ");
	LCD_DrawText(0,0,ch,19,RGB(0,0,0),RGB(255,255,255));
	delay(500);

	memset(ch,0,sizeof(ch));
	sprintf(ch,"R0_Base = 0x%p R0_Size = 0x%x",Image$$RO$$Base,Image$$RO$$Limit - Image$$RO$$Base);
	LCD_DrawText(80,0,ch,37,RGB(0,0,0),RGB(255,255,255));
	delay(500);

	memset(ch,0,sizeof(ch));
	sprintf(ch,"RW_Base = 0x%p RW_Size = 0x%x",Image$$RW$$Base,Image$$ZI$$Base - Image$$RW$$Base);
	LCD_DrawText(100,0,ch,38,RGB(0,0,0),RGB(255,255,255));
	delay(500);

	memset(ch,0,sizeof(ch));
	sprintf(ch,"ZI_Base = 0x%p ZI_Size = 0x%x",Image$$ZI$$Base,Image$$ZI$$Limit - Image$$ZI$$Base);
	LCD_DrawText(120,0,ch,38,RGB(0,0,0),RGB(255,255,255));
	delay(500);
		
	memset(ch,0,sizeof(ch));
	sprintf(ch,"HanZi_Base = 0x%x",HZK16_BASE);
	LCD_DrawText(140,0,ch,21,RGB(0,0,0),RGB(255,255,255));
	delay(500);

	memset(ch,0,sizeof(ch));
	sprintf(ch,"ANSII_Base = 0x%x",ASC16_BASE);
	LCD_DrawText(160,0,ch,21,RGB(0,0,0),RGB(255,255,255));

		
	//LCD_draw(0,0,240,320,local_pit);
	return 1;
}

int check_block_init()
{
	int bad_block_size = 0;
	char ch[50] = {0};
	unsigned int n;
	unsigned int i;
	unsigned int j;
	unsigned int k;		
	
	i = 0;
	j = 0;
	k = 0;
	is_front_bad = 0;
	memset(&bad_block,0,sizeof(bad_block));
	memset(ch,0,sizeof(ch));
	LCD_ClearScreen(RGB(0,0,0));//����

	LCD_DrawText(80,31,"������:",9,RGB(0,0,0),RGB(255,255,255));
	LCD_DrawText(135,31,"�����:",7,RGB(0,0,0),RGB(255,255,255));
	LCD_ShowRectangle(100,31,130,289,RGB(255,255,255));
	

	for(n = 0;n < 2048;n++)
	{
		memset(ch,0,sizeof(ch));
		sprintf(ch,"%d",n+1);
		LCD_DrawText(135,100,ch,strlen(ch),RGB(0,0,0),RGB(255,255,255));
		if( NF_CheckBlock(n) == 1)//���� 
		{
			i++;
			bad_block_size++;
			bad_block[i] = n;	//���뻵������
		}		
		if( n != 0 && (n+1) % 8 ==0)
		{
			LCD_switch_Screen(32 + j,101,29,1,RGB(88,187,83));
			j++;
			if(j%2==0 && j !=4 && j!=8 && j!=10 && j!=12 && j!=14 && j!=16 && j!=18 && j!=20 && j!=24 && j!=26 && j!=28 && j!=32 && j!=34 && j!=36 && j!=38 && j!=44 && j!=48 && j!=50 && j!=54 && j!=58 && j!=62 && j!=66 && j!=68 && j!=72 && j!=76 && j!=80 && j!=88)
			{
				memset(ch,0,sizeof(ch));
				sprintf(ch,"%d%%",k);
				LCD_DrawText(80,105,ch,strlen(ch),RGB(0,0,0),RGB(255,255,255));
				k++;
			}		
		}	
	}
	LCD_switch_Screen(32 + j,101,29,1,RGB(88,187,83));
	
	bad_block[0] = bad_block_size;

	LCD_DrawText(135,140,"�������:",9,RGB(0,0,0),RGB(255,255,255));
	memset(ch,0,sizeof(ch));
	sprintf(ch,"%d",bad_block_size);
	LCD_DrawText(135,220,ch,strlen(ch),RGB(0,0,0),RGB(255,255,255));
	delay(2000);

	//memset(ch,0,sizeof(ch));
	//sprintf(ch,"%d",bad_block_size);
	//LCD_DrawText(180,0,ch,40,RGB(255,255,255),RGB(0,0,0));

	return 1;
}

int dida_work_init()
{	
	timer_id_dida = 0;
	timer_id_dida = TIMER_TS_Create(300,1,timer_dida_work);
	event_add(event_dida,dida_work);
	return 1;
}

int system_sleep_init()
{
	is_reshow_pit = 0;
	event_add(event_system_sleep,system_sleep_work);
	timer_id_sleep = TIMER_TS_Create(10000,0,timer_system_sleep);
	return 1;
}

int state_init()
{
	event_add(event_state_pit_hand,state_pit_hand_work);//ע���¼�
	event_add(event_state_pit_keyboard,state_pit_keyboard_work);//ע���¼�
	event_add(event_state_pit_ldle,state_pit_idle_work);//ע���¼�
	return 1;
}

int system_init()
{		
	LED_INIT();

	if(checkmem() == -1)
		return -1;

	event_init();
	IRQ_Init();
	LCD_Init();
	NAND_Init();
	/**/
	LCD_ClearScreen(RGB(0,0,0));//����
	if(check_system_mes() == -1)
		return -1;	
	delay(2000);
	if(check_block_init() == -1)
		return -1;
  	
	TIMER_TS_Init(0,249,2,25,TIMER_TS_Manger,1);//��������ʱ 0x19һ���� 0x61a8һ��
	UART_Init(0,115200,8,1,1);
	UART_Open(0);
	TOUCH_Init();
	RTC_Init();

	dida_work_init();
	system_sleep_init();	    
	key_board_init();
	my_text_init();	
	state_init();

	is_sending_file_now = 0;
	is_have_start_hand_sleep = 0;

	nand_control_init();
	

	return 1;
}
