#ifndef _INIT_H_
#define _INIT_H_

#define LED_ON() (GPBDAT &= ~(0xf<<5))
#define LED1_ON() (GPBDAT &= ~(0x1<<5))
#define LED2_ON() (GPBDAT &= ~(0x1<<6))
#define LED3_ON() (GPBDAT &= ~(0x1<<7))
#define LED4_ON() (GPBDAT &= ~(0x1<<8))

#define LED_OFF() (GPBDAT |= (0xf<<5))
#define LED1_OFF() (GPBDAT |= (0x1<<5))
#define LED2_OFF() (GPBDAT |= (0x1<<6))
#define LED3_OFF() (GPBDAT |= (0x1<<7))
#define LED4_OFF() (GPBDAT |= (0x1<<8))

#define beep_ON()  (GPBDAT	|= (0x1  << 0))  
#define beep_OFF() (GPBDAT  &= ~(0x1<<0))

void LED_INIT(void);
int checkmem(void);
int check_system_mes(void);
int check_block_init(void);
int dida_work_init(void);
int system_sleep_init(void);

int system_init(void);

#endif
