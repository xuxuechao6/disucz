#include <stdio.h> 
#include <S3C2440.h>
#include <stdlib.h>

#include <time.h>
#include <rt_heap.h>
#include <locale.h>
#include "global.h"
#include "../lua/lua.h"
#include "../lua/lauxlib.h"
#include "../lua/lualib.h"

#pragma import(__use_realtime_heap)

extern int job1_flag;
extern int job2_flag;
extern fifobuf_t recv_fifobuf_t;
extern unsigned char recv_fifobuf_data[fifo_recv_size];

unsigned char * local_pit = NULL;

void LED1_work()
{	
   	GPBDAT = 0xffff;
 	GPBDAT &=~(1 << 5);
	LCD_ClearScreen(RGB(255,255,255));
	LCD_DrawText(100,100,"�³���05", 8,RGB(255,255,255),RGB(0,0,0));
	LCD_DispCN_DIY(15,1,50,150, RGB(255,255,255),RGB(0,0,0));
}
void LED2_work()
{	
	
	GPBDAT = 0xffff;
	GPBDAT &=~(1 << 6);
	LCD_ClearScreen(RGB(255,255,0));
}
void LED3_work()
{
	GPBDAT = 0xffff;
	GPBDAT &=~(1 << 7);
	LCD_ClearScreen(RGB(0,255,255));	

}
void LED4_work()
{
	GPBDAT = 0xffff;
	GPBDAT &=~(1 << 8);
	LCD_ClearScreen(RGB(255,0,0));
}

void LED5_work()
{
	GPBDAT = 0xffff;
	GPBDAT &=~(1 << 8);

	LCD_ClearScreen(RGB(0,255,0));
	LCD_DrawText(159,150,"�³���05", 8,RGB(255,255,255),RGB(0,0,0));
	LCD_DispCN_DIY(15,1,50,150, RGB(255,255,255),RGB(0,0,0));
}

static int rtrt(lua_State *L)
{
	beep_ON();
	return 1;
}

int lua_test()
{
	lua_State *L;
    char  error1[100] = {0};
	char buff[10]={0};
	char buff2[10]={0};
    L = luaL_newstate();
	//L = lua_open();      
	//luaL_openlibs(L);    
    //luaopen_base(L);
	//luaopen_table(L);
    //luaopen_io(L);
    //luaopen_string(L);
    //luaopen_math(L);
    
	lua_pushcfunction(L,rtrt);
	strcpy(buff2,"rtrt");
	lua_setglobal(L,buff2);
	//lua_register(L, "mybeep", mybeep);     
	//beep_ON();
	strcpy(buff,"rtrt();");
	luaL_dostring(L,buff);
	{
		strcpy(error1,lua_tostring(L,-1));
		UART_SendBuff(0,error1,strlen(error1));
	}
	
//	lua_pcall(L,0,-1,0);
	lua_close(L);

	return 0;


}

void Main()
{
	
   	int a = 0;

	local_pit = (unsigned char *)(0x001d0000);
	job1_flag=0;
	job2_flag=0;
	
	_init_alloc(0x31000000,0x32000000);
	setlocale(LC_ALL,"c");

  if(system_init() == -1)
	{
		return ;
	}

    IRQ_SetMask(INT_TYPE_EINT8_23, INT_MASK_ENABLE);//�����ⲿһ���ж�
	IRQ_Install(INT_TYPE_EINT8, LED1_work);
	IRQ_Install(INT_TYPE_EINT11, LED2_work);
	IRQ_Install(INT_TYPE_EINT13, LED3_work);
	IRQ_Install(INT_TYPE_EINT14, LED4_work);
	IRQ_Install(INT_TYPE_EINT15, LED5_work);
	
	//IRQ_Install(INT_TYPE_INT_TIMER0, timeer0_work);
	//IRQ_Install(INT_TYPE_INT_TIMER1, timeer1_work);
	a++;
	a++;
	a++;
	a++;
	a++;
	a++;
	a++;
		
	
	while(1)
	{
		lua_test();	
	  
	}
	event_listen();
}






