/*
 * File      : app.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2006, RT-Thread Development Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://www.rt-thread.org/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2006-06-05     Bernard      the first version
 */

/**
 * @addtogroup aduc7026
 */
/*@{*/
#include <rtthread.h>
#include <board.h>
//int rt_application_init()
//{
//	rt_uint32_t counter1 = 0 ,counter2 = 0;
//	while(1){
//		counter1 ++;
//		rt_hw_board_led_off(2);
////		rt_thread_delay(1000);
//		rt_hw_board_led_on(2);
////		rt_thread_delay(1000);
//		counter2 ++;
//	}
//	
//}

/*@}*/
