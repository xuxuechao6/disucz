/*
 * File      : board.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2006, RT-Thread Develop Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://openlab.rt-thread.com/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2006-08-23     Bernard      first implementation
 */

#include <rtthread.h>
#include <rthw.h>

#include <aduc7026.h>
#include "board.h"

static void rt_hw_board_led_init(void);

/**
 * @addtogroup aduc7026
 */
/*@{*/

/* Periodic Interval Value */
#define TIMER_PRESCALE  16        /* prescaler for timer frequency */
#define TIMER_RELOAD       (MCK/TIMER_PRESCALE/RT_TICK_PER_SECOND)
/**
 * This is the timer interrupt service routine.
 * @param vector the irq number for timer
 */
void rt_hw_timer_handler(int vector)
{
		T0CLRI = 0;				/* clear timer interrupt    */
		/* increase a tick */
		rt_tick_increase();
}
/**
 * This function will init led on the board
 */
static void rt_hw_board_led_init()
{
	GP2CON &= 0xf00fffff;		//GP2.5 GP2.6 ->GPIO
	GP3CON &= 0xff00ffff;		//GP3.4 GP3.5 ->GPIO
	GP2DAT |= 0x60000000;		//GP2.5 GP2.6 ->GPIO OUT
	GP3DAT |= 0x30000000;		//GP3.4 GP3.5 ->GPIO OUT
	GP2CLR |= ((1 << 5) << 16);
	GP2CLR |= ((1 << 6) << 16);
	GP3CLR |= ((1 << 4) << 16);
	GP3CLR |= ((1 << 5) << 16);
}

/**
 * This function will take the led on board on.
 *
 * @param n the number nth led
 */
void rt_hw_board_led_on(rt_uint8_t lednum)
{
	switch(lednum){
		case 0:GP2CLR = ((1 << 5) << 16);break;
		case 1:GP2CLR = ((1 << 6) << 16);break;
		case 2:GP3CLR = ((1 << 4) << 16);break;
		case 3:GP3CLR = ((1 << 5) << 16);break;
		default:break;
	}
}

/**
 * This function will take the led on board off.
 *
 * @param n the number nth led
 */
void rt_hw_board_led_off(rt_uint8_t lednum)
{
	switch(lednum){
		case 0:GP2SET = ((1 << 5) << 16);break;
		case 1:GP2SET = ((1 << 6) << 16);break;
		case 2:GP3SET = ((1 << 4) << 16);break;
		case 3:GP3SET = ((1 << 5) << 16);break;
		default:break;
	} 
}

void rt_hw_led_flash()
{
	int i;

	rt_hw_board_led_off(0);
	for (i = 0; i < 2000000; i ++);

	rt_hw_board_led_on(0);
	for (i = 0; i < 2000000; i ++);
}

/*
 * RT-Thread Console Interface, used by rt_kprintf
 */
/**
 * This function is used to display a string on console, normally, it's
 * invoked by rt_kprintf
 *
 * @param str the displayed string
 */
void rt_hw_console_output(const char* str)
{
	while (*str)
	{
		if (*str == '\n')
		{
			while (!(COMSTA0 & ADI_US_TEMT));
			COMTX = '\r';
		}
		/* Wait for Empty Tx Buffer */
			while (!(COMSTA0 & ADI_US_TEMT));
		/* Transmit Character */
		COMTX = *str;
		str ++;
	}
}

static void rt_hw_console_init()
{
	volatile char Dummy;
  	//  Initialize P1.0 and P1.1 as SIN and SOUT
  	GP1CON &= 0xFFFFFF00;    // Mask configuration for P1.0 and P1.1
  	GP1CON |= ((0x01 << 0) | (0x01 << 4));  // Set P1.0 to SIN function, Set P1.1 to SOUT function
  	//
  	//  Disable all UART interrupts
  	//
  	COMIEN0 = 0;
  	//  Initialize Baudrate generator
  	COMCON0 |= (1 << 7);   // Enable access to divisor latch
  	COMDIV0  =  (_BAUDDIVIDE & 0xFF);
  	COMDIV1  = ((_BAUDDIVIDE >> 8) & 0xFF);
  	COMDIV2  = 0;          // Disable fractional baudrate divider
  	COMCON0 &= ~(1 << 7);
  	//
  	//  Initialize Data-Format 8N1
  	//
  	COMCON0  = 0x3         // 3 => 8 data bits
           | (0 << 2)    // 1 Stop bit
           | (0 << 3)    // Parity disabled
           | (0 << 4)    // ODD parity; don't care if parity is disabled
           | (0 << 5)    // Stick parity; don't care if parity is disabled
           | (0 << 6)    // Normal mode (no Break)
           | (0 << 7)    // Access Rx and Tx data registers
           ;
  	COMCON1  = 0           //
           | (0 << 0)    // DTR passive
           | (0 << 1)    // RTS passive
           | (0 << 2)    // undefined
           | (0 << 3)    // undefined
           | (0 << 4)    // Loopback disabled
           | (0 << 5)    // reserved
           | (0 << 6)    // reserved
           | (0 << 7)    // reserved
           ;
  	//
  	//  Clear all UART erros
  	//
  	Dummy = COMRX;
  	Dummy = COMSTA0;      // Read Line state to clear error
  	//
  	// Finally enable UART interrupts
  	//
  	COMIEN0 = 0
          | (1 << 0)    // Enable Rx interrupt
          | (0 << 1)    // Enable Tx interrupt
          | (1 << 2)    // Enable Rx error (Line Status) interrupt
          ;
  	//IRQEN |= UART_BIT; // Enable UART interrupt
}

/**
 * This function will initial sam7s64 board.
 */
void rt_hw_board_init()
{
	extern void rt_serial_init(void);
	/* init hardware console */
	rt_hw_console_init();

	/* init led */
	rt_hw_board_led_init();

	/* init Rtos Timer0 */
  	T0CON  = 0;              // Initially disable timer
  	T0LD   = TIMER_RELOAD;   // initialize time constant
  	T0CON  = 0               // Initialize timer
         | (1 << 7)        // Enable Timer
         | (1 << 6)        // in periodic mode
         | (0 << 4)        // bits 5 and 4 reserved, write 0
         | (1 << 2)        // bits 3 and 2: 00 => runs at core clock / 16
         ;                 // bits 1 and 0 reserved, write 0
  	T0CLRI = 0;              // Clear timer interrupt
//  	IRQEN |= TIMER0_ID_MASK; // Enable timer interrupt
//	/* install timer handler */
	rt_hw_interrupt_install(ADI_ID_RTOS_TIMER, rt_hw_timer_handler, RT_NULL);
//	AT91C_AIC_SMR(ADI_ID_RTOS_TIMER) = 0;
	rt_hw_interrupt_umask(ADI_ID_RTOS_TIMER);
}
/*@}*/
