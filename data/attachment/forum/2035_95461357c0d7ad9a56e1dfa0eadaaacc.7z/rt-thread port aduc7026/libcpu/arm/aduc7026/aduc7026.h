/*
 * File      : aduc7026.h
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2006, RT-Thread Develop Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://openlab.rt-thread.com/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2006-08-23     Bernard      first version
 */

#ifndef __ADUC7026_H__
#define __ADUC7026_H__

#ifdef __cplusplus
extern "C" {
#endif



/*  REMAP AND SYSTEM CONTROL  */


#define REMAPBASE 	(*(volatile unsigned long *) 	0XFFFF0200)
#define REMAP 		(*(volatile unsigned long *) 	0XFFFF0220)
#define RSTSTA 		(*(volatile unsigned long *) 	0XFFFF0230)
#define RSTCLR 		(*(volatile unsigned long *) 	0XFFFF0234)

/*  PLL AND OSCILLATOR CONTROL  */

#define PLLBASE 	(*(volatile unsigned long *) 	0XFFFF0400)
#define PLLSTA	 	(*(volatile unsigned long *) 	0XFFFF0400)
#define POWKEY1		(*(volatile unsigned long *) 	0XFFFF0404)
#define POWCON 		(*(volatile unsigned long *) 	0XFFFF0408)
#define POWKEY2		(*(volatile unsigned long *) 	0XFFFF040C)
#define PLLKEY1		(*(volatile unsigned long *) 	0XFFFF0410)
#define PLLCON 		(*(volatile unsigned long *) 	0XFFFF0414)
#define PLLKEY2		(*(volatile unsigned long *) 	0XFFFF0418)
/*  POWER SUPPLY MONITOR   */

#define PSMBASE 	(*(volatile unsigned long *) 	0XFFFF0440)
#define PSMCON 		(*(volatile unsigned long *) 	0XFFFF0440)
#define CMPCON 		(*(volatile unsigned long *) 	0XFFFF0444)

/*	Band Gap Reference */
#define REFBASE 	(*(volatile unsigned long *) 	0XFFFF0480)
#define REFCON 		(*(volatile unsigned long *) 	0XFFFF048C)

/*  ADC INTERFACE REGISTERS   */

#define ADCBASE 	(*(volatile unsigned long *)	0XFFFF0500)
#define ADCCON 		(*(volatile unsigned long *) 	0XFFFF0500)
#define ADCCP 		(*(volatile unsigned long *) 	0XFFFF0504)
#define ADCCN 		(*(volatile unsigned long *) 	0XFFFF0508)
#define ADCSTA 		(*(volatile unsigned long *) 	0XFFFF050C)
#define ADCDAT 		(*(volatile unsigned long *) 	0XFFFF0510)
#define ADCRST 		(*(volatile unsigned long *) 	0XFFFF0514)
#define ADCGN 		(*(volatile unsigned long *) 	0XFFFF0530)
#define ADCOF 		(*(volatile unsigned long *) 	0XFFFF0534)

/* EXTERNAL MEMORY REGISTERS */

#define XMBASE		(*(volatile unsigned long *)	0XFFFFF000)
#define XMCFG		(*(volatile unsigned long *)	0XFFFFF000)
#define XM0CON		(*(volatile unsigned long *)	0XFFFFF010)
#define XM1CON		(*(volatile unsigned long *)	0XFFFFF014)
#define XM2CON		(*(volatile unsigned long *)	0XFFFFF018)
#define XM3CON		(*(volatile unsigned long *)	0XFFFFF01C)
#define XM0PAR		(*(volatile unsigned long *)	0XFFFFF020)
#define XM1PAR		(*(volatile unsigned long *)	0XFFFFF024)
#define XM2PAR		(*(volatile unsigned long *)	0XFFFFF028)
#define XM3PAR		(*(volatile unsigned long *)	0XFFFFF02C)

/* 	DAC Registers 				*/

#define DACBASE 	(*(volatile unsigned long *) 	0XFFFF0600)
#define DAC0CON 	(*(volatile unsigned long *)	0XFFFF0600)
#define DAC0DAT 	(*(volatile unsigned long *) 	0XFFFF0604)
#define DAC1CON 	(*(volatile unsigned long *) 	0XFFFF0608)
#define DAC1DAT 	(*(volatile unsigned long *) 	0XFFFF060C)
#define DAC2CON 	(*(volatile unsigned long *) 	0XFFFF0610)
#define DAC2DAT 	(*(volatile unsigned long *) 	0XFFFF0614)
#define DAC3CON 	(*(volatile unsigned long *) 	0XFFFF0618)
#define DAC3DAT 	(*(volatile unsigned long *) 	0XFFFF061C)

/*  I2C BUS PERIPHERAL DEVICE  */

#define I2CBASE 	(*(volatile unsigned long *) 	0XFFFF0800)
#define I2CMSTA 	(*(volatile unsigned long *) 	0XFFFF0800)
#define I2CSSTA 	(*(volatile unsigned long *) 	0XFFFF0804)
#define I2CSRX 		(*(volatile unsigned long *) 	0XFFFF0808)
#define I2CSTX 		(*(volatile unsigned long *) 	0XFFFF080C)
#define I2CMRX 		(*(volatile unsigned long *) 	0XFFFF0810)
#define I2CMTX 		(*(volatile unsigned long *) 	0XFFFF0814)
#define I2CCNT 		(*(volatile unsigned long *) 	0XFFFF0818)
#define I2CADR 		(*(volatile unsigned long *) 	0XFFFF081C)
#define I2CBYTE 	(*(volatile unsigned long *) 	0XFFFF0824)
#define I2CALT 		(*(volatile unsigned long *) 	0XFFFF0828)
#define I2CCFG 		(*(volatile unsigned long *) 	0XFFFF082C)
#define I2CDIV	 	(*(volatile unsigned short *) 	0XFFFF0830)
#define I2CDIVL	 	(*(volatile unsigned char *) 	0XFFFF0830)
#define I2CDIVH	 	(*(volatile unsigned char *) 	0XFFFF0831)
#define I2CID0 		(*(volatile unsigned long *) 	0XFFFF0838)
#define I2CID1 		(*(volatile unsigned long *) 	0XFFFF083C)
#define I2CID2 		(*(volatile unsigned long *) 	0XFFFF0840)
#define I2CID3 		(*(volatile unsigned long *) 	0XFFFF0844)
#define I2CCCNT 	(*(volatile unsigned long *) 	0XFFFF0848)
#define I2CFSTA 	(*(volatile unsigned long *) 	0XFFFF084C)

/*  I2C BUS PERIPHERAL DEVICE 1 */

#define I2C0BASE 	(*(volatile unsigned long *) 	0XFFFF0800)
#define I2C0MSTA 	(*(volatile unsigned long *) 	0XFFFF0800)
#define I2C0SSTA 	(*(volatile unsigned long *) 	0XFFFF0804)
#define I2C0SRX 	(*(volatile unsigned long *) 	0XFFFF0808)
#define I2C0STX 	(*(volatile unsigned long *) 	0XFFFF080C)
#define I2C0MRX 	(*(volatile unsigned long *) 	0XFFFF0810)
#define I2C0MTX 	(*(volatile unsigned long *) 	0XFFFF0814)
#define I2C0CNT 	(*(volatile unsigned long *) 	0XFFFF0818)
#define I2C0ADR 	(*(volatile unsigned long *) 	0XFFFF081C)
#define I2C0BYTE 	(*(volatile unsigned long *) 	0XFFFF0824)
#define I2C0ALT 	(*(volatile unsigned long *)	0XFFFF0828)
#define I2C0CFG 	(*(volatile unsigned long *) 	0XFFFF082C)
#define I2C0DIV	 	(*(volatile unsigned short *) 	0XFFFF0830)
#define I2C0DIVL 	(*(volatile unsigned char *) 	0XFFFF0830)
#define I2C0DIVH 	(*(volatile unsigned char *) 	0XFFFF0831)
#define I2C0ID0 	(*(volatile unsigned long *) 	0XFFFF0838)
#define I2C0ID1 	(*(volatile unsigned long *) 	0XFFFF083C)
#define I2C0ID2 	(*(volatile unsigned long *) 	0XFFFF0840)
#define I2C0ID3 	(*(volatile unsigned long *) 	0XFFFF0844)
#define I2C0CCNT 	(*(volatile unsigned long *) 	0XFFFF0848)
#define I2C0FSTA 	(*(volatile unsigned long *) 	0XFFFF084C)

/*  I2C BUS PERIPHERAL DEVICE 2 */

#define I2C1BASE 	(*(volatile unsigned long *) 	0XFFFF0900)
#define I2C1MSTA 	(*(volatile unsigned long *) 	0XFFFF0900)
#define I2C1SSTA 	(*(volatile unsigned long *) 	0XFFFF0904)
#define I2C1SRX 	(*(volatile unsigned long *)	0XFFFF0908)
#define I2C1STX 	(*(volatile unsigned long *) 	0XFFFF090C)
#define I2C1MRX 	(*(volatile unsigned long *) 	0XFFFF0910)
#define I2C1MTX 	(*(volatile unsigned long *) 	0XFFFF0914)
#define I2C1CNT 	(*(volatile unsigned long *) 	0XFFFF0918)
#define I2C1ADR 	(*(volatile unsigned long *) 	0XFFFF091C)
#define I2C1BYTE 	(*(volatile unsigned long *) 	0XFFFF0924)
#define I2C1ALT 	(*(volatile unsigned long *) 	0XFFFF0928)
#define I2C1CFG 	(*(volatile unsigned long *) 	0XFFFF092C)
#define I2C1DIV	 	(*(volatile unsigned short *) 	0XFFFF0930)
#define I2C1DIVL 	(*(volatile unsigned char *) 	0XFFFF0930)
#define I2C1DIVH 	(*(volatile unsigned char *) 	0XFFFF0931)
#define I2C1ID0 	(*(volatile unsigned long *) 	0XFFFF0938)
#define I2C1ID1 	(*(volatile unsigned long *) 	0XFFFF093C)
#define I2C1ID2 	(*(volatile unsigned long *) 	0XFFFF0940)
#define I2C1ID3 	(*(volatile unsigned long *) 	0XFFFF0944)
#define I2C1CCNT 	(*(volatile unsigned long *) 	0XFFFF0948)
#define I2C1FSTA 	(*(volatile unsigned long *) 	0XFFFF094C)

/*  SERIAL PORT INTERFACE PERIPHERAL  */

#define SPIBASE 	(*(volatile unsigned long *) 	0XFFFF0A00)
#define SPISTA  	(*(volatile unsigned long *) 	0XFFFF0A00)
#define SPIRX 		(*(volatile unsigned long *) 	0XFFFF0A04)
#define SPITX 		(*(volatile unsigned long *) 	0XFFFF0A08)
#define SPIDIV 		(*(volatile unsigned long *) 	0XFFFF0A0C)
#define SPICON 		(*(volatile unsigned long *) 	0XFFFF0A10)

/*  450 COMPATIABLE UART CORE REGISTERS */

#define UARTBASE 	(*(volatile unsigned long *) 	0XFFFF0700)
#define COMTX 	 	(*(volatile unsigned long *) 	0XFFFF0700)
#define COMRX 	 	(*(volatile unsigned long *) 	0XFFFF0700)
#define COMDIV0  	(*(volatile unsigned long *) 	0XFFFF0700)
#define COMIEN0  	(*(volatile unsigned long *) 	0XFFFF0704)
#define COMDIV1  	(*(volatile unsigned long *) 	0XFFFF0704)
#define COMIID0  	(*(volatile unsigned long *) 	0XFFFF0708)
#define COMCON0  	(*(volatile unsigned long *) 	0XFFFF070C)
#define COMCON1  	(*(volatile unsigned long *) 	0XFFFF0710)
#define COMSTA0  	(*(volatile unsigned long *) 	0XFFFF0714)
#define COMSTA1  	(*(volatile unsigned long *) 	0XFFFF0718)
#define COMSCR   	(*(volatile unsigned long *) 	0XFFFF071C)
#define COMIEN1  	(*(volatile unsigned long *) 	0XFFFF0720)
#define COMIID1  	(*(volatile unsigned long *) 	0XFFFF0724)
#define COMADR 	 	(*(volatile unsigned long *) 	0XFFFF0728)
#define COMDIV2  	(*(volatile unsigned long *) 	0XFFFF072C)

/*  PROGRAMABLE LOGIC ARRAY   */

#define PLABASE 	(*(volatile unsigned long *) 	0XFFFF0B00)
#define PLAELM0 	(*(volatile unsigned long *) 	0XFFFF0B00)
#define PLAELM1 	(*(volatile unsigned long *) 	0XFFFF0B04)
#define PLAELM2 	(*(volatile unsigned long *) 	0XFFFF0B08)
#define PLAELM3 	(*(volatile unsigned long *) 	0XFFFF0B0C)
#define PLAELM4 	(*(volatile unsigned long *)	0XFFFF0B10)
#define PLAELM5 	(*(volatile unsigned long *) 	0XFFFF0B14)
#define PLAELM6 	(*(volatile unsigned long *) 	0XFFFF0B18)
#define PLAELM7 	(*(volatile unsigned long *) 	0XFFFF0B1C)
#define PLAELM8 	(*(volatile unsigned long *) 	0XFFFF0B20)
#define PLAELM9 	(*(volatile unsigned long *) 	0XFFFF0B24)
#define PLAELM10 	(*(volatile unsigned long *) 	0XFFFF0B28)
#define PLAELM11 	(*(volatile unsigned long *) 	0XFFFF0B2C)
#define PLAELM12 	(*(volatile unsigned long *) 	0XFFFF0B30)
#define PLAELM13 	(*(volatile unsigned long *) 	0XFFFF0B34)
#define PLAELM14 	(*(volatile unsigned long *) 	0XFFFF0B38)
#define PLAELM15 	(*(volatile unsigned long *) 	0XFFFF0B3C)
#define PLACLK 		(*(volatile unsigned long *) 	0XFFFF0B40)
#define PLAIRQ 		(*(volatile unsigned long *) 	0XFFFF0B44)
#define PLAADC 		(*(volatile unsigned long *) 	0XFFFF0B48)
#define PLADIN 		(*(volatile unsigned long *) 	0XFFFF0B4C)
#define PLADOUT 	(*(volatile unsigned long *) 	0XFFFF0B50)
#define PLALCK	 	(*(volatile unsigned long *) 	0XFFFF0B54)

/*  FLASH CONTROL INTERFACE   */

#define READ_HALF_WORD 			0x00000001
#define WRITE_HALF_WORD			0x00000002
#define ERASE_WRITE 			0x00000003
#define VERIFY_HALF_WORD		0x00000004
#define ERASE_PAGE			    0x00000005
#define MASS_ERASE 			    0x00000006
#define READ_BURST 			    0x00000007
#define WRITE_BURST 			0x00000008
#define ERASE_BURST_WRITE		0x00000009
#define USR_SIGN 			    0x0000000B
#define FEE_PROT 			    0x0000000C
#define PING 			        0x0000000F

#define FLASHBASE 	(*(volatile unsigned long *) 	0XFFFFF800)
#define FEESTA 		(*(volatile unsigned long *) 	0XFFFFF800)
#define FEEMOD 		(*(volatile unsigned long *)	0XFFFFF804)
#define FEECON 		(*(volatile unsigned long *) 	0XFFFFF808)
#define FEEDAT 		(*(volatile unsigned long *) 	0XFFFFF80C)
#define FEEADR 		(*(volatile unsigned long *) 	0XFFFFF810)
#define FEESIGN 	(*(volatile unsigned long *) 	0XFFFFF818)
#define FEEPRO 		(*(volatile unsigned long *) 	0XFFFFF81C)
#define FEEHIDE 	(*(volatile unsigned long *) 	0XFFFFF820)

/*  TIMER 0    */

#define T0BASE 		(*(volatile unsigned long *) 	0XFFFF0300)
#define T0LD 		(*(volatile unsigned long *)	0XFFFF0300)
#define T0VAL 		(*(volatile unsigned long *) 	0XFFFF0304)
#define T0CON 		(*(volatile unsigned long *)	0XFFFF0308)
#define T0CLRI 		(*(volatile unsigned long *) 	0XFFFF030C)

/*  GENERAL PURPOSE TIMER   */

#define T1BASE 		(*(volatile unsigned long *) 	0XFFFF0320)
#define T1LD 		(*(volatile unsigned long *) 	0XFFFF0320)
#define T1VAL 		(*(volatile unsigned long *) 	0XFFFF0324)
#define T1CON 		(*(volatile unsigned long *) 	0XFFFF0328)
#define T1CLRI 		(*(volatile unsigned long *) 	0XFFFF032C)
#define T1CAP 		(*(volatile unsigned long *) 	0XFFFF0330)

/*  WAKE UP TIMER   */

#define T2BASE 		(*(volatile unsigned long *) 	0XFFFF0340)
#define T2LD 		(*(volatile unsigned long *) 	0XFFFF0340)
#define T2VAL 		(*(volatile unsigned long *) 	0XFFFF0344)
#define T2CON 		(*(volatile unsigned long *) 	0XFFFF0348)
#define T2CLRI 		(*(volatile unsigned long *) 	0XFFFF034C)

/*  WATCHDOG TIMER    */

#define T3BASE 		(*(volatile unsigned long *) 	0XFFFF0360)
#define T3LD 		(*(volatile unsigned long *) 	0XFFFF0360)
#define T3VAL 		(*(volatile unsigned long *) 	0XFFFF0364)
#define T3CON 		(*(volatile unsigned long *) 	0XFFFF0368)
#define T3CLRI 		(*(volatile unsigned long *) 	0XFFFF036C)

/*  PWM     */

#define PWMBASE 	(*(volatile unsigned long *) 	0XFFFFFC00)
#define PWMCON 		(*(volatile unsigned long *) 	0XFFFFFC00)
#define PWMSTA	 	(*(volatile unsigned long *) 	0XFFFFFC04)
#define PWMDAT0 	(*(volatile unsigned long *) 	0XFFFFFC08)
#define PWMDAT1 	(*(volatile unsigned long *) 	0XFFFFFC0C)
#define PWMCFG 		(*(volatile unsigned long *) 	0XFFFFFC10)
#define PWMCH0 		(*(volatile unsigned long *) 	0XFFFFFC14)
#define PWMCH1 		(*(volatile unsigned long *) 	0XFFFFFC18)
#define PWMCH2 		(*(volatile unsigned long *) 	0XFFFFFC1C)
#define PWMEN 		(*(volatile unsigned long *) 	0XFFFFFC20)
#define PWMDAT2 	(*(volatile unsigned long *) 	0XFFFFFC24)

/*  INTERRUPT CONTROLLER    */

#define FIQ_SOURCE_BIT 			0x00000001
#define SWI_BIT 			    0x00000002
#define RTOS_TIMER_BIT 			0x00000004
#define GP_TIMER_BIT 			0x00000008
#define WAKEUP_TIMER_BIT 		0x00000010
#define WATCHDOG_TIMER_BIT 		0x00000020
#define FLASHCON_BIT 			0x00000040
#define ADC_BIT 			    0x00000080
#define PLL_LOCK_BIT 			0x00000100
#define SM_SLAVE_BIT 			0x00000200
#define SM_MASTER0_BIT 			0x00000400
#define SM_MASTER1_BIT 			0x00000800
#define SPI_SLAVE_BIT 			0x00001000
#define SPI_MASTER_BIT 			0x00002000
#define UART_BIT 			    0x00004000
#define XIRQ0_BIT 			    0x00008000
#define MONITOR_BIT 			0x00010000
#define PSM_BIT 			    0x00020000
#define XIRQ1_BIT 			    0x00040000
#define PLA_IRQ0_BIT 			0x00080000
#define PLA_IRQ1_BIT 			0x00100000
#define SPM4_IO_BIT 			0x00200000
#define SPM5_IO_BIT 			0x00400000
#define PWM_BIT 			    0x00800000

/******************************************************************************/
/*               PERIPHERAL ID DEFINITIONS FOR ADUC7026                       */
/******************************************************************************/
#define ADI_ID_FIQ 				 0
#define ADI_ID_SWI 			     1
#define ADI_ID_RTOS_TIMER 		 2
#define ADI_ID_GP_TIMER			 3
#define ADI_ID_WAKEUP_TIME		 4
#define ADI_ID_WATCHDOG_TIMER    5
#define ADI_ID_FLASHCON 		 6
#define ADI_ID_ADC 			     7
#define ADI_ID_PLL				 8
#define ADI_ID_SM_SLAVE 		 9
#define ADI_ID_SM_MASTER0	    10
#define ADI_ID_SM_MASTER1 		11
#define ADI_ID_SPI_SLAVE		12
#define ADI_ID_SPI_MASTER 		13
#define ADI_ID_UART				14
#define ADI_ID_XIRQ0 		    15
#define ADI_ID_MONITOR 			16
#define ADI_ID_PSM 			    17
#define ADI_ID_XIRQ1		    18
#define ADI_ID_PLA_IRQ0 		19
#define ADI_ID_PLA_IRQ1			20
#define ADI_ID_SPM4_IO			21
#define ADI_ID_SPM5_IO 			22
#define ADI_ID_PWM 			    23


#define IRQBASE 	(*(volatile unsigned long *) 0XFFFF0000)
#define IRQSTA 		(*(volatile unsigned long *) 0XFFFF0000)
#define IRQSIG 		(*(volatile unsigned long *) 0XFFFF0004)
#define IRQEN 		(*(volatile unsigned long *) 0XFFFF0008)
#define IRQCLR 		(*(volatile unsigned long *) 0XFFFF000C)
#define SWICFG 		(*(volatile unsigned long *) 0XFFFF0010)
#define FIQSTA 		(*(volatile unsigned long *) 0XFFFF0100)
#define FIQSIG 		(*(volatile unsigned long *) 0XFFFF0104)
#define FIQEN 		(*(volatile unsigned long *) 0XFFFF0108)
#define FIQCLR 		(*(volatile unsigned long *) 0XFFFF010C)

/*  GPIO AND SERIAL PORT MUX */

#define GPIOBASE 	(*(volatile unsigned long *) 	0XFFFFF400)
#define GP0CON 		(*(volatile unsigned long *) 	0XFFFFF400)
#define GP1CON 		(*(volatile unsigned long *) 	0XFFFFF404)
#define GP2CON 		(*(volatile unsigned long *) 	0XFFFFF408)
#define GP3CON 		(*(volatile unsigned long *) 	0XFFFFF40C)
#define GP4CON 		(*(volatile unsigned long *) 	0XFFFFF410)
#define GP0DAT 		(*(volatile unsigned long *) 	0XFFFFF420)
#define GP0SET 		(*(volatile unsigned long *) 	0XFFFFF424)
#define GP0CLR 		(*(volatile unsigned long *) 	0XFFFFF428)
#define GP0PAR 		(*(volatile unsigned long *) 	0XFFFFF42C)
#define GP1DAT 		(*(volatile unsigned long *) 	0XFFFFF430)
#define GP1SET 		(*(volatile unsigned long *) 	0XFFFFF434)
#define GP1CLR 		(*(volatile unsigned long *) 	0XFFFFF438)
#define GP1PAR 		(*(volatile unsigned long *) 	0XFFFFF43C)
#define GP2DAT 		(*(volatile unsigned long *) 	0XFFFFF440)
#define GP2SET 		(*(volatile unsigned long *) 	0XFFFFF444)
#define GP2CLR 		(*(volatile unsigned long *) 	0XFFFFF448)
#define GP3DAT 		(*(volatile unsigned long *) 	0XFFFFF450)
#define GP3SET 		(*(volatile unsigned long *) 	0XFFFFF454)
#define GP3CLR 		(*(volatile unsigned long *) 	0XFFFFF458)
#define GP3PAR 		(*(volatile unsigned long *) 	0XFFFFF45C)
#define GP4DAT 		(*(volatile unsigned long *) 	0XFFFFF460)
#define GP4SET 		(*(volatile unsigned long *) 	0XFFFFF464)
#define GP4CLR 		(*(volatile unsigned long *) 	0XFFFFF468)

/*****************************/
/* CPU Mode                  */
/*****************************/
#define USERMODE			0x10
#define FIQMODE				0x11
#define IRQMODE				0x12
#define SVCMODE				0x13
#define ABORTMODE			0x17
#define UNDEFMODE			0x1b
#define MODEMASK			0x1f
#define NOINT				0xc0

#ifdef __cplusplus
}
#endif

#endif



