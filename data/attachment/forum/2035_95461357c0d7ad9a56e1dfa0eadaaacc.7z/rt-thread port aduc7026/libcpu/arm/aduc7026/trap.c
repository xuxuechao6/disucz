/*
 * File      : trap.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2006, RT-Thread Development Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://openlab.rt-thread.com/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2006-08-25     Bernard      first version
 */

#include <rtthread.h>
#include <rthw.h>

#include "aduc7026.h"

#define MAX_HANDLERS	24
#define RTOS_TIMER0_INT
extern rt_uint32_t VECTOR_TAB[MAX_HANDLERS];
/**
 * @addtogroup aduc7026
 */
/*@{*/

void rt_hw_trap_irq()
{
	//aduc7026û�������ж�ֻ��ʹ�ñ�׼��ѯ��ʽ
	unsigned int irqsta_flag,vector;
    rt_isr_handler_t hander;
	irqsta_flag = IRQSTA & 0xfe;
#ifdef SWI_INT
   	if((irqsta_flag &  SWI_BIT)){
        hander = (rt_isr_handler_t) VECTOR_TAB[1];
        vector = 1;
        (*hander)(vector);
		irqsta_flag = 0;
	}
#endif
#ifdef RTOS_TIMER0_INT       	
    if((irqsta_flag & RTOS_TIMER_BIT)){
        hander = (rt_isr_handler_t) VECTOR_TAB[2];
        vector = 2;
        (*hander)(vector);
		irqsta_flag = 0;
	}
#endif
#ifdef GP_TIMER1_INT
    if((irqsta_flag & GP_TIMER_BIT)){
        hander = (rt_isr_handler_t) VECTOR_TAB[3];
        vector = 2;
        (*hander)(vector);
		irqsta_flag = 0;
    }
#endif
#ifdef WAKEUP_TIMER2_INT
    if((irqsta_flag & WAKEUP_TIMER_BIT)){
        hander = (rt_isr_handler_t) VECTOR_TAB[4];
        vector = 2;
        (*hander)(vector);
		irqsta_flag = 0;
    }
#endif
#ifdef WATCHDOG_TIMER3_INT
	if((irqsta_flag & WATCHDOG_TIMER_BIT )){
        hander = (rt_isr_handler_t) VECTOR_TAB[5];
        vector = 2;
        (*hander)(vector);
		irqsta_flag = 0;
    }
#endif
#ifdef	FLASHCON_INT 
	if((irqsta_flag & FLASHCON_BIT )){
        hander = (rt_isr_handler_t) VECTOR_TAB[6];
        vector = 2;
        (*hander)(vector);
		irqsta_flag = 0;
    }				
#endif
#ifdef ADC_INT
	if((irqsta_flag & ADC_BIT )){
        hander = (rt_isr_handler_t) VECTOR_TAB[8];
        vector = 2;
        (*hander)(vector);
		irqsta_flag = 0;
    }
#endif
#ifdef PLL_LOCK_BIT
	if((irqsta_flag & PLL_LOCK_BIT )){
        hander = (rt_isr_handler_t) VECTOR_TAB[9];
        vector = 2;
        (*hander)(vector);
		irqsta_flag = 0;
    }
#endif
#ifdef SM_SLAVE_INT
	if((irqsta_flag & SM_SLAVE_BIT )){
        hander = (rt_isr_handler_t) VECTOR_TAB[10];
        vector = 2;
        (*hander)(vector);
		irqsta_flag = 0;
    }
#endif
#ifdef SM_MASTER0_INT
	if((irqsta_flag & SM_MASTER0_BIT )){
        hander = (rt_isr_handler_t) VECTOR_TAB[11];
        vector = 2;
        (*hander)(vector);
		irqsta_flag = 0;
    }
#endif
#ifdef SM_MASTER1_INT
	if((irqsta_flag & SM_MASTER1_BIT )){
        hander = (rt_isr_handler_t) VECTOR_TAB[12];
        vector = 2;
        (*hander)(vector);
		irqsta_flag = 0;
    }
#endif
}

void rt_hw_trap_fiq()
{
    rt_kprintf("fast interrupt request\n");

}

/*@}*/
