//*****************************************************************************
//
// luminaryif.h - Prototypes for the Luminary Micro Ethernet interface.
//
//*****************************************************************************

#ifndef __LUMINARYIF_H__
#define __LUMINARYIF_H__

int rt_hw_luminaryif_init(void);

#endif // __LUMINARYIF_H__
