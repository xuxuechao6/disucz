#ifndef __DM9000_H__
#define __DM9000_H__

void rt_hw_dm9000_init(void);

#endif
