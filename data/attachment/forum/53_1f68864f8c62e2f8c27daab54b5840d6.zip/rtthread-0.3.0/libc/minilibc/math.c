#include <math.h>

/* Fix me */
double sin(double x) 
{
	#warning sin function not supported for this platform
}

double cos(double x) 
{
	#warning cos function not supported for this platform
}
