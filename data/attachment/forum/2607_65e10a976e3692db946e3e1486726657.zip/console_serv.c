/*
*	Remote Console Server for RT-Thread
*	Author: JoyChen
*/
#include <rtthread.h>
#include <lwip/sockets.h>
#include <stdint.h>

#define CONSOLE_PORT 2266
#define MAX_BUF_SIZE 256
#define PWD "1234"
#define INPUT_PWD_MSG "Input password: "
#define PWD_FAIL_MSG "Password worng!!\r\nBYE!\r\n"
#define PWD_OK_MSG "Password correct\r\n"
#define CLI_REJECT_MSG "Some user bind server!\r\n"
#define WELCOME_MSG "===Weclome remote console===\r\n"

#define NEW_CLIENT 1

static struct rt_device con_dev;
static rt_sem_t cons_sem;

static int cliFD = -1;
static uint8_t netRX_Buf[MAX_BUF_SIZE];
static int32_t read_ptr = 0;
static int32_t write_ptr = 0;


void console_server(void *args)
{
#ifdef RT_USING_LWIP
	uint8_t buf[MAX_BUF_SIZE];
	uint32_t servfd, connfd, clilen;

	typedef struct sockaddr SA;
	typedef struct sockaddr_in SA_in;

	SA_in cliaddr, servaddr;
	if( (servfd = socket(AF_INET,SOCK_STREAM,0)) < 0 )
		return;

	servaddr.sin_family = AF_INET;
	servaddr.sin_port =  htons(CONSOLE_PORT);
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);

	rt_memset(&(servaddr.sin_zero),8, sizeof(servaddr.sin_zero));

	bind( servfd, (SA*)&servaddr, sizeof( servaddr ) );
	listen( servfd,5 );
	//rt_kprintf("console server\n");
	while( (connfd = accept( servfd, (SA*)&cliaddr, &clilen)) >= 0)
  	{
		//rt_kprintf("Accept client %d\n",connfd);
		send(connfd, WELCOME_MSG, strlen(WELCOME_MSG),0);
		if( cliFD > 0 ) //Anther client not yet release
		{
			send(connfd, CLI_REJECT_MSG, strlen(CLI_REJECT_MSG),0);
			lwip_close(connfd);
		}
		else
		{
			//check password
			
			 send(connfd, INPUT_PWD_MSG, strlen(INPUT_PWD_MSG),0);
			 rt_memset(buf, 0, MAX_BUF_SIZE);
			 recv( connfd, buf, strlen(PWD), 0 );

			 if( strncmp( buf, PWD, sizeof(PWD) ) == 0 )
			 {
			 	send(connfd, PWD_OK_MSG, strlen(PWD_OK_MSG),0);
			 	cliFD = connfd;

				while(1)
				{
					int32_t cnt;
					rt_device_t device = RT_NULL;
					device = rt_device_find("netConsole");
					RT_ASSERT(device != RT_NULL);

					if( write_ptr < MAX_BUF_SIZE )
					{
						cnt = recv(	cliFD, (void*)&netRX_Buf[write_ptr], MAX_BUF_SIZE - write_ptr, 0 );	 
						if( cnt > 0 )
						{
							write_ptr += cnt;
							device->rx_indicate(device, cnt);
						}
						else
						{
							lwip_close(cliFD);
							cliFD = -1;	
							break;
						}
					}
					else
						rt_thread_delay(50);
						
				}
			 }
			 else
			 {
			 	send(connfd, PWD_FAIL_MSG, strlen(PWD_FAIL_MSG),0);
				lwip_close(connfd);
			 }

		}

	}
#endif
}

static rt_err_t netConsole_init (rt_device_t dev)
{
	return RT_EOK;
}
static rt_size_t netConsole_read( rt_device_t dev, rt_off_t pos, void *buf, rt_size_t size )
{
	uint32_t ev, i;
	int32_t read_cnt = 0;
	uint8_t *ptr = (uint8_t*)buf;

	int tmp = 0;

	for( i = read_ptr; i < write_ptr && size > 0; i++ )
	{
		ptr[read_cnt] = netRX_Buf[i];
		//rt_kprintf("read byte %X at %d\r\n", ptr[i], i);
		read_cnt++;
		tmp++;
		size--;
	}

	read_ptr += tmp;

	//rt_kprintf("size = %d, read = %d write = %d\n", size, read_ptr, write_ptr);
	if( read_ptr == write_ptr && write_ptr == MAX_BUF_SIZE )
	{
		read_ptr = 0;
		write_ptr = 0;
	}
	return read_cnt;


}

static rt_size_t netConsole_write( rt_device_t dev, rt_off_t pos, const void *buf, rt_size_t size )
{
	uint32_t newline = pos, i = pos;
	if( cliFD < 0 ) 
		return 0;
	else
	{ 
		int32_t ret;
		uint8_t *ptr = (uint8_t*)buf;

		rt_sem_take(cons_sem, RT_WAITING_FOREVER );
		while( i < size )
		{
			for( ; i < size; i++ )
				if( ptr[i] == '\n' ) break;
			ret = send(	cliFD, (void*)&ptr[newline], i - newline, 0 );
			if( ret < 0 ) goto write_err;
			if( i < size )
			{
				ret = send( cliFD, "\r\n", 2, 0 );
				if( ret < 0 ) goto write_err;
			}
			i++;
			newline = i;
		}
		rt_sem_release(cons_sem);
		return ret;
	}

write_err:
	lwip_close(cliFD);
	cliFD = -1;
	rt_sem_release(cons_sem);
	return i - pos;
}

static rt_err_t netConsole_open(rt_device_t dev, rt_uint16_t oflag)
{
	return RT_EOK;
}

static rt_err_t netConsole_close(rt_device_t dev)
{
	if( cliFD >= 0 )
	lwip_close( cliFD );	

	return RT_EOK;
}

static rt_err_t netConsole_control (rt_device_t dev, rt_uint8_t cmd, void *args)
{
	return RT_EOK;
}
void netConsole_hw_init()
{ 
    uint32_t delay, i;

	rt_thread_t thread;

	cons_sem = rt_sem_create("cons_sem", 1, RT_IPC_FLAG_FIFO);
	thread = rt_thread_create("Console Serv", console_server, RT_NULL,2048, 10, 50 );

    if( thread != RT_NULL )
	{
        rt_thread_startup(thread);
	}

    con_dev.init 	= netConsole_init;
    con_dev.open 	= netConsole_open;
    con_dev.close	= netConsole_close;
    con_dev.read 	= netConsole_read;
    con_dev.write	= netConsole_write;
    con_dev.control  = netConsole_control;
    con_dev.type 	= RT_Device_Class_Char;


    rt_device_register(&con_dev, "netConsole", RT_DEVICE_FLAG_RDWR);
}

void consle_test()
{
	char ch;
	rt_device_t device = RT_NULL;
	device = rt_device_find("netConsole");

	if( device )
	{
		while (rt_device_read(device, 0, &ch, 1) == 1)
		{
			rt_kprintf("%c", ch );
			rt_device_write(device, 0, &ch, 1);
		}
	}
}

#ifdef RT_USING_FINSH
#include <finsh.h>
FINSH_FUNCTION_EXPORT(consle_test, cmd server);
#endif