/**
 * @file  cs8900a.h
 * @brief Ethernet network driver for CS8900A
 */

#ifndef __CS8900A_H__
#define __CS8900A_H__

#include "lwip/netif.h"
#include <stdbool.h>

extern err_t rt_hw_cs8900a_init(struct netif *netif);
extern void  cs8900a_poll(void);
extern bool  cs8900a_link(void);
extern bool  cs8900a_act(void);

void rt_hw_cs8900a_init(void);

#endif /* CS8900A_H */

