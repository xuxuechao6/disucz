
#include <stm32f4xx.h>
 

 
/*******************************************************************************
* Function Name  : assert_failed
* Description    : Reports the name of the source file and the source line number
*                  where the assert error has occurred.
* Input          : - file: pointer to the source file name
*                  - line: assert error line source number
* Output         : None
* Return         : None
*******************************************************************************/

#include "uart.h"
void assert_failed(u8* file, u32 line)
{
 

	while (1) ;
}

 
int main(void)
{
    uart_init();
	  debug("hello realtouch!");
	
	  return 0;
}


