/*
+------------------------------------------------------------------------------
| Project   : FAT for Device Filesystem
+------------------------------------------------------------------------------
| Copyright 2004, 2005  www.fayfayspace.org.
| All rights reserved.
|------------------------------------------------------------------------------
| File      : fatfs_def.h, the fat filesystem defines for Device FileSystem
|------------------------------------------------------------------------------
| Chang Logs:
| Date           Author       Notes
| 2003-01-12     ffxz         The first version.
| 2005-07-26     ffxz         Add support for MTD device
+------------------------------------------------------------------------------
*/

#ifndef __FATFS_DEF_H__
#define __FATFS_DEF_H__

#include <dfs_def.h>
#include <dfs_config.h>

/* Device Filesystem raw APIs */
#include <dfs_raw.h>

typedef rt_uint32_t cluster_t;
typedef rt_uint32_t  sector_t;

#define FAT_ATTR_READ_ONLY		0x01
#define FAT_ATTR_HIDDEN			0x02
#define FAT_ATTR_SYSTEM			0x04
#define FAT_ATTR_VOLUME_ID		0x08
#define FAT_ATTR_DIRECTORY		0x10
#define FAT_ATTR_ARCHIVE		0x20

#define FAT_FSINFO_FREECOUNT	488
#define FAT_FSINFO_NEXTFREE		492

#define FATDIR_NAME          0
#define FATDIR_ATTR          11
#define FATDIR_NTRES         12
#define FATDIR_CRTTIMETENTH  13
#define FATDIR_CRTTIME       14
#define FATDIR_CRTDATE       16
#define FATDIR_LSTACCDATE    18
#define FATDIR_FSTCLUSHI     20
#define FATDIR_WRTTIME       22
#define FATDIR_WRTDATE       24
#define FATDIR_FSTCLUSLO     26
#define FATDIR_FILESIZE      28

#define FATTYPE_FAT12       	0x01
#define FATTYPE_FAT16       	0x02
#define FATTYPE_FAT32       	0x04

#define DIR_ENTRY_SIZE          32
#define CLUSTERS_PER_FAT_SECTOR (SECTOR_SIZE / 4)
#define DIR_ENTRIES_PER_SECTOR  (SECTOR_SIZE / DIR_ENTRY_SIZE)

#define FAT_ATTR_LONG_NAME   0x0f

#define NAME_BYTES_PER_ENTRY    13

#define FATLONG_ORDER           0
#define FATLONG_TYPE            12
#define FATLONG_CHKSUM          13

#define first_sector_of_cluster(fatfs, cluster) \
    ( (cluster) - 2 ) * (fatfs)->bpb.bpb_secperclus + (fatfs)->first_data_sector
#define cluster_of_sector(fatfs, sector)    \
    ( ( (sector) - (fatfs)->first_data_sector ) / (fatfs)->bpb.bpb_secperclus ) + 2

#define fat_read_sectors(fatfs, start, count, buf)  rt_device_read((fatfs)->device,  \
	(start) * SECTOR_SIZE, (buf), (count) * SECTOR_SIZE)
#define fat_write_sectors(fatfs, start, count, buf) rt_device_write((fatfs)->device, \
	(start) * SECTOR_SIZE, (buf), (count) * SECTOR_SIZE)

#define FAT_CACHE_EMPTY	0x00
#define FAT_CACHE_USED	0x01
#define FAT_CACHE_DIRTY	0x02
struct fat_cache_entry
{
    sector_t sector;
	rt_uint8_t state;
};

struct fat_direntry
{
    rt_uint8_t 		name[FAT_NAME_MAX + 1];	/* name with terminal character */
    rt_uint8_t 		attr;					/* attributes */
    rt_uint8_t 		create_time_tenth;		/* millisecond creation
									 	   time stamp (0-199) */
    rt_uint16_t 	create_time;			/* creation time */
    rt_uint16_t 	create_date;			/* creation date */
    rt_uint16_t 	access_date;			/* last access date */
    rt_uint16_t 	write_time;				/* last write time */
    rt_uint16_t 	write_date;				/* last write date */

    int 		file_size;				/* file size in bytes */
    cluster_t 	first_cluster;			/* fstclusterhi<<16 + fstcluslo */

	/* private data of direntry */
	rt_uint8_t		shortname[12];			/* the raw 8.3 shortname */
    int		offset;					/* offset in standard direntry */
	rt_uint8_t		entries;				/* the count of the direntry needed */
};

struct fat_file
{
    cluster_t	first_cluster;		/* first cluster in file */
    cluster_t	last_cluster;		/* cluster of last access */
    sector_t	last_sector;		/* sector of last access */

    int		direntry;			/* direntry index from start of dir */
	rt_uint8_t		entries;			/* the count of direntries */
};

/* BIOS Parameter Block struct define */
struct fat_bpb
{
    char    bs_oemname[9];              /* OEM string, ending with \0 */
    rt_uint16_t bpb_bytspersec;             /* Bytes per sectory, typically 512 */
    rt_uint8_t  bpb_secperclus;             /* Sectors per cluster */
    rt_uint16_t bpb_rsvdseccnt;             /* Number of reserved sectors */
    rt_uint8_t  bpb_numfats;                /* Number of FAT structures, typically 2 */
    rt_uint16_t bpb_rootentcnt;             /* Number of dir entries in the root */
    rt_uint16_t bpb_totsec16;               /* Number of sectors on the volume (old 16-bit) */
    char    bpb_media;                  /* Media type (typically 0xf0 or 0xf8) */
    rt_uint16_t bpb_fatsz16;                /* Number of used sectors per FAT structure */
    rt_uint16_t bpb_secpertrk;              /* Number of sectors per track */
    rt_uint16_t bpb_numheads;               /* Number of heads */
    int  bpb_hiddsec;           		/* Hidden sectors before the volume */
    int  bpb_totsec32;          		/* Number of sectors on the volume (new 32-bit) */

    int 	last_word;                  /* 0xAA55 */

    /**** FAT12/16 specific *****/
    char    bs_drvnum;                  /* Drive number */
    char    bs_bootsig;                 /* Is 0x29 if the following 3 fields are valid */
    int  bs_volid;              		/* Volume ID */
    char 	bs_vollab[12];              /* Volume label, 11 chars plus \0 */
    char 	bs_filsystype[9];           /* File system type, 8 chars plus \0 */

    /**** FAT32 specific *****/
    int  bpb_fatsz32;
    rt_int16_t   bpb_extflags;
    rt_int16_t   bpb_fsver;
    int  bpb_rootclus;
    rt_int16_t   bpb_fsinfo;
    rt_int16_t   bpb_bkbootsec;
};

/* the struct of FAT filesystem */
struct fat_filesystem
{
    rt_device_t device;					/* device handler */

    struct fat_bpb bpb; 			/* BIOS Parameter Block */

    rt_uint8_t fat_type;				/* FAT type, FAT12, FAT16 or FAT32 */
    int fat_size;				/* FAT table size */

    rt_uint8_t root_dir_sectors;		/* the count of sectors on root directory */
    int total_sectors;			/* total sectors */

    sector_t root_dir_sector;		/* root directory's sector */
    sector_t first_data_sector;		/* first data's sector */
    sector_t start_sector;			/* start sector */

    int data_clusters;			/* data cluster number */

    int free_count;				/* last known free cluster count */
    int next_free;         		/* first cluster to start looking for free
                                     * clusters, or 0xffffffff for no hint
                                     */

    rt_uint8_t fat_cache_sector[FAT_CACHE_SIZE][SECTOR_SIZE];	/* FAT table cache sector */
    struct fat_cache_entry fat_cache[FAT_CACHE_SIZE];   	/* FAT table cache entry */

    rt_sem_t lock;
};

#endif

