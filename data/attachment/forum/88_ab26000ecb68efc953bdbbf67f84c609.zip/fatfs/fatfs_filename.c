/*
+------------------------------------------------------------------------------
| Project   : Device Filesystem
+------------------------------------------------------------------------------
| Copyright 2004, 2005  www.fayfayspace.org.
| All rights reserved.
|------------------------------------------------------------------------------
| File      : fatfs_filename.c, the file name related operations
|------------------------------------------------------------------------------
| Chang Logs:
| Date           Author       Notes
| 2005-02-26     ffxz         The first version.
+------------------------------------------------------------------------------
*/

#include "fatfs_int.h"

/*
+------------------------------------------------------------------------------
| Function    : char2dos
+------------------------------------------------------------------------------
| Description :convert and check the special character 
|
| Parameters  : 
| Returns     : 
|
+------------------------------------------------------------------------------
*/
static rt_uint8_t char2dos(rt_uint8_t c)
{
    switch(c)
    {
        case 0xe5: /* Special kanji character */
            c = 0x05;
            break;
        case 0x20:
        case 0x22:
        case 0x2a:
        case 0x2b:
        case 0x2c:
        case 0x2e:
        case 0x3a:
        case 0x3b:
        case 0x3c:
        case 0x3d:
        case 0x3e:
        case 0x3f:
        case 0x5b:
        case 0x5c:
        case 0x5d:
        case 0x7c:
            /* Illegal name */
            c = 0;
            break;

        default:
            if(c < 0x20)
            {
                /* Illegal name */
                c = 0;
            }
            break;
    }
    return c;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_make_shortname
+------------------------------------------------------------------------------
| Description : Makes short name 
|
| Parameters  : name, the source name
|               short_name, the returned short-name
|               mask, the short name number, if mask is zero, then the name is 
|                     already a short name, just copy to 'short_name'
| Returns     : if name is RT_NULL, return -1, others, return 0
|
+------------------------------------------------------------------------------
*/
int fatfs_make_shortname( char* name, char* short_name, int mask )
{
    int i, j = 0;
    rt_uint8_t *ch, c;

    if ( name == RT_NULL || name[0] == '\0' ) return -1;

	memset(short_name, 0, 11);
	if (name[0] == '.' && name[1] == '\0')
	{
		memcpy(short_name, ".          ", 11);
		return 0;
	}
	else if (name[0] == '.' && name[1] == '.' && name[2] == '\0')
	{
		memcpy(short_name, "..         ", 11);
		return 0;
	}

    if ( mask == 0 || strlen(name) < 13)
    {
		/* Name part */
        for ( i =0, j = 0; name[i] && name[i] != '.' && j < 8; i++)
        {
            c = char2dos( name[i] );
            if ( c ) short_name[j++] = toupper( c );
        }

		/* EXT part */
        while ( j < 8 ) short_name[j++] = ' ';
    }
    else if ( mask < 9 )
    {
        /* NAMENA~1.EXT */
        for ( i = 0, j = 0; j < 6; i++)
        {
            c = char2dos( name[i] );
            if ( c ) short_name[j++] = toupper( c );
        }
        short_name[j++] = '~';
        short_name[j++] = mask + '0';
    }
    else if ( mask < 99 )
    {
        /* NAMEN~99.EXT */
        for ( i = 0, j = 0; j < 5; i++)
        {
            rt_uint8_t c = char2dos( name[i] );
            if ( c ) short_name[j++] = toupper( c );
        }
        short_name[j++] = '~';
        short_name[j++] = mask/10 + '0';
        short_name[j++] = mask%10 + '0';
    }

    ch = strrchr( name, '.' );
    if ( ch != RT_NULL )
    {
        ch ++;

        for ( i = 0, j = 0; *(ch + i) && (j < 3); i++ )
        {
            c = char2dos( *(ch + i) );
            if ( c ) short_name[8 + j++] = toupper( c );
        }
        j += 8;
    }
    while ( j < 11 ) short_name[j++] = ' ';

	dfs_log(DFS_DEBUG_INFO, ("%s", short_name));
    return 0;
}

void __d_cmd_shotname_test(char* name)
{
	char shortname[12];

	fatfs_make_shortname(name, shortname, 1);
	dfs_log(DFS_DEBUG_INFO, ("%s", shortname));
}

/*
 * Update the short name
 */
int fatfs_update_shortname(struct fat_filesystem* fatfs, struct fat_file* fatfile, int size)
{
    rt_uint8_t buf[SECTOR_SIZE], *entry;
	sector_t sector;
	cluster_t cluster;
	int idx;
    int result;

	sector  = fatfile->direntry / DIR_ENTRIES_PER_SECTOR;
	cluster = cluster_of_sector(fatfs, sector);
	idx     = fatfile->direntry % DIR_ENTRIES_PER_SECTOR;

	/* the shortname is located in next sector */
	if (idx + fatfile->entries > DIR_ENTRIES_PER_SECTOR)
	{
		sector ++;
		if ((sector - 1) % fatfs->bpb.bpb_secperclus == 0)
		{
			cluster = fatfs_cluster_next(fatfs, cluster);
			sector  = first_sector_of_cluster(fatfs, cluster);

			idx		= (idx + fatfile->entries) % DIR_ENTRIES_PER_SECTOR;
		}
	}
	entry   = buf + (idx + fatfile->entries - 1)* DIR_ENTRY_SIZE;

    result = fat_read_sectors( fatfs, sector, 1, buf );
    if ( result < 0 ) return result;

	if (fatfs->device->type == RT_Device_Class_MTD)
	{
	    if (entry[FATDIR_NAME] == '\0' || 
			entry[FATDIR_NAME] == 0xff || 
			entry[FATDIR_NAME] == 0xe5) 
			return -1;
	}
	else
	{
	    if (entry[FATDIR_NAME] == '\0' || 
			entry[FATDIR_NAME] == 0xe5) 
			return -1;
	}

	SET32(&entry[FATDIR_FILESIZE], size);
	SET16(&entry[FATDIR_FSTCLUSHI], fatfile->first_cluster >> 16);
	SET16(&entry[FATDIR_FSTCLUSLO], fatfile->first_cluster & 0xffffffff);

#ifdef HAVE_RTC
    {
        rt_uint16_t date = 0, time = 0;
        fatfs_time( &date, &time, RT_NULL );
        SET16(&entry[FATDIR_WRTIME], time);
        SET16(&entry[FATDIR_WRTDATE], date);
        SET16(&entry[FATDIR_LSTACCDATE], date);
    }
#endif

    result = fat_write_sectors( fatfs, sector, 1, buf );
    if ( result < 0 ) return result;
    return 0;
}

