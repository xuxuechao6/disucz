/*
+------------------------------------------------------------------------------
| Project   : FAT for Device Filesystem
+------------------------------------------------------------------------------
| Copyright 2004, 2005  www.fayfayspace.org.
| All rights reserved.
|------------------------------------------------------------------------------
| File      : fatfs_init.c, the fat filesystem initilization for Device FileSystem
|------------------------------------------------------------------------------
| Chang Logs:
| Date           Author       Notes
| 2003-01-12     ffxz         The first version.
+------------------------------------------------------------------------------
*/

#include <dfs_fs.h>
#include "fatfs_int.h"

struct dfs_filesystem_operation fatfs;
int fatfs_init()
{
	/* init FAT filesystem operations */
	fatfs.name[0] 	= 'f';
	fatfs.name[1] 	= 'a';
	fatfs.name[2] 	= 't';
	fatfs.name[3]	= '\0';

	fatfs.mount 	= fatfs_mount;
	fatfs.unmount 	= fatfs_unmount;
	fatfs.open 		= fatfs_open;
	fatfs.close 	= fatfs_close;
	fatfs.ioctl 	= fatfs_ioctl;
	fatfs.read 		= fatfs_read;
	fatfs.write 	= fatfs_write;
	fatfs.lseek 	= fatfs_lseek;
	fatfs.getdents 	= fatfs_getdents;
	fatfs.unlink 	= fatfs_unlink;
	fatfs.stat 		= fatfs_stat;
	fatfs.rename 	= fatfs_rename;

	/* init FAT filesystem table */
	fatfs_table_init();

	/* register fatfs file system */
	dfs_register(&fatfs);

	return 0;
}

