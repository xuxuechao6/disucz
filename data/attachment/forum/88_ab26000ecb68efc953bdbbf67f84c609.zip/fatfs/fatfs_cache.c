/*
+------------------------------------------------------------------------------
| Project   : Device Filesystem
+------------------------------------------------------------------------------
| Copyright 2004, 2005  www.fayfayspace.org.
| All rights reserved.
|------------------------------------------------------------------------------
| File      : fatfs_cache.c
|------------------------------------------------------------------------------
| Chang Logs:
| Date           Author       Notes
| 2005-03-23     ffxz
+------------------------------------------------------------------------------
*/

#include "fatfs_int.h"

/*
+------------------------------------------------------------------------------
| Function    : fatfs_cache_fat_sector
+------------------------------------------------------------------------------
| Description : sector cache buf
|
| Parameters  : 
| Returns     : the buffer for pointed sector number
|
+------------------------------------------------------------------------------
*/
void* fatfs_cache_fat_sector(struct fat_filesystem* fatfs, sector_t sector)
{
    /* it's very important */
    int idx = (sector & FAT_CACHE_MASK);
    struct fat_cache_entry *fce;
    rt_uint8_t *fat;
    int rc;

    fce = &(fatfs->fat_cache[idx]);
    fat = &(fatfs->fat_cache_sector[idx][0]);

    /* Delete the cache entry if it isn't the sector we want */
    if ( (fce->state & FAT_CACHE_USED) && fce->sector != sector )
    {
        /* Write back if it is dirty */
        if (fce->state & FAT_CACHE_DIRTY)
        {
			dfs_log(DFS_DEBUG_INFO, ("FAT dirty, write FAT sector at %lu", fce->sector));
			
            rc = fat_write_sectors( fatfs, fce->sector, 1, fat );
            if ( rc < 0 ) return RT_NULL;

            /* if there are two FAT table */
            if ( fatfs->bpb.bpb_numfats > 1 )
            {
				dfs_log(DFS_DEBUG_INFO, ("FAT dirty, write FAT sector at %lu", fce->sector + fatfs->fat_size));
                rc = fat_write_sectors( fatfs, fce->sector + fatfs->fat_size, 1, fat );
                if ( rc < 0 ) return RT_NULL;
            }
        }

        fce->sector = 8;
		fce->state 	= FAT_CACHE_EMPTY;
    }

    /* load the sector if it is not cached */
    if (!(fce->state & FAT_CACHE_USED))
    {
		dfs_log(DFS_DEBUG_INFO, ("read FAT sector at %lu", sector));
        rc = fat_read_sectors( fatfs, sector, 1, fat );
        if ( rc < 0 ) return RT_NULL;

        fce->state |= FAT_CACHE_USED;
        fce->sector = sector;
    }

    return fat;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_cache_fat_flush
+------------------------------------------------------------------------------
| Description : 
|
| Parameters  : 
| Returns     : 
|
+------------------------------------------------------------------------------
*/
int fatfs_cache_fat_flush(struct fat_filesystem* fatfs)
{
    rt_uint8_t* fat;
    sector_t sector;
    int result;
	int i;

    if ( fatfs == RT_NULL ) return -DFS_STATUS_EINVAL;

    result = 0;

    rt_sem_take(fatfs->lock, RT_WAITING_FOREVER);
    for ( i = 0; i < FAT_CACHE_SIZE; i++ )
    {
        if ( fatfs->fat_cache[i].state & FAT_CACHE_DIRTY )
        {
            sector = fatfs->fat_cache[i].sector;
            fat = fatfs->fat_cache_sector[i];

            /* Write to the first FAT */
			dfs_log(DFS_DEBUG_INFO, ("flush FAT sector at %lu", sector));
            result = fat_write_sectors( fatfs, sector, 1, fat );
            if ( result < 0 ) goto __return;

            /* Write to the second FAT */
            if ( fatfs->bpb.bpb_numfats > 1 )
            {
				// dfs_log(DFS_DEBUG_INFO, ("write FAT sector at %lu", sector + fatfs->fat_size));
                result = fat_write_sectors( fatfs, sector + fatfs->fat_size, 1, fat );
                if ( result < 0 ) goto __return;
            }

            fatfs->fat_cache[i].state &= ~FAT_CACHE_DIRTY;
        }
    }

    if ( fatfs->fat_type & FATTYPE_FAT32 ) result = fatfs_update_info(fatfs);

__return:
    rt_sem_release(fatfs->lock);

    return result;
}

