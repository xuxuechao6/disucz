/*
+------------------------------------------------------------------------------
| Project   : FAT for Device Filesystem
+------------------------------------------------------------------------------
| Copyright 2004, 2005  www.fayfayspace.org.
| All rights reserved.
|------------------------------------------------------------------------------
| File      : fatfs.c, the fat filesystem implementation for Device FileSystem
|------------------------------------------------------------------------------
| Chang Logs:
| Date           Author       Notes
| 2003-01-12     ffxz         The first version.
| 2005-04-07     ffxz         Fixed the bug in fatfs_update_info()
+------------------------------------------------------------------------------
*/
#include "fatfs_int.h"

#if 0
static void fatfs_time(rt_uint16_t* date,
                      rt_uint16_t* time,
                      rt_uint16_t* tenth )
{
    struct tm * tm = time();

    if ( date )
    {
        * date = ( ( tm->tm_year - 80 ) << 9 ) |
                 ( ( tm->tm_mon + 1 ) << 5 ) |
                 tm->tm_mday;
    }

    if ( time )
    {
        * time = ( tm->tm_hour << 11 ) |
                 ( tm->tm_min << 5 ) |
                 ( tm->tm_sec >> 1 );
    }

    if ( tenth ) * tenth = ( tm->tm_sec & 1 ) * 100;
}
#endif

/*
+------------------------------------------------------------------------------
| Function    : fatfs_update_info
+------------------------------------------------------------------------------
| Description : Updates fatfs info (free count and next free in FAT32)
|
| Parameters  : 
| Returns     : 
|
+------------------------------------------------------------------------------
*/
int fatfs_update_info(struct fat_filesystem* fatfs)
{
    rt_uint8_t fsinfo[SECTOR_SIZE];
    int intptr;
    int rc;

    /* update fsinfo */
    rc = fat_read_sectors(fatfs, fatfs->bpb.bpb_fsinfo, 1, fsinfo);
    if (rc < 0) return -1;

	rc = 0;

	intptr = GET32(&fsinfo[FAT_FSINFO_FREECOUNT]);
	if ( intptr != fatfs->free_count )
	{
		SET32(&fsinfo[FAT_FSINFO_FREECOUNT], fatfs->free_count);

		/* set to modify */
		rc = 1;
	}

	intptr = GET32(&fsinfo[FAT_FSINFO_NEXTFREE]);
	if ( intptr != fatfs->next_free )
	{
		SET32(&fsinfo[FAT_FSINFO_NEXTFREE], fatfs->next_free);

		/* set to modify */
		rc = 1;
	}

	/* if modified the NextFree or FreeCount, write back to disk */
	if ( rc == 1 )
	{
	    rc = fat_write_sectors(fatfs, fatfs->bpb.bpb_fsinfo, 1, fsinfo);
	    if (rc < 0) return -1;
	}

    return 0;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_recalc_free
+------------------------------------------------------------------------------
| Description : Recalc FAT32 free count and update free count and next free info
| notes: It's called only for FAT32
| Parameters  : 
| Returns     : always return zero
|
+------------------------------------------------------------------------------
*/
int fatfs_recalc_free(struct fat_filesystem* fatfs)
{
    int i, j;
    int free = 0;

    rt_sem_take(fatfs->lock, RT_WAITING_FOREVER);
    for (i = 0; i<fatfs->fat_size; i++)
    {
        int* fat = (int*)fatfs->fat_cache_sector[i];

        for (j = 0; j < CLUSTERS_PER_FAT_SECTOR; j++)
        {
            int c = i * CLUSTERS_PER_FAT_SECTOR + j;
            if (c > fatfs->data_clusters+1) /* nr 0 is unused */
                break;

            if (!(fat[j] & 0x0fffffff))
            {
                free++;
                if (fatfs->next_free == 0xffffffff)
                    fatfs->next_free = c;
            }
        }
    }
    fatfs->free_count = free;
    if (fatfs->fat_type & FATTYPE_FAT32) fatfs_update_info(fatfs);

    rt_sem_release(fatfs->lock);

    return 0;
}

