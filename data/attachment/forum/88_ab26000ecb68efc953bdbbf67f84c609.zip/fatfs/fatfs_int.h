/*
+------------------------------------------------------------------------------
| Project   : Device Filesystem
+------------------------------------------------------------------------------
| Copyright 2004, 2005  www.fayfayspace.org.
| All rights reserved.
|------------------------------------------------------------------------------
| File      : fatfs_int.h
|------------------------------------------------------------------------------
| Chang Logs:
| Date           Author       Notes
| 2005-03-23     ffxz
+------------------------------------------------------------------------------
*/

#ifndef __FATFS_INT_H__
#define __FATFS_INT_H__

#include "fatfs_def.h"

/* FAT filesystem fat table */
cluster_t fatfs_cluster_next( struct fat_filesystem* fatfs, cluster_t cluster );
cluster_t fatfs_cluster_find_empty(struct fat_filesystem* fatfs, cluster_t start_cluster);
sector_t fatfs_cluster_allocate(struct fat_filesystem* fatfs, cluster_t old_cluster, cluster_t *new_cluster);
int fatfs_cluster_remove(struct fat_filesystem* fatfs, cluster_t cluster);

/* FAT filesystem direntry */
int fatfs_direntry_lookup(struct fat_filesystem* fatfs, 
	struct fat_direntry* direntry, 
	const char* name);
int fatfs_direntry_add(struct fat_filesystem* fatfs,
	struct fat_direntry* parent_direntry,
	struct fat_direntry* direntry);
int fatfs_direntry_add_file(struct fat_filesystem* fatfs,
		struct fat_direntry* direntry, 
		const char* name);
int fatfs_direntry_add_dir(struct fat_filesystem* fatfs,
		struct fat_direntry* direntry, 
		const char* name);
int fatfs_direntry_update(struct fat_filesystem* fatfs,
	struct fat_direntry* direntry);
int fatfs_direntry_write(struct fat_filesystem* fatfs, 
	struct fat_direntry* direntry);
int fatfs_direntry_remove(struct fat_filesystem* fatfs,
	struct fat_direntry* direntry);
int fatfs_direntry_next(struct fat_filesystem* fatfs, 
	struct fat_direntry* direntry, int idx);

/* FAT filesystem cache */
void* fatfs_cache_fat_sector(struct fat_filesystem* fatfs, sector_t sector);
int fatfs_cache_fat_flush(struct fat_filesystem* fatfs);

/* FAT filesystem filename */
int fatfs_make_shortname( char* name, char* short_name, int mask );
int fatfs_update_shortname(struct fat_filesystem* fatfs, struct fat_file* fatfile, int size);

/* FAT filesystem table init */
int fatfs_table_init();

/* FAT filesystem file operations */
int fatfs_mount(struct dfs_filesystem* fs);
int fatfs_unmount(struct dfs_filesystem* fs);
int fatfs_open(struct dfs_fd* file);
int fatfs_close(struct dfs_fd* file);
int fatfs_ioctl(struct dfs_fd* file, int cmd, void* args);
int fatfs_read(struct dfs_fd* file, void* buf, rt_size_t len);
int fatfs_write(struct dfs_fd* file, const void* buf, rt_size_t len);
int fatfs_lseek(struct dfs_fd* file, rt_off_t offset);
int fatfs_getdents(struct dfs_fd* file, struct dfs_dirent* dirp, rt_uint32_t count);
int fatfs_unlink(struct dfs_filesystem* fs, const char* path);
int fatfs_stat(struct dfs_filesystem* fs, const char *path, struct dfs_stat *st);
int fatfs_rename(struct dfs_filesystem* fs, const char* oldpath, const char* newpath);

/* FAT filesystem misc */
int fatfs_recalc_free(struct fat_filesystem* fatfs);
int fatfs_update_info(struct fat_filesystem* fatfs);

#endif
