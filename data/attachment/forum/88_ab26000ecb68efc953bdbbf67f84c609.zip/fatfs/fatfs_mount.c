/*
+------------------------------------------------------------------------------
| Project   : FAT for Device Filesystem
+------------------------------------------------------------------------------
| Copyright 2004, 2005  www.fayfayspace.org.
| All rights reserved.
|------------------------------------------------------------------------------
| File      : fatfs_mount.c, the fat filesystem mount/umount implementation
|------------------------------------------------------------------------------
| Chang Logs:
| Date           Author       Notes
| 2003-01-12     ffxz         The first version.
| 2005-07-26     ffxz         Add support for MTD device
+------------------------------------------------------------------------------
*/

#include <dfs_fs.h>

#include "fatfs_int.h"

/* ---- BPB defines ---- */
/* BPB offsets; generic */
#define BS_JMPBOOT          0
#define BS_OEMNAME          3
#define BPB_BYTSPERSEC      11
#define BPB_SECPERCLUS      13
#define BPB_RSVDSECCNT      14
#define BPB_NUMFATS         16
#define BPB_ROOTENTCNT      17
#define BPB_TOTSEC16        19
#define BPB_MEDIA           21
#define BPB_FATSZ16         22
#define BPB_SECPERTRK       24
#define BPB_NUMHEADS        26
#define BPB_HIDDSEC         28
#define BPB_TOTSEC32        32

/* fat12/16 */
#define BS_DRVNUM           36
#define BS_RESERVED1        37
#define BS_BOOTSIG          38
#define BS_VOLID            39
#define BS_VOLLAB           43
#define BS_FILSYSTYPE       54

/* fat 32 */
#define BPB_FATSZ32         36
#define BPB_EXTFLAGS        40
#define BPB_FSVER           42
#define BPB_ROOTCLUS        44
#define BPB_FSINFO          48
#define BPB_BKBOOTSEC       50
#define BS_32_DRVNUM        64
#define BS_32_BOOTSIG       66
#define BS_32_VOLID         67
#define BS_32_VOLLAB        71
#define BS_32_FILSYSTYPE    82

#define BPB_LAST_WORD       510

struct fat_filesystem fatfs_table[FATFS_MAX];
rt_sem_t fatfs_table_lock;

/*
+------------------------------------------------------------------------------
| Function    : fatfs_table_init
+------------------------------------------------------------------------------
| Description : 
|
| Parameters  : 
| Returns     : 
|
+------------------------------------------------------------------------------
*/
int fatfs_table_init()
{
	int i;

	for (i = 0; i < FATFS_MAX; i ++)
	{
		memset(&fatfs_table[i], 0, sizeof(struct fat_filesystem));
	}

	fatfs_table_lock = rt_sem_create("sem_fat", 1, RT_IPC_FLAG_FIFO); 
	return 0;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_mount
+------------------------------------------------------------------------------
| Description : 
|
| Parameters  : 
| Returns     : 
|
+------------------------------------------------------------------------------
*/
int fatfs_mount(struct dfs_filesystem* fs)
{
    rt_uint8_t buf[SECTOR_SIZE];
    struct fat_filesystem* fatfs;
    struct fat_bpb* bpb;
    int error;
	int i;

	/* allocate an emptry FAT filesystem entry from FAT table */
	rt_sem_take(fatfs_table_lock, RT_WAITING_FOREVER);
	for ( i = 0; i < FATFS_MAX; i ++)
	{
		if ( fatfs_table[i].data_clusters == 0 ) break;
	}
	rt_sem_release(fatfs_table_lock);
	if ( i == FATFS_MAX ) return -1;

	fatfs = &fatfs_table[i];

	/* init fat filesystem struct */
	fatfs->device = fs->dev_id;

	/* init cache */
	memset( fatfs->fat_cache, 0, sizeof(fatfs->fat_cache));

	/* take the lock */
	fatfs->lock = rt_sem_create("sem_fts", 1, RT_IPC_FLAG_FIFO); 

	/* read BPB */
	bpb = &(fatfs->bpb);

    error = fat_read_sectors( fatfs, 0, 1, buf );
    if ( error < 0 )
    {
		/* clean FAT filesystem entry */
		memset(fatfs, 0, sizeof(struct fat_filesystem));
        return error;
    }

    memset(bpb, 0, sizeof ( struct fat_bpb ) );
    strncpy(bpb->bs_oemname, &buf[BS_OEMNAME], 8);
    bpb->bs_oemname[8] = 0;

	bpb->bpb_bytspersec = GET16(&buf[BPB_BYTSPERSEC]);
    bpb->bpb_secperclus = buf[BPB_SECPERCLUS];
    bpb->bpb_rsvdseccnt = GET16(&buf[BPB_RSVDSECCNT]);
    bpb->bpb_numfats    = buf[BPB_NUMFATS];
    bpb->bpb_totsec16   = GET16(&buf[BPB_TOTSEC16]);
    bpb->bpb_media      = buf[BPB_MEDIA];
    bpb->bpb_fatsz16    = GET16(&buf[BPB_FATSZ16]);
    bpb->bpb_fatsz32    = GET32(&buf[BPB_FATSZ32]);
    bpb->bpb_secpertrk  = GET16(&buf[BPB_SECPERTRK]);
    bpb->bpb_numheads   = GET16(&buf[BPB_NUMHEADS]);
    bpb->bpb_hiddsec    = GET32(&buf[BPB_HIDDSEC]);
    bpb->bpb_totsec32   = GET32(&buf[BPB_TOTSEC32]);
    bpb->last_word      = GET16(&buf[BPB_LAST_WORD]);
    bpb->bpb_rootentcnt = GET16(&buf[BPB_ROOTENTCNT]);

	fatfs->fat_size = bpb->bpb_fatsz16? bpb->bpb_fatsz16 :
		bpb->bpb_fatsz32;

	fatfs->total_sectors = bpb->bpb_totsec16? bpb->bpb_totsec16 :
		bpb->bpb_totsec32;

    /* the root dir sectors always zero for FAT32 */
    fatfs->root_dir_sectors = ((bpb->bpb_rootentcnt * DIR_ENTRY_SIZE) + 
    	(bpb->bpb_bytspersec - 1)) / bpb->bpb_bytspersec;
	
    fatfs->first_data_sector = bpb->bpb_rsvdseccnt 
		+ fatfs->root_dir_sectors
		+ bpb->bpb_numfats * fatfs->fat_size;

    /* determine FAT type */
    fatfs->data_clusters = (fatfs->total_sectors - fatfs->first_data_sector) / bpb->bpb_secperclus;
    if (fatfs->data_clusters < 4085)
    {
        /* it should be FAT 12 */
        fatfs->fat_type = FATTYPE_FAT12;
        bpb->bpb_rootclus = 0;
    }
    else if (fatfs->data_clusters < 65525)
    {
        /* it should be FAT 16 */
        fatfs->fat_type = FATTYPE_FAT16;
        bpb->bpb_rootclus = 0;
    }
    else
    {
        /* it should be FAT 32 */
        fatfs->fat_type = FATTYPE_FAT32;

        /* load FAT 32 parameters */
        bpb->bpb_extflags   = GET16(&buf[BPB_EXTFLAGS]);
        bpb->bpb_fsver      = GET16(&buf[BPB_FSVER]);
        bpb->bpb_rootclus   = GET16(&buf[BPB_ROOTCLUS]);
        bpb->bpb_fsinfo     = GET16(&buf[BPB_FSINFO]);
        bpb->bpb_bkbootsec  = GET16(&buf[BPB_BKBOOTSEC]);
        bpb->bs_drvnum      = buf[BS_32_DRVNUM];
    }

    bpb->bs_bootsig      = buf[BS_32_BOOTSIG];
    if ( bpb->bs_bootsig == 0x29 )
    {
        bpb->bs_volid = GET32(&buf[BS_32_VOLID]);
        strncpy(bpb->bs_vollab, &buf[BS_32_VOLLAB], 11);
        strncpy(bpb->bs_filsystype, &buf[BS_32_FILSYSTYPE], 8);
    }

    if ( fatfs->fat_type & FATTYPE_FAT32 )
    {
        /* FAT32 */
        fatfs->root_dir_sector = first_sector_of_cluster(fatfs, bpb->bpb_rootclus);

		/* read filesystem info */
        error = fat_read_sectors( fatfs, bpb->bpb_fsinfo, 1, buf );
        if ( error < 0 )
        {
			/* clean FAT filesystem entry */
			memset(fatfs, 0, sizeof(struct fat_filesystem));
	        return error;
        }

        fatfs->free_count = GET32(&buf[FAT_FSINFO_FREECOUNT]);
        fatfs->next_free  = GET32(&buf[FAT_FSINFO_NEXTFREE]);

        /* calculate freecount if unset */
        if ( fatfs->free_count == 0xffffffff) fatfs_recalc_free(fatfs);
    }
    else
    {
        /* FAT 12/16 */
        fatfs->root_dir_sector = bpb->bpb_rsvdseccnt + 
        	(bpb->bpb_numfats * bpb->bpb_fatsz16);
    }

    fs->data = fatfs;

	dfs_log(DFS_DEBUG_INFO, ("OEM %s", fatfs->bpb.bs_oemname));
	dfs_log(DFS_DEBUG_INFO, ("Bytes per sector %d", fatfs->bpb.bpb_bytspersec));
	dfs_log(DFS_DEBUG_INFO, ("Sectors per cluster %d", fatfs->bpb.bpb_secperclus));
	dfs_log(DFS_DEBUG_INFO, ("Number of reserved sector %d", fatfs->bpb.bpb_rsvdseccnt));
	dfs_log(DFS_DEBUG_INFO, ("Number of FAT table %d", fatfs->bpb.bpb_numfats));
	dfs_log(DFS_DEBUG_INFO, ("Number of directories entry in root %d", fatfs->bpb.bpb_rootentcnt));
	dfs_log(DFS_DEBUG_INFO, ("Number of sectors per FAT %lu", fatfs->fat_size));

	dfs_log(DFS_DEBUG_INFO, ("Number of sectors in root directory %d", fatfs->root_dir_sectors));
	dfs_log(DFS_DEBUG_INFO, ("Total sectors %lu", fatfs->total_sectors));
	dfs_log(DFS_DEBUG_INFO, ("Sector of root directory %lu", fatfs->root_dir_sector));
	dfs_log(DFS_DEBUG_INFO, ("Number of data cluster %lu", fatfs->data_clusters));
	dfs_log(DFS_DEBUG_INFO, ("The first data sector %lu", fatfs->first_data_sector));
	dfs_log(DFS_DEBUG_INFO, ("FAT type: %d", fatfs->fat_type));	

    return 0;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_unmount
+------------------------------------------------------------------------------
| Description : 
|
| Parameters  : 
| Returns     : 
|
+------------------------------------------------------------------------------
*/
int fatfs_unmount(struct dfs_filesystem* fs)
{
	struct fat_filesystem* fatfs;

	fatfs = (struct fat_filesystem*) fs->data;
	if ( fatfs == RT_NULL ) return -DFS_STATUS_EINVAL;
	
	/* flush FAT table to disk */
	fatfs_cache_fat_flush(fatfs);

	/* take filesystem lock */
	rt_sem_take(fatfs->lock, RT_WAITING_FOREVER);
	/* delete filesystem lock */
	rt_sem_delete(fatfs->lock);

	/* release fat filesystem struct */
	rt_sem_take(fatfs_table_lock, RT_WAITING_FOREVER);
	memset(fatfs, 0, sizeof(struct fat_filesystem));
	rt_sem_release(fatfs_table_lock);

	fs->data = RT_NULL;

    return 0;
}

