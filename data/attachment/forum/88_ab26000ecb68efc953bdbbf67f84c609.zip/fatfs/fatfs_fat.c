/*
+------------------------------------------------------------------------------
| Project   : FAT for Device Filesystem
+------------------------------------------------------------------------------
| Copyright 2004, 2005  www.fayfayspace.org.
| All rights reserved.
|------------------------------------------------------------------------------
| File      : fatfs_fat.c, the fat table in filesystem
|------------------------------------------------------------------------------
| Chang Logs:
| Date           Author       Notes
| 2003-01-12     ffxz         The first version.
+------------------------------------------------------------------------------
*/

#include "fatfs_int.h"

/* bad cluster */
#define BADC12  0x00000ff7
#define BADC16  0x0000fff7
#define BADC32  0x0ffffff7

/* end of cluster */
#define EOC12   0x00000ff8
#define EOC16   0x0000fff8
#define EOC32   0x0ffffff8

/* max of cluster */
#define MAX12	0x00000fff
#define MAX16	0x0000ffff
#define MAX32	0xffffffff

/*
+------------------------------------------------------------------------------
| Function    : fatfs_fat12_get
+------------------------------------------------------------------------------
| Description : Gets the cluster's value in FAT12 table
|
| Parameters  : 
| Returns     : 
|
+------------------------------------------------------------------------------
*/
cluster_t fatfs_fat12_get(struct fat_filesystem* fatfs, cluster_t cluster)
{
    rt_uint8_t 	  *fat, *nfat;
	sector_t  fat_sector;
	cluster_t result, fat_offset;
    rt_uint16_t   sector_offset;

    if ( cluster == 0 ) return 0;

    fat_offset = cluster + (cluster/2);

    fat_sector = fatfs->bpb.bpb_rsvdseccnt + (fat_offset/fatfs->bpb.bpb_bytspersec);
    sector_offset = (fat_offset%fatfs->bpb.bpb_bytspersec);

    rt_sem_take(fatfs->lock, RT_WAITING_FOREVER);

    fat = fatfs_cache_fat_sector(fatfs, fat_sector);
    if ( !fat ) goto __return;

    if (sector_offset == fatfs->bpb.bpb_bytspersec - 1)
    {
        nfat = fatfs_cache_fat_sector(fatfs, fat_sector + 1);
        if ( !nfat  ) goto __return;

        result  = fat[sector_offset] | (nfat[0] << 8);
    }
    else result = fat[sector_offset] | (fat[sector_offset + 1] << 8);

    rt_sem_release(fatfs->lock);

	result = cluster & 0x0001? (result >> 4) : (result & 0x0fff);

	/* add support of MTD device */
	if (result == MAX12 && fatfs->device->type == RT_Device_Class_MTD) result = 0;

    return result;

__return:
    rt_sem_release(fatfs->lock);
    return -1;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_fat12_update
+------------------------------------------------------------------------------
| Description : Updates the cluster chain in FAT12
|
| Parameters  : 
| Returns     : 
|
+------------------------------------------------------------------------------
*/
int fatfs_fat12_update(struct fat_filesystem* fatfs, cluster_t entry, 
	cluster_t value)
{
    rt_uint8_t    *fat, *nfat;
	sector_t  fat_sector;
	cluster_t fat_offset;
    rt_uint16_t   sector_offset;

	nfat = fat = RT_NULL;

    if ( entry == value ) return -1;
    if ( entry < 2 ) return -1;

    rt_sem_take( fatfs->lock, RT_WAITING_FOREVER );
	if ( fatfs->fat_type & FATTYPE_FAT12 )
	{
        fat_offset = entry + entry /2;

        fat_sector = fatfs->bpb.bpb_rsvdseccnt + (fat_offset/fatfs->bpb.bpb_bytspersec);
        sector_offset = (fat_offset % fatfs->bpb.bpb_bytspersec);

		/* get FAT sector */
        fat = fatfs_cache_fat_sector(fatfs, fat_sector);
        if ( !fat ) goto __return;

        if (sector_offset == fatfs->bpb.bpb_bytspersec - 1)
        {
			/* get next FAT sector */
            nfat = fatfs_cache_fat_sector(fatfs, fat_sector + 1);
            if ( !nfat  ) goto __return;
        }
		
		if (entry & 0x1)
		{
			/* the first 4bits */
			fat[sector_offset] = (fat[sector_offset] & 0x0f) | ((value & 0x0f) << 4);

			/* the last 8bits */
			if (sector_offset == fatfs->bpb.bpb_bytspersec - 1)
			{
				nfat[0] = (value & 0x0ff0) >> 4;

				/* mark the next FAT sector as dirty */
				fatfs->fat_cache[(fat_sector + 1) & (FAT_CACHE_MASK)].state |= FAT_CACHE_DIRTY;
			}
			else
			{
				fat[sector_offset + 1] = (value & 0x0ff0) >> 4;
			}
		}
		else
		{
			/* the first 8bits */
			fat[sector_offset] = (value & 0xff);

			/* the last 4bits */
			if (sector_offset == fatfs->bpb.bpb_bytspersec -1)
			{
				nfat[0] = ((value & 0xf00) >> 8) | (nfat[0] & 0xf0);
				
				/* mark the next FAT sector as dirty */
				fatfs->fat_cache[(fat_sector + 1) & (FAT_CACHE_MASK)].state |= FAT_CACHE_DIRTY;
			}
			else
			{
				fat[sector_offset + 1] = ((value & 0xf00) >> 8) | (fat[sector_offset + 1] & 0xf0);
			}
		}

		fatfs->fat_cache[fat_sector & (FAT_CACHE_MASK)].state |= FAT_CACHE_DIRTY;
	}
    rt_sem_release(fatfs->lock);

    return 0;

__return:
    rt_sem_release(fatfs->lock);
    return -1;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_fat16_get
+------------------------------------------------------------------------------
| Description : Gets the cluster's value in FAT16 table
|
| Parameters  : 
| Returns     : 
|
+------------------------------------------------------------------------------
*/
cluster_t fatfs_fat16_get(struct fat_filesystem* fatfs, cluster_t cluster)
{
    rt_uint8_t *fat;
	sector_t  fat_sector;
	cluster_t result, fat_offset;
    rt_uint16_t   sector_offset;

    if ( cluster == 0 ) return 0;

    fat_offset = cluster * 2;

    fat_sector = fatfs->bpb.bpb_rsvdseccnt + (fat_offset/fatfs->bpb.bpb_bytspersec);
    sector_offset = (fat_offset%fatfs->bpb.bpb_bytspersec);

    rt_sem_take( fatfs->lock, RT_WAITING_FOREVER );
    fat = fatfs_cache_fat_sector(fatfs, fat_sector);
    if ( !fat )
    {
        rt_sem_release( fatfs->lock );
        return -1;
    }
	result = GET16(&fat[sector_offset]);
    rt_sem_release( fatfs->lock );

	/* add support of MTD device */
	if (result == MAX16 && fatfs->device->type == RT_Device_Class_MTD) result = 0;

    return result;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_fat16_update
+------------------------------------------------------------------------------
| Description : Updates the cluster chain in FAT16
|
| Parameters  : 
| Returns     : 
|
+------------------------------------------------------------------------------
*/
int fatfs_fat16_update(struct fat_filesystem* fatfs, cluster_t entry, 
	cluster_t value)
{
    rt_uint8_t *fat;
	sector_t  fat_sector;
	cluster_t fat_offset;
    rt_uint16_t   sector_offset;

    if ( entry == value ) return -1;
    if ( entry < 2 ) return -1;

    rt_sem_take( fatfs->lock, RT_WAITING_FOREVER );
	if ( fatfs->fat_type & FATTYPE_FAT16 )
	{
        fat_offset = entry * 2;

        fat_sector = fatfs->bpb.bpb_rsvdseccnt + (fat_offset/fatfs->bpb.bpb_bytspersec);
        sector_offset = (fat_offset%fatfs->bpb.bpb_bytspersec);

        fat = fatfs_cache_fat_sector(fatfs, fat_sector);
        if ( !fat ) goto __return;

		SET16(&fat[sector_offset], value & 0xffff);
		
        fatfs->fat_cache[fat_sector & (FAT_CACHE_MASK) ].state |= FAT_CACHE_DIRTY;
	}
    rt_sem_release(fatfs->lock);
    return 0;

__return:
    rt_sem_release(fatfs->lock);
    return -1;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_fat32_get
+------------------------------------------------------------------------------
| Description : Gets the cluster's value in FAT32 table
|
| Parameters  : 
| Returns     : 
|
+------------------------------------------------------------------------------
*/
cluster_t fatfs_fat32_get(struct fat_filesystem* fatfs, cluster_t cluster)
{
    rt_uint8_t *fat;
	sector_t  fat_sector;
	cluster_t result, fat_offset;
    rt_uint16_t   sector_offset;

    if ( cluster == 0 ) return 0;

    fat_offset = cluster * 4;

    fat_sector = fatfs->bpb.bpb_rsvdseccnt + (fat_offset/fatfs->bpb.bpb_bytspersec);
    sector_offset = (fat_offset%fatfs->bpb.bpb_bytspersec);

    rt_sem_take(fatfs->lock, RT_WAITING_FOREVER);
    fat = fatfs_cache_fat_sector(fatfs, fat_sector);
    if ( !fat )
    {
        rt_sem_release(fatfs->lock);
        return -1;
    }
	result = GET32(&fat[sector_offset]);
    rt_sem_release(fatfs->lock);

	/* add support of MTD device */
	if (result == MAX32 && fatfs->device->type == RT_Device_Class_MTD) result = 0;

    return result;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_fat32_update
+------------------------------------------------------------------------------
| Description : Updates the cluster chain in FAT32
|
| Parameters  : 
| Returns     : 
|
+------------------------------------------------------------------------------
*/
int fatfs_fat32_update(struct fat_filesystem* fatfs, cluster_t entry, 
	cluster_t value)
{
	sector_t  fat_sector;
	cluster_t fat_offset;
    rt_uint8_t*   fat;
    rt_uint16_t   sector_offset;

	/* parameters check */
    if ( entry == value ) return -1;
    if ( entry < 2 ) return -1;

    rt_sem_take( fatfs->lock, RT_WAITING_FOREVER );
    fat_offset = entry * 4;

    fat_sector = fatfs->bpb.bpb_rsvdseccnt + (fat_offset/fatfs->bpb.bpb_bytspersec);
    sector_offset = (fat_offset%fatfs->bpb.bpb_bytspersec);

    fat = fatfs_cache_fat_sector(fatfs, fat_sector);
    if ( !fat ) goto __return;

	value = (value & 0x0fffffff) | ((GET32(&fat[sector_offset])) & 0xf0000000);
	SET32(&fat[sector_offset], value);

    fatfs->fat_cache[fat_sector & (FAT_CACHE_MASK)].state |= FAT_CACHE_DIRTY;

	/* update FAT32 info */
	if (!(value && fatfs->free_count > 0)) fatfs->free_count --;
	else fatfs->free_count ++;

    rt_sem_release(fatfs->lock);
    return 0;

__return:
    rt_sem_release(fatfs->lock);
    return -1;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_cluster_next
+------------------------------------------------------------------------------
| Description : Get the cluster's next cluster
|
| Parameters  : 
| Returns     : 0 on error, next cluster number on successful
|
+------------------------------------------------------------------------------
*/
cluster_t fatfs_cluster_next( struct fat_filesystem* fatfs, cluster_t cluster )
{
    cluster_t next_cluster = 0;

	if ( fatfs->fat_type & FATTYPE_FAT12 )
    {
        next_cluster = fatfs_fat12_get(fatfs, cluster);
        if ( next_cluster >= EOC12 ) return 0;
	}

    if ( fatfs->fat_type & FATTYPE_FAT16 )
    {
        next_cluster = fatfs_fat16_get(fatfs, cluster);
        if ( next_cluster >= EOC16 ) return 0;
    }

	if ( fatfs->fat_type & FATTYPE_FAT32 )
	{
        next_cluster = fatfs_fat32_get(fatfs, cluster);
        if ( next_cluster >= EOC32 ) return 0;
    }

    return next_cluster;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_cluster_find_empty
+------------------------------------------------------------------------------
| Description : Find the next empty cluster in FAT table
|
| Parameters  : 
| Returns     : 
|
+------------------------------------------------------------------------------
*/
cluster_t fatfs_cluster_find_empty(struct fat_filesystem* fatfs, 
	cluster_t start_cluster)
{
    int j;
    int fat_length;
	cluster_t result, index;

    fat_length = fatfs->data_clusters;
    if ( start_cluster < fatfs->bpb.bpb_rsvdseccnt + 1) 
	{
		start_cluster = fatfs->bpb.bpb_rsvdseccnt + 1;
    }

    /* change the FAT type judge to out of 'for' circulation, which will be more faster */
	if ( fatfs->fat_type & FATTYPE_FAT12 )
	{
        for ( j = 0; j < 2; j++)
        {
            for ( index = start_cluster; index < fat_length; index++)
            {
                result = fatfs_fat12_get(fatfs, index);
                if ( result == 0 ) return index;
            }

            fat_length = start_cluster;
            start_cluster = fatfs->bpb.bpb_rsvdseccnt + 1;
        }
	}
	else if ( fatfs->fat_type & FATTYPE_FAT16 )
	{
        for ( j = 0; j < 2; j++)
        {
            for ( index = start_cluster; index < fat_length; index++)
            {
                result = fatfs_fat16_get(fatfs, index);
                if ( result == 0 ) return index;
            }

            fat_length = start_cluster;
            start_cluster = fatfs->bpb.bpb_rsvdseccnt + 1;
        }
	}
	else if ( fatfs->fat_type & FATTYPE_FAT32 )
	{
		/* scan from the next free in FAT32 */
		start_cluster = fatfs->next_free;

        for ( j = 0; j < 2; j++)
        {
            for ( index = start_cluster; index < fat_length; index++)
            {
                result = fatfs_fat32_get(fatfs, index);
                if ( !result ) return index;
            }

            fat_length = start_cluster;
            start_cluster = fatfs->bpb.bpb_rsvdseccnt + 1;
        }
    }

    return 0;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_cluster_allocate
+------------------------------------------------------------------------------
| Description : Allocate a writeable cluster from FAT table
| Note        : if the cluster pointed by old_cluster exists, return this clust
|
| Parameters  : 
| Returns     : the first sector of next cluster
|
+------------------------------------------------------------------------------
*/
sector_t fatfs_cluster_allocate(struct fat_filesystem* fatfs, 
	cluster_t old_cluster, 
	cluster_t *new_cluster)
{
    cluster_t cluster = 0;

    if (old_cluster) cluster = fatfs_cluster_next(fatfs, old_cluster);

    if (cluster == 0)
    {
    	cluster = old_cluster? 
    		fatfs_cluster_find_empty(fatfs, old_cluster + 1) :
    		fatfs_cluster_find_empty(fatfs, 0);

        if ( cluster )
        {
            /* set the cluster to end */
			if ( fatfs->fat_type & FATTYPE_FAT12 )
			{
	            /* the old_cluster point to the next cluster */
	            if ( old_cluster ) fatfs_fat12_update( fatfs, old_cluster, cluster );

                fatfs_fat12_update( fatfs, cluster, EOC12 );
			}
			else if ( fatfs->fat_type & FATTYPE_FAT16 )
			{
	            /* the old_cluster point to the next cluster */
	            if ( old_cluster ) fatfs_fat16_update( fatfs, old_cluster, cluster );

                fatfs_fat16_update( fatfs, cluster, EOC16 );
			}
			else if ( fatfs->fat_type & FATTYPE_FAT32 )
			{
	            /* the old_cluster point to the next cluster */
	            if ( old_cluster ) fatfs_fat32_update( fatfs, old_cluster, cluster );

                fatfs_fat32_update( fatfs, cluster, EOC32 );

				/* update FAT32 info */
				fatfs->next_free = cluster;
            }

			dfs_log(DFS_DEBUG_INFO, ("connect %lu to %lu", old_cluster, cluster));
        }
        else return 0;
    }

    *new_cluster = cluster;
    return first_sector_of_cluster(fatfs, cluster);
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_cluster_remove
+------------------------------------------------------------------------------
| Description : remove a FAT chain
|
| Parameters  : fatfs, the pointer refer to FAT filesystem structure
|               cluster, the begin of cluster in FAT chain
|
| Returns     : always return 0
|
+------------------------------------------------------------------------------
*/
int fatfs_cluster_remove(struct fat_filesystem* fatfs, cluster_t cluster)
{
	cluster_t next_cluster;

	/* FAT12 */	
	if ( fatfs->fat_type & FATTYPE_FAT12 )
	{
        while ( cluster && cluster < EOC12 )
        {
            next_cluster = fatfs_fat12_get(fatfs, cluster);
            fatfs_fat12_update( fatfs, cluster, 0 );
            cluster = next_cluster;
        }
	}
	else 
	/* FAT16 */
	if ( fatfs->fat_type & FATTYPE_FAT16 )
	{
        while ( cluster && cluster < EOC16 )
        {
            next_cluster = fatfs_fat16_get(fatfs, cluster);
            fatfs_fat16_update( fatfs, cluster, 0 );
            cluster = next_cluster;
        }
	}
	else 
	/* FAT32 */
	if ( fatfs->fat_type & FATTYPE_FAT32 )
	{
        while ( cluster && cluster < EOC32 )
        {
            next_cluster = fatfs_fat32_get(fatfs, cluster);
            fatfs_fat32_update(fatfs, cluster, 0);
            cluster = next_cluster;
        }
    }

	return 0;
}

