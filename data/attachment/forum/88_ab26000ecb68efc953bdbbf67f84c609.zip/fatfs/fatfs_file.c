/*
+------------------------------------------------------------------------------
| Project   : Device Filesystem
+------------------------------------------------------------------------------
| Copyright 2004, 2005  www.fayfayspace.org.
| All rights reserved.
|------------------------------------------------------------------------------
| File      : fatfs_file.c, the file related operations
|------------------------------------------------------------------------------
| Chang Logs:
| Date           Author       Notes
| 2005-02-26     ffxz         The first version.
| 2005-04-07     ffxz         Fixed the bug in fatfs_update_info()
+------------------------------------------------------------------------------
*/
#include <dfs_util.h>
#include "fatfs_int.h"

/*
+------------------------------------------------------------------------------
| Function    : fatfs_open
+------------------------------------------------------------------------------
| Description : file open routin 
|
| Parameters  : file, the specified file descriptor
| Returns     : the status of opening
|               0 for successful, 
|               -1 is returned in case of an error, and the following errno 
|               error conditions are defined for this routin:
|
|               DFS_STATUS_EEXIST, the named file already exists.
|               DFS_STATUS_EISDIR, the file is a directory.
|               DFS_STATUS_ENOENT, the named file does not exist.
|               DFS_STATUS_ENOSPC, there is no disk space left.
+------------------------------------------------------------------------------
*/
int fatfs_open(struct dfs_fd* file)
{
    struct fat_file* fatfile;
    struct fat_filesystem* fatfs;
    struct fat_direntry direntry;
    int result = 0;

    if ( file == RT_NULL || file->fs == RT_NULL || 
		file->fs->data == RT_NULL ) return -DFS_STATUS_EINVAL;
    fatfs = (struct fat_filesystem*)(file->fs->data);

	// FIXME:
    fatfile = ( struct fat_file * ) malloc ( sizeof(struct fat_file ) );
    if ( file == RT_NULL ) return -DFS_STATUS_ENOMEM;

    file->pos = 0;

    /* Create */
    if ( file->flags & DFS_O_CREAT )
    {
        /* create a directory */
		if (fatfs_direntry_lookup(fatfs, &direntry, file->path) < 0)
        {
			/* clean direntry */
			memset(&direntry, 0, sizeof(struct fat_direntry));

			if ( file->flags & DFS_O_DIRECTORY )
			{
				dfs_log(DFS_DEBUG_INFO, ("add a dir"));
				result = fatfs_direntry_add_dir(fatfs, &direntry, file->path);
			}
			else
			{
				dfs_log(DFS_DEBUG_INFO, ("add a file"));
				result = fatfs_direntry_add_file(fatfs, &direntry, file->path);
			}

            if ( result < 0 ) goto __return;
        }
        else
        {
            if ( file->flags & DFS_O_DIRECTORY || 
				 file->flags & DFS_O_EXCL) result = -DFS_STATUS_EEXIST;
            else result = 0;

            if ( result < 0 ) goto __return;
        }
    }
    /* Write */
    else if ( file->flags & DFS_O_WRONLY || file->flags & DFS_O_RDWR )
    {
		if ( file->flags & DFS_O_DIRECTORY )
		{
			/* do not support directory write */
			result = -DFS_STATUS_EISDIR;
			goto __return;
		}
		
		result = fatfs_direntry_lookup(fatfs, &direntry, file->path);
        if (result < 0) /* file not found, create it */
        {
			/* clean direntry */
			memset(&direntry, 0, sizeof(struct fat_direntry));

			result = fatfs_direntry_add_file(fatfs, &direntry, file->path);
            if (result < 0) goto __return;
        }

        if (file->flags & DFS_O_APPEND)
        {
            /* seek to end */
			result = fatfs_lseek(file, direntry.file_size);
			if (result < 0) goto __return;
        }
    }
    /* Only Read , O_RDONLY be defined as 0 */
    else
    {
		if (fatfs_direntry_lookup(fatfs, &direntry, file->path) < 0)
        {
            result = -DFS_STATUS_ENOENT;
            goto __return;
        }
        else
        {
            /* read a directory */
            if ( file->flags & DFS_O_DIRECTORY )
            {
                if (direntry.attr & FAT_ATTR_DIRECTORY) file->flags |= DFS_F_DIRECTORY; /* is directory */
                else
                {
                    result = -DFS_STATUS_ENOENT;
                    goto __return;
                }
            }
        }
    }

    /* set dfs_fd properties */
    if ( file->pos == 0 )
    {
        fatfile->first_cluster = direntry.first_cluster ;
        fatfile->last_cluster = direntry.first_cluster;
        if ( fatfile->last_cluster == 0 ) fatfile->last_sector = fatfs->root_dir_sector; /* is FAT12/16 root direntry */
        else fatfile->last_sector = first_sector_of_cluster(fatfs, fatfile->first_cluster);
    }
    else /* if using O_APPEND */
    {
        fatfile->first_cluster = direntry.first_cluster;
    }

    fatfile->direntry = direntry.offset;
	fatfile->entries  = direntry.entries;

	/* if using O_TRUNC */
	if ( (file->flags & DFS_O_TRUNC) && (file->flags & DFS_O_WRONLY || file->flags & DFS_O_RDWR) )
	{
		/* remove FAT chain */
		fatfs_cluster_remove(fatfs, direntry.first_cluster);

		direntry.first_cluster = 0;
		direntry.file_size = 0;

		file->size = direntry.file_size;
		file->data = fatfile;

		/* update directory entry */
		fatfs_direntry_update(fatfs, &direntry);
	}
	else
	{
		file->size = direntry.file_size;
		file->data = fatfile;
	}

	/* lseek to the end */
	if (file->flags & DFS_O_APPEND)
	{
        /* seek to last sector and last cluster */
        fatfs_lseek(file, file->size);
	}

    return 0;

__return:
    free(fatfile);
    return result;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_close
+------------------------------------------------------------------------------
| Description : file close routin 
|
| Parameters  : file, the specified file descriptor
| Returns     : the status of close
|               0 for normal returned value, 
|               -1 is returned in case of an error, and the following errno 
|               error conditions are defined for this routin:
|
|               DFS_STATUS_EBADF, The argument is not a valid file descriptor.
+------------------------------------------------------------------------------
*/
int fatfs_close(struct dfs_fd* file)
{
    struct fat_filesystem* fatfs;

	if ( !file || !(file->flags & DFS_F_OPEN) ) return -DFS_STATUS_EBADF;

    fatfs = file->fs->data;
    fatfs_cache_fat_flush( fatfs );

    free(file->data);

    return 0;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_ioctl
+------------------------------------------------------------------------------
| Description : file ioctl routin, currently, fatfs does not support ioctl
|
| Parameters  : file, the specified file descriptor
|               cmd, the command of ioctl
|               args, the arguments of command
| Returns     : the status of ioctl
|               0 for normal returned value, 
|               -1 is returned in case of an error
+------------------------------------------------------------------------------
*/
int fatfs_ioctl(struct dfs_fd* file, int cmd, void* args)
{
    return 0;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_read
+------------------------------------------------------------------------------
| Description : file read routin 
|               The read algorithms is descripted as following:
|                __pos
|               / <---
| -       +---------------------------+
| ^       |    |                      |<---last_sector, last_cluster
| |       +---------------------------+
| sectors .           ...             .
| |       +---------------------------+
| V       |           |               |
| -       +---------------------------+
|            len  --->|
|
| Parameters  : file, the specified file descriptor
|               buf, the buffer which saves read data
|               len, the expected length of read data
| Returns     : the status of read
|               the number of bytes actually read for normal return,
|               -1 is returned in case of an error, and the following errno 
|               error conditions are defined for this routin:
|
|               DFS_STATUS_EBADF, the argument is not a valid file descriptor.
|               DFS_STATUS_EIO, indicates a hardware error.
+------------------------------------------------------------------------------
*/
int fatfs_read(struct dfs_fd* file, void* buf, rt_size_t len)
{
    rt_uint8_t sector_buf[SECTOR_SIZE], *ptr;
	sector_t current_sector;
	cluster_t current_cluster;
    int sectors, remain_in_begin, remain_in_end, i, rc;
    struct fat_file* fatfile = file->data;
    struct fat_filesystem* fatfs = file->fs->data;

	/* parameter check */
    if ( fatfile == RT_NULL || fatfs == RT_NULL ) return -DFS_STATUS_EBADF;

	ptr = (rt_uint8_t*) buf;
    if ( file->pos >= file->size )
    {
        file->flags |= DFS_F_EOF;
        return 0;
    }
    if ( file->pos + len > file->size ) len = file->size - file->pos;

    remain_in_begin = file->pos % SECTOR_SIZE;
    remain_in_end   = (file->pos % SECTOR_SIZE + len) % SECTOR_SIZE;

    current_sector  = fatfile->last_sector;
    current_cluster = fatfile->last_cluster;

	/* calculate the number of sectors */
    sectors = (remain_in_begin + len) / SECTOR_SIZE;
    if ( remain_in_end ) sectors ++;

	// dfs_log(DFS_DEBUG_INFO, ("%d:<--%d-->:%d", remain_in_begin, sectors, remain_in_end));

    for ( i=0; i < sectors ; i++ )
    {
		// dfs_log(DFS_DEBUG_INFO, ("c:s: %lu:%lu, i = %d", current_cluster, current_sector, i));
        if ( (rc = fat_read_sectors( fatfs, current_sector, 1, sector_buf )) < 0 )
            return rc;

        /* copy to buf */

        if ( i == sectors - 1)
        {
            /* copy the last sector */
            if ( i == 0 ) memcpy(ptr, sector_buf + remain_in_begin, len ); /* also the first sector */
            else 
			{
				memcpy(ptr, sector_buf, 
					remain_in_end == 0? fatfs->bpb.bpb_bytspersec : remain_in_end);
            }

			/* it's the end of this sector, move to next sector */
            if ( remain_in_end == 0 ) current_sector ++;
			else break;
        }
		else
		{
			if ( i == 0 )
	        {
	            /* copy the first sector */
	            memcpy(ptr, sector_buf + remain_in_begin,
	                fatfs->bpb.bpb_bytspersec - remain_in_begin );
	            ptr += fatfs->bpb.bpb_bytspersec - remain_in_begin;
	        }
	        else
	        {
	            /* copy a sector */
	            memcpy(ptr, sector_buf, fatfs->bpb.bpb_bytspersec);
	            ptr += fatfs->bpb.bpb_bytspersec;
	        }

			/* move to next sector */
			current_sector ++;
		}

        /* if need move to next cluseter, get next sector */
        if ((current_sector - 1) % (fatfs->bpb.bpb_secperclus) == 0)
        {
			// dfs_log(DFS_DEBUG_INFO, ("try to move to next cluster"));
            current_cluster = fatfs_cluster_next(fatfs, current_cluster);
            if ( current_cluster == 0 ) return -DFS_STATUS_EINVAL;

            current_sector = first_sector_of_cluster(fatfs, current_cluster);
        }
    }

	fatfile->last_sector  = current_sector;
    fatfile->last_cluster = current_cluster;
    file->pos += len;

    return len;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_write
+------------------------------------------------------------------------------
| Description : file write routin 
|               The write algorithms is descripted as following:
|                __pos
|               / <---
| -       +---------------------------+
| ^       |    |                      |<---last_sector, last_cluster
| |       +---------------------------+
| sectors .           ...             .
| |       +---------------------------+
| V       |           |               |
| -       +---------------------------+
|           *len  --->|
|
| Parameters  : file, the specified file descriptor
|               buf, the buffer which saves written data
|               len, the expected length of written data
| Returns     : the status of opening
|               the number of bytes actually written for normal return, 
|               -1 is returned in case of an error, and the following errno 
|               error conditions are defined for this routin:
|
|               DFS_STATUS_EBADF, the argument is not a valid file descriptor.
|               DFS_STATUS_EIO, indicates a hardware error.
|               DFS_STATUS_ENOSPC, there is no disk space left.
+------------------------------------------------------------------------------
*/
int fatfs_write(struct dfs_fd* file, const void* buf, rt_size_t len)
{
    rt_uint8_t sector_buf[SECTOR_SIZE], *ptr;
	sector_t current_sector;
	cluster_t current_cluster;
    int sectors, remain_in_begin, remain_in_end;
    int rc, i;

    struct fat_filesystem* fatfs = file->fs->data;
    struct fat_file* fatfile = file->data;

	/* parameter check */
    if ( fatfile == RT_NULL || fatfs == RT_NULL ) return -DFS_STATUS_EBADF; 

	ptr = (rt_uint8_t*)buf;
    remain_in_begin = file->pos % SECTOR_SIZE;
    remain_in_end = (file->pos % SECTOR_SIZE + len) % SECTOR_SIZE;

    current_sector  = fatfile->last_sector;
    current_cluster = fatfile->last_cluster;

    /* if it's a zero length file, alloc a cluster  */
    if (current_cluster == 0 && len > 0)
    {
        current_sector = fatfs_cluster_allocate(fatfs, current_cluster, 
        	&current_cluster);
        if ( !current_cluster ) return -DFS_STATUS_ENOSPC; /* disk full */

        fatfile->first_cluster 	= current_cluster;
        fatfile->last_cluster 	= current_cluster;
        fatfile->last_sector 	= current_sector;
        fatfs_update_shortname(fatfs, fatfile, 0);

		// dfs_log(DFS_DEBUG_INFO, ("allocate a new cluster for file, c:s: %lu:%lu", 
		//	current_cluster, current_sector));
    }
	else if ((file->pos == file->size) && len > 0)
	{
		/* in the end of file, allocate cluster or not? */
		if ((current_sector - 1)% fatfs->bpb.bpb_secperclus == 0)
		{
			current_sector = fatfs_cluster_allocate(fatfs, current_cluster,
				&current_cluster);
		}
	}

	/* calculate the number of sectors */
    sectors = (remain_in_begin + len) / SECTOR_SIZE;
    if ( remain_in_end ) sectors ++;

	// dfs_log(DFS_DEBUG_INFO, ("%d:<--%d-->:%d", remain_in_begin, sectors, remain_in_end));

    for ( i=0; i < sectors ; i++)
    {
		int no_move = 0;
		// dfs_log(DFS_DEBUG_INFO, ("c:s: %lu:%lu, i = %d", current_cluster, current_sector, i));
		
        /* the first sector */
        if ( i == 0 )
        {
            /* read the remain in begin */
            if ( remain_in_begin )
            {
                if ( (rc = fat_read_sectors( fatfs, current_sector, 1,
                    sector_buf)) < 0 )
                    return rc;
            }

            if ( remain_in_begin + len < fatfs->bpb.bpb_bytspersec ) /* less than one SECTOR */
            {
                memset( sector_buf, 0, sizeof( sector_buf ) );
                memcpy( sector_buf + remain_in_begin, ptr, len );
                ptr += len;

				/* end of writing, do not move to next sector */
				no_move = 1;
            }
            else /* greater than one SECTOR */
            {
                memcpy( sector_buf + remain_in_begin, ptr, fatfs->bpb.bpb_bytspersec - remain_in_begin );
                ptr += fatfs->bpb.bpb_bytspersec - remain_in_begin;
            }
        }
        /* end of sector in writing */
        else if ( i == sectors - 1 )
        {
            memset( sector_buf, 0, sizeof( sector_buf ) );
			if ( remain_in_end == 0 )
			{
				/* copy full of sector */
	            memcpy(sector_buf, ptr, fatfs->bpb.bpb_bytspersec);
			}
			else 
			{
				/* copy remain in end of sector */
	            memcpy(sector_buf, ptr, remain_in_end );

				/* end of writing, not move to next sector */
				no_move = 1;
			}
        }
        else
        {
            memcpy( sector_buf, ptr, fatfs->bpb.bpb_bytspersec );
            ptr += fatfs->bpb.bpb_bytspersec;
        }

        /* write the sector */
        if ( (rc = fat_write_sectors( fatfs, current_sector, 1, sector_buf )) < 0 )
            return rc;

		/* move to next sector */
		if (!no_move) current_sector ++;

        /* if not the end, then it need move to next cluseter */
        if (((current_sector - 1) % fatfs->bpb.bpb_secperclus == 0) && 
			!no_move &&
			(i != sectors - 1))
        {
			/* allocate new cluster if not in the end of file */

			/* move to next cluster */
            current_sector = fatfs_cluster_allocate(fatfs, current_cluster, &current_cluster);
            if ( !current_cluster ) return -DFS_STATUS_ENOSPC; /* disk full */

			// dfs_log(DFS_DEBUG_INFO, ("move to next cluster:sector: %lu:%lu", current_cluster, current_sector));
        }
    }

    fatfile->last_sector = current_sector;
    fatfile->last_cluster = current_cluster;

    file->pos += len;
    if ( file->pos > file->size )
    {
        file->size = file->pos;
        fatfs_update_shortname( fatfs, fatfile, file->size );
    }

    return len;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_lseek
+------------------------------------------------------------------------------
| Description : file lseek routin 
|
| Parameters  : file, the specified file descriptor
|               offset, the specified file position
| Returns     : the status of lseek
|               the resulting file position is returned normally,
|               -1 is returned in case of an error, and the following errno 
|               error conditions are defined for this routin:
|
|               DFS_STATUS_EBADF, the argument is not a valid file descriptor.
|               DFS_STATUS_EINVAL, the argument value is not valid.
+------------------------------------------------------------------------------
*/
int fatfs_lseek(struct dfs_fd* file, rt_off_t offset)
{
    struct fat_file* fatfile;
    struct fat_filesystem* fatfs;
    rt_uint32_t sectors;
    int i;

    fatfile = (struct fat_file*)file->data;
    fatfs = (struct fat_filesystem*)file->fs->data;

    if ( fatfile == RT_NULL || fatfs == RT_NULL ) return -DFS_STATUS_EBADF;

    sectors = offset / fatfs->bpb.bpb_bytspersec;
    if ( offset % fatfs->bpb.bpb_bytspersec ) sectors ++;

    if ( first_sector_of_cluster( fatfs, fatfile->first_cluster ) + sectors != 
        fatfile->last_sector )
    {
        rt_uint32_t clusters = sectors / fatfs->bpb.bpb_secperclus;
        rt_uint32_t sectors_remain = sectors % fatfs->bpb.bpb_secperclus;
        rt_uint32_t cluster = fatfile->first_cluster;
		
        if ( sectors_remain ) clusters ++;

        for ( i = 0; i < clusters ; i++ ) 
        {
            cluster = fatfs_cluster_next(fatfs, cluster);
            if ( !cluster )
            {
                return -DFS_STATUS_EINVAL;
            }
        }

        fatfile->last_cluster = cluster;
        fatfile->last_sector = first_sector_of_cluster( fatfs, cluster ) + sectors_remain;
    }

    return offset;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_getdents
+------------------------------------------------------------------------------
| Description : file getdents routin 
|
| Parameters  : file - the specified file descriptor
|               
| Returns     : the status of getdents
|               the resulting file position is returned normally,
|               0 is returned in case of end of directory
|               negative is returned in case of an error happen, which descript 
|               the following errno:
|
|               DFS_STATUS_EBADF, the argument is not a valid file descriptor.
|               DFS_STATUS_EINVAL, the argument value is not valid.
+------------------------------------------------------------------------------
*/
int fatfs_getdents(struct dfs_fd* file, struct dfs_dirent* dirp, rt_uint32_t count)
{
	struct fat_file* fatfile;
	struct fat_filesystem* fatfs;
	struct fat_direntry direntry;

	sector_t  sector;
	cluster_t cluster;

	int result, remain, idx;

	result 	= 0;

	fatfile = (struct fat_file*)file->data;
	fatfs = (struct fat_filesystem*)file->fs->data;

	/* the remain of one sector */
	remain  = file->pos % SECTOR_SIZE;

	/* fd check */
	if ( fatfile == RT_NULL || fatfs == RT_NULL) return -DFS_STATUS_EBADF;

	/* get the last cluster and sector */
	cluster = fatfile->last_cluster;
	sector  = fatfile->last_sector;

	/* make integer count */
	count = (count / sizeof(struct dfs_dirent)) * sizeof(struct dfs_dirent);
	if ( count == 0 ) return -DFS_STATUS_EINVAL;

	idx = sector * DIR_ENTRIES_PER_SECTOR + remain / DIR_ENTRY_SIZE;
	while ( 1 )
	{
		int nidx;

		if ((nidx = fatfs_direntry_next(fatfs, &direntry, idx)) == 0)
		{
			/* it's the end of cluster chain */
			return 0;
		}
		else if (nidx < 0) return nidx;

		if (direntry.shortname[0] == 0xe5)
		{
			/* move to next direntry */
			idx = nidx;

			/* update file position */
			file->pos += DIR_ENTRY_SIZE;

			dfs_log(DFS_DEBUG_INFO, ("find removed file, skip it"));

			continue;	/* skip removed direntry */
		}
		if (direntry.shortname[0] == 0) return 0;
		else if (fatfs->device->type == RT_Device_Class_MTD && direntry.shortname[0] == 0xff) return 0;
		else
		{
			struct dfs_dirent* d;

			d = dirp + result;
        		/* copy dirent name */
            		strncpy(d->d_name, direntry.name, 255);
			dfs_log(DFS_DEBUG_INFO, ("find a direntry, %s", d->d_name));

			/* set type */
			d->d_type = DFS_DT_UNKNOWN;
			if (direntry.attr & FAT_ATTR_DIRECTORY ) d->d_type &= DFS_DT_DIR;
			else d->d_type &= DFS_DT_REG;

			d->d_reclen = (rt_uint16_t)sizeof(struct dfs_dirent);	

			result ++;

			/* update file position */
			file->pos += direntry.entries * DIR_ENTRY_SIZE;

			/* is it enough? */
			if ( result * sizeof(struct dfs_dirent) >= count )
			{
				/* calculate the last accessed cluster & sector */
				sector  = idx / DIR_ENTRIES_PER_SECTOR;
				cluster = cluster_of_sector(fatfs, sector);

				/* yi.qiu @ 2009/04/19 */
				if ((idx + 1) % DIR_ENTRIES_PER_SECTOR == 0)
				{
					sector ++;

					/* it's the different cluster, seek it */
					if ((sector-1)%fatfs->bpb.bpb_secperclus == 0 )
					{
						cluster = fatfs_cluster_next(fatfs, cluster);
						sector  = first_sector_of_cluster(fatfs, cluster);
					}
				}
				/* yi.qiu @ 2009/04/19, End */

				/* update last accessed cluster & sector */
				fatfile->last_sector  = sector;
				fatfile->last_cluster = cluster;

				return result * sizeof(struct dfs_dirent);
			}			
		}

		/* move to next direntry */
		idx = nidx;
	}

	/* never reach */
	return 0;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_unlink
+------------------------------------------------------------------------------
| Description : file unlink routin 
|
| Parameters  : file - the specified file descriptor
|               
| Returns     : the status of unlink
|               the resulting file position is returned normally,
|               -1 is returned in case of an error, and the following errno 
|               error conditions are defined for this routin:
|
|               DFS_STATUS_EINVAL,
|               DFS_STATUS_ENOENT,
|				DFS_STATUS_EROFS,
|               DFS_STATUS_ENOTEMPTY
+------------------------------------------------------------------------------
*/
int fatfs_unlink(struct dfs_filesystem* fs, const char* path)
{
    struct fat_direntry direntry, entry;
    struct fat_filesystem* fatfs;
	cluster_t cluster;
	sector_t  sector;
    int result = 0, idx;

    if ( (fs == RT_NULL) || (path == RT_NULL) ) return -DFS_STATUS_EINVAL;

    fatfs = (struct fat_filesystem*) (fs->data);
    if ( fatfs == RT_NULL ) return -DFS_STATUS_EINVAL;

    /* not entry */
	if ((result = fatfs_direntry_lookup(fatfs, &direntry, path)) < 0)
		return -DFS_STATUS_ENOENT;

    if ( strcmp( direntry.name, "/" ) == 0 )
    {
		/* it's the root directory */
        return -DFS_STATUS_EISDIR;
    }

    /* if it's a directory, check whether it's empty or not */
    if ( direntry.attr & FAT_ATTR_DIRECTORY )
    {
        cluster = direntry.first_cluster;
        sector  = first_sector_of_cluster (fatfs, cluster);

		idx = sector * DIR_ENTRIES_PER_SECTOR;
        while ( cluster != 0 )
        {
			result = fatfs_direntry_next(fatfs, &entry, idx);
			if (result == 0 ) break;
			else if (result < 0) return result;

			/* move to next direntry */
			idx = result;

            if ( entry.shortname[0] != 0 && entry.shortname[0] != 0xe5 )
            {
                if ( strcmp( entry.name, ".") == 0 || strcmp( entry.name, "..") == 0 ) continue;
                else return -DFS_STATUS_ENOTEMPTY;
            }
            else if ( entry.name[0] == 0 ) break;
        }
    }

    /* it's not a zero length file, then clear its cluster chain */
    if ( direntry.first_cluster != 0 ) 
		fatfs_cluster_remove(fatfs, direntry.first_cluster);

    /* clear direntry */
	result = fatfs_direntry_remove(fatfs, &direntry);
	if ( result < 0 ) return result;

	/* flush FAT table */
	fatfs_cache_fat_flush(fatfs);
	
    return 0;
}

int fatfs_rename(struct dfs_filesystem* fs, const char* oldpath, const char* newpath)
{
	struct fat_direntry old_entry, new_entry;
	struct fat_filesystem* fatfs;

	rt_uint8_t parent_name[DFS_PATH_MAX];
	struct fat_direntry parent_direntry;

	int result;
	
	fatfs = (struct fat_filesystem*) fs->data ;

	/* parameters check */
	if (strlen(oldpath) > DFS_PATH_MAX || 
		strlen(newpath) > DFS_PATH_MAX ||
		/* oldpath is a directory that contains newpath */
		strncmp(oldpath, newpath, strlen(newpath)) == 0) 
		return -DFS_STATUS_EINVAL;

	if ( dir_name(newpath, &parent_name[0], DFS_PATH_MAX) == 0 )
	{
		/* if can't find old direntry */
		if ((result = fatfs_direntry_lookup(fatfs, &old_entry, oldpath)) < 0) 
			return -DFS_STATUS_ENOENT;

		/* if the new direntry exist */
		if ((result = fatfs_direntry_lookup(fatfs, &new_entry, newpath)) >= 0) 
			return -DFS_STATUS_ENOTEMPTY;

		/* lookup the parent direntry */
		if (fatfs_direntry_lookup(fatfs, &parent_direntry, parent_name) == 0)
		{
			/* fill new entry information */
			file_name(newpath, &new_entry.name[0], DFS_FILE_MAX);

			/* makeup direntry struct */
			new_entry.file_size 	= old_entry.file_size;
			new_entry.attr			= old_entry.attr;
			new_entry.first_cluster	= old_entry.first_cluster;

			new_entry.create_time_tenth = old_entry.create_time_tenth;
			new_entry.create_date 	= old_entry.create_date;
			new_entry.create_time 	= old_entry.create_time;
			new_entry.access_date 	= old_entry.access_date;
			new_entry.write_date	= old_entry.write_date;
			new_entry.write_time	= old_entry.write_time;

			/* add the new direntry in parent direntry */
			result = fatfs_direntry_add(fatfs, &parent_direntry, &new_entry);
			if (result < 0) return result;
			
			result = fatfs_direntry_remove(fatfs, &old_entry);
			if (result < 0)
			{
				/* delete the added direntry */
				fatfs_direntry_remove(fatfs, &new_entry);
				return result;
			}
		}
	}

	/* flush FAT table */
	fatfs_cache_fat_flush(fatfs);

    return 0;
}

int fatfs_stat(struct dfs_filesystem* fs, const char *path, struct dfs_stat *st)
{
    struct fat_direntry entry;
    struct fat_filesystem* fatfs;
    int result;

    fatfs = (struct fat_filesystem*)fs->data;
	if ((result = fatfs_direntry_lookup(fatfs, &entry, path)) < 0)
	{
		dfs_log(DFS_DEBUG_ERROR, ("can't find direntry:%s", path));
		return -DFS_STATUS_ENOENT;
	}

    st->st_dev = fs->dev_id;
    st->st_mode = DFS_S_IFREG | DFS_S_IRUSR | DFS_S_IRGRP | DFS_S_IROTH | 
		DFS_S_IWUSR | DFS_S_IWGRP | DFS_S_IWOTH;
    if ( entry.attr & FAT_ATTR_DIRECTORY )
    {
        st->st_mode &= ~DFS_S_IFREG;
        st->st_mode |= DFS_S_IFDIR | DFS_S_IXUSR | DFS_S_IXGRP | DFS_S_IXOTH;
    }
    if ( entry.attr & FAT_ATTR_READ_ONLY )
    {
        st->st_mode &= ~(DFS_S_IWUSR | DFS_S_IWGRP | DFS_S_IWOTH);
    }
    st->st_size  = entry.file_size;
    st->st_mtime = entry.write_time;
    return 0;
}
