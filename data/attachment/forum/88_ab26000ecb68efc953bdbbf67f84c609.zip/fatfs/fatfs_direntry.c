/*
+------------------------------------------------------------------------------
| Project   : Device Filesystem
+------------------------------------------------------------------------------
| Copyright 2004, 2005  www.fayfayspace.org.
| All rights reserved.
|------------------------------------------------------------------------------
| File      : fatfs_direntry.c, the direntry related operations
|------------------------------------------------------------------------------
| Chang Logs:
| Date           Author       Notes
| 2005-03-16     ffxz         The first version.
| 2005-07-26     ffxz         Add support for MTD device
+------------------------------------------------------------------------------
*/
#include "fatfs_int.h"
#include <dfs_util.h>

static int fatfs_direntry_add_simple(struct fat_filesystem* fatfs,
	struct fat_direntry* parent_direntry,
	struct fat_direntry* direntry);

/*
+------------------------------------------------------------------------------
| Function    : fatfs_direntry_shortname_to_string
+------------------------------------------------------------------------------
| Description : convert FAT's short name to string
|
| Parameters  : src, the source string
|               nm,  the destination name string
| Returns     : null
|
+------------------------------------------------------------------------------
*/
inline void fatfs_direntry_shortname_to_string(register const char* src,
	register char* nm)
{
	register long i;

	i = 8;
	while (i-- && *src != ' ')
	{
		*nm++ = *src++;
	}

	src += i + 1;
	if (*src > ' ')
	{
		*nm++ = '.';
		i = 3;
		while (i-- && *src != ' ')
		{
			*nm++ = *src++;
		}
	}

	*nm = '\0';
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_direntry_longname_to_string
+------------------------------------------------------------------------------
| Description : convert FAT's long name to string
|
| Parameters  : slot,
|               src,  the source string
|               nm,   the destination name string
| Returns     : null
|
+------------------------------------------------------------------------------
*/
inline void fatfs_direntry_longname_to_string(register int slot,
	register const char* src,
	register char* nm)
{
 	register int offset = (slot - 1) * 13;
	register int i;

	for (i = 0; i < 5; i++)
	{
		nm[offset + i] = src[i * 2 + 1];
		/* skip, src[i * 2 + 2] = 0 */
	}

	offset += 5;
	for (i = 0; i < 6; i++)
	{
		nm[offset + i] = src[i * 2 + 14];
		/* skip, src[i * 2 + 15] = 0 */
	}

	offset += 6;
	for (i = 0; i < 2; i++)
	{
		nm[offset + i] = src[i * 2 + 28];
		/* skip, src[i * 2 + 29] = 0 */
	}
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_direntry_from_shortname
+------------------------------------------------------------------------------
| Description : convert shortname to FAT's short name
|
| Parameters  : str, the source string
|               nm,  the destination name
| Returns     : null
|
+------------------------------------------------------------------------------
*/
inline void fatfs_direntry_from_shortname(register const char* src,
	register char* nm)
{
	memcpy(nm, src, 11);
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_direntry_from_longname
+------------------------------------------------------------------------------
| Description : convert long name to FAT's long name
|
| Parameters  : slot,
|               str,  the source string
|               nm,   the destination name string
| Returns     : null
|
+------------------------------------------------------------------------------
*/
inline void fatfs_direntry_from_longname(register int slot,
	register const char* src,
	register char* nm)
{
	register int i;
	char unicode[26], *ptr;

	/* convert to unicode */
	/* if it's the last name entry, add padding */
	if (slot == (strlen(src) + 12)/ 13)
	{
		src += (slot - 1) * 13;

		/* copy the last name */
		for (i = 0; i < 26 && *src; i +=2)
		{
			unicode[i] = *src++;
			unicode[i + 1] = 0;
		}

		/* add padding */
		if (i < 25)
		{
			unicode [i ++] = 0x00;
			unicode [i ++] = 0x00;

			if (i < 25)
			{
				unicode [i ++] = 0x00;
				unicode [i ++] = 0x00;
				while (i < 26)unicode[i++] = 0xff;
			}
		}
    }
	else
	{
		src += (slot - 1) * 13;
		for (i = 0; i < 26; i += 2)
		{
			unicode[i] = *src++;
			unicode[i + 1] = 0;
		}
	}

	ptr = &unicode[0];
    /* copy unicode to FAT's direntry */
	/* 0 - 4 */
    for (i = 0; i < 5; i ++)
    {
        nm[ i * 2 + 1 ] = *ptr++;
        nm[ i * 2 + 2 ] = *ptr++;
    }

	/* 5 - 11 */
    for (i = 0; i < 6; i ++)
    {
        nm[ i * 2 + 14 ] = *ptr++;
        nm[ i * 2 + 15 ] = *ptr++;
    }

	/* 12 - 13 */
    for (i = 0; i < 2; i++)
    {
        nm[ i * 2 + 28 ] = *ptr++;
        nm[ i * 2 + 29 ] = *ptr++;
    }
}


/*
+------------------------------------------------------------------------------
| Function    : fatfs_direntry_clean_cluster
+------------------------------------------------------------------------------
| Description : clean one cluster of directory
|
| Parameters  : fatfs, the FAT filesystem structure
|               cluster, the specified cluster, which will be earse
| Returns     : 0 on successful, negative on error happen
|
+------------------------------------------------------------------------------
*/
inline int fatfs_direntry_clean_cluster(struct fat_filesystem* fatfs,
	cluster_t cluster)
{
	register int i, result;
	sector_t sector;
	rt_uint8_t buf[SECTOR_SIZE];

	sector = first_sector_of_cluster(fatfs, cluster);

	/* check sector range */
	if ( sector < fatfs->first_data_sector ||
		sector > fatfs->first_data_sector + fatfs->total_sectors)
		return -DFS_STATUS_ENOSPC;

	memset(buf, 0, sizeof(buf));

	for ( i = 0; i < fatfs->bpb.bpb_secperclus; i ++)
	{
		result = fat_write_sectors(fatfs, sector + i, 1, buf);
		if ( result < 0 ) return result;
	}

	return 0;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_direntry_check_sum
+------------------------------------------------------------------------------
| Description : check sum of direntry name
|
| Parameters  : shorname, the shortname of direntry entry
| Returns     : the chksum is returned
|
+------------------------------------------------------------------------------
*/
inline rt_uint8_t fatfs_direntry_check_sum(char* shortname)
{
	register int i, j;
	rt_uint8_t chksum;

	chksum = 0;
    for ( i = 11, j =0; i > 0; i-- )
    {
        chksum = ( ( chksum & 1 ) ? 0x80 : 0 ) + ( chksum >> 1 ) + shortname[j++];
    }

	return chksum;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_direntry_next
+------------------------------------------------------------------------------
| Description : get the next directory entry
|
| Parameters  : fatfs, the FAT filesystem structure
|               direntry, the next direntry is saved to
|               idx, the index of current direntry
| Returns     : the index of next direntry is returned
|
+------------------------------------------------------------------------------
*/
int fatfs_direntry_next(struct fat_filesystem* fatfs,
	struct fat_direntry* direntry, int idx)
{
	rt_uint8_t buf[SECTOR_SIZE], nbuf[SECTOR_SIZE], *entry;
	rt_uint8_t chksum;

	sector_t sector;
	cluster_t cluster;

	rt_uint8_t entries;
	rt_uint8_t longname;

	int result;

	chksum = 0;

	/* get cluster & sector */
	sector = idx / DIR_ENTRIES_PER_SECTOR;
	cluster = cluster_of_sector(fatfs, sector);
	/* point to offset in current sector */
	idx = idx % DIR_ENTRIES_PER_SECTOR;

	result = fat_read_sectors(fatfs, sector, 1, &buf);
	if (result < 0) return result;

	/* init the name of direntry */
	memset(direntry->name, 0, sizeof(direntry->name));
	memset(direntry->shortname, 0, sizeof(direntry->shortname));

/* if there are errors on reading of direntry, especially for longname, reback to this */
__restart:
	if (idx > DIR_ENTRIES_PER_SECTOR)
	/* reread the sector buf */
	{
		sector ++;
		idx = idx % DIR_ENTRIES_PER_SECTOR;

		/* it's the different cluster, seek it */
		if ((sector-1)%fatfs->bpb.bpb_secperclus == 0 )
		{
			cluster = fatfs_cluster_next(fatfs, cluster);
			if (cluster == 0) return 0; /* it's the end of cluster chain */

			sector  = first_sector_of_cluster(fatfs, cluster);
			dfs_log(DFS_DEBUG_INFO, ("switch to cluster:%d, sector:%d", cluster, sector));
		}

		/* read next sector to buffer */
		result = fat_read_sectors(fatfs, sector, 1, buf);
		if (result < 0) return result;
	}

	entries  = buf[idx * DIR_ENTRY_SIZE + FATLONG_ORDER];
	longname = buf[idx * DIR_ENTRY_SIZE + FATDIR_ATTR];

	/* if it's a longname direntry */
	if (longname == FAT_ATTR_LONG_NAME && entries != 0xe5)
	{
		/* it's the last long name direntry */
		if (entries & 0x40)
		{
			int i;

			entries &= 0x1F;
			/* there is some part of longname in next sector */
			if (entries + idx > DIR_ENTRIES_PER_SECTOR)
			{
				sector ++;

				/* it's the different cluster, seek it */
				if ((sector-1)%fatfs->bpb.bpb_secperclus == 0 )
				{
					cluster = fatfs_cluster_next(fatfs, cluster);
					sector  = first_sector_of_cluster(fatfs, cluster);
					dfs_log(DFS_DEBUG_INFO, ("switch to cluster:%d, sector:%d", cluster, sector));
				}

				/* read next sector to buffer */
				result = fat_read_sectors(fatfs, sector, 1, nbuf);
				if (result < 0) return result;
			}

			/* get the long name */
			for (i = 0; i < entries; i++)
			{
				/* point to corrected entry */
				entry = entries - i + idx > DIR_ENTRIES_PER_SECTOR?
					&nbuf[(entries - i - 1 + idx) % DIR_ENTRIES_PER_SECTOR * DIR_ENTRY_SIZE] :
					&buf[(entries - i - 1 + idx) * DIR_ENTRY_SIZE];

				fatfs_direntry_longname_to_string(i + 1, entry, direntry->name);
				if (i == 0) chksum = entry[FATLONG_CHKSUM];
				else if (entry[FATLONG_CHKSUM] != chksum)
				{
					idx += i;
					goto __restart;
				}
			}
		}
		else
		/* it's an invalid longname part, skip it */
		{
			idx += entries + 1;
			goto __restart;
		}
	}
	else entries = 0;

	/* the shortname part */
	/* point to correct entry */
	if ( entries + idx > DIR_ENTRIES_PER_SECTOR )
	{
		/* in the next sector buf */
		entry = &nbuf[(entries + idx) % DIR_ENTRIES_PER_SECTOR
			* DIR_ENTRY_SIZE];
	}
	else
	{
		entry = &buf[(entries + idx) * DIR_ENTRY_SIZE];
	}

	/* read the shortname entry */
	direntry->create_time_tenth = entry[FATDIR_CRTTIMETENTH];
	direntry->create_time 		= GET16(&entry[FATDIR_CRTTIME]);
	direntry->create_date 		= GET16(&entry[FATDIR_CRTDATE]);
	direntry->access_date		= GET16(&entry[FATDIR_LSTACCDATE]);
	direntry->write_time  		= GET16(&entry[FATDIR_WRTTIME]);
	direntry->write_date  		= GET16(&entry[FATDIR_WRTDATE]);

	direntry->attr 				= entry[FATDIR_ATTR];
	direntry->file_size   		= GET32(&entry[FATDIR_FILESIZE]);
	direntry->first_cluster 	= GET16(&entry[FATDIR_FSTCLUSLO])
		| (GET16(&entry[FATDIR_FSTCLUSHI]) << 16);
	direntry->entries			= entries + 1;
	direntry->offset			= sector * DIR_ENTRIES_PER_SECTOR + idx;

	/* get short name */
	memcpy(direntry->shortname, &entry[FATDIR_NAME], 11);
	dfs_log(DFS_DEBUG_INFO, ("get the short direntry:%s", direntry->shortname));
	// fatfs_direntry_shortname_to_string(&entry[FATDIR_NAME], direntry->shortname);

	if (longname == FAT_ATTR_LONG_NAME && entries != 0xe5)
	/* for long name, check it checksum */
	{
		if (fatfs_direntry_check_sum(&entry[FATDIR_NAME]) != chksum)
		{
			/* it's not the long name's short direntry */
			fatfs_direntry_shortname_to_string(direntry->shortname, direntry->name);
			// strncpy(direntry->name, direntry->shortname, 13);
		}
	}
	else
	/* it's shortname, copy the shortname to name */
	{
		fatfs_direntry_shortname_to_string(direntry->shortname, direntry->name);
		// strncpy(direntry->name, direntry->shortname, 13);
	}

	/* yi.qiu @ 2009/04/18 */
	if ((idx + entries + 1) >= DIR_ENTRIES_PER_SECTOR)
	/* reread the sector buf */
	{
		sector ++;
		idx = idx % DIR_ENTRIES_PER_SECTOR;

		/* it's the different cluster, seek it */
		if ((sector-1)%fatfs->bpb.bpb_secperclus == 0 )
		{
			cluster = fatfs_cluster_next(fatfs, cluster);
			if (cluster == 0) return 0; /* it's the end of cluster chain */

			sector  = first_sector_of_cluster(fatfs, cluster);
			dfs_log(DFS_DEBUG_INFO, ("switch to cluster:%d, sector:%d", cluster, sector));
		}
	}
	/* yi.qiu @ 2009/04/19, End */

	dfs_log(DFS_DEBUG_INFO, ("the next direntry index should be %d",
		sector * DIR_ENTRIES_PER_SECTOR +
		(idx + entries + 1) % DIR_ENTRIES_PER_SECTOR));
		
	/* point to next direntry */
	return sector * DIR_ENTRIES_PER_SECTOR +
		(idx + entries + 1) % DIR_ENTRIES_PER_SECTOR;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_direntry_lookup
+------------------------------------------------------------------------------
| Description : lookup a specified direntry in FAT filesystem
|
| Parameters  : fatfs, the fat filesystem structure
|               direntry, the returned direntry structure
|               name, the speicified entry name
| Returns     : 0 on successful, -1 on no found
|
+------------------------------------------------------------------------------
*/
int fatfs_direntry_lookup(struct fat_filesystem* fatfs,
	struct fat_direntry* direntry,
	const char* name)
{
    char path[DFS_FILE_MAX], shortname[12];
    int pos; /* the name item position */
    int idx; /* the offset of direntry */

	sector_t sector;

    /* must lookup from root directory */
    sector = fatfs->root_dir_sector;
	memset(direntry, 0, sizeof(struct fat_direntry));

	pos = 0;
    if ( (pos = next_dir_name(name, pos, path)) < 0 )
    {
		dfs_log(DFS_DEBUG_INFO, ("is root direntry"));
        /* is root directory */
        direntry->name[0] = '/';
        direntry->name[1] = '\0';
		memcpy(direntry->shortname, "/          ", 11);
        direntry->attr   |= FAT_ATTR_DIRECTORY;
		direntry->offset  = sector / DIR_ENTRIES_PER_SECTOR;

		/* point to cluster of root */
		direntry->first_cluster = fatfs->bpb.bpb_rootclus;

        return 0;
    }
	dfs_log(DFS_DEBUG_INFO, ("lookup direntry:%s", name));

	memset(&shortname, 0, 12);
	/* should compare short name */
	if (!(fatfs->fat_type & FATTYPE_FAT32)) fatfs_make_shortname(path, shortname, 0);

	idx = sector * DIR_ENTRIES_PER_SECTOR;
    while ( 1 )
    {
		int nidx;
__restart:
		// dfs_log(DFS_DEBUG_INFO, ("lookup direntry:%s, [%s]", path, shortname));
		if ((nidx = fatfs_direntry_next(fatfs, direntry, idx)) < 0) return nidx;

		dfs_log(DFS_DEBUG_INFO, ("get direntry:%s", direntry->shortname));
		/* check direntry */
		if (direntry->shortname[0] == 0xe5)
		{
			/* move to next sector */
			idx = nidx;
			continue; /* skip a removed direntry */
		}
		else if (direntry->shortname[0] == '\0')
		{
			/* no found */
			return -1;
		}
		else if (fatfs->device->type == RT_Device_Class_MTD && direntry->shortname[0] == 0xff)
		{
			/* no found */
			return -1;
		}

		if (fatfs->fat_type & FATTYPE_FAT32)
		{
			/* it's the current path or not? */
			if ( strncasecmp(direntry->name, path, DFS_FILE_MAX) == 0 )
			{
				/* it's a directory */
				if ((direntry->attr & FAT_ATTR_DIRECTORY) &&
					((pos = next_dir_name(name, pos, path)) >= 0))
				{
					/* restart the scan */
					sector = first_sector_of_cluster(fatfs, direntry->first_cluster);
					idx = sector * DIR_ENTRIES_PER_SECTOR;
					goto __restart;
				}
				else
				{

					/* found */
					return 0;
				}
			}
		}
		else
		{
			/* it's the current path or not? */
			if ( strncasecmp(direntry->shortname, shortname, 11) == 0 )
			{
				/* it's a directory */
				if ((direntry->attr & FAT_ATTR_DIRECTORY) &&
					((pos = next_dir_name(name, pos, path)) >= 0))
				{
					fatfs_make_shortname(path, shortname, 0);

					/* restart the scan */
					sector = first_sector_of_cluster(fatfs, direntry->first_cluster);
					idx = sector * DIR_ENTRIES_PER_SECTOR;
					goto __restart;
				}
				else
				{
					dfs_log(DFS_DEBUG_INFO, ("find the directory, return:%s", direntry->shortname));
					/* found */
					return 0;
				}
			}
		}

		/* move to new offset */
		idx = nidx;
	}
	/* can't find direntry, never reach this one */
    return -1;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_direntry_add_file
+------------------------------------------------------------------------------
| Description : add a file in FAT filesystem
|
| Parameters  : fatfs, the fat filesystem structure
|               direntry, the returned direntry, which is the added file
|               name, the specified file name(with full path)
| Returns     : 0 on successful, -1 on error
|
+------------------------------------------------------------------------------
*/
int fatfs_direntry_add_file(struct fat_filesystem* fatfs,
		struct fat_direntry* direntry,
		const char* name)
{
	rt_uint8_t parent_name[DFS_PATH_MAX + 1];
	struct fat_direntry parent_direntry;

	/* get parent path name */
	if ( dir_name(name, &parent_name[0], DFS_PATH_MAX) == 0 )
	{
		if ( fatfs_direntry_lookup(fatfs, &parent_direntry, parent_name) == 0 )
		{
			/* make direntry struct */
			file_name(name, &direntry->name[0], DFS_FILE_MAX);

			/* makeup direntry struct */
			direntry->attr |= FAT_ATTR_ARCHIVE;
			direntry->create_time_tenth = 0;
			direntry->create_time = 0;
			direntry->create_date = 10273;
			direntry->access_date = 10273;
			direntry->write_time  = 0;
			direntry->write_date  = 10273;

			direntry->file_size   = 0;
			direntry->first_cluster = 0;

			return fatfs_direntry_add(fatfs, &parent_direntry, direntry);
		}
	}

	return -1;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_direntry_add_dir
+------------------------------------------------------------------------------
| Description : add a directory entry in FAT filesystem
|
| Parameters  : fatfs, the fat filesystem structure
|               direntry, the returned direntry, which is the added directory
|               name, the specified directory(with full path)
| Returns     : 0 on successful, -1 on error
|
+------------------------------------------------------------------------------
*/
int fatfs_direntry_add_dir(struct fat_filesystem* fatfs,
		struct fat_direntry* direntry,
		const char* name)
{
	cluster_t first_cluster;

	struct fat_direntry parent_direntry, child_direntry;
	rt_uint8_t parent_name[DFS_PATH_MAX];

	/* add the directory entry */

	/* get parent path name */
	if ( dir_name(name, &parent_name[0], DFS_PATH_MAX) == 0 )
	{
		if ( fatfs_direntry_lookup(fatfs, &parent_direntry, parent_name) == 0 )
		{
			/* make direntry struct */
			file_name(name, &direntry->name[0], DFS_FILE_MAX);

			direntry->attr |= FAT_ATTR_DIRECTORY;

			/* make up direntry time */
			direntry->create_time_tenth = 0;
			direntry->create_time = 0;
			direntry->create_date = 10273;
			direntry->access_date = 10273;
			direntry->write_time  = 0;
			direntry->write_date  = 10273;

			direntry->file_size   = 0;

			/* allocate a new cluster */
			first_cluster = 0;
			fatfs_cluster_allocate(fatfs, first_cluster, &first_cluster);

			if (fatfs->device->type != RT_Device_Class_MTD)
			{
				/* clean the extend directory cluster */
				fatfs_direntry_clean_cluster(fatfs, first_cluster);
			}
			else
			{
				register sector_t sector;
				register int i;

				sector = first_sector_of_cluster(fatfs, first_cluster);
				for (i = 0; i < fatfs->bpb.bpb_secperclus; i++)
				{
					rt_off_t offset = (sector + i) * SECTOR_SIZE;
					rt_device_control(fatfs->device, DEVICE_CLEAN_SECTOR, &offset);
				}
			}

			/* set first cluster */
			direntry->first_cluster = first_cluster;

			/* add direntry */
			fatfs_direntry_add(fatfs, &parent_direntry, direntry);

			dfs_log(DFS_DEBUG_INFO, ("add '.' and '..' to dir"));

			/* add '.' */
			memcpy(&child_direntry, direntry, sizeof(child_direntry));
			child_direntry.name[0] = '\0';
			memcpy(child_direntry.shortname, ".          ", 11);
			fatfs_direntry_add_simple(fatfs, direntry, &child_direntry);

			/* add '..' */
			memcpy(child_direntry.shortname, "..         ", 11);
			fatfs_direntry_add_simple(fatfs, direntry, &child_direntry);
		}
	}

	return 0;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_direntry_update
+------------------------------------------------------------------------------
| Description : update attributes of direntry to directory file
|
| Parameters  : fatfs, the pointer of fat filesystem structure
|               direntry, the modified direntry
| Returns     :
+------------------------------------------------------------------------------
*/
int fatfs_direntry_update(struct fat_filesystem* fatfs,
	struct fat_direntry* direntry)
{
    rt_uint8_t buf[SECTOR_SIZE], *entry;
    sector_t  sector;
	cluster_t cluster;
	rt_uint16_t idx;
    int result, i;

	if ( direntry == RT_NULL ) return -DFS_STATUS_EINVAL;

	/* get sector & cluster */
	sector 	= direntry->offset / DIR_ENTRIES_PER_SECTOR;
	cluster = cluster_of_sector(fatfs, sector);

	/* get index of direntry */
	idx 	= direntry->offset % DIR_ENTRIES_PER_SECTOR;

	/* read direntry file */
    if ( (result = fat_read_sectors( fatfs, sector, 1, buf )) < 0 ) goto __return;

    for ( i = 0; i < direntry->entries; i++ )
    {
        /* read all of this sector, move to next sector */
        if ( idx >= DIR_ENTRIES_PER_SECTOR )
        {
            /* move to next sector */
		    if ((sector - 1) % fatfs->bpb.bpb_secperclus == 0)
		    {
		        cluster = fatfs_cluster_next (fatfs, cluster);
		        sector  = first_sector_of_cluster(fatfs, cluster);
		    }
		    else sector ++;

			/* read direntry file on the next sector */
            if ( (result = fat_read_sectors(fatfs, sector, 1, buf)) < 0 ) goto __return;

            idx = 0;
        }

		/* point to direntry */
        entry = buf + idx * DIR_ENTRY_SIZE;
        idx++;

		/* it's the short name entry */
        if (i + 1 == direntry->entries)
        {
			/* update attributes */
            entry[FATDIR_ATTR] 	= direntry->attr;
            entry[FATDIR_NTRES] = 0;

            entry[FATDIR_CRTTIMETENTH] = direntry->create_time_tenth;
			SET16(&entry[FATDIR_CRTTIME], direntry->create_time);
			SET16(&entry[FATDIR_WRTTIME], direntry->write_time);
			SET16(&entry[FATDIR_CRTDATE], direntry->create_date);
			SET16(&entry[FATDIR_WRTDATE], direntry->write_date);
			SET16(&entry[FATDIR_LSTACCDATE], direntry->access_date);
			SET32(&entry[FATDIR_FILESIZE], direntry->file_size);
			SET16(&entry[FATDIR_FSTCLUSHI], direntry->first_cluster >> 16);
			SET16(&entry[FATDIR_FSTCLUSLO], direntry->first_cluster & 0xffffffff);
        }
    }

    /* update last sector */
    if ( (result = fat_write_sectors( fatfs, sector, 1, buf )) < 0 ) goto __return;

    return 0;

__return:
    return result;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_direntry_add_simple
+------------------------------------------------------------------------------
| Description : add an simple direntry
| Notes, only invoked in make directory case(".", "..")
|
| Parameters  : fatfs, the pointer of fat filesystem structure
|               parent_direntry, the parent direntry of added on
|               direntry, the new direntry
| Returns     :
+------------------------------------------------------------------------------
*/
static int fatfs_direntry_add_simple(struct fat_filesystem* fatfs,
	struct fat_direntry* parent_direntry,
	struct fat_direntry* direntry)
{
    rt_uint8_t buf[SECTOR_SIZE], *entry;
	sector_t  sector;
	int result, i;

	/* parameters check */
	if ( direntry == RT_NULL || parent_direntry == RT_NULL )
		return -DFS_STATUS_EINVAL;

	/* check it's root directory or not */
	/* not support add simple direntry in root directory*/
    if ( parent_direntry->first_cluster == 0 ) return -1;

	sector = first_sector_of_cluster(fatfs, parent_direntry->first_cluster);

	/* read old directory file */
    if ((result = fat_read_sectors(fatfs, sector, 1, buf)) < 0) goto __return;

	/* find a free direntry */
    for ( i = 0; i < DIR_ENTRIES_PER_SECTOR; i++)
    {
		entry = buf + i * DIR_ENTRY_SIZE;
		if (fatfs->device->type == RT_Device_Class_MTD)
		{
			if ( entry[FATDIR_NAME] == 0xe5 || entry[FATDIR_NAME] == 0xff || entry[FATDIR_NAME] == 0 )
				break;
		}
		else
		{
			if ( entry[FATDIR_NAME] == 0xe5 || entry[FATDIR_NAME] == 0 )
				break;
		}
    }

	if ( i == DIR_ENTRIES_PER_SECTOR ) return -DFS_STATUS_EINVAL;

	/* make direntry from short name */
	fatfs_direntry_from_shortname(direntry->shortname, &entry[FATDIR_NAME]);

    entry[FATDIR_ATTR] 	= direntry->attr;
    entry[FATDIR_NTRES] = 0;

    entry[FATDIR_CRTTIMETENTH] =  direntry->create_time_tenth;
	SET16(&entry[FATDIR_CRTTIME], direntry->create_time);
	SET16(&entry[FATDIR_WRTTIME], direntry->write_time);
	SET16(&entry[FATDIR_CRTDATE], direntry->create_date);
	SET16(&entry[FATDIR_WRTDATE], direntry->write_date);
	SET16(&entry[FATDIR_LSTACCDATE], direntry->access_date);
	SET16(&entry[FATDIR_FSTCLUSHI],  direntry->first_cluster >> 16);
	SET16(&entry[FATDIR_FSTCLUSLO],  direntry->first_cluster & 0xffffffff);

	/* write direntry file sector */
	if ( (result = fat_write_sectors(fatfs, sector, 1, buf)) < 0 ) goto __return;

	/* update direntry */
	direntry->offset = sector * DIR_ENTRIES_PER_SECTOR + i ;

	// dfs_log(DFS_DEBUG_INFO, ("add a simple direntry at %lu", direntry->offset));
	return 0;

__return:
    return result;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_direntry_add
+------------------------------------------------------------------------------
| Description : add an direntry
|
| Parameters  : fatfs, the pointer of fat filesystem structure
|               parent_direntry, the parent direntry of added on
|               direntry, the new direntry
| Returns     :
+------------------------------------------------------------------------------
*/
int fatfs_direntry_add(struct fat_filesystem* fatfs,
	struct fat_direntry* parent_direntry,
	struct fat_direntry* direntry)
{
    struct fat_direntry find_entry;
	sector_t  sector;
	cluster_t cluster;
    int first_entry = 0;
    int result, entries_found = 0, extend = 0;
	int idx;
    rt_uint8_t done;

	/* parameters check */
	if ( direntry == RT_NULL || parent_direntry == RT_NULL ) return -DFS_STATUS_EINVAL;

	cluster = parent_direntry->first_cluster;
	/* calculate the needed direntries */
    if ( fatfs->fat_type & FATTYPE_FAT32 )
    {
        /*
         * one dir entry needed for every 13 bytes of filename,
         * plus one entry for the short name
         */
        direntry->entries = (strlen(direntry->name) + (NAME_BYTES_PER_ENTRY - 1)) /
        	NAME_BYTES_PER_ENTRY + 1;
    }
    else direntry->entries = 1;

__restart:
	/* make shortname(8.3 dos name) */
    if ( direntry->entries > 1 ) fatfs_make_shortname( direntry->name, direntry->shortname, ++extend );
    else fatfs_make_shortname( direntry->name, direntry->shortname, 0 );

	/* check it's root directory or not, and then get the first sector */
    if ( parent_direntry->first_cluster == 0 ) sector = fatfs->root_dir_sector;
    else sector = first_sector_of_cluster(fatfs, parent_direntry->first_cluster);

	/* the initial offset */
	idx = sector * DIR_ENTRIES_PER_SECTOR;

    /* find a free direntry */
    done = 0;
	while (!done)
	{
		if ((result = fatfs_direntry_next(fatfs, &find_entry, idx)) == 0)
		{
			/* allocate a new direntry */
			sector_t new_sector;

			cluster = cluster_of_sector(fatfs, sector);
			new_sector = fatfs_cluster_allocate(fatfs, cluster, &cluster);
			if (new_sector == 0) return -DFS_STATUS_ENOSPC;

			if (fatfs->device->type != RT_Device_Class_MTD)
			{
				/* clean the allocated direntry cluster */
				fatfs_direntry_clean_cluster(fatfs, cluster);
			}

	        first_entry = entries_found? sector * DIR_ENTRIES_PER_SECTOR - entries_found :
	            new_sector * DIR_ENTRIES_PER_SECTOR;

			break;
		}
		else if (result < 0) return result;

		/* check entry */
		switch (find_entry.shortname[0])
		{
			/* idx, the old direntry offset
			   result, the end of direntry offset
			*/
		case 0xe5:
			/* save the first entry */
			if (entries_found == 0) first_entry = idx;

			entries_found ++;
			if (entries_found == direntry->entries) done = 1;
			break;

		case 0:
			if (entries_found == 0) first_entry = idx;
			done = 1;
			break;

		case 0xff:
			if (fatfs->device->type == RT_Device_Class_MTD)
			{
				if (entries_found == 0) first_entry = idx;
				done = 1;
				break;
			}
			/* else goto default case */
		default:
			/* reset found entries */
			entries_found = 0;

			/* reset first entry */
			first_entry = 0;
			if (strncasecmp(direntry->shortname, find_entry.shortname, 11) == 0)
			{
				/* found a short name entry */
				goto __restart;
			}
		}

		/* move to next direntry */
		idx = result;
	}

	/* update direntry */
	direntry->offset = first_entry;

	/* write entry */
	fatfs_direntry_write(fatfs, direntry);

    return result;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_direntry_write
+------------------------------------------------------------------------------
| Description : write an direntry to directory file
|
| Parameters  : fatfs, the pointer of fat filesystem structure
|               direntry, the specified direntry
| Returns     :
|               0 on successfully write,
|               DFS_STATUS_EINVAL,
|               DFS_STATUS_EIO,
+------------------------------------------------------------------------------
*/
int fatfs_direntry_write(struct fat_filesystem* fatfs,
	struct fat_direntry* direntry)
{
    rt_uint8_t buf[SECTOR_SIZE], *entry;
    sector_t  sector;
	cluster_t cluster;
    rt_uint8_t chksum;
	int idx;
    int result;
    int i;

	chksum = 0;
	if ( direntry == RT_NULL ) return -DFS_STATUS_EINVAL;

	sector 	= direntry->offset / DIR_ENTRIES_PER_SECTOR;
	cluster = cluster_of_sector(fatfs, sector);

    if ( (result = fat_read_sectors( fatfs, sector, 1, buf )) < 0 ) goto __return;

    /* calculate shortname checksum */
	chksum = fatfs_direntry_check_sum(direntry->shortname);

	idx = direntry->offset % DIR_ENTRIES_PER_SECTOR;
    for ( i = 0; i < direntry->entries; i++ )
    {
        /* read all of this sector, move to next sector */
        if ( idx >= DIR_ENTRIES_PER_SECTOR )
        {
            /* update current sector */
            if ( (result = fat_write_sectors(fatfs, sector, 1, buf)) < 0 ) goto __return;

			/* move to next sector */
			sector++;

            /* move to next cluster */
		    if ((sector - 1) % fatfs->bpb.bpb_secperclus == 0)
		    {
				cluster_t next_cluster;

		        next_cluster = fatfs_cluster_next(fatfs, cluster);

				/* should allocate a new cluster */
				if ( next_cluster == 0 )
				{
					next_cluster = fatfs_cluster_find_empty(fatfs, cluster);
					if ( next_cluster == 0)
					{
						result = -DFS_STATUS_ENOSPC;
						goto __return;
					}

					if (fatfs->device->type != RT_Device_Class_MTD)
					{
						/* clean new allocated direntry cluster */
						fatfs_direntry_clean_cluster(fatfs, next_cluster);
					}
					cluster = next_cluster;
				}

		        sector = first_sector_of_cluster(fatfs, cluster);
		    }

			/* read next sector */
            if ( (result = fat_read_sectors(fatfs, sector, 1, buf)) < 0 ) goto __return;

            idx = 0;
        }

		/* point to direntry */
        entry = buf + idx * DIR_ENTRY_SIZE;

        /* verify this entry is empty */
        if ( entry[0] && entry[0] != 0xe5 );

		/* clear this entry */
        memset(entry, 0, DIR_ENTRY_SIZE);

		/* for long name entry */
        if ( i + 1 < direntry->entries )
        {
            entry[FATLONG_ORDER] = direntry->entries - i - 1;

			/* mark this as last long entry */
            if (i == 0) entry[ FATLONG_ORDER ] |= 0x40;

			/* copy longname to direntry */
			fatfs_direntry_from_longname(direntry->entries - i - 1,
				direntry->name, entry);

            entry[FATDIR_ATTR] 		= FAT_ATTR_LONG_NAME;
            entry[FATDIR_FSTCLUSLO] = 0;
            entry[FATLONG_TYPE] 	= 0;
            entry[FATLONG_CHKSUM] 	= chksum;
        }
		/* shortname entry */
        else
        {
			/* copy short name */
			fatfs_direntry_from_shortname(direntry->shortname, &entry[FATDIR_NAME]);

            entry[FATDIR_ATTR] 	= direntry->attr;
            entry[FATDIR_NTRES] = 0;

            entry[FATDIR_CRTTIMETENTH] = direntry->create_time_tenth;
			SET16(&entry[FATDIR_CRTTIME], direntry->create_time);
			SET16(&entry[FATDIR_WRTTIME], direntry->write_time);
			SET16(&entry[FATDIR_LSTACCDATE], direntry->access_date);
			SET16(&entry[FATDIR_CRTDATE], direntry->create_date);
			SET16(&entry[FATDIR_WRTDATE], direntry->write_date);

			SET32(&entry[FATDIR_FILESIZE], direntry->file_size);
			SET16(&entry[FATDIR_FSTCLUSHI], direntry->first_cluster >> 16);
			SET16(&entry[FATDIR_FSTCLUSLO], direntry->first_cluster & 0xffffffff);
        }

        idx++;
    }

    /* update last sector */
    if ( (result = fat_write_sectors( fatfs, sector, 1, buf )) < 0 ) goto __return;

    return 0;

__return:
    return result;
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_direntry_remove
+------------------------------------------------------------------------------
| Description :
|
| Parameters  :
| Returns     :
|
+------------------------------------------------------------------------------
*/
int fatfs_direntry_remove(struct fat_filesystem* fatfs,
	struct fat_direntry* direntry)
{
    rt_uint8_t buf[SECTOR_SIZE], *entry;
	cluster_t cluster;
	sector_t  sector;
    rt_uint16_t idx, entries_needed;
    int result;

	result = 0;
	if ( direntry == RT_NULL ) return -DFS_STATUS_EINVAL;

	/* get the index of direntry */
	idx 	= direntry->offset % DIR_ENTRIES_PER_SECTOR;
	/* get sector & cluster */
	sector  = direntry->offset / DIR_ENTRIES_PER_SECTOR;
	cluster = cluster_of_sector(fatfs, sector);

	entries_needed = direntry->entries;

	/* read directory file */
    result = fat_read_sectors( fatfs, sector, 1, buf );
    if ( result < 0 ) return result; /* read disk IO error */

	while ( entries_needed )
	{
        /* read all of this sector, move to next sector */
        if ( idx >= DIR_ENTRIES_PER_SECTOR )
        {
            /* move to next sector */
		    if ((sector - 1) % fatfs->bpb.bpb_secperclus == 0)
		    {
		        cluster = fatfs_cluster_next (fatfs, cluster);
		        sector  = first_sector_of_cluster(fatfs, cluster);
		    }
		    else sector ++;

			/* read next sector */
            if ( (result = fat_read_sectors(fatfs, sector, 1, buf)) < 0 ) goto __return;

            sector++;
            idx = 0;
        }

		/* point to direntry */
        entry = buf + idx * DIR_ENTRY_SIZE;

		/* check direntry */
		if (fatfs->device->type == RT_Device_Class_MTD)
		{
			if (entry[FATDIR_NAME] == '\0' ||
				entry[FATDIR_NAME] == 0xff ||
				entry[FATDIR_NAME] == 0xe5)
				return -DFS_STATUS_ENOENT;
		}
		else
		{
			if ( entry[FATDIR_NAME] == '\0' || entry[FATDIR_NAME] == 0xe5)
				return -DFS_STATUS_ENOENT;
		}

		/* mark it as delete */
		entry[FATDIR_NAME] = 0xe5;

        idx++;
		entries_needed --;
	}

    /* update last sector */
    if ( (result = fat_write_sectors( fatfs, sector, 1, buf )) < 0 ) goto __return;
	result = 0;

__return:
	return result;
}

