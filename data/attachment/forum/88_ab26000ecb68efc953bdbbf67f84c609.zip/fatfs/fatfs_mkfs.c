/*
+------------------------------------------------------------------------------
| Project   : Device Filesystem
+------------------------------------------------------------------------------
| Copyright 2004, 2005  www.fayfayspace.org.
| All rights reserved.
|------------------------------------------------------------------------------
| File      : fatfs_cache.c
|------------------------------------------------------------------------------
| Chang Logs:
| Date           Author       Notes
| 2005-07-26     ffxz         The first version 
+------------------------------------------------------------------------------
*/

#include <dfs_def.h>

#define MK_FS_FAT12 12
#define MK_FS_FAT16	16
#define MK_FS_FAT32	32

#define SECTOR_SIZE 512

#define _cdiv(a, b) (((a) + (b) + 1)/ (b))

char msdos_boot_code[450] =
"\x0e"			  /* push cs */
"\x1f"			  /* pop ds */
"\xbe\x5b\x7c"		  /* mov si, offset message_txt */
/* write_msg: */
"\xac"			  /* lodsb */
"\x22\xc0"			  /* and al, al */
"\x74\x0b"			  /* jz key_press */
"\x56"			  /* push si */
"\xb4\x0e"			  /* mov ah, 0eh */
"\xbb\x07\x00"		  /* mov bx, 0007h */
"\xcd\x10"			  /* int 10h */
"\x5e"			  /* pop si */
"\xeb\xf0"			  /* jmp write_msg */
/* key_press: */
"\x32\xe4"			  /* xor ah, ah */
"\xcd\x16"			  /* int 16h */
"\xcd\x19"			  /* int 19h */
"\xeb\xfe"			  /* foo: jmp foo */
/* message_txt: */
"This is not a bootable disk.  Please insert a bootable floppy and\r\n"
"press any key to try again ... \r\n";

struct fat_format_struct
{
	/* BIOS Parameter Block struct define */
	struct _bpb
	{
		rt_uint8_t	bs_jmpboot[3];			/* Jump instruction to boot code */
		rt_uint8_t	bs_oemname[8];			/* OEM string, ending with \0 */
		unsigned bpb_bytspersec 	: 16 __attribute__ ((packed));    	/* Bytes per sectory, typically 512 */
		unsigned bpb_secperclus 	: 8  __attribute__ ((packed));    	/* Sectors per cluster */
		unsigned bpb_rsvdseccnt 	: 16 __attribute__ ((packed));    	/* Number of reserved sectors */
		unsigned bpb_numfats 		: 8  __attribute__ ((packed));		/* Number of FAT structures, typically 2 */
		unsigned bpb_rootentcnt 	: 16 __attribute__ ((packed));		/* Number of dir entries in the root */
		unsigned bpb_totsec16 		: 16 __attribute__ ((packed));		/* Number of sectors on the volume (old 16-bit) */
		unsigned bpb_media 			: 8  __attribute__ ((packed));		/* Media type (typically 0xf0 or 0xf8) */
		unsigned bpb_fatsz16 		: 16 __attribute__ ((packed));		/* Number of used sectors per FAT structure in FAT12/16 */
		unsigned bpb_secpertrk 		: 16 __attribute__ ((packed));		/* Number of sectors per track */
		unsigned bpb_numheads 		: 16 __attribute__ ((packed));		/* Number of heads */
		unsigned bpb_hiddsec_low	: 16 __attribute__ ((packed));		/* Hidden sectors before the volume */
		unsigned bpb_hiddsec_high	: 16 __attribute__ ((packed));		/* Hidden sectors before the volume */
		unsigned bpb_totsec32_low	: 16 __attribute__ ((packed));    	/* Number of sectors on the volume (new 32-bit) */
		unsigned bpb_totsec32_high	: 16 __attribute__ ((packed));		/* Number of sectors on the volume (new 32-bit) */
	}bpb;
	
	union
	{
		/**** FAT12/16 specific *****/
		struct _fat16_ext
		{
			rt_uint8_t	bs_drvnum 	__attribute__ ((packed));		/* Drive number */
			rt_uint8_t	bs_reseved1 __attribute__ ((packed));
			rt_uint8_t	bs_bootsig 	__attribute__ ((packed));		/* Is 0x29 if the following 3 fields are valid */
			int	bs_volid 	__attribute__ ((packed));       /* Volume ID */
			rt_uint8_t	bs_vollab[11];			/* Volume label, 11 chars plus \0 */
			rt_uint8_t	bs_filsystype[8];		/* File system type, 8 chars plus \0 */
		}fat16;
		
		/**** FAT32 specific *****/
		struct _fat32_ext
		{
			int	bpb_fatsz32 	__attribute__ ((packed));		/* Number of used sectors per FAT structure in FAT32 */
			rt_uint16_t	bpb_extflags	__attribute__ ((packed));		/* extra flags of FAT32 */
			rt_uint16_t	bpb_fsver 		__attribute__ ((packed));		/* FAT fs version */
			int	bpb_rootclus	__attribute__ ((packed));		/* Cluster number of the the first cluster of the root directory */
			rt_uint16_t	bpb_fsinfo 		__attribute__ ((packed));		/* */
			rt_uint16_t	bpb_bkbootsec	__attribute__ ((packed));
			rt_uint8_t	bpb_reseved[12] ;
			rt_uint8_t	bs_drvnum		__attribute__ ((packed));
			rt_uint8_t	bs_reseved1 	__attribute__ ((packed));
			rt_uint8_t	bs_bootsig 		__attribute__ ((packed));		/* Is 0x29 if the following 3 fields are valid */
			int	bs_volid 		__attribute__ ((packed));       /* Volume ID */
			rt_uint8_t	bs_vollab[11];      /* Volume label, 11 chars plus \0 */
			rt_uint8_t	bs_filsystype[8];	/* File system type, 8 chars plus \0 */
		}fat32;
	};

	int sectors_per_cluster;
	int cluster_size;
	int type;
	rt_device_t devno;
	
	struct device_geometry geometry;

	rt_uint8_t buffer[SECTOR_SIZE];	
};

/*
+------------------------------------------------------------------------------
| Function    : mk_bpb
+------------------------------------------------------------------------------
| Description : make BPB section of FAT filesystem
|
| Parameters  : _fmt, the structure used for format
| Returns     : empty
|
+------------------------------------------------------------------------------
*/
static void mk_bpb(struct fat_format_struct* _fmt)
{
	if ( _fmt->type == MK_FS_FAT12 || _fmt->type == MK_FS_FAT16)
	{
		_fmt->bpb.bs_jmpboot [0] = 0xeb;
		_fmt->bpb.bs_jmpboot [1] = 0x3c;
		_fmt->bpb.bs_jmpboot [2] = 0x90;
	}
	else 
	{
		_fmt->bpb.bs_jmpboot [0] = 0xeb;
		_fmt->bpb.bs_jmpboot [1] = 0x58;
		_fmt->bpb.bs_jmpboot [2] = 0x90;
	}

	memcpy(_fmt->bpb.bs_oemname , "DFS 100 ", 8);
	
	_fmt->bpb.bpb_bytspersec= SECTOR_SIZE;
									/* Count of bytes per sector. This value may 
									 * take on only the following values: 512, 
									 * 1024, 2048 or 4096.
									 */
	_fmt->bpb.bpb_rsvdseccnt= 1;	/* For FAT12 and FAT16 volumes, this value 
									 * should never beanything other than 1. For 
									 * FAT32 volumes, this value is typically 32.
									 */
	_fmt->bpb.bpb_numfats 	= 2;	/* recommand to 2 */
	_fmt->bpb.bpb_rootentcnt= 512;	/* For maximum compatibility, FAT16 volumes 
									 * should use the value 512. 
									 */ 
	_fmt->bpb.bpb_totsec16 	= _fmt->geometry.sector_count;

	if ( _fmt->devno->flag & RT_DEVICE_FLAG_REMOVABLE)
		_fmt->bpb.bpb_media = (char)0xf9;
	else _fmt->bpb.bpb_media= (char)0xf8;
	
	_fmt->bpb.bpb_secpertrk = _fmt->geometry.sectors_per_track;
	_fmt->bpb.bpb_numheads 	= _fmt->geometry.head_count;
	_fmt->bpb.bpb_hiddsec_low  = 0;
	_fmt->bpb.bpb_hiddsec_high = 0;
	
	if ( _fmt->type == MK_FS_FAT32 )
	{
		if ( _fmt->geometry.sector_count >= 65536 ) 
		{
			_fmt->bpb.bpb_totsec32_high = _fmt->geometry.sector_count;
			_fmt->bpb.bpb_totsec32_low  = 0;
		}
		else
		{
			_fmt->bpb.bpb_totsec32_high = 0;
			_fmt->bpb.bpb_totsec32_low  = _fmt->geometry.sector_count;
		}
	}
	else 
	{
		_fmt->bpb.bpb_totsec32_high = 0;
		_fmt->bpb.bpb_totsec32_low  = 0;
	}

	switch (_fmt->type)
	{
	case MK_FS_FAT12:
		memcpy( &(_fmt->fat16.bs_filsystype[0]), "FAT12   ", 8);
		
		_fmt->fat16.bs_drvnum 	= _fmt->bpb.bpb_media;
		_fmt->fat16.bs_reseved1 = 0;	/* always be 0 */
		_fmt->fat16.bs_bootsig 	= 0x29;	/* Extended boot signature */
		
		memcpy( &(_fmt->fat16.bs_volid),  "3322", 4);
		memcpy( &(_fmt->fat16.bs_vollab), "DFS 100     ", 11);

		break;
	case MK_FS_FAT16:
		memcpy( &(_fmt->fat16.bs_filsystype[0]), "FAT16   ", 8);
		
		_fmt->fat16.bs_drvnum 	= _fmt->bpb.bpb_media;	
		_fmt->fat16.bs_reseved1 = 0;	/* always be 0 */
		_fmt->fat16.bs_bootsig 	= 0x29;	/* Extended boot signature */
		
		memcpy( &(_fmt->fat16.bs_volid),  "3322", 4);
		memcpy( &(_fmt->fat16.bs_vollab), "DFS 100     ", 11);
		
		break;
	case MK_FS_FAT32:
		_fmt->bpb.bpb_totsec16 	= 0;

		_fmt->bpb.bpb_rsvdseccnt= 32;
		_fmt->bpb.bpb_rootentcnt= 0;

		_fmt->fat32.bpb_extflags= 0; /*fix me for FAT32*/
		_fmt->fat32.bpb_fsver 	= 0;
		_fmt->fat32.bpb_rootclus= 2; /* This is set to the cluster number of 
									 * the first cluster of the root directory, 
									 * usually 2 but not required to be 2.
									 */
		_fmt->fat32.bpb_fsinfo 	= 1;/* Sector number of FSINFO structure in the
									 * reserved area of the FAT32 volume. Usually 1.
									 */
		_fmt->fat32.bpb_bkbootsec= 6;/* If non-zero, indicates the sector number
									 * in the reserved area of the volume of a 
									 * copy of the boot record. Usually 6. No 
									 * value other than 6 is recommended.
									 */
		memset( _fmt->fat32.bpb_reseved, 0, 12);
									/* Code that formats FAT32 volumes should
									 * always set all of the bytes of this field 
									 * to 0.
									 */
		_fmt->fat32.bs_drvnum 	= 0x80;/* always look it as hard driver */
		_fmt->fat32.bs_reseved1 = 0;		
		_fmt->fat32.bs_bootsig 	= 0x29;/* Extended boot signature */
		
		memcpy(&(_fmt->fat32.bs_volid), "3322", 4);
		memcpy(&(_fmt->fat32.bs_vollab), "DFS 100     ", 11);

		memcpy(&(_fmt->fat32.bs_filsystype[0]), "FAT32   ", 8);
		break;
	}
}

/*
+------------------------------------------------------------------------------
| Function    : mk_resever_sectors
+------------------------------------------------------------------------------
| Description : clean resevered sectors of FAT filesystem
|
| Parameters  : _fmt, the structure used for format
| Returns     : empty
|
+------------------------------------------------------------------------------
*/
static void mk_resever_sectors(struct fat_format_struct *_fmt)
{
	int index = 0;

	memset(_fmt->buffer, 0, sizeof(_fmt->buffer));

	while (index < _fmt->bpb.bpb_rsvdseccnt)
	{
		/* ignore some sectors */
		if (_fmt->type == MK_FS_FAT32)
		{
			if (index == 0 || 
				index == 1 || 
				index == 2 || 
				index == 7 || 
				index == 8 ||
				index == _fmt->fat32.bpb_bkbootsec )
			{
				index ++;
				continue;
			}
		}
		else
		{
			if (index == 0) 
			{
				index ++;
				continue;
			}
		}

		rt_device_write(_fmt->devno, index * SECTOR_SIZE, _fmt->buffer, SECTOR_SIZE);
		index ++;
	} 
}

/*
+------------------------------------------------------------------------------
| Function    : mk_fat_tables
+------------------------------------------------------------------------------
| Description : make FAT table of FAT filesystem
|
| Parameters  : _fmt, the structure used for format
| Returns     : empty
|
+------------------------------------------------------------------------------
*/
static void mk_fat_tables(struct fat_format_struct* _fmt)
{
	int index, fat_size;

	if (_fmt->devno->type == RT_Device_Class_MTD) memset(_fmt->buffer, 0xff, SECTOR_SIZE);
	else memset(_fmt->buffer, 0, SECTOR_SIZE);

	_fmt->buffer[0] = _fmt->bpb.bpb_media;
	_fmt->buffer[1] = 0xff;
	_fmt->buffer[2] = 0xff;

	if ( _fmt->type == MK_FS_FAT16 ) _fmt->buffer[3] = 0xff;
	else if ( _fmt->type == MK_FS_FAT32 ) 
	{
		_fmt->buffer[3] = 0x0f;
		_fmt->buffer[4] = 0xff;
		_fmt->buffer[5] = 0xff;
		_fmt->buffer[6] = 0xff;
		_fmt->buffer[7] = 0x0f;
		_fmt->buffer[8] = 0xff;
		_fmt->buffer[9] = 0xff;
		_fmt->buffer[10] = 0xff;
		_fmt->buffer[11] = 0x0f;
	}

	/* write FAT table */
	index = 0;
	fat_size = _fmt->bpb.bpb_fatsz16? _fmt->bpb.bpb_fatsz16 : _fmt->fat32.bpb_fatsz32 ;
	while ( index < _fmt->bpb.bpb_numfats)
	{
		rt_device_write(_fmt->devno, 
			(_fmt->bpb.bpb_rsvdseccnt + index * fat_size) * SECTOR_SIZE, 
			_fmt->buffer, 
			SECTOR_SIZE);

		index ++;
	}

	if (_fmt->devno->type == RT_Device_Class_Block) memset(_fmt->buffer, 0xff, SECTOR_SIZE);
	else memset(_fmt->buffer, 0, SECTOR_SIZE);
	
	for (index = 1; index < fat_size; index ++)
	{
		int num;

		/* write each fat item of fat table to empty */
		for (num = 0; num < _fmt->bpb.bpb_numfats; num ++)
		{
			rt_device_write(_fmt->devno,
				(_fmt->bpb.bpb_rsvdseccnt + index + fat_size * num) * SECTOR_SIZE,
				_fmt->buffer,
				SECTOR_SIZE);
		}
	}
}

/*
+------------------------------------------------------------------------------
| Function    : mk_info
+------------------------------------------------------------------------------
| Description : make info sector of FAT32 filesystem
|
| Parameters  : _fmt, the structure used for format
| Returns     : empty
|
+------------------------------------------------------------------------------
*/
static void mk_info(struct fat_format_struct* _fmt)
{
	static struct
	{
		unsigned long    lead_signature;
		char             reserved_1[480];
		unsigned long    struc_signature;
		unsigned long    free_count;
		unsigned long    next_free;
		char             reserved_2[12];
		unsigned long    trailing_signature;
	}fs_info_sector;

	char* fs_info = (char*)(&fs_info_sector);
	
	memset(fs_info, 0, sizeof(fs_info_sector));

	fs_info_sector.lead_signature     =0x41615252L;
	fs_info_sector.struc_signature    =0x61417272L;
	// fs_info_sector.free_count      = file_sys_info.total_clusters - 1; // FIXME
	
	/* 1 cluster used by root directory */
	fs_info_sector.next_free          =0x2;
	fs_info_sector.trailing_signature =0xaa550000L;

	memcpy(&(_fmt->buffer[0]), (char *)(&fs_info_sector), SECTOR_SIZE);
}

/*
+------------------------------------------------------------------------------
| Function    : mk_root_directory
+------------------------------------------------------------------------------
| Description : clean root directory for FAT12/16 filesystem
|
| Parameters  : _fmt, the structure used for format
| Returns     : empty
|
+------------------------------------------------------------------------------
*/
static void mk_root_directory(struct fat_format_struct *_fmt)
{
	int index, start_root_dir_sector;

	/* just clean root directory sector */
	if (_fmt->devno->type == RT_Device_Class_Block) memset(_fmt->buffer, 0xff, sizeof(_fmt->buffer));
	else memset(_fmt->buffer, 0, sizeof(_fmt->buffer));

	start_root_dir_sector = _fmt->bpb.bpb_rsvdseccnt + 
		(_fmt->bpb.bpb_fatsz16? _fmt->bpb.bpb_fatsz16 : _fmt->fat32.bpb_fatsz32) * _fmt->bpb.bpb_numfats ;
	
	index = start_root_dir_sector;
	while ( index < start_root_dir_sector + (_fmt->bpb.bpb_rootentcnt * 32 / _fmt->bpb.bpb_bytspersec))
	{
		rt_device_write(_fmt->devno, index * SECTOR_SIZE, _fmt->buffer, SECTOR_SIZE);
		index ++;
	} 
}

/*
+------------------------------------------------------------------------------
| Function    : mk_fat_type
+------------------------------------------------------------------------------
| Description : make sure the FAT type
|
| Parameters  : _fmt, the structure used for format
| Returns     : empty 
|
+------------------------------------------------------------------------------
*/
static void mk_fat_type(struct fat_format_struct* _fmt)
{
	int fatlength12, fatlength16, fatlength32;
	int maxclust12, maxclust16, maxclust32;
	int clust12, clust16, clust32;
	char cluster_size;
	int max_clust_size = 128, fatdata;

	/* to determinate the FAT type */
	if ( _fmt->geometry.sector_count < 32768 ) _fmt->type = MK_FS_FAT12;
	else if ( _fmt->geometry.sector_count  > 4194303 ) _fmt->type = MK_FS_FAT32;
	else if ( _fmt->type == MK_FS_FAT32 && _fmt->geometry.sector_count  >= 66560 ) _fmt->type = MK_FS_FAT32;
	else _fmt->type = MK_FS_FAT16;
	
	fatdata = _fmt->geometry.sector_count - (_fmt->type == MK_FS_FAT32? 32 : 1);

	if (_fmt->type == MK_FS_FAT32) cluster_size = (char)(_fmt->geometry.sector_count > 524488? 8:1);
	else cluster_size = (char)4; /* the minimal sector of cluster is 4 */

	do
	{
		/* FIXME: long long div of gcc */
		clust12 = (long) fatdata * SECTOR_SIZE / (cluster_size * SECTOR_SIZE + 3);
		fatlength12 = _cdiv ((clust12 * 3 + 1) >> 1, SECTOR_SIZE);
		maxclust12 = (fatlength12 * 2 * SECTOR_SIZE) / 3;
		if (maxclust12 > 4086) maxclust12 = 4086;
		if (clust12 > maxclust12) clust12 = 0;

		clust16 = (long) fatdata * SECTOR_SIZE / (cluster_size * SECTOR_SIZE + 4);
		fatlength16 = _cdiv (clust16 * 2, SECTOR_SIZE);
		maxclust16 = (fatlength16 * SECTOR_SIZE) / 2;
		if (maxclust16 > 65526) maxclust16 = 65526;
		if (clust16 > maxclust16) clust16 = 0;

		clust32 = (long) fatdata * SECTOR_SIZE / ( cluster_size * SECTOR_SIZE + 4);
		fatlength32 = _cdiv (clust32 * 4, SECTOR_SIZE);
		maxclust32 = (fatlength32 * SECTOR_SIZE) / 4;
		if (maxclust32 > 0xffffff6) maxclust32 = 0xffffff6;
		if (clust32 > maxclust32) clust32 = 0;

		if ((clust12 && (_fmt->type == 12 || _fmt->type == 0)) ||
			(clust16 && (_fmt->type == 16 || _fmt->type == 0)) ||
			(clust32 && (_fmt->type == 32)))
			break;

		cluster_size <<= 1;
	}while (cluster_size <= max_clust_size);

	if ( _fmt->type )_fmt->type = (clust16 > clust12? MK_FS_FAT16 : MK_FS_FAT12);

	switch ( _fmt->type )
	{
	case MK_FS_FAT12:
		_fmt->bpb.bpb_secperclus = cluster_size;
		_fmt->bpb.bpb_fatsz16	 = fatlength12;
		break;

	case MK_FS_FAT16:
		_fmt->bpb.bpb_secperclus = cluster_size;
		_fmt->bpb.bpb_fatsz16	 = fatlength16;
		break;

	case MK_FS_FAT32:
		_fmt->bpb.bpb_secperclus = cluster_size;
		_fmt->bpb.bpb_fatsz16 	 = 0;
		_fmt->fat32.bpb_fatsz32  = fatlength32;
		break;
	}
}

/*
+------------------------------------------------------------------------------
| Function    : fatfs_mkfs
+------------------------------------------------------------------------------
| Description : format disk to FAT filesystem
|
| Parameters  : device, device name of disk 
|               type, the type of FAT filesytem (FAT12/16/32)
| Returns     : empty
|
+------------------------------------------------------------------------------
*/
void fatfs_mkfs(const char* device, int type)
{
	struct fat_format_struct _fmt;

	_fmt.devno = rt_device_find(device);
	if ( _fmt.devno == DEVICES_MAX ) return;

	/* format device */
	rt_device_control(_fmt.devno, DEVICE_FORMAT, RT_NULL);

	/* get geometry of block device */
	if ( rt_device_control(_fmt.devno, DEVICE_GETGEOME, &_fmt.geometry) < 0 ) return;

	/* open device */
 	if ( rt_device_open (_fmt.devno, RT_DEVICE_OFLAG_RDWR) < 0 ) return;

	/* make a FAT filesytem type */
	_fmt.type = type;
	mk_fat_type(&_fmt);

	/* to determinate the sectors per cluster and cluster size */
	mk_bpb(&_fmt);

	memcpy(&_fmt.buffer[0], &(_fmt.bpb), sizeof(_fmt.bpb));
	if ( _fmt.type == MK_FS_FAT32 ) 
	{
		memcpy(&_fmt.buffer[36], &(_fmt.fat32), sizeof(_fmt.fat32));
		memcpy(&_fmt.buffer[90], msdos_boot_code, 130);
	}
	else
	{
		memcpy(&_fmt.buffer[36], &(_fmt.fat16), sizeof(_fmt.fat16));
		memcpy(&_fmt.buffer[62], msdos_boot_code, 130);
	}

	_fmt.buffer[510] = 0x55;
	_fmt.buffer[511] = 0xaa;

	/* write boot sector */
	rt_device_write(_fmt.devno, 0 * SECTOR_SIZE, _fmt.buffer, SECTOR_SIZE);

	/* write FAT32 relevant sector */
	if ( _fmt.type == MK_FS_FAT32 )
	{
		/* write a copy of boot sector to fat32::bkbootsec for backup */
		rt_device_write(_fmt.devno, _fmt.fat32.bpb_bkbootsec * SECTOR_SIZE, _fmt.buffer, SECTOR_SIZE);

		/* make info sector */
		mk_info(&_fmt);
		rt_device_write(_fmt.devno, 1 * SECTOR_SIZE, _fmt.buffer, SECTOR_SIZE);
		rt_device_write(_fmt.devno, 7 * SECTOR_SIZE, _fmt.buffer, SECTOR_SIZE);

		/* write the end of sector */
		memset(_fmt.buffer, 0, SECTOR_SIZE);
		_fmt.buffer[510] = 0x55;
		_fmt.buffer[511] = 0xaa;
		rt_device_write(_fmt.devno, 2 * SECTOR_SIZE, _fmt.buffer, SECTOR_SIZE);
		rt_device_write(_fmt.devno, 8 * SECTOR_SIZE, _fmt.buffer, SECTOR_SIZE);
	}

	/* clear resevered sectors */
	mk_resever_sectors(&_fmt);

	mk_fat_tables(&_fmt);
	mk_root_directory(&_fmt);

	rt_device_close(_fmt.devno);
}

int __d_cmd_mkfatfs(char* device, int type)
{
	if (device != RT_NULL) 
	{
		fatfs_mkfs(device, type);
	}

	return 0;
}
