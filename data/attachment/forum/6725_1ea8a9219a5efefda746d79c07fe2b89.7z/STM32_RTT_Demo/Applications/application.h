/*
 * File      : APPLICATION.h
 *
 * Change Logs:
 * Date           Author       Notes
 * 2014-06-07     LI.Guang     the first version
 */

#ifndef __APPLICATION_H__
#define __APPLICATION_H__

#include <rtthread.h>


static void test_thread_entry(void* parameter);
static void led_thread_entry(void* parameter);


#endif
