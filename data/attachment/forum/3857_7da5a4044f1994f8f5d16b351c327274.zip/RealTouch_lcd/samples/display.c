#include "display.h"
#include "fonts.h"
#include "ra8875.h"

static sFONT *_current_font = &Font16x24;



void display_setfont(sFONT *font)
{
    _current_font = font;
}

sFONT* display_getfont(void)
{
    return (_current_font);
}

void display_drawascii(char c, uint16_t x, uint16_t y, uint16_t color)
{
    const uint16_t *pdata;
	uint16_t data;
	uint16_t pos;
	uint16_t line,column;
	uint16_t white = 0xFFFF;
	/* ASCII�����ǰ32���ַ�Ϊ�����ַ���������ʾ */
    pos = (c - 32) * _current_font->Height;
	/* ��ȡ�����ַ */
	pdata = &_current_font->Table[pos];
    
	for (line = y; line < y + _current_font->Height; line ++)
	{
	    /* ȡ�������һ�е������� */
	    data = *pdata;
		/* ָ����һ�� */
		pdata ++;
		/* �����еĸ������� */
		for (column = x; column < x + _current_font->Width; column ++)
		{
		    if (data & 0x01)
			{
			    /* ��ʾǰ��ɫcolor */
			    ra8875_lcd_set_pixel(&color, column, line);
			}
			else
			{
			    /* ��ʾ��ɫ���� */
			    ra8875_lcd_set_pixel(&white, column, line);
			}
			
			data >>= 1;
		}	
	}
}

void display_drawstring(char *str, uint16_t x, uint16_t y, uint16_t color)
{
    uint16_t line,column;
	
	line = y,column = x;
	
	while (*str != '\0')
	{		
		if ((column + _current_font->Width) < 800)
		{
		    column += _current_font->Width;
		}
		else
		{
		    column = 0;
			
			if ((line + _current_font->Height) < 480)
			{
			    line += _current_font->Height;
			}
			else
			{
			    line = 0;
			}
		}
		
		display_drawascii(*str, column, line, color);
        str ++;		
	}

}










