#include "stm32f4xx.h"
#include "uart.h"
#include "ra8875.h"
#include "display.h"



int main(void)
{	
    uart_init();
	
	debug("Hello RealTouch\n");
	
	ra8875_init();
    display_drawstring("Hello RealTouch", 250, 200, 0);
 
	for (;;);
	
	return 0;
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{
    /* User can add his own implementation to report the file name and line number,
       ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

    /* Infinite loop */
    while (1)
    {}
}
#endif
