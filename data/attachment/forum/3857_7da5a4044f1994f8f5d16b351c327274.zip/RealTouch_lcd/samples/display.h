#ifndef  __DISPLAY_H__
#define  __DISPLAY_H__

#include "fonts.h"

void display_setfont(sFONT *font);
sFONT* display_getfont(void); 
void display_drawascii(char c, uint16_t x, uint16_t y, uint16_t color);
void display_drawstring(char *str, uint16_t x, uint16_t y, uint16_t color);



#endif
