#ifndef __RA8875_H__
#define __RA8875_H__

/* RA8875 register list */
#define PWRR            0x01    /* Power and Display Control Register */
#define MRWC            0x02    /* Memory Read/Write Command */
#define PCSR            0x04    /* Pixel Clock Setting Register */
#define SROC            0x05    /* Serial Flash/ROM Configuration Register */
#define SFCLR           0x06    /* Serial Flash/ROM CLK Setting Register */
#define SYSR            0x10    /* System Configuration Register */
#define DPCR            0x20    /* Display Configuration Register */

#define MWCR0           0x40    /* Memory Write Control Register 0 */
#define MWCR1           0x41    /* Memory Write Control Register 1 */
#define MRCD            0x45    /* Memory Read Cursor Direction. */

#define CURH0           0x46    /* Memory Write Cursor Horizontal Position Register 0 */
#define CURH1           0x47    /* Memory Write Cursor Horizontal Position Register 1 */
#define CURV0           0x48    /* Memory Write Cursor Vertical Position Register 0 */
#define CURV1           0x49    /* Memory Write Cursor Vertical Position Register 1 */

#define RCURH0          0x4A    /* Memory read Cursor Horizontal Position Register 0 */
#define RCURH1          0x4B    /* Memory read Cursor Horizontal Position Register 1 */
#define RCURV0          0x4C    /* Memory read Cursor Vertical Position Register 0 */
#define RCURV1          0x4D    /* Memory read Cursor Vertical Position Register 1 */

#define P1CR            0x8A    /* PWM1 Control Register */
#define P1DCR           0x8B    /* PWM1 Duty Cycle Register */

#define GPIOX           0xC7    /* Extra General Purpose IO Register */

#define TEST            0x00    /*  */


#define NULL (void*)0

void ra8875_init(void);

void ra8875_lcd_blit_line(const uint16_t* pixels, int x, int y, uint16_t size);
void ra8875_lcd_draw_vline(const uint16_t* pixel, int x, int y1, int y2);
void ra8875_lcd_draw_hline(const uint16_t* pixel, int x1, int x2, int y);
void ra8875_lcd_get_pixel(char* pixel, int x, int y);
void ra8875_lcd_set_pixel(const uint16_t* pixel, int x, int y);


#endif
