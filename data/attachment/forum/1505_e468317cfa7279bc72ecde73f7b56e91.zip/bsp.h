/*********************************************************************************************************
 *
 *                                        CPU���ڲ�IO���ⲿ�豸�ȳ�ʼ��
 *
 * Filename      : bsp.h
 * Version       : V1.00
 * Programmer(s) : wangyong
 *********************************************************************************************************/

#ifndef  __BSP_H
#define  __BSP_H


/////////////////////////////////ͷ�ļ�����///////////////////////////////////////////////
#include <stdio.h>
#include "stm32f10x.h"
#include "timer_api.h"
#include "led_api.h" 
#include "lcd_api.h" 
#include "touch_api.h"

/////////////////////////////////�궨��///////////////////////////////////////////////////

/////////////////////////////////��������/////////////////////////////////////////////////

/////////////////////////////////�ڲ���������/////////////////////////////////////////////


/////////////////////////////////�ⲿ��������/////////////////////////////////////////////


/////////////////////////////////��������/////////////////////////////////////////////////

/*******************************************************************************
 * Function Name  : BSP_Init
 * Description    : ��ʼ��������֧�ֵ�Ӳ��������Initialize the Board Support Package (BSP).
 * Input          : None
 * Output         : None
 * Return         : None
 *******************************************************************************/
void BSP_Init(void);

/*******************************************************************************
 * Function Name  : RCC_Configuration
 * Description    : STM32��λ��ʱ�ӿ��� Reset and clock control (RCC).
 * Input          : None
 * Output         : None
 * Return         : None
 *******************************************************************************/
void RCC_Configuration(void);

/*******************************************************************************
 * Function Name  : EXTI_Configuration
 * Description    : STM32�ж�(EXTI)��������.
 * Input          : None
 * Output         : None
 * Return         : None
 *******************************************************************************/
void EXTI_Configuration(void);

/*******************************************************************************
 * Function Name  : NVIC_Configuration
 * Description    : �ж���������ʼ��.
 * Input          : None
 * Output         : None
 * Return         : None
 *******************************************************************************/
void NVIC_Configuration(void);

/*******************************************************************************
 * Function Name  : GPIO_Configuration
 * Description    : STM32 GPIO����.
 * Input          : None
 * Output         : None
 * Return         : None
 *******************************************************************************/
void GPIO_Configuration(void);

/*******************************************************************************
 * Function Name  : USART_Configuration
 * Description    : ���ڳ�ʼ��.
 * Input          : None
 * Output         : None
 * Return         : None
 *******************************************************************************/
void USART_Configuration(void);

/*******************************************************************************
 * Function Name  : FSMC_Configuration
 * Description    : FSMC���ľ�̬�洢����������ʼ��.
 * Input          : None
 * Output         : None
 * Return         : None
 *******************************************************************************/
void FSMC_Configuration(void);

/*******************************************************************************
 * Function Name  : SPI_Configuration
 * Description    : SPI��������ӿڳ�ʼ��.
 * Input          : None
 * Output         : None
 * Return         : None
 *******************************************************************************/
void SPI_Configuration(void);

/*******************************************************************************
 * Function Name  : SysTick_Configuration
 * Description    : SysTickϵͳ��ળ�ʼ��.���Ѿ���timer_apiʹ�÷ǿ���ʽʵ�֣�
 * Input          : None
 * Output         : None
 * Return         : None
 *******************************************************************************/
void SysTick_Configuration(void);

/*******************************************************************************
* Function Name  : fputc
* Description    : �ض���printfΪ�������Retargets the C library printf function to the USART.
* Input          : --ch:�ַ�
*                  --f :�豸���
* Output         : None
* Return         : None
*******************************************************************************/
int fputc(int ch, FILE *f);

#endif
