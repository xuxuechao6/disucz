/***************************************************************
 * Name:      hdc_conversionApp.h
 * Purpose:   Defines Application Class
 * Author:    aozima (master@aozima.cn)
 * Created:   2009-12-26
 * Copyright: aozima (www.aozima.com)
 * License:
 **************************************************************/

#ifndef HDC_CONVERSIONAPP_H
#define HDC_CONVERSIONAPP_H

#include <wx/app.h>

class hdc_conversionApp : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // HDC_CONVERSIONAPP_H
