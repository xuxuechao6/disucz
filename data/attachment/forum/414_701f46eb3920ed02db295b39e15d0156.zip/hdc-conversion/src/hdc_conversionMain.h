/***************************************************************
 * Name:      hdc_conversionMain.h
 * Purpose:   Defines Application Frame
 * Author:    aozima (master@aozima.cn)
 * Created:   2009-12-26
 * Copyright: aozima (www.aozima.com)
 * License:
 **************************************************************/

#ifndef HDC_CONVERSIONMAIN_H
#define HDC_CONVERSIONMAIN_H

//(*Headers(hdc_conversionFrame)
#include <wx/sizer.h>
#include <wx/stattext.h>
#include <wx/panel.h>
#include <wx/statbmp.h>
#include <wx/button.h>
#include <wx/frame.h>
#include <wx/combobox.h>
#include <wx/statusbr.h>
//*)

class hdc_conversionFrame: public wxFrame
{
    public:

        hdc_conversionFrame(wxWindow* parent,wxWindowID id = -1);
        virtual ~hdc_conversionFrame();

        //(*Declarations(hdc_conversionFrame)
        wxButton* save_hdc_file;
        wxStaticText* Text_info;
        wxPanel* Panel4;
        wxButton* open_image;
        wxPanel* Panel_image;
        wxStaticText* StaticText1;
        wxButton* save_image;
        wxPanel* Panel_file;
        wxStatusBar* StatusBar1;
        wxStaticBitmap* image_view;
        wxComboBox* ComboBox1;
        wxPanel* Panel_info;
        wxPanel* Panel2;
        wxPanel* Panel_main;
        wxButton* load_hdc_file;
        //*)

    private:

        //(*Handlers(hdc_conversionFrame)
        void OnButton_load_hdc_fileClick(wxCommandEvent& event);
        void Onopen_imageClick(wxCommandEvent& event);
        void Onsave_hdc_fileClick(wxCommandEvent& event);
        //*)

        //(*Identifiers(hdc_conversionFrame)
        static const long ID_STATICTEXT1;
        static const long ID_BUTTON1;
        static const long ID_BUTTON2;
        static const long ID_PANEL5;
        static const long ID_COMBOBOX1;
        static const long ID_BUTTON3;
        static const long ID_BUTTON4;
        static const long ID_PANEL6;
        static const long ID_PANEL2;
        static const long ID_STATICBITMAP1;
        static const long ID_PANEL3;
        static const long ID_STATICTEXT2;
        static const long ID_PANEL4;
        static const long ID_PANEL1;
        static const long ID_STATUSBAR1;
        //*)

        DECLARE_EVENT_TABLE()
};

#endif // HDC_CONVERSIONMAIN_H
