#ifndef FILE_LOAD_H_INCLUDED
#define FILE_LOAD_H_INCLUDED

#include "hdc_conversionMain.h"

extern void hdc_load(hdc_conversionFrame* frame_main,wxString path);
extern void image_open(hdc_conversionFrame * frame_main,wxString path);

#endif // FILE_LOAD_H_INCLUDED
