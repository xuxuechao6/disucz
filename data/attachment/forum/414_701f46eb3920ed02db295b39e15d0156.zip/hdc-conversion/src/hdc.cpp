#include <wx/image.h>

wxImage image_cov;
