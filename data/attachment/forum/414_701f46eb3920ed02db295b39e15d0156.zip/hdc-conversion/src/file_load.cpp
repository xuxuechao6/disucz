#include "hdc_conversionMain.h"
#include <wx/file.h>
#include <wx/image.h>
#include "hdc.h"

void hdc_load(hdc_conversionFrame* frame_main,wxString path)
{
    wxFile hdc_file;

    if(hdc_file.Open(path,wxFile::read) == true)
    {
        unsigned char * ptr;
        unsigned int w,h;
        wxString out = _("\r\nhdc file load OK! size:");
        out << hdc_file.Length();

        //read file data
        ptr = (unsigned char *)malloc(hdc_file.Length());
        hdc_file.Read(ptr,hdc_file.Length());

        w = *(unsigned int *)(ptr+0x04);
        h = *(unsigned int *)(ptr+0x08);
        out << _("width:") << w << _("height:") << h;

        //show image
        image_cov.Create(w,h,true);
        {
            unsigned short * tmp = (unsigned short *)(ptr+0x14);
            unsigned int a;
            unsigned char * to = (unsigned char *)malloc(w*h*3);

            //为数据申请空间,不必free,此空间以后由wximage管理
            image_cov.SetData(to);
            for(a=0; a<w*h; a++)
            {
                *to++ = ((*tmp>>11)&0x1F)<<3;//R
                *to++ = ((*tmp>> 5)&0x3F)<<2;//G
                *to++ = ((*tmp    )&0x1F)<<3;//B
                tmp++;
            }
        }

        frame_main->image_view->SetBitmap(image_cov);
        frame_main->Panel_image->Refresh();

        free(ptr);
        {
            wxString out = _("width:");
            out << image_cov.GetWidth();
            out << _(" height:") << image_cov.GetHeight();
            frame_main->Text_info->SetLabel(out);
        }
    }
}

void image_open(hdc_conversionFrame * frame_main,wxString path)
{
    if(image_cov.LoadFile(path,wxBITMAP_TYPE_ANY) == true)
    {
        frame_main->image_view->SetBitmap(image_cov);
        frame_main->Panel_image->Refresh();
        wxString out = _("width:");
        out << image_cov.GetWidth();
        out << _(" height:") << image_cov.GetHeight();
        frame_main->Text_info->SetLabel(out);
    }
    else
    {
        frame_main->Text_info->SetLabel(_("Can't open the image!!"));
    }
}
