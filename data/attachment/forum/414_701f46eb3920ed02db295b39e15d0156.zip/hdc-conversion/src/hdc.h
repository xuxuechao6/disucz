#ifndef HDC_H_INCLUDED
#define HDC_H_INCLUDED

extern wxImage image_cov;

#endif // HDC_H_INCLUDED
