/***************************************************************
 * Name:      hdc_conversionMain.cpp
 * Purpose:   Code for Application Frame
 * Author:    aozima (master@aozima.cn)
 * Created:   2009-12-26
 * Copyright: aozima (www.aozima.com)
 * License:
 **************************************************************/

#include "hdc_conversionMain.h"
#include <wx/msgdlg.h>
#include <wx/filedlg.h>
#include <wx/file.h>
#include <wx/image.h>
#include "hdc.h"
#include "file_load.h"

//(*InternalHeaders(hdc_conversionFrame)
#include <wx/settings.h>
#include <wx/intl.h>
#include <wx/string.h>
//*)

//(*IdInit(hdc_conversionFrame)
const long hdc_conversionFrame::ID_STATICTEXT1 = wxNewId();
const long hdc_conversionFrame::ID_BUTTON1 = wxNewId();
const long hdc_conversionFrame::ID_BUTTON2 = wxNewId();
const long hdc_conversionFrame::ID_PANEL5 = wxNewId();
const long hdc_conversionFrame::ID_COMBOBOX1 = wxNewId();
const long hdc_conversionFrame::ID_BUTTON3 = wxNewId();
const long hdc_conversionFrame::ID_BUTTON4 = wxNewId();
const long hdc_conversionFrame::ID_PANEL6 = wxNewId();
const long hdc_conversionFrame::ID_PANEL2 = wxNewId();
const long hdc_conversionFrame::ID_STATICBITMAP1 = wxNewId();
const long hdc_conversionFrame::ID_PANEL3 = wxNewId();
const long hdc_conversionFrame::ID_STATICTEXT2 = wxNewId();
const long hdc_conversionFrame::ID_PANEL4 = wxNewId();
const long hdc_conversionFrame::ID_PANEL1 = wxNewId();
const long hdc_conversionFrame::ID_STATUSBAR1 = wxNewId();
//*)

BEGIN_EVENT_TABLE(hdc_conversionFrame,wxFrame)
    //(*EventTable(hdc_conversionFrame)
    //*)
END_EVENT_TABLE()

hdc_conversionFrame::hdc_conversionFrame(wxWindow* parent,wxWindowID id)
{
    //(*Initialize(hdc_conversionFrame)
    wxBoxSizer* BoxSizer4;
    wxBoxSizer* BoxSizer6;
    wxBoxSizer* BoxSizer5;
    wxBoxSizer* BoxSizer2;
    wxBoxSizer* BoxSizer1;
    wxBoxSizer* BoxSizer3;

    Create(parent, wxID_ANY, _("hdc-conversion"), wxDefaultPosition, wxDefaultSize, wxDEFAULT_FRAME_STYLE, _T("wxID_ANY"));
    SetClientSize(wxSize(700,700));
    Move(wxPoint(300,100));
    SetMinSize(wxSize(400,600));
    SetBackgroundColour(wxSystemSettings::GetColour(wxSYS_COLOUR_MENUBAR));
    Panel_main = new wxPanel(this, ID_PANEL1, wxDefaultPosition, wxDefaultSize, wxTAB_TRAVERSAL, _T("ID_PANEL1"));
    Panel_main->SetFocus();
    BoxSizer1 = new wxBoxSizer(wxVERTICAL);
    Panel_file = new wxPanel(Panel_main, ID_PANEL2, wxDefaultPosition, wxDefaultSize, wxTAB_TRAVERSAL, _T("ID_PANEL2"));
    BoxSizer3 = new wxBoxSizer(wxHORIZONTAL);
    Panel2 = new wxPanel(Panel_file, ID_PANEL5, wxDefaultPosition, wxDefaultSize, wxTAB_TRAVERSAL, _T("ID_PANEL5"));
    Panel2->SetBackgroundColour(wxColour(192,192,192));
    BoxSizer4 = new wxBoxSizer(wxVERTICAL);
    StaticText1 = new wxStaticText(Panel2, ID_STATICTEXT1, _("support bmp jpeg"), wxDefaultPosition, wxDefaultSize, 0, _T("ID_STATICTEXT1"));
    BoxSizer4->Add(StaticText1, 1, wxALL|wxALIGN_LEFT|wxALIGN_BOTTOM, 5);
    open_image = new wxButton(Panel2, ID_BUTTON1, _("open_image"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON1"));
    BoxSizer4->Add(open_image, 1, wxALL|wxALIGN_LEFT|wxALIGN_BOTTOM, 5);
    save_image = new wxButton(Panel2, ID_BUTTON2, _("save_image"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON2"));
    BoxSizer4->Add(save_image, 1, wxALL|wxALIGN_LEFT|wxALIGN_BOTTOM, 5);
    Panel2->SetSizer(BoxSizer4);
    BoxSizer4->Fit(Panel2);
    BoxSizer4->SetSizeHints(Panel2);
    BoxSizer3->Add(Panel2, 1, wxALL|wxALIGN_LEFT|wxALIGN_BOTTOM, 5);
    Panel4 = new wxPanel(Panel_file, ID_PANEL6, wxDefaultPosition, wxDefaultSize, wxTAB_TRAVERSAL, _T("ID_PANEL6"));
    Panel4->SetBackgroundColour(wxColour(192,192,192));
    BoxSizer5 = new wxBoxSizer(wxVERTICAL);
    ComboBox1 = new wxComboBox(Panel4, ID_COMBOBOX1, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0, 0, 0, wxDefaultValidator, _T("ID_COMBOBOX1"));
    ComboBox1->SetSelection( ComboBox1->Append(_("RGB565")) );
    ComboBox1->Append(_("RGB666"));
    ComboBox1->Append(_("RGB888"));
    BoxSizer5->Add(ComboBox1, 1, wxALL|wxALIGN_LEFT|wxALIGN_BOTTOM, 5);
    load_hdc_file = new wxButton(Panel4, ID_BUTTON3, _("load_hdc_file"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON3"));
    BoxSizer5->Add(load_hdc_file, 1, wxALL|wxALIGN_LEFT|wxALIGN_BOTTOM, 5);
    save_hdc_file = new wxButton(Panel4, ID_BUTTON4, _("save_hdc_file"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON4"));
    BoxSizer5->Add(save_hdc_file, 1, wxALL|wxALIGN_LEFT|wxALIGN_BOTTOM, 5);
    Panel4->SetSizer(BoxSizer5);
    BoxSizer5->Fit(Panel4);
    BoxSizer5->SetSizeHints(Panel4);
    BoxSizer3->Add(Panel4, 1, wxALL|wxALIGN_LEFT|wxALIGN_BOTTOM, 5);
    Panel_file->SetSizer(BoxSizer3);
    BoxSizer3->Fit(Panel_file);
    BoxSizer3->SetSizeHints(Panel_file);
    BoxSizer1->Add(Panel_file, 0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_BOTTOM, 5);
    Panel_image = new wxPanel(Panel_main, ID_PANEL3, wxDefaultPosition, wxSize(680,500), wxTAB_TRAVERSAL, _T("ID_PANEL3"));
    Panel_image->SetBackgroundColour(wxSystemSettings::GetColour(wxSYS_COLOUR_INACTIVECAPTION));
    BoxSizer2 = new wxBoxSizer(wxHORIZONTAL);
    image_view = new wxStaticBitmap(Panel_image, ID_STATICBITMAP1, wxNullBitmap, wxDefaultPosition, wxSize(640,480), 0, _T("ID_STATICBITMAP1"));
    BoxSizer2->Add(image_view, 1, wxALL|wxEXPAND|wxSHAPED|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    Panel_image->SetSizer(BoxSizer2);
    BoxSizer2->SetSizeHints(Panel_image);
    BoxSizer1->Add(Panel_image, 1, wxALL|wxEXPAND|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    Panel_info = new wxPanel(Panel_main, ID_PANEL4, wxDefaultPosition, wxDefaultSize, wxTAB_TRAVERSAL, _T("ID_PANEL4"));
    BoxSizer6 = new wxBoxSizer(wxHORIZONTAL);
    Text_info = new wxStaticText(Panel_info, ID_STATICTEXT2, _("no image load..."), wxDefaultPosition, wxDefaultSize, 0, _T("ID_STATICTEXT2"));
    BoxSizer6->Add(Text_info, 1, wxALL|wxALIGN_LEFT|wxALIGN_BOTTOM, 5);
    Panel_info->SetSizer(BoxSizer6);
    BoxSizer6->Fit(Panel_info);
    BoxSizer6->SetSizeHints(Panel_info);
    BoxSizer1->Add(Panel_info, 0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_BOTTOM, 5);
    Panel_main->SetSizer(BoxSizer1);
    BoxSizer1->Fit(Panel_main);
    BoxSizer1->SetSizeHints(Panel_main);
    StatusBar1 = new wxStatusBar(this, ID_STATUSBAR1, 0, _T("ID_STATUSBAR1"));
    int __wxStatusBarWidths_1[1] = { -10 };
    int __wxStatusBarStyles_1[1] = { wxSB_NORMAL };
    StatusBar1->SetFieldsCount(1,__wxStatusBarWidths_1);
    StatusBar1->SetStatusStyles(1,__wxStatusBarStyles_1);
    SetStatusBar(StatusBar1);

    Connect(ID_BUTTON1,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&hdc_conversionFrame::Onopen_imageClick);
    Connect(ID_BUTTON3,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&hdc_conversionFrame::OnButton_load_hdc_fileClick);
    Connect(ID_BUTTON4,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&hdc_conversionFrame::Onsave_hdc_fileClick);
    //*)
}

hdc_conversionFrame::~hdc_conversionFrame()
{
    //(*Destroy(hdc_conversionFrame)
    //*)
}



void hdc_conversionFrame::OnButton_load_hdc_fileClick(wxCommandEvent& event)
{
    wxFileDialog dialog(
        //parent window.
        this,
        //Message to show on the dialog.
        _("open hdc image file..."),
        //The default directory, or the empty string.
        _("./"),
        //The default filename, or the empty string.
        _(""),
        //A wildcard,.
        _("hdc files (*.hdc)|*.hdc"),
        //style.
        wxOPEN);

    //检查文件是否确认打开
    if (dialog.ShowModal() == wxID_OK)
    {
        wxString path = dialog.GetPath();
        hdc_load(this,path);
    }
}

void hdc_conversionFrame::Onopen_imageClick(wxCommandEvent& event)
{
    wxFileDialog dialog(
        //parent window.
        this,
        //Message to show on the dialog.
        _("open image file..."),
        //The default directory, or the empty string.
        _("./"),
        //The default filename, or the empty string.
        _(""),
        //A wildcard,.
        _("support image file|*.bmp;*.jpg;*.gif;*.png"),
        //style.
        wxOPEN);
    if (dialog.ShowModal() == wxID_OK)
    {
        wxString path = dialog.GetPath();
        image_open(this,path);
    }
}

void hdc_conversionFrame::Onsave_hdc_fileClick(wxCommandEvent& event)
{
    wxFileDialog dialog(
        //parent window.
        this,
        //Message to show on the dialog.
        _("open hdc image file..."),
        //The default directory, or the empty string.
        _("./"),
        //The default filename, or the empty string.
        _(""),
        //A wildcard,.
        _("hdc files (*.hdc)|*.hdc"),
        //style.
        wxFD_SAVE);
    if(dialog.ShowModal() == wxID_OK)
    {
        wxString path = dialog.GetPath();
        wxFile hdc_file;

        if(hdc_file.Open(path,wxFile::write) == true)
        {
            unsigned char * p_image_cov_buf
            =(unsigned char *)malloc((image_cov.GetWidth()*image_cov.GetHeight()*2)+20);

            //clean the file head;
            memset(p_image_cov_buf,0,20 );

            //file head
            *p_image_cov_buf = 'H';
            *(p_image_cov_buf+1) = 'D';
            *(p_image_cov_buf+2) = 'C';
            //image size
            *(unsigned int *)(p_image_cov_buf+4)=image_cov.GetWidth();
            *(unsigned int *)(p_image_cov_buf+8)=image_cov.GetHeight();

            {
                wxString out=_("The file size:");
                unsigned short * P_temp = (unsigned short *)(p_image_cov_buf + 20);
                int i;
                unsigned char * p_image_sourc;

                //get the image date (RGB888)
                p_image_sourc = image_cov.GetData();
                for(i=0; i<(image_cov.GetWidth()*image_cov.GetHeight()); i++)
                {
                    *P_temp  = (unsigned int)(*p_image_sourc++>>3)<<11;//R
                    *P_temp |= (unsigned int)(*p_image_sourc++>>2)<<5; //G
                    *P_temp |= (unsigned int)(*p_image_sourc++>>3);    //B
                    P_temp++;
                }

                //write file
                i = hdc_file.Write(p_image_cov_buf,(image_cov.GetWidth()*image_cov.GetHeight()*2)+20);
                free(p_image_cov_buf);

                out << i <<_("Byte write OK!!");
                this->Text_info->SetLabel(out);
            }
        }
        else
        {
            this->Text_info->SetLabel(_("File write fail: ")+path);
        }
    }
}



