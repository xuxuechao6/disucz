/***************************************************************
 * Name:      hdc_conversionApp.cpp
 * Purpose:   Code for Application Class
 * Author:    aozima (master@aozima.cn)
 * Created:   2009-12-26
 * Copyright: aozima (www.aozima.com)
 * License:
 **************************************************************/

#include "hdc_conversionApp.h"
#include "version.h"
#include "file_load.h"

//(*AppHeaders
#include "hdc_conversionMain.h"
#include <wx/image.h>
//*)


IMPLEMENT_APP(hdc_conversionApp);
bool hdc_conversionApp::OnInit()
{
    //(*AppInitialize
    bool wxsOK = true;

    wxInitAllImageHandlers();
    if ( wxsOK )
    {
        hdc_conversionFrame* Frame = new hdc_conversionFrame(0);
        Frame->Show();

        //------ set icon
#if defined(__WXMSW__)
        Frame->SetIcon(wxICON(aaaa));
#endif


        //------ version -------
        {
            wxString wxbuild = wxEmptyString;
            wxbuild << _T("hdc-conversion Build:");
            wxbuild << wxVERSION_STRING;
#if defined(__WXMSW__)
            wxbuild << _T("-Windows");
#elif defined(__UNIX__)
            wxbuild << _T("-Linux");
#endif

#if wxUSE_UNICODE
            wxbuild << _T("-Unicode build_count:");
#else
            wxbuild << _T("-ANSI build_count:");
#endif // wxUSE_UNICODE

            wxbuild << AutoVersion::BUILDS_COUNT;
            Frame->StatusBar1->SetStatusText(wxbuild);
        }
        //------- version

        SetTopWindow(Frame);

        if(argc == 2)
        {
            wxString path(argv[1],wxConvUTF8);
            wxString file_type = path.Right(4);
            if(file_type == _(".hdc") || file_type == _(".HDC"))
            {
                hdc_load(Frame,path);
            }
            else
            {
                if(file_type == _(".bmp") || file_type == _(".BMP")
                        || file_type == _(".jpg") || file_type == _(".JPG")
                        || file_type == _(".gif") || file_type == _(".GIF"))
                {
                    image_open(Frame,path);
                }
            }
        }
    }
    //*)
    return wxsOK;

}
