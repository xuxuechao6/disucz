/*
 * File      : app.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2006, RT-Thread Development Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://openlab.rt-thread.com/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2009-01-05     Bernard      the first version
 */

/**
 * @addtogroup STM32
 */
/*@{*/

#include <rthw.h>
#include <rtthread.h>

char thread1_stack[0x120];
char thread2_stack[0x120];

struct rt_thread thread1;
struct rt_thread thread2;

void thread1_entry(void* parameter)
{
	rt_uint32_t i = 0;

	while (1)
	{
		rt_kprintf("thread1 --> %d\n", ++i);
		rt_thread_delay(100);
	}
}

/* UART received msg structure */
struct rx_msg
{
	rt_device_t dev;
	rt_size_t size;
};

/* message queue for Rx */
static rt_mq_t rx_mq;
static char uart_rx_buffer[64];

rt_err_t uart_input(rt_device_t dev, rt_size_t size)
{
	struct rx_msg msg;
	msg.dev  = dev;
	msg.size = size;

	/* send message to message queue */
	rt_mq_send(rx_mq, &msg, sizeof(struct rx_msg));

	return RT_EOK;
}

void thread2_entry(void* parameter)
{
	struct rx_msg msg;
	int count = 0;

	rt_device_t device, write_device;
	rt_err_t result = RT_EOK;

	device = rt_device_find("uart3");
	if (device != RT_NULL)
	{
		rt_device_set_rx_indicate(device, uart_input);
		rt_device_open(device, RT_DEVICE_OFLAG_RDWR);
	}

	/* set write device */
	write_device = device;

	device = rt_device_find("uart2");
	if (device != RT_NULL)
	{
		rt_device_set_rx_indicate(device, uart_input);
		rt_device_open(device, RT_DEVICE_OFLAG_RDWR);
	}

	while (1)
	{
		result = rt_mq_recv(rx_mq, &msg, sizeof(struct rx_msg), 50);
		if (result == -RT_ETIMEOUT)
		{
			/* rx timeout */
			rt_kprintf("Thread2 count:%d\n", ++count);
			// rt_device_write(device, 0, &test_str[0], sizeof(test_str) - 1);
		}

		if (result == RT_EOK)
		{
			rt_uint32_t rx_length;

			rx_length = (sizeof(uart_rx_buffer) - 1) > msg.size ?
				msg.size : sizeof(uart_rx_buffer) - 1;

			rx_length = rt_device_read(msg.dev, 0, &uart_rx_buffer[0], rx_length);
			uart_rx_buffer[rx_length] = '\0';

			rt_kprintf("%s", &uart_rx_buffer[0]);
			rt_device_write(msg.dev, 0, &uart_rx_buffer[0], rx_length);

			/* write to device:uart3 too */
			if (write_device != RT_NULL)
				rt_device_write(write_device, 0, &uart_rx_buffer[0], rx_length);
		}
	}
}

#ifdef RT_USING_DFS
/* dfs init */
#include <dfs_init.h>
/* dfs filesystem:EFS filesystem init */
#include <dfs_efs.h>
/* dfs Filesystem APIs */
#include <dfs_fs.h>
#endif

/* thread phase init */
void rt_init_thread_entry(void *parameter)
{
/* Filesystem Initialization */
#ifdef RT_USING_DFS
	{
		/* init the device filesystem */
		dfs_init();
		/* init the efsl filesystam*/
		efsl_init();

		/* mount sd card fat partition 1 as root directory */
		if (dfs_mount("sd0", "/", "efs", 0, 0) == 0)
			rt_kprintf("File System initialized successfully!\n");
		else
			rt_kprintf("File System initialized failure!\n");
	}
#endif
}

int rt_application_init()
{
    rt_thread_t init_thread;

    init_thread = rt_thread_create("init",
                                rt_init_thread_entry, RT_NULL,
                                2048, 12, 20);
    rt_thread_startup(init_thread);

	rt_thread_init(&thread1,
		"thread1",
		thread1_entry, RT_NULL,
		&thread1_stack[0], sizeof(thread1_stack),
		20, 15);

	/* create message queue */
	rx_mq = rt_mq_create("umq", sizeof(struct rx_msg), 8, RT_IPC_FLAG_FIFO);

	rt_thread_init(&thread2,
		"thread2",
		thread2_entry, RT_NULL,
		&thread2_stack[0], sizeof(thread2_stack),
		25, 10);

	rt_thread_startup(&thread1);
	rt_thread_startup(&thread2);

	return 0;
}

/*@}*/
