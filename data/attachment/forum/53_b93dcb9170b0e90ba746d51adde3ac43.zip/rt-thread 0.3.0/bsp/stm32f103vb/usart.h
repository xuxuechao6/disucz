#ifndef __USART_H__
#define __USART_H__

#include <rthw.h>
#include <rtthread.h>

void rt_hw_usart_init(void);

#endif
