#include"main.h"



extern void can_recv_thread(void);
extern unsigned char CanreveiveFlag;
extern Message m;
/**************************************************************************

**************************************************************************/
int main(void)
{
        
		
       // uart2_init(115200);
		can_recv_thread();
	    while(1)
		{
            ;
//            if(CanreveiveFlag==1)
//            {
//            	TIM5->DIER &= (uint16_t)~TIM_IT_CC1;
//                    canDispatch(&TestSlave_Data, &m);
//			/* Enable the Interrupt sources */
//                TIM5->DIER |= TIM_IT_CC1;
//                CanreveiveFlag=0;
//            }
		}


}//end main


