/*
************************************************************************************************************************
* File    : main.c
* By      : xyou
* Version : V1.00.00
************************************************************************************************************************
*/

/*
*********************************************************************************************************
*                                             INCLUDE FILES
*********************************************************************************************************
*/
#include <rtthread.h>

#include <cpu_port.h>

rt_base_t   OSHeadBuf[1024 * 1024 * 10];

/*
*********************************************************************************************************
*                                            main()
* Description : Application's main entry
* Argument(s) : void
* Return(s)   : int
* Caller(s)   : none
* Note(s)     : none
*********************************************************************************************************
*/
extern int rt_application_init(void);
int main(void)
{
    /* show version */
    rt_show_version();

    /* init tick */
    rt_system_tick_init();

    /* init kernel object */
    rt_system_object_init();

    /* init timer system */
    rt_system_timer_init();


#ifdef RT_USING_HEAP
#   ifdef __CC_ARM
    rt_system_heap_init((void*)&Image$$RW_IRAM1$$ZI$$Limit, (void*)STM32_SRAM_END);
#   elif __ICCARM__
    rt_system_heap_init(__segment_end("HEAP"), (void*)STM32_SRAM_END);
#   elif WIN32
    rt_system_heap_init((rt_uint8_t *) (&OSHeadBuf[0]),
                        (rt_uint8_t *) (&OSHeadBuf[0]) + sizeof(OSHeadBuf));
#   endif
#endif

    rt_system_scheduler_init();

    /* init all device */
    rt_device_init_all();

    /* init application */
    rt_application_init();

    /* init timer thread */
    rt_system_timer_thread_init();

    /* init idle thread */
    rt_thread_idle_init();

    /* start scheduler */
    rt_system_scheduler_start();

    return 0;
} /*** main ***/





