/*
************************************************************************************************************************
* File    : rt_app.c
* By      : xyou
* Version : V1.00.00
************************************************************************************************************************
*/

/*
*********************************************************************************************************
*                                             INCLUDE FILES
*********************************************************************************************************
*/
#include <rtthread.h>

#include <stdio.h>
#include <stdlib.h>

static void led0_thread_entry(void* parameter)
{
    unsigned int count=0;

    while(1)
    {
        printf("led 0,count : %d \r\n",count);

        count += 1;

        rt_thread_delay(RT_TICK_PER_SECOND);
    }
}

static void led1_thread_entry(void* parameter)
{
    unsigned int count=0;

    while(1)
    {
        printf("led 1,count : %d \r\n",count);

        count += 1;

        rt_thread_delay(RT_TICK_PER_SECOND);
    }
}


/*
*********************************************************************************************************
*                                            rt_application_init()
* Description : Initialzie Applications
* Argument(s) : void
* Return(s)   : int
* Caller(s)   : none
* Note(s)     : none
*********************************************************************************************************
*/
int rt_application_init(void)
{
    rt_thread_t led_thread;

    led_thread = rt_thread_create("LED0",
                                  led0_thread_entry,
                                  NULL,
                                  1024,
                                  5,
                                  20);
    if (led_thread != RT_NULL)
    {
        rt_thread_startup(led_thread);
    }

    led_thread = rt_thread_create("LED1",
                                   led1_thread_entry,
                                   NULL,
                                   1024,
                                   6,
                                   20);
     if (led_thread != RT_NULL)
     {
         rt_thread_startup(led_thread);
     }

    return 0;
} /*** rt_application_init ***/





