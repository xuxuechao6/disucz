/*
 * File      : board.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2006, RT-Thread Develop Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://openlab.rt-thread.com/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2006-08-23     Bernard      first implementation
 */

#include "board.h"

#include <AT91SAM7X.h>

static void rt_hw_board_led_init(void);

/**
 * @addtogroup sam7s
 */
/*@{*/

#define TCK  1000                           /* Timer Clock  */
#define PIV  (((MCK/16)/1000)*(1000/RT_TICK_PER_SECOND))	/* Periodic Interval Value */

/**
 * This is the timer interrupt service routine.
 * @param vector the irq number for timer
 */
void rt_hw_timer_handler(int vector)
{
	if (AT91C_PITC_PISR & 0x01)
	{
		/* increase a tick */
		rt_tick_increase();

		/* ack interrupt */
		AT91C_AIC_EOICR = AT91C_PITC_PIVR;
	}
	else
	{
		/* end of interrupt */
		AT91C_AIC_EOICR = 0;
	}
}
						/* PIO   Flash    PA    PB   PIN */
#define LED1 (1 << 19)	/* PA0 / PGMEN0 & PWM0 TIOA0  48 */
#define LED2 (1 << 20)	/* PA1 / PGMEN1 & PWM1 TIOB0  47 */
#define LED3 (1 << 21)	/* PA2          & PWM2 SCK0   44 */
#define LED4 (1 << 22)	/* PA3          & TWD  NPCS3  43 */
#define LED_MASK		(LED1|LED2|LED3|LED4)

int leds[] = {LED1, LED2, LED3, LED4};

/** 
 * This function will init led on the board
 */
static void rt_hw_board_led_init()
{
	/* enable the clock of the PIO A, PIO B */
	AT91C_PMC_PCER = 1 << AT91C_ID_PIOA | 1 << AT91C_ID_PIOB;

	/* configure PIO as output for led */
	AT91C_PIOB_PER = LED_MASK;
	AT91C_PIOB_OER = LED_MASK;
}

/**
 * This function will take the led on board on.
 *
 * @param n the number nth led
 */
void rt_hw_board_led_on(int n)
{
	if (n >= 0 && n < 4)
	{
		AT91C_PIOB_CODR = leds[n];
	}
}

/**
 * This function will take the led on board off.
 *
 * @param n the number nth led
 */
void rt_hw_board_led_off(int n)
{
	if (n >= 0 && n < 4)
	{
		AT91C_PIOB_SODR = leds[n];
	}
}

/**
 * This function will initial sam7x board.
 */
void rt_hw_board_init()
{
	/* init hardware serial */
	rt_serial_init();

	/* init led */
	rt_hw_board_led_init();

	/* init PITC */
	AT91C_PITC_PIMR = (1 << 25) | (1 << 24) | PIV;

	/* install timer handler */
	rt_hw_interrupt_install(AT91C_ID_SYS, rt_hw_timer_handler, RT_NULL);
	AT91C_AIC_SMR(AT91C_ID_SYS) = 0;
	rt_hw_interrupt_umask(AT91C_ID_SYS);	
}

#ifdef RT_USING_FINSH
void rt_hw_uart_rx_int(int irqno)
{
	extern void finsh_notify(void);

	/* notify finsh shell thread */
	finsh_notify();

	/* ack interrupt */
	AT91C_AIC_EOICR = 1;
}

void rt_hw_finsh_init()
{
	/* init UART rx interrupt */
	AT91C_US0_IER = 1 << 0; 	/* RxReady Interrupt */
	AT91C_US0_IMR |= 1 << 0; 	/* unmask RxReady Interrupt */

	/* install UART handler */
	rt_hw_interrupt_install(AT91C_ID_US0, rt_hw_uart_rx_int, RT_NULL);
	AT91C_AIC_SMR(AT91C_ID_US0) = 5 | (0x01 << 5);
	rt_hw_interrupt_umask(AT91C_ID_US0);
}
#endif

/*@}*/
