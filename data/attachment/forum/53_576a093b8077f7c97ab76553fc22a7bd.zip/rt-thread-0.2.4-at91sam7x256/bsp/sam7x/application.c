/*
 * File      : app.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2006, RT-Thread Development Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://www.rt-thread.org/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2006-06-05     Bernard      the first version
 */

/**
 * @addtogroup sam7x
 */
/*@{*/
#include <rtthread.h>

#ifdef RT_USING_LWIP
#include <lwip/sys.h>
#include <lwip/api.h>
#include <lwip/netbuf.h>
#endif

#ifdef RT_USING_LWIP
void thread_tcpecho(void *parameter)
{
	struct netconn *conn, *newconn;
	err_t err;

	/* Create a new connection identifier. */
	conn = netconn_new(NETCONN_TCP);

	/* Bind connection to well known port number 7. */
	netconn_bind(conn, RT_NULL, 7);

	/* Tell connection to go into listening mode. */
	netconn_listen(conn);

	while(1)
	{
		/* Grab new connection. */
		newconn = netconn_accept(conn);
		/* Process the new connection. */
		if(newconn != NULL)
		{
			struct netbuf *buf;
			void *data;
			u16_t len;

			while((buf = netconn_recv(newconn)) != NULL)
			{
				do
				{
					netbuf_data(buf, &data, &len);
					err = netconn_write(newconn, data, len, NETCONN_COPY);
					if(err != ERR_OK)
					{
						rt_kprintf("echo write error %d\n", err);
						break;
					}
				} while(netbuf_next(buf) >= 0);

				netbuf_delete(buf);
			}

			/* Close connection and discard connection identifier. */
			netconn_delete(newconn);
		}
	}
}

void lwip_init_entry(void* parameter)
{
	/* init lwip system */
	lwip_sys_init();
	rt_kprintf("TCP/IP initialized!\n");
}
#endif

int rt_application_init()
{
#ifdef RT_USING_LWIP
	rt_thread_t lwip_init;
	rt_thread_t echo;

	lwip_init = rt_thread_create("lw0",
								 lwip_init_entry, RT_NULL,
								 1024, 10, 20);
	rt_thread_startup(lwip_init);

	echo = rt_thread_create("echo",
							thread_tcpecho, RT_NULL,
							1024, 20, 20);
	rt_thread_startup(echo);
#endif

	return 0;
}

/*@}*/
