import socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect(("192.168.1.30", 7))
for i in range(1, 500000):
	s.send("tcp echo count %d" % (i, ))
	print s.recv(8192)
s.close()
