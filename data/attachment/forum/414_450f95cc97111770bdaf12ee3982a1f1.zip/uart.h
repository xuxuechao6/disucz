#ifndef UART_H_INCLUDED
#define UART_H_INCLUDED

extern void rt_hw_uart_init(void);

#endif // UART_H_INCLUDED
