/*
 * File      : application.c
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2009 - 2011, RT-Thread Development Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://www.rt-thread.org/license/LICENSE
 *
 * Change Logs:
 * Date           Author       Notes
 * 2011-05-24     Bernard      the first version
 */

/**
 * @addtogroup FM3
 */
/*@{*/

#include <rtthread.h>
#include "board.h"

#ifdef RT_USING_DFS
/* dfs init */
#include <dfs_init.h>
/* dfs filesystem:ELM filesystem init */
#include <dfs_elm.h>
/* dfs Filesystem APIs */
#include <dfs_fs.h>
#endif

#ifdef RT_USING_LWIP
#include <lwip/sys.h>
#include <lwip/api.h>
#include <netif/ethernetif.h>
#include <lwip/sockets.h> /* ʹ��BSD Socket�ӿڱ������sockets.h���ͷ�ļ� */
#include <lwip/netdb.h> /* Ϊ�˽�������������Ҫ����netdb.hͷ�ļ� */

#include "lwip/opt.h"
#include "lwip/mem.h"
#include "lwip/icmp.h"
#include "lwip/netif.h"
#include "lwip/inet.h"
#include "lwip/inet_chksum.h"
#include "lwip/ip.h"


#define BUF_LEN     1024

/*
FM3 EMAC
P44/PHY1_RESET
P45/PHY0_RESET
*/

#define    PHY0_RESET_LOW()     FM3_GPIO->PDOR4_f.P5 = 0;
#define    PHY0_RESET_HIGH()    FM3_GPIO->PDOR4_f.P5 = 1;

#define    PHY1_RESET_LOW()     FM3_GPIO->PDOR4_f.P4 = 0;
#define    PHY1_RESET_HIGH()    FM3_GPIO->PDOR4_f.P4 = 1;

#endif


ALIGN(RT_ALIGN_SIZE)
static char eneta_thread_stack[512];
/* �̵߳�TCB���ƿ�*/
static struct rt_thread eneta_thread;



void rt_init_thread_entry(void *parameter)
{
    /**< init led device */
    {
        extern void rt_led_hw_init(void);
        rt_led_hw_init();
    }

    /* Filesystem Initialization */
#ifdef RT_USING_DFS
    {
        /* init the device filesystem */
        dfs_init();

#ifdef RT_USING_DFS_ELMFAT
        /* init the elm chan FatFs filesystam*/
        elm_init();

        /* mount ELM FatFs on NAND flash as root directory */
        if (dfs_mount("sd0", "/", "elm", 0, 0) == 0)
        {
            rt_kprintf("File System initialized!\n");
        }
        else
            rt_kprintf("File System initialzation failed!\n");
#endif
    }
#endif

    /* LwIP Initialization */
#ifdef RT_USING_LWIP
    {
        extern void lwip_sys_init(void);
        extern void fm3_emac_hw_init(void);
        extern void set_ethernet_e_cout_clock(int is_rmii);

        eth_system_device_init();

        /**< config PHY0_RESET */
        FM3_GPIO->PFR4_f.P5 = 0;
        FM3_GPIO->DDR4_f.P5 = 1;

        /**< config PHY1_RESET */
        FM3_GPIO->PFR4_f.P4 = 0;
        FM3_GPIO->DDR4_f.P4 = 1;

        /**< RESET PHY */
        PHY0_RESET_LOW();
        PHY0_RESET_HIGH();
        rt_thread_delay(RT_TICK_PER_SECOND/100); /* delay 10ms */
        PHY1_RESET_LOW();
        PHY1_RESET_HIGH();
        rt_thread_delay(RT_TICK_PER_SECOND/100); /* delay 10ms */

        /* register ethernetif device */
        set_ethernet_e_cout_clock(1);
        fm3_emac_hw_init();


        /* init all device */
        rt_device_init_all();

        /* init lwip system */
        lwip_sys_init();
        rt_kprintf("TCP/IP initialized!\n");
    }

    /* set ip */
    {
        extern void set_if(char* netif_name, char* ip_addr, char* gw_addr, char* nm_addr);
        set_if("e0", "192.100.1.35", "192.168.0.1", "255.255.255.0");
        set_if("e1", "192.100.2.35", "192.168.1.1", "255.255.255.0");
    }
#endif
}


//*****************************************************************************
//
// enet thread function
//
//*****************************************************************************
static void eneta_thread_entry(void* parameter)
{
	int sock;
	int bytes_read;
	char *recv_data;
	rt_uint32_t addr_len;
	struct sockaddr_in server_addr , client_addr;
  rt_thread_delay(1000);
    recv_data = rt_malloc(BUF_LEN);
    if (recv_data == RT_NULL)
    {
        rt_kprintf("No memory\n");
        return;
    }
		
    /* create socket */
	if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
	{
		rt_kprintf("Socket error\n");

        /* release recv buffer */
        rt_free(recv_data);
		return;
	}

    /* init server socket address */
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(5000);
	server_addr.sin_addr.s_addr = INADDR_ANY;
	rt_memset(&(server_addr.sin_zero),0, sizeof(server_addr.sin_zero));
  /* ��socket������˵�ַ*/
	if (bind(sock,(struct sockaddr *)&server_addr,
			 sizeof(struct sockaddr)) == -1)
	{
		rt_kprintf("Bind error\n");

        /* release recv buffer */
        rt_free(recv_data);
        return;
	}

	addr_len = sizeof(struct sockaddr);

	rt_kprintf("UDPServer Waiting for client on port 5000...\n");

 	while (1)
 	{
		bytes_read = recvfrom(sock, recv_data, 1024, 0,
            (struct sockaddr *)&client_addr, &addr_len);
		if (bytes_read <= 0) continue;
		recv_data[bytes_read] = '\0';
		//rt_kprintf("\n(%s , %d) said : ",inet_ntoa(client_addr.sin_addr),
		//	   ntohs(client_addr.sin_port));
		//rt_kprintf("%s", recv_data);
		if(client_addr.sin_addr.s_addr == 0xd30264c0)
			client_addr.sin_port = htons(5000);
		else
			client_addr.sin_port = htons(5100);
		sendto(sock, recv_data, 1024, 0,
		(struct sockaddr *)&client_addr, sizeof(struct sockaddr));
		
        if (strcmp(recv_data, "exit") == 0)
        {
            lwip_close(sock);

            /* release recv buffer */
            rt_free(recv_data);
            break;
         }
		//rt_thread_delay(1);
 	}
}
int rt_application_init()
{
    rt_thread_t tid;

    tid = rt_thread_create("init",
                           rt_init_thread_entry, RT_NULL,
                           2048, 8, 20);
    if (tid != RT_NULL) rt_thread_startup(tid);

	  rt_thread_init(&eneta_thread,
					"eneta",
					eneta_thread_entry, RT_NULL,
					&eneta_thread_stack[0], sizeof(eneta_thread_stack),
					0x12, 8);

	  rt_thread_startup(&eneta_thread);
	
    return 0;
}

/*@}*/
