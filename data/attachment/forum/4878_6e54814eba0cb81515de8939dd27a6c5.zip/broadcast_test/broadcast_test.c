#include "broadcast_test.h"

//�㲥������
static struct rt_broadcast_server s_broadcast_server;

//�ͻ���1
static struct rt_broadcast_client s_client_1; //�㲥�ͻ���1
static rt_uint8_t s_listener1_mq_buffer[2048];
static struct rt_thread s_client_entry1;//�����߳�1
static rt_int8_t s_client_entry1_stack[2048];//�����̵߳��߳�ջ
//�㲥���ղ����߳�1
static void broadcast_thread_entry_rev1(void* parameter)
{
	struct MSG msg;
	while(1)
	{
		rt_memset(&msg,0,sizeof(struct MSG));
		if(RT_EOK ==rt_broadcast_recv(&s_client_1,&msg,sizeof(struct MSG),RT_WAITING_FOREVER))
		{
			rt_kprintf("<-client1 recv msg:%02x  %s\n",msg.head,msg.msg_body);
		}
	}
}
//�ͻ���2
static struct rt_broadcast_client s_client_2; //�㲥�ͻ���2
static rt_uint8_t s_listener2_mq_buffer[2048];
static struct rt_thread s_client_entry2;//�����߳�2
static rt_int8_t s_client_entry2_stack[2048];//�����̵߳��߳�ջ
//�㲥���ղ����߳�1
static void broadcast_thread_entry_rev2(void* parameter)
{
	struct MSG msg;
	while(1)
	{
		rt_memset(&msg,0,sizeof(struct MSG));
		if(RT_EOK ==rt_broadcast_recv(&s_client_2,&msg,sizeof(struct MSG),RT_WAITING_FOREVER))
		{
			rt_kprintf("<-client2 recv msg:%02x  %s\n",msg.head,msg.msg_body);
		}
	}
}
//�ͻ���3
static struct rt_broadcast_client s_client_3; //�㲥�ͻ���3
static rt_uint8_t s_listener3_mq_buffer[2048];
static struct rt_thread s_client_entry3;//�����߳�3
static rt_int8_t s_client_entry3_stack[2048];//�����̵߳��߳�ջ
//�㲥���ղ����߳�1
static void broadcast_thread_entry_rev3(void* parameter)
{
	struct MSG msg;
	while(1)
	{
		rt_memset(&msg,0,sizeof(struct MSG));
		if(RT_EOK ==rt_broadcast_recv(&s_client_3,&msg,sizeof(struct MSG),RT_WAITING_FOREVER))
		{
			rt_kprintf("<-client3 recv msg:%02x  %s\n",msg.head,msg.msg_body);
		}
	}
}

//������1
static struct rt_thread s_send_entry1;//�����߳�1
static rt_int8_t s_send1_entry_stack[2048];//�����̵߳��߳�ջ
//�㲥�����߳�1
static void broadcast_thread_entry_send1(void *parameter)
{
	struct MSG msg;
	rt_uint8_t temp =0;
	rt_err_t err;

	while(1)
	{
		rt_memset(&msg,0,sizeof(struct MSG));
		msg.head =temp ++;
		strncpy(msg.msg_body,"entry_send1 msg",sizeof(msg.msg_body));
		err =rt_broadcast_send(&s_broadcast_server,&msg,sizeof(struct MSG)); 
		if(RT_EOK ==err)
		{
			rt_kprintf("->send1 msg:%02x %s\n",msg.head,msg.msg_body);
		}
		else
		{
			rt_kprintf("send1 msg failed:%d\n",err);
		}

		rt_thread_delay(500);
	}
}

//������2
static struct rt_thread s_send_entry2;//�����߳�2
static rt_int8_t s_send2_entry_stack[2048];//�����̵߳��߳�ջ
//�㲥�����߳�2
static void broadcast_thread_entry_send2(void *parameter)
{
	struct MSG msg;
	rt_uint8_t temp =0;
	rt_err_t err;

	while(1)
	{
		rt_memset(&msg,0,sizeof(struct MSG));
		msg.head =temp ++;
		strncpy(msg.msg_body,"entry_send2 msg",sizeof(msg.msg_body));
		err =rt_broadcast_send(&s_broadcast_server,&msg,sizeof(struct MSG)); 
		if(RT_EOK ==err)
		{
			rt_kprintf("->send2 msg:%02x %s\n",msg.head,msg.msg_body);
		}
		else
		{
			rt_kprintf("send2 msg failed:%d\n",err);
		}

		rt_thread_delay(300);
	}
}

//������3
static struct rt_thread s_send_entry3;//�����߳�3
static rt_int8_t s_send3_entry_stack[2048];//�����̵߳��߳�ջ
//�㲥�����߳�3
static void broadcast_thread_entry_send3(void *parameter)
{
	struct MSG msg;
	rt_uint8_t temp =0;
	rt_err_t err;

	while(1)
	{
		rt_memset(&msg,0,sizeof(struct MSG));
		msg.head =temp ++;
		strncpy(msg.msg_body,"entry_send3 msg",sizeof(msg.msg_body));
		err =rt_broadcast_send(&s_broadcast_server,&msg,sizeof(struct MSG)); 
		if(RT_EOK ==err)
		{
			rt_kprintf("->send3 msg:%02x %s\n",msg.head,msg.msg_body);
		}
		else
		{
			rt_kprintf("send3 msg failed:%d\n",err);
		}

		rt_thread_delay(400);
	}
}


//�㲥���Ժ���
int broadcast_test(void)
{
	rt_err_t err;

	rt_broadcast_server_init(&s_broadcast_server);//��ʼ���㲥������

	//��ʼ���㲥�ͻ���1
	err =rt_broadcast_client_init(&s_client_1,
								"client1",
								&s_listener1_mq_buffer[0],
								sizeof(struct MSG),
								sizeof(s_listener1_mq_buffer),
								RT_IPC_FLAG_FIFO);
	if(err !=RT_EOK)
	{
		rt_kprintf("rt_broadcast_client1_init failed:%d\n",err);
		return err;
	}
	//ע��ͻ���1
	rt_broadcast_client_regist(&s_broadcast_server,&s_client_1);
	//��ʼ�������߳�1
	err = rt_thread_init(&s_client_entry1,
								"client1",
								broadcast_thread_entry_rev1, RT_NULL,
								s_client_entry1_stack,
								sizeof(s_client_entry1_stack),								
								5, 20);

	if (err == RT_EOK)
	{
		rt_thread_startup(&s_client_entry1);
		rt_kprintf("broadcast_thread_entry_rev1 startup ok!\n");
	}
	else
	{
		rt_kprintf("broadcast_thread_entry_rev1 startup failed!\n");
	}


	//��ʼ���㲥�ͻ���2
	err =rt_broadcast_client_init(&s_client_2,
								"client2",
								&s_listener2_mq_buffer[0],
								sizeof(struct MSG),
								sizeof(s_listener2_mq_buffer),
								RT_IPC_FLAG_FIFO);
	if(err !=RT_EOK)
	{
		rt_kprintf("rt_broadcast_client2_init failed:%d\n",err);
		return err;
	}
	//ע��ͻ���
	rt_broadcast_client_regist(&s_broadcast_server,&s_client_2);
	//��ʼ�������߳�1
	err = rt_thread_init(&s_client_entry2,
								"client2",
								broadcast_thread_entry_rev2, RT_NULL,
								s_client_entry2_stack,
								sizeof(s_client_entry2_stack),								
								5, 20);

	if (err == RT_EOK)
	{
		rt_thread_startup(&s_client_entry2);
		rt_kprintf("broadcast_thread_entry_rev2 startup ok!\n");
	}
	else
	{
		rt_kprintf("broadcast_thread_entry_rev2 startup failed!\n");
	}

	//��ʼ���㲥�ͻ���3
	err =rt_broadcast_client_init(&s_client_3,
								"client3",
								&s_listener3_mq_buffer[0],
								sizeof(struct MSG),
								sizeof(s_listener3_mq_buffer),
								RT_IPC_FLAG_FIFO);
	if(err !=RT_EOK)
	{
		rt_kprintf("rt_broadcast_client3_init failed:%d\n",err);
		return err;
	}
	//ע��ͻ���
	rt_broadcast_client_regist(&s_broadcast_server,&s_client_3);
	//��ʼ�������߳�1
	err = rt_thread_init(&s_client_entry3,
								"client3",
								broadcast_thread_entry_rev3, RT_NULL,
								s_client_entry3_stack,
								sizeof(s_client_entry3_stack),								
								5, 20);

	if (err == RT_EOK)
	{
		rt_thread_startup(&s_client_entry3);
		rt_kprintf("broadcast_thread_entry_rev3 startup ok!\n");
	}
	else
	{
		rt_kprintf("broadcast_thread_entry_rev3 startup failed!\n");
	}

	//��ʼ�������߳�1
	err =rt_thread_init(&s_send_entry1,"send1",
								broadcast_thread_entry_send1, RT_NULL,
								s_send1_entry_stack,sizeof(s_send1_entry_stack), 5, 20);

	if (err ==RT_EOK)
	{
		rt_thread_startup(&s_send_entry1);
		rt_kprintf("broadcast_thread_entry_send1 startup ok!\n");
	}
	else
	{
		rt_kprintf("broadcast_thread_entry_send1 startup failed!\n");
	}

	//��ʼ�������߳�2
	err =rt_thread_init(&s_send_entry2,"send2",
								broadcast_thread_entry_send2, RT_NULL,
								s_send2_entry_stack,sizeof(s_send2_entry_stack), 5, 20);

	if (err ==RT_EOK)
	{
		rt_thread_startup(&s_send_entry2);
		rt_kprintf("broadcast_thread_entry_send2 startup ok!\n");
	}
	else
	{
		rt_kprintf("broadcast_thread_entry_send2 startup failed!\n");
	}

	//��ʼ�������߳�3
	err =rt_thread_init(&s_send_entry3,"send3",
								broadcast_thread_entry_send3, RT_NULL,
								s_send3_entry_stack,sizeof(s_send3_entry_stack), 5, 20);

	if (err ==RT_EOK)
	{
		rt_thread_startup(&s_send_entry3);
		rt_kprintf("broadcast_thread_entry_send3 startup ok!\n");
	}
	else
	{
		rt_kprintf("broadcast_thread_entry_send3 startup failed!\n");
	}

	return 0;
}

