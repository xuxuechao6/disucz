/*-----------------------------------------------------------------------*/
/* Low level disk control module for Win32              (C)ChaN, 2012    */
/*-----------------------------------------------------------------------*/
#define FILE_METHORD 2
/*
 * 1:open(),read(),lseek()
 * 2:fopen(),fwrite(),fseek()
 */
#include <stdio.h>
#include <ctype.h>
#include "diskio.h"
#include "ffconf.h"
#include "ff.h"
#if FILE_METHORD == 1
#include <fcntl.h>
#include <sys/types.h>
#include <unistd.h>
#endif
//#define DK_DEBUG
#define SDCARD    "/home/parai/sd/SD.img"
//"E:\\workspace\\IMG\\SD.img"  /*image name of the sdcard*/
#define _VOLUMES _DRIVES
char* device_name[_VOLUMES]={SDCARD};
/*-----------------------------------------------------------------------*/
/* Read Sector(s)                                                        */
/*-----------------------------------------------------------------------*/

DRESULT sd_read (
	BYTE drv,			/* Physical drive nmuber (0) */
	BYTE *buff,			/* Pointer to the data buffer to store read data */
	DWORD sector,		/* Start sector number (LBA) */
	BYTE count			/* Sector count (1..255) */
)
{
#if FILE_METHORD == 1
	int fd=-1;
#elif FILE_METHORD == 2
	FILE *fp=NULL;
#endif
	int lread;
	DRESULT res=RES_OK;
#ifdef DK_DEBUG
	printf("in sd_read()\n");
	printf("drv=%d,buffer=0x%x,sector=%d,count=%d\n",drv,(unsigned int)buff,(unsigned int)sector,count);
#endif
	if (drv >= _VOLUMES)
		return RES_NOTRDY;
#if FILE_METHORD == 1
	fd=open(device_name[drv],O_RDONLY);
#elif FILE_METHORD == 2
	fp=fopen(device_name[drv],"r");
#endif

#ifdef DK_DEBUG
#if FILE_METHORD == 1
	if(fd<0)
#elif FILE_METHORD == 2
	if(fp==NULL)
#endif
	 printf("disk image %s is not exist.\n",device_name[drv]);
	else printf("disk image open successfully\n");
#endif
#if FILE_METHORD == 1
	lseek(fd,512*(sector),SEEK_SET);
	lread=read(fd,buff,count*512);
#elif FILE_METHORD == 2
	fseek(fp,512*(sector),SEEK_SET);
	lread=512*fread(buff,count*512,1,fp);
#endif

#ifdef DK_DEBUG
	printf("has read %d bytes \n",lread);
#endif

#ifdef DK_DEBUG
	int ii,jj;
	char chr;
	printf("the read data:\n");
	for(ii=0;ii<lread;ii=ii+16){
		printf("0x%3x: ",ii);
	for(jj=0;jj<16;jj++)
		printf("%2x ",buff[ii+jj]);
	for(jj=0;jj<16;jj++){/*打印数据对应字符*/
		chr=buff[ii+jj];
		printf("%c",isprint(chr)?chr:'.');
	}
	printf("\n");
	}
#endif
	
	if(lread!=count*512) res=RES_ERROR;
#if FILE_METHORD == 1
	close(fd);
#elif FILE_METHORD == 2
	fclose(fp);
#endif

	return res;
}



/*-----------------------------------------------------------------------*/
/* Write Sector(s)                                                       */
/*-----------------------------------------------------------------------*/

#if _READONLY == 0
DRESULT sd_write (
	BYTE drv,			/* Physical drive nmuber (0) */
	const BYTE *buff,	/* Pointer to the data to be written */
	DWORD sector,		/* Start sector number (LBA) */
	BYTE count			/* Sector count (1..255) */
)
{
#if FILE_METHORD == 1
	int fd=-1;
#elif FILE_METHORD == 2
	FILE *fp=NULL;
#endif
	int lwrite;
	DRESULT res=RES_OK;
#ifdef DK_DEBUG
	printf("in sd_write()\n");
	printf("drv=%d,buffer=0x%x,sector=%d,count=%d\n",drv,(unsigned int)buff,(unsigned int)sector,count);
#endif	
	if (drv >= _VOLUMES)
		return RES_NOTRDY;
#if FILE_METHORD == 1
	fd=open(device_name[drv],O_WRONLY);
#elif FILE_METHORD == 2
	fp=fopen(device_name[drv],"r+");/*you must used r+*/
#endif

#ifdef DK_DEBUG
#if FILE_METHORD == 1
	if(fd<0)
#elif FILE_METHORD == 2
	if(fp==NULL)
#endif
		printf("disk image %s is not exist.\n",device_name[drv]);
	else printf("disk image open successfully\n");
#endif
#if FILE_METHORD == 1
	lseek(fd,512*(sector),SEEK_SET);
	lwrite=write(fd,buff,count*512);
#elif FILE_METHORD == 2
	fseek(fp,512*(sector),SEEK_SET);
	lwrite=512*fwrite(buff,count*512,1,fp);
#endif

#ifdef DK_DEBUG
	printf("has write %d bytes \n",lwrite);
#endif
#ifdef DK_DEBUG
	int ii,jj;
	char chr;
	printf("the write data:\n");
	for(ii=0;ii<lwrite;ii=ii+16){
		printf("0x%3x: ",ii);
	for(jj=0;jj<16;jj++)
		printf("%2x ",buff[ii+jj]);
	for(jj=0;jj<16;jj++){/*打印数据对应字符*/
		chr=buff[ii+jj];
		printf("%c",isprint(chr)?chr:'.');
	}
	printf("\n");
	}
#endif
	
	if(lwrite!=count*512) res=RES_ERROR;
#if FILE_METHORD == 1
	close(fd);
#elif FILE_METHORD == 2
	fclose(fp);
#endif
	return res;
}
#endif /* _READONLY */




