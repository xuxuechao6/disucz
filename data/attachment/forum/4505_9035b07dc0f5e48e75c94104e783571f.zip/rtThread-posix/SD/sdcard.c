#include "sdcard.h"
#ifdef RT_USING_DFS

#include "rtthread.h"
#include "dfs_fs.h"
#include "diskio.h"

struct rt_device sdcard_device;
struct dfs_partition part;
/* RT-Thread Device Driver Interface */
static rt_err_t rt_sdcard_init(rt_device_t dev)
{
	return RT_EOK;
}

static rt_err_t rt_sdcard_open(rt_device_t dev, rt_uint16_t oflag)
{
	return RT_EOK;
}

static rt_err_t rt_sdcard_close(rt_device_t dev)
{
	return RT_EOK;
}

/* set sector size to 512 */
#define SECTOR_SIZE		512
static rt_size_t rt_sdcard_read(rt_device_t dev, rt_off_t pos, void* buffer, rt_size_t size)
{
	DRESULT status;

	status = sd_read(0,buffer, part.offset + pos / SECTOR_SIZE, size / SECTOR_SIZE);
	if (status != RES_OK)
	{
		rt_kprintf("sd card read failed\n");
		return 0;
	}

	return size;
}

static rt_size_t rt_sdcard_write (rt_device_t dev, rt_off_t pos, const void* buffer, rt_size_t size)
{
	DRESULT status;

	status = sd_write(0,buffer, part.offset + pos / SECTOR_SIZE, size / SECTOR_SIZE);
	if (status != RES_OK)
	{
		rt_kprintf("sd card write failed\n");
		return 0;
	}
	return size;
}

static rt_err_t rt_sdcard_control(rt_device_t dev, rt_uint8_t cmd, void *args)
{
	return RT_EOK;
}
void rt_hw_sdcard_init(void)
{
	DRESULT status;
	rt_uint8_t *sector;
#if SD_DEBUG==1
  rt_kprintf("in rt_hw_sdcard_init()\n");
#endif
	/* get the first sector to read partition table */
	sector = (rt_uint8_t*) rt_malloc (512);
	if (sector == RT_NULL){
		rt_kprintf("allocate partition sector buffer failed\n");
		return;
	}
	status = sd_read(0, sector, 0, 1);
	if (status == RES_OK)
	{
#if SD_DEBUG==1
		rt_kprintf("in rt_hw_sdcard_init():read OK\n");
#endif
		/* get the first partition */
		if (dfs_filesystem_get_partition(&part, sector, 0) != 0)
		{
			/* there is no partition */
			part.offset = 0;
			part.size   = 0;
		}
	}
	else
	{
		/* there is no partition table */
		part.offset = 0;
		part.size   = 0;
#if SD_DEBUG==1
		rt_kprintf("in rt_hw_sdcard_init():read FAULT\n");
#endif
	}
#if SD_DEBUG==1
rt_kprintf("in rt_hw_sdcard_init():part(0x%x,0x%x,0x%x)\n",part.type,part.offset,part.size);
#endif
	/* release sector buffer */
	rt_free(sector);

	/* register sdcard device */
	sdcard_device.init 	= rt_sdcard_init;
	sdcard_device.open 	= rt_sdcard_open;
	sdcard_device.close = rt_sdcard_close;
	sdcard_device.read 	= rt_sdcard_read;
	sdcard_device.write = rt_sdcard_write;
	sdcard_device.control = rt_sdcard_control;

	/* no private */
	sdcard_device.private = RT_NULL;
		
	rt_device_register(&sdcard_device, "sd0",
		RT_DEVICE_FLAG_RDWR | RT_DEVICE_FLAG_REMOVABLE | RT_DEVICE_FLAG_STANDALONE);
	return;
}
#endif
