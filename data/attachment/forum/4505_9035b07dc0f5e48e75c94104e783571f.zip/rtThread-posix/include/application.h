#ifndef APPLICATION_H_H_H_

#define THREAD_STACK_SIZE 1000
#define THREAD_PRIORITY 10
int rt_application_init();
int semaphore_producer_consumer_init();
#endif
