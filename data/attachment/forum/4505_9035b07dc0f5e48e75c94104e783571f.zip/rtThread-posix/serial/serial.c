/*
******************************************************************************
* By   : parai 
* email:parai@foxmail.com 
* 这并不是一个真的串口设备，只是为了能够让内核打印信息而创建
******************************************************************************
*/

#include "rtthread.h"
#if RT_USING_SERIAL==1
#define _DEBUG_SERIAL 0
#include "serial.h"
#include <stdio.h>
struct rt_device serial_device;


/*@{*/

/* RT-Thread Device Interface */
/**
 * This function initializes serial
 */
static rt_err_t rt_serial_init (rt_device_t dev)
{
#if _DEBUG_SERIAL==1
	printf("in rt_serial_init()\n");
#endif
	return RT_EOK;
}

static rt_err_t rt_serial_open(rt_device_t dev, rt_uint16_t oflag){
#if _DEBUG_SERIAL==1
	printf("in rt_serial_open()\n");
#endif
	return RT_EOK;
}

static rt_err_t rt_serial_close(rt_device_t dev)
{
#if _DEBUG_SERIAL==1
	printf("in rt_serial_close()\n");
#endif
	return RT_EOK;
}
static rt_size_t rt_serial_write (rt_device_t dev, rt_off_t pos, const void* buffer, rt_size_t size)
{
#if _DEBUG_SERIAL==1
	printf("in rt_serial_write()\n");
#endif
	printf("%s",(char*)buffer);
	return size;
}

static rt_err_t rt_serial_control (rt_device_t dev, rt_uint8_t cmd, void *args)
{
	RT_ASSERT(dev != RT_NULL);

	switch (cmd){
	case RT_DEVICE_CTRL_SUSPEND:
		/* suspend device */
		dev->flag |= RT_DEVICE_FLAG_SUSPENDED;
		break;

	case RT_DEVICE_CTRL_RESUME:
		/* resume device */
		dev->flag &= ~RT_DEVICE_FLAG_SUSPENDED;
		break;
	}

	return RT_EOK;
}

/*
 * serial register
 */
rt_err_t rt_hw_serial_register(rt_device_t device, const char* name, rt_uint32_t flag)
{
	RT_ASSERT(device != RT_NULL);
#if _DEBUG_SERIAL==1
	printf("in rt_serial_register()\n");
#endif
	device->type 		= RT_Device_Class_Char;
	device->rx_indicate = RT_NULL;
	device->tx_complete = RT_NULL;
	device->init 		= rt_serial_init;
	device->open		= rt_serial_open;
	device->close		= rt_serial_close;
	device->read 		= RT_NULL;
	device->write 		= rt_serial_write;
	device->control 	= rt_serial_control;
	device->private		= RT_NULL;

	/* register a character device */
	return rt_device_register(device, name, RT_DEVICE_FLAG_RDWR | flag);
}
#endif
