/*
*********************************************************************************************************
*                                       MC9S12DP256/DG128 Specific code
*                                          BANKED MEMORY MODEL
*
* File : rthw.c
* By   : parai 
* email:parai@foxmail.com 
*******************************************************************************************************/

#ifndef __RT_HW_SERIAL_H__
#define __RT_HW_SERIAL_H__
#if RT_USING_SERIAL

#include "rthw.h"
#include "rtthread.h"

rt_err_t rt_hw_serial_register(rt_device_t device, const char* name, rt_uint32_t flag);
#endif
#endif
