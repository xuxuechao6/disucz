/*
**********************************************************************************
*File : rthw.c
* By   : parai 
* email:parai@foxmail.com 
**********************************************************************************
*/
#include "rthw.h"

#include <pthread.h>
#include <sched.h>
#include <signal.h>
#include <errno.h>
#include <sys/time.h>
#include <time.h>
#include <sys/times.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <limits.h>

#define FALSE 0
#define TRUE 1
#define MAX_NUMBER_OF_TASKS 		( _POSIX_THREAD_THREADS_MAX )
extern volatile rt_uint8_t rt_interrupt_nest;
typedef void* TaskHandle_t;
/*-----------------------------------------------------------*/

/* Parameters to pass to the newly created pthread. */
typedef struct PARAMS
{
	void (*task)(void *);
	void *parameter;
	void (*exit)();
	pthread_t hThread;
	unsigned int interrupt_nest;
	int InterruptsEnabled;
} Params_t;
/*-----------------------------------------------------------*/

static pthread_once_t g_hSigSetupThread = PTHREAD_ONCE_INIT;
static pthread_attr_t g_ThreadAttributes;
static pthread_mutex_t g_SuspendResumeThreadMutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t g_SingleThreadMutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_t g_hMainThread = ( pthread_t )NULL;
/*-----------------------------------------------------------*/

static volatile int g_Sentinel = 0;
static volatile int g_SchedulerEnd = FALSE;
static volatile int g_InterruptsEnabled = TRUE;
static volatile int g_ServicingTick = FALSE;;

/*
 * Setup the timer to generate the tick interrupts.
 */
static void SetupTimerInterrupt( void );
static void *WaitForStart( void * Params );
static void SuspendSignalHandler(int sig);
static void ResumeSignalHandler(int sig);
static void SetupSignalsAndSchedulerPolicy( void );
static void SuspendThread( pthread_t ThreadId );
static void ResumeThread( pthread_t ThreadId );
static void EnterCritical( void );
static void ExitCritical( void );
/*-----------------------------------------------------------*/

/*
 * Exception handlers.
 */
void SystemTickHandler( int sig );

/*
 * Start first task is a separate function so it can be tested in isolation.
 */

rt_uint8_t *rt_hw_stack_init(void (*task)(void *),/*the entry of task*/ 
          void *parameter,   /*he parameter of task*/
        	rt_uint8_t *stack_addr, /*the beginning stack address*/
        	void (*exit)()/*the function will be called when task exit*/
){    
   /* Should actually keep this struct on the stack. */
#if _DEBUG==1
	printf("in rt_hw_stack_init():SP=%x\n",(int)stack_addr);
#endif
	Params_t *pThisThreadParams = (Params_t *)(stack_addr=stack_addr- sizeof(Params_t));
	(void)pthread_once( &g_hSigSetupThread, SetupSignalsAndSchedulerPolicy );

	if ( (pthread_t)NULL == g_hMainThread ){
		g_hMainThread = pthread_self();
	}

	/* No need to join the threads. */
	pthread_attr_init( &g_ThreadAttributes );
	pthread_attr_setdetachstate( &g_ThreadAttributes, PTHREAD_CREATE_DETACHED );

	/* Add the task parameters. */
	pThisThreadParams->task=task;
	pThisThreadParams->parameter=parameter;
	pThisThreadParams->exit=exit;
	pThisThreadParams->interrupt_nest=0;
	pThisThreadParams->InterruptsEnabled=TRUE;
	EnterCritical();

	/* Create the new pThread. */
	if ( 0 == pthread_mutex_lock( &g_SingleThreadMutex ) )
	{
		g_Sentinel = 0;
		if ( 0 != pthread_create(&(pThisThreadParams->hThread),
			 &g_ThreadAttributes, WaitForStart, (void *)pThisThreadParams ) ){
			/* Thread create failed, signal the failure */
			stack_addr = 0;
		}
		/* Wait until the task suspends. */
		(void)pthread_mutex_unlock( &g_SingleThreadMutex );
		while ( g_Sentinel == 0 );
		ExitCritical();
	}
#if _DEBUG==1
	printf("out rt_hw_stack_init():init OK,thread_id=%d\n",(int)pThisThreadParams->hThread);
#endif
#if _DEBUG==1
	printf("out rt_hw_stack_init():SP=%x\n",(int)stack_addr);
#endif
    return (stack_addr);
}

void rt_hw_context_switch(rt_uint32_t from, rt_uint32_t to){ 
		if ( 0 == pthread_mutex_lock(&g_SingleThreadMutex))
		{
			Params_t* xTaskToSuspend=(Params_t*)(*((int*)from));
			Params_t* xTaskToResume=(Params_t*)(*((int*)to));
		#if _DEBUG==0
			printf("in rt_hw_context_switch():from_SP=%x,to_SP=%x\n",
											(int)xTaskToSuspend,
											(int)xTaskToResume);
		#endif
			if ( xTaskToSuspend != xTaskToResume )
			{
				/* Remember and switch the critical nesting. */
				xTaskToSuspend->interrupt_nest=rt_interrupt_nest;
				xTaskToSuspend->InterruptsEnabled=g_InterruptsEnabled;
				rt_interrupt_nest =xTaskToResume->interrupt_nest;
				g_InterruptsEnabled=xTaskToResume->InterruptsEnabled;
				/* Switch tasks. */
				ResumeThread( xTaskToResume->hThread );
				SuspendThread( xTaskToSuspend->hThread );
			}
			else
			{
				/* Yielding to self */
				(void)pthread_mutex_unlock( &g_SingleThreadMutex );
			}
		}
}
void rt_hw_context_switch_to(rt_uint32_t to){
	int iSignal;
	sigset_t xSignals;
	sigset_t xSignalToBlock;
	sigset_t xSignalsBlocked;
#if _DEBUG==0
	printf("in rt_hw_context_switch_to():to_SP=%x\n",(int)(*(int*)to));
#endif
	/* Establish the signals to block before they are needed. */
	sigfillset( &xSignalToBlock );

	/* Block until the end */
	(void)pthread_sigmask( SIG_SETMASK, &xSignalToBlock, &xSignalsBlocked );

	/* Start the timer that generates the tick ISR.  Interrupts are disabled
	here already. */
	SetupTimerInterrupt();

/******************************************************************/

		Params_t*param=(Params_t *)(*(int*)to);
	/* Initialise the critical nesting count ready for the first task. */
		rt_interrupt_nest = param->interrupt_nest;
		g_InterruptsEnabled=param->InterruptsEnabled;
		/* Start the first task. */
		ResumeThread(param->hThread);

/****************************************************************/

	/* This is the end signal we are looking for. */
	sigemptyset( &xSignals );
	sigaddset( &xSignals, SIG_RESUME );

	while ( TRUE != g_SchedulerEnd )
	{
		if ( 0 != sigwait( &xSignals, &iSignal ) )
		{
			printf( "Main thread spurious signal: %d\n", iSignal );
		}
	}

	printf( "Cleaning Up, Exiting.\n" );
	/* Cleanup the mutexes */
	pthread_mutex_destroy( &g_SuspendResumeThreadMutex );
	pthread_mutex_destroy( &g_SingleThreadMutex );

	/* Should not get here! */
}

rt_uint32_t  rt_interrupt_from_thread=0;
rt_uint32_t  rt_interrupt_to_thread=0;
rt_uint32_t  rt_thread_switch_interrput_flag=0;
void rt_hw_context_switch_interrupt(rt_uint32_t from,rt_uint32_t to){
    rt_interrupt_from_thread = from;
    rt_interrupt_to_thread = to;
    rt_thread_switch_interrput_flag = 1;
}
void interrupt_thread_switch(){
	Params_t* xTaskToSuspend=(Params_t*)(*(int*)rt_interrupt_from_thread);
	Params_t* xTaskToResume=(Params_t*)(*(int*)rt_interrupt_to_thread);
#if _DEBUG==0
	printf("in interrupt_thread_switch():from_SP=%x,to_SP=%x\n",
									(int)xTaskToSuspend,
									(int)xTaskToResume);
#endif
	/* Remember and switch the critical nesting. */
	xTaskToSuspend->interrupt_nest=rt_interrupt_nest;
	xTaskToSuspend->InterruptsEnabled=g_InterruptsEnabled;
	rt_interrupt_nest =xTaskToResume->interrupt_nest;
	g_InterruptsEnabled=xTaskToResume->InterruptsEnabled;
	/* Switch tasks. */
	ResumeThread( xTaskToResume->hThread );
	SuspendThread( xTaskToSuspend->hThread );
}
rt_base_t rt_hw_interrupt_disable(void){
	g_InterruptsEnabled =FALSE;
	return 0;
}
void rt_hw_interrupt_enable(rt_base_t level){
	g_InterruptsEnabled =TRUE;
}
/*-----------------------------------------------------------*/

void EnterCritical( void ){
	rt_hw_interrupt_disable();
	rt_interrupt_nest ++;
}
/*-----------------------------------------------------------*/

void ExitCritical( void )
{
	/* Check for unmatched exits. */
	if ( rt_interrupt_nest > 0 )
	{
		rt_interrupt_nest--;
	}

	/* If we have reached 0 then re-enable the interrupts. */
	if( rt_interrupt_nest == 0 )
	{
		rt_hw_interrupt_enable(0);
	}
}
/*-----------------------------------------------------------*/

void SetupSignalsAndSchedulerPolicy( void )
{
/* The following code would allow for configuring the scheduling of this task as a Real-time task.
 * The process would then need to be run with higher privileges for it to take affect.
int iPolicy;
int iResult;
int iSchedulerPriority;
	iResult = pthread_getschedparam( pthread_self(), &iPolicy, &iSchedulerPriority );
	iResult = pthread_attr_setschedpolicy( &xThreadAttributes, SCHED_FIFO );
	iPolicy = SCHED_FIFO;
	iResult = pthread_setschedparam( pthread_self(), iPolicy, &iSchedulerPriority );		*/

struct sigaction sigsuspendself, sigresume, sigtick;
#if _DEBUG==1
	printf("in SetupSignalsAndSchedulerPolicy()\n");
#endif
	sigsuspendself.sa_flags = 0;
	sigsuspendself.sa_handler = SuspendSignalHandler;
	sigfillset( &sigsuspendself.sa_mask );

	sigresume.sa_flags = 0;
	sigresume.sa_handler = ResumeSignalHandler;
	sigfillset( &sigresume.sa_mask );

	sigtick.sa_flags = 0;
	sigtick.sa_handler = SystemTickHandler;
	sigfillset( &sigtick.sa_mask );

	if ( 0 != sigaction( SIG_SUSPEND, &sigsuspendself, NULL ) )
	{
		printf( "Problem installing SIG_SUSPEND_SELF\n" );
	}
	if ( 0 != sigaction( SIG_RESUME, &sigresume, NULL ) )
	{
		printf( "Problem installing SIG_RESUME\n" );
	}
	if ( 0 != sigaction( SIG_TICK, &sigtick, NULL ) )
	{
		printf( "Problem installing SIG_TICK\n" );
	}
	printf( "Running as PID: %d\n", getpid() );
}
void SystemTickHandler( int sig )
{
#if _DEBUG==0
	static int count=0;
	if(count++==75){
	printf("in SystemTickHandler():g_InterruptsEnabled=%s,g_ServicingTick=%s,rt_interrupt_nest=%d\n",
			g_InterruptsEnabled?"true":"false",
			g_ServicingTick?"true":"false",
			rt_interrupt_nest);
	count=0;
	}
#endif
	if ( ( TRUE == g_InterruptsEnabled ) && ( TRUE != g_ServicingTick ) )
	{
		if ( 0 == pthread_mutex_trylock( &g_SingleThreadMutex ) ){
			g_ServicingTick = TRUE;
#if _DEBUG==1
			printf("in SystemTickHandler():mutex trylock OK\n");
#endif
			rt_interrupt_enter();
			/* Tick Increment. */
			rt_tick_increase();
			rt_interrupt_leave();
			if(rt_thread_switch_interrput_flag==1){
				rt_thread_switch_interrput_flag=0 ;
				interrupt_thread_switch();
			}else{
				/* Release the lock as we are Resuming. */
				(void)pthread_mutex_unlock( &g_SingleThreadMutex );
#if _DEBUG==1
				printf("in SystemTickHandler():mutex unlock OK\n");
#endif
			}
			g_ServicingTick = FALSE;
			//g_InterruptsEnabled=TRUE;
			/*a bug some where that may set g_InterruptsEnabled false
			*but the fact is that when come here it should be TRUE
			*/
		}
	}
#if _DEBUG==1
	printf("out SystemTickHandler()\n");
#endif
}
/*
 * Setup the systick timer to generate the tick interrupts at the required
 * frequency.
 */
void SetupTimerInterrupt( void )
{
struct itimerval itimer, oitimer;
int xMicroSeconds = 1000000 / RT_TICK_PER_SECOND;
#if _DEBUG==1
	printf("in SetupTimerInterrupt()\n");
#endif
	/* Initialise the structure with the current timer information. */
	if ( 0 == getitimer( TIMER_TYPE, &itimer ) )
	{
		/* Set the interval between timer events. */
		itimer.it_interval.tv_sec = 0;
		itimer.it_interval.tv_usec = xMicroSeconds;
		/* Set the current count-down. */
		itimer.it_value.tv_sec = 0;
		itimer.it_value.tv_usec = xMicroSeconds;

		/* Set-up the timer interrupt. */
		if ( 0 != setitimer( TIMER_TYPE, &itimer, &oitimer ) )
		{
			printf( "Set Timer problem.\n" );
		}
	}
	else
	{
		printf( "Get Timer problem.\n" );
	}
}
void SuspendSignalHandler(int sig)
{
sigset_t xSignals;

	/* Only interested in the resume signal. */
	sigemptyset( &xSignals );
	sigaddset( &xSignals, SIG_RESUME );
	g_Sentinel = 1;

	/* Unlock the Single thread mutex to allow the resumed task to continue. */
	if ( 0 != pthread_mutex_unlock( &g_SingleThreadMutex ) )
	{
		printf( "Releasing someone else's lock.\n" );
	}

	/* Wait on the resume signal. */
	if ( 0 != sigwait( &xSignals, &sig ) )
	{
		printf( "SSH: Sw %d\n", sig );
	}

	/* Will resume here when the SIG_RESUME signal is received. */
	/* Need to set the interrupts based on the task's critical nesting. */
	if ( rt_interrupt_nest == 0 )
	{
		rt_hw_interrupt_enable(0);
	}
	else
	{
		rt_hw_interrupt_disable();
	}
}

void *WaitForStart( void * pvParams )
{
Params_t * pxParams = ( Params_t * )pvParams;
void (*task)(void *);
void (*exit)();
task = pxParams->task;
exit= pxParams->exit;
void * pParams = pxParams->parameter;
#if _DEBUG==1
	printf("in WaitForStart()\n");
#endif

	if ( 0 == pthread_mutex_lock( &g_SingleThreadMutex ) )
	{
		SuspendThread( pthread_self() );
	}

	task( pParams );
	exit();

	return (void *)NULL;
}
/*-----------------------------------------------------------*/

void ResumeSignalHandler(int sig)
{
#if _DEBUG==1
	printf("in ResumeSignalHandler()\n");
#endif
	/* Yield the Scheduler to ensure that the yielding thread completes. */
	if ( 0 == pthread_mutex_lock( &g_SingleThreadMutex ) )
	{
		(void)pthread_mutex_unlock( &g_SingleThreadMutex );
	}
}
void SuspendThread( pthread_t xThreadId )
{
#if _DEBUG==1
	printf("in SuspendThread()\n");
#endif
	int xResult = pthread_mutex_lock( &g_SuspendResumeThreadMutex );
	if ( 0 == xResult )
	{
		/* Set-up for the Suspend Signal handler? */
		g_Sentinel = 0;
		xResult = pthread_mutex_unlock( &g_SuspendResumeThreadMutex );
		xResult = pthread_kill( xThreadId, SIG_SUSPEND );
		while ( ( g_Sentinel == 0 ) && ( TRUE != g_ServicingTick ) )
		{
			sched_yield();
		}
	}
}
void ResumeThread( pthread_t xThreadId )
{
#if _DEBUG==1
	printf("in ResumeThread():thread_id=%d\n",(int)xThreadId);
#endif
	if ( 0 == pthread_mutex_lock( &g_SuspendResumeThreadMutex ) )
	{
#if _DEBUG==1
	printf("in ResumeThread(),mutex locked successfully\n");
#endif
		if ( pthread_self() != xThreadId )
		{
			pthread_kill( xThreadId, SIG_RESUME );
		}
#if _DEBUG==1
	printf("in ResumeThread(),resumed successfully\n");
#endif
		pthread_mutex_unlock( &g_SuspendResumeThreadMutex );
#if _DEBUG==1
	printf("in ResumeThread(),mutex unlocked successfully\n");
#endif
	}
}
