#include "rtthread.h"
#include "application.h"

#ifdef RT_USING_DFS
#include "dfs_fs.h"
#include "dfs_fat.h"
#include "dfs_init.h"
#include "dfs_elm.h"
#include "sdcard.h"
#include "dfs_posix.h"
#endif

static void thread_entry(void* parameter){
      	 while(1){    
          rt_kprintf("thread %d is running\n",(int)parameter);
      	  rt_thread_delay(RT_TICK_PER_SECOND);
  	}
}
#ifdef RT_USING_DFS
#define TEST_FN	"/test2.dat"
/* 测试用的数据和缓冲 */
static char buffer[514];
static char test_data[120];
/* 线程入口 */
static void thread_fs_entry(void* parameter){
 #ifdef RT_USING_DFS_ELMFAT
  /* 如果使用的是ELM的FAT文件系统,需要对它进行初始化 */
  elm_init();
#if SD_DEBUG==1
  rt_kprintf("elm_init(): OK\n");
#endif
  /* 调用dfs_mount函数对设备进行挂接 */
    if (0==dfs_mount((char*)"sd0",(char*) "/", (char*)"elm", (unsigned long)0,(void*) 0)  )
      rt_kprintf("File System initialized!\n");
    else
      rt_kprintf("File System init failed!\n");
 #endif
		int fd;
		int index, length;
		/* 只写 & 创建 打开 */
		fd = open(TEST_FN, O_WRONLY | O_CREAT | O_TRUNC, 0);
		if (fd < 0)
		{
			rt_kprintf("open file for write failed\n");
			return;
		}

		/* 准备写入数据 */
		for (index = 0; index < sizeof(test_data); index ++)
		{
			test_data[index] = index + 27;
		}

		/* 写入数据 */
		length = write(fd, test_data, sizeof(test_data));
		if (length != sizeof(test_data))
		{
			rt_kprintf("write data failed\n");
			close(fd);
			return;
		}

		/* 关闭文件 */
		close(fd);

		/* 只写并在末尾添加打开 */
		fd = open(TEST_FN, O_WRONLY | O_CREAT | O_APPEND, 0);
		if (fd < 0)
		{
			rt_kprintf("open file for append write failed\n");
			return;
		}

		length = write(fd, test_data, sizeof(test_data));
		if (length != sizeof(test_data))
		{
			rt_kprintf("append write data failed\n");
			close(fd);
			return;
		}
		/* 关闭文件 */
		close(fd);

		/* 只读打开进行数据校验 */
		fd = open(TEST_FN, O_RDONLY, 0);
		if (fd < 0)
		{
			rt_kprintf("check: open file for read failed\n");
			return;
		}

		/* 读取数据(应该为第一次写入的数据) */
		length = read(fd, buffer, sizeof(test_data));
		if (length != sizeof(test_data))
		{
			rt_kprintf("check: read file failed\n");
			close(fd);
			return;
		}

		/* 检查数据是否正确 */
		for (index = 0; index < sizeof(test_data); index ++)
		{
			if (test_data[index] != buffer[index])
			{
				rt_kprintf("check: check data failed at %d\n", index);
				close(fd);
				return;
			}
		}

		/* 读取数据(应该为第二次写入的数据) */
		length = read(fd, buffer, sizeof(test_data));
		if (length != sizeof(test_data))
		{
			rt_kprintf("check: read file failed\n");
			close(fd);
			return;
		}

		/* 检查数据是否正确 */
		for (index = 0; index < sizeof(test_data); index ++)
		{
			if (test_data[index] != buffer[index])
			{
				rt_kprintf("check: check data failed at %d\n", index);
				close(fd);
				return;
			}
		}

	/* 检查数据完毕，关闭文件 */
	close(fd);
	/* 打印结果 */
	rt_kprintf("read/write done.\n");
}
#endif

int thread_dynamic_simple_init()
{
      rt_thread_t tid;
      /*动态的创建一个线程1*/
     tid=rt_thread_create("t1",
		thread_entry,(void *)1,
		THREAD_STACK_SIZE, THREAD_PRIORITY, 2);
#if _DEBUG==1
    rt_kprintf("create thread 1 OK\n");
#endif
	if (tid != RT_NULL){
		rt_thread_startup(tid);
#if _DEBUG==1
		rt_kprintf("start thread 1 OK\n");
#endif
	}
	 /*动态的创建一个线程2*/
        tid=rt_thread_create("t2",
		thread_entry,(void *)2,
		THREAD_STACK_SIZE, THREAD_PRIORITY, 2);
#if _DEBUG==1
    rt_kprintf("create thread 2 OK\n");
#endif
	if (tid != RT_NULL){
		rt_thread_startup(tid);
#if _DEBUG==1
		rt_kprintf("start thread 2 OK\n");
#endif
	}
#ifdef RT_USING_DFS
	/*动态的创建一个线程3*/
       tid=rt_thread_create("t3",
		thread_fs_entry,(void *)3,
		THREAD_STACK_SIZE, THREAD_PRIORITY, 2);
#if _DEBUG==1
    rt_kprintf("create thread 3 OK\n");
#endif
	if (tid != RT_NULL){
		rt_thread_startup(tid);
#if _DEBUG==1
		rt_kprintf("start thread 3 OK\n");
#endif
	}
#endif
	return 0;
}
/* 用户应用入口 */
int rt_application_init()
{
#ifdef _DEBUG
rt_kprintf("in rt_application_init()\n");
#endif
	thread_dynamic_simple_init();
	semaphore_producer_consumer_init();
	return 0;
}

