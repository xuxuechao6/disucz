//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
//------------------------------------------------------------------------------
//
//  Header: s3c2450.h
//
//  This header file defines the S3C2450 processor.
//
//  The s3C2450 is a System on Chip (SoC) part consisting of an ARM920T core. 
//  This header file is comprised of component header files that define the 
//  register layout of each component.
//  
//------------------------------------------------------------------------------
#ifndef __S3C2450_H
#define __S3C2450_H

#if __cplusplus
extern "C" {
#endif


#include <stdint.h>

#define __REG(x)    (*(volatile uint32_t *)(x))

#define __REGb(x)   (*(volatile uint16_T *)(x))


/* S3C2416 only supports 512 Byte HW ECC */
#define S3C2410_ECCSIZE     512
#define S3C2410_ECCBYTES    3

/* S3C2416 device base addresses */
#define ELFIN_SSTONE_BASE   0x40000000 /* stepping stone on iROM boot */
#define ELFIN_DMA_BASE      0x4b000000
#define ELFIN_USB_HOST_BASE 0x49000000
#define ELFIN_USB_DEVICE_BASE   0x49800000
#define ELFIN_I2C_BASE      0x54000000
#define ELFIN_I2S_BASE      0x55000000
#define ELFIN_ADC_BASE      0x58000000
#define ELFIN_SPI_BASE      0x59000000

/*
 * Clock and power management
 */
#define ELFIN_CLOCK_POWER_BASE  0x4c000000

/* Clock & Power Controller */
#define LOCKCON0_OFFSET     0x00
#define LOCKCON1_OFFSET     0x04
#define OSCSET_OFFSET       0x08
#define MPLLCON_OFFSET      0x10
#define EPLLCON_OFFSET      0x18
#define CLKSRCCON_OFFSET    0x20
#define CLKDIV0CON_OFFSET   0x24
#define CLKDIV1CON_OFFSET   0x28
#define HCLKCON_OFFSET      0x30
#define PCLKCON_OFFSET      0x34
#define SCLKCON_OFFSET      0x38
#define PWRMODECON_OFFSET   0x40
#define SWRSTCON_OFFSET     0x44
#define BUSPRI0_OFFSET      0x50
#define BUS_MISC_OFFSET     0x58
#define SYSID_OFFSET        0x5c
#define PWRCFG_OFFSET       0x60
#define RSTCON_OFFSET       0x64
#define RSTSTAT_OFFSET      0x68
#define WKUPSTAT_OFFSET     0x6c
#define INFORM0_OFFSET      0x70
#define INFORM1_OFFSET      0x74
#define INFORM2_OFFSET      0x78
#define INFORM3_OFFSET      0x7c
#define USB_PHYCTRL_OFFSET  0x80
#define USB_PHYPWR_OFFSET   0x84
#define USB_RSTCON_OFFSET   0x88
#define USB_CLKCON_OFFSET   0x8c
#define USB_TESTTI_OFFSET   0x90
#define USB_TESTTO_OFFSET   0x94

#define LOCKCON0    (0x4c000000)
#define LOCKCON1    (0x4c000004)
#define OSCSET      (0x4c000008)
#define MPLLCON     (0x4c000010)
#define EPLLCON     (0x4c000018)
#define CLKSRCCON   (0x4c000020)
#define CLKDIV0CON  (0x4c000024)
#define CLKDIV1CON  (0x4c000028)
#define HCLKCON     (0x4c000030)
#define PCLKCON     (0x4c000034)
#define SCLKCON     (0x4c000038)
#define PWRMODECON  (0x4c000040)
#define SWRSTCON    (0x4c000044)
#define BUSPRI0     (0x4c000050)
#define BUS_MISC    (0x4c000058)
#define SYSID       (0x4c00005c)
#define PWRCFG      (0x4c000060)
#define RSTCON      (0x4c000064)
#define RSTSTAT     (0x4c000068)
#define WKUPSTAT    (0x4c00006c)
#define INFORM0     (0x4c000070)
#define INFORM1     (0x4c000074)
#define INFORM2     (0x4c000078)
#define INFORM3     (0x4c00007c)
#define USB_PHYCTRL (0x4c000080)
#define USB_PHYPWR  (0x4c000084)
#define USB_RSTCON  (0x4c000088)
#define USB_CLKCON  (0x4c00008c)
#define USB_TESTTI  (0x4c000090)
#define USB_TESTTO  (0x4c000094)

#define LOCKCON0_REG        __REG(0x4c000000)
#define LOCKCON1_REG        __REG(0x4c000004)
#define OSCSET_REG      __REG(0x4c000008)
#define MPLLCON_REG     __REG(0x4c000010)
#define EPLLCON_REG     __REG(0x4c000018)
#define CLKSRCCON_REG       __REG(0x4c000020)
#define CLKDIV0CON_REG      __REG(0x4c000024)
#define CLKDIV1CON_REG      __REG(0x4c000028)
#define HCLKCON_REG     __REG(0x4c000030)
#define PCLKCON_REG     __REG(0x4c000034)
#define SCLKCON_REG     __REG(0x4c000038)
#define PWRMODECON_REG      __REG(0x4c000040)
#define SWRSTCON_REG        __REG(0x4c000044)
#define BUSPRI0_REG     __REG(0x4c000050)
#define BUS_MISC_REG        __REG(0x4c000058)
#define SYSID_REG       __REG(0x4c00005c)
#define PWRCFG_REG      __REG(0x4c000060)
#define RSTCON_REG      __REG(0x4c000064)
#define RSTSTAT_REG     __REG(0x4c000068)
#define WKUPSTAT_REG        __REG(0x4c00006c)
#define INFORM0_REG     __REG(0x4c000070)
#define INFORM1_REG     __REG(0x4c000074)
#define INFORM2_REG     __REG(0x4c000078)
#define INFORM3_REG     __REG(0x4c00007c)
#define USB_PHYCTRL_REG     __REG(0x4c000080)
#define USB_PHYPWR_REG      __REG(0x4c000084)
#define USB_RSTCON_REG      __REG(0x4c000088)
#define USB_CLKCON_REG      __REG(0x4c00008c)
#define USB_TESTTI_REG      __REG(0x4c000090)
#define USB_TESTTO_REG      __REG(0x4c000094)


/*
 * Bus Matrix (chap 3)
 */

#define ELFIN_BUS_MAT_BASE  0x4e800000
#define BPRIORITY0      (ELFIN_BUS_MAT_BASE+0x00)
#define BPRIORITY1      (ELFIN_BUS_MAT_BASE+0x04)
#define EBICON          (ELFIN_BUS_MAT_BASE+0x08)

//typedef struct
//{
//    uint32_t  PRIORITY0;             //0x00
//    uint32_t  PRIORITY1;             //0x04
//    uint32_t  EBICON;                //0x08
//    uint32_t  ROMSEL;                //0x0C
//} MATRIX_TypeDef;
//
//#define MATRIX_CTRL     ((MATRIX_TypeDef *)ELFIN_BUS_MAT_BASE)

/*
 * GPIO
 */

#define ELFIN_GPIO_BASE     0x56000000

typedef struct {
    uint32_t GPACON;                      // Port A - offset 0x00
    uint32_t GPADAT;                      // Data
    uint32_t PAD1[2];

    uint32_t GPBCON;                      // Port B - offset 0x10
    uint32_t GPBDAT;                      // Data
    uint32_t GPBUDP;                      // Pull-up disable
    uint32_t PAD2;

    uint32_t GPCCON;                  // Port C - offset 0x20
    uint32_t GPCDAT;                  // Data
    uint32_t GPCUDP;                   // Pull-up disable
    uint32_t PAD3;

    uint32_t GPDCON;                  // Port D - offset 0x30
    uint32_t GPDDAT;                  // Data
    uint32_t GPDUDP;                   // Pull-up disable
    uint32_t PAD4;

    uint32_t GPECON;                  // Port E - offset 0x40
    uint32_t GPEDAT;                  // Data
    uint32_t GPEUDP;                   // Pull-up disable
    uint32_t PAD5;

    uint32_t GPFCON;                  // Port F - offset 0x50
    uint32_t GPFDAT;
    uint32_t GPFUDP;
    uint32_t PAD6;

    uint32_t GPGCON;                  // Port G - offset 0x60
    uint32_t GPGDAT;
    uint32_t GPGUDP;
    uint32_t PAD7;

    uint32_t GPHCON;                  // Port H - offset 0x70
    uint32_t GPHDAT;
    uint32_t GPHUDP;
    uint32_t PAD8;

    uint32_t MISCCR;                  // misc control reg - offset 0x80
    uint32_t DCLKCON;                 // DCLK0/1 control reg

    uint32_t EXTINT0;                 // external interrupt control reg 0
    uint32_t EXTINT1;                 // external interrupt control reg 1
    uint32_t EXTINT2;                 // external interrupt control reg 2

    uint32_t EINTFLT0;                // reserved
    uint32_t EINTFLT1;                // reserved
    uint32_t EINTFLT2;                // external interrupt filter reg 2
    uint32_t EINTFLT3;                // external interrupt filter reg 3

    uint32_t EINTMASK;                // external interrupt mask reg
    uint32_t EINTPEND;                // external interrupt pending reg

    uint32_t GSTATUS0;                // external pin status
    uint32_t GSTATUS1;                // chip ID
    uint32_t GSTATUS2;                // reset status
    uint32_t GSTATUS3;                // inform register
    uint32_t GSTATUS4;                // inform register

    uint32_t DSC0;                    // C0 - added by simon
    uint32_t DSC1;
    uint32_t DSC2;
    uint32_t MSLCON;

    uint32_t GPJCON;                  // D0
    uint32_t GPJDAT;
    uint32_t GPJUDP;
    uint32_t PDA9;

    uint32_t GPKCON;                  // E0
    uint32_t GPKDAT;
    uint32_t GPKUDP;
    uint32_t PDA10;

    uint32_t GPLCON;                  // F0
    uint32_t GPLDAT;
    uint32_t GPLUDP;
    uint32_t PDA11;

    uint32_t GPMCON;                  // 100
    uint32_t GPMDAT;
    uint32_t GPMUDP;
    uint32_t PDA12;
} GPIO_TypeDef;

#define GPIO_CTRL       ((GPIO_TypeDef *)ELFIN_GPIO_BASE)


/*
 * Memory controller
 */

#define ELFIN_SROM_BASE 0x40c20000

#define SROM_BW_REG __REG(0x40C20000)
#define SROM_BC0_REG    __REG(0x40C20004)
#define SROM_BC1_REG    __REG(0x40C20008)
#define SROM_BC2_REG    __REG(0x40C2000C)

/*
 * SDRAM Controller
 */

#define ELFIN_DRAMCTL_BASE   0x48000000
#define BANKCFG_OFFSET      0x00
#define BANKCON1_OFFSET     0x04
#define BANKCON2_OFFSET     0x08
#define BANKCON3_OFFSET     0x0c
#define REFRESH_OFFSET      0x10
#define TIMEOUT_OFFSET      0x14

typedef struct
{
    uint32_t  BANKCFG;             //0x00
    uint32_t  BANKCON1;             //0x04
    uint32_t  BANKCON2;                //0x08
    uint32_t  BANKCON3;                //0x0C
    uint32_t  REFRESH;                //0x10
    uint32_t  TIMEOUT;                //0x14

} DRAM_TypeDef;

#define DRAM_CTRL    ((DRAM_TypeDef *)0x48000000)


#define INIT_NORMAL 0x0
#define INIT_PALL   0x1
#define INIT_MRS    0x2
#define INIT_EMRS   0x3
#define INIT_MASK   0x3


/*
 * Nand flash controller
 */

#define ELFIN_NAND_BASE 0x4e000000

#define NFCONF_OFFSET       0x00
#define NFCONT_OFFSET       0x04
#define NFCMMD_OFFSET       0x08
#define NFADDR_OFFSET       0x0c
#define NFDATA_OFFSET       0x10
#define NFMECCDATA0_OFFSET  0x14
#define NFMECCDATA1_OFFSET  0x18
#define NFSECCDATA0_OFFSET  0x1c
#define NFSBLK_OFFSET       0x20
#define NFEBLK_OFFSET       0x24
#define NFSTAT_OFFSET       0x28
#define NFESTAT0_OFFSET     0x2c
#define NFESTAT1_OFFSET     0x30
#define NFMECC0_OFFSET      0x34
#define NFMECC1_OFFSET      0x38
#define NFSECC_OFFSET       0x3c
#define NFMLCBITPT_OFFSET       0x40
#define NF8ECCERR0_OFFSET   0x44
#define NF8ECCERR1_OFFSET   0x48
#define NF8ECCERR2_OFFSET   0x4c
#define NFM8ECC0_OFFSET     0x50
#define NFM8ECC1_OFFSET     0x54
#define NFM8ECC2_OFFSET     0x58
#define NFM8ECC3_OFFSET     0x5c
#define NFMLC8BITPT0_OFFSET 0x60
#define NFMLC8BITPT1_OFFSET 0x64

#define NFCONF      (0x4e000000)
#define NFCONT      (0x4e000004)
#define NFCMMD      (0x4e000008)
#define NFADDR      (0x4e00000c)
#define NFDATA      (0x4e000010)
#define NFMECCDATA0 (0x4e000014)
#define NFMECCDATA1 (0x4e000018)
#define NFSECCDATA0 (0x4e00001c)
#define NFSBLK      (0x4e000020)
#define NFEBLK      (0x4e000024)
#define NFSTAT      (0x4e000028)
#define NFESTAT0    (0x4e00002c)
#define NFESTAT1    (0x4e000030)
#define NFMECC0     (0x4e000034)
#define NFMECC1     (0x4e000038)
#define NFSECC      (0x4e00003c)
#define NFMLCBITPT  (0x4e000040)
#define NF8ECCERR0      (0x4e000044)
#define NF8ECCERR1      (0x4e000048)
#define NF8ECCERR2      (0x4e00004c)
#define NFM8ECC0        (0x4e000050)
#define NFM8ECC1        (0x4e000054)
#define NFM8ECC2        (0x4e000058)
#define NFM8ECC3        (0x4e00005c)
#define NFMLC8BITPT0        (0x4e000060)
#define NFMLC8BITPT1        (0x4e000064)

#define NFCONF_REG      __REG(0x4e000000)
#define NFCONT_REG      __REG(0x4e000004)
#define NFCMD_REG       __REG(0x4e000008)
#define NFADDR_REG      __REG(0x4e00000c)
#define NFDATA_REG      __REG(0x4e000010)
#define NFDATA8_REG     __REGb(0x4e000010)
#define NFMECCDATA0_REG     __REG(0x4e000014)
#define NFMECCDATA1_REG     __REG(0x4e000018)
#define NFSECCDATA0_REG     __REG(0x4e00001c)
#define NFSBLK_REG      __REG(0x4e000020)
#define NFEBLK_REG      __REG(0x4e000024)
#define NFSTAT_REG      __REG(0x4e000028)
#define NFESTAT0_REG        __REG(0x4e00002c)
#define NFESTAT1_REG        __REG(0x4e000030)
#define NFMECC0_REG     __REG(0x4e000034)
#define NFMECC1_REG     __REG(0x4e000038)
#define NFSECC_REG      __REG(0x4e00003c)
#define NFMLCBITPT_REG      __REG(0x4e000040)

#define NFCONF_ECC_MLC      (1<<24)

#define NFCONF_ECC_1BIT     (0<<23)
#define NFCONF_ECC_4BIT     (2<<23)
#define NFCONF_ECC_8BIT     (1<<23)

#define NFCONT_ECC_ENC      (1<<18)
#define NFCONT_WP       (1<<16)
#define NFCONT_MECCLOCK     (1<<7)
#define NFCONT_SECCLOCK     (1<<6)
#define NFCONT_INITMECC     (1<<5)
#define NFCONT_INITSECC     (1<<4)
#define NFCONT_INITECC      (NFCONT_INITMECC | NFCONT_INITSECC)
#define NFCONT_CS_ALT       (1<<1)
#define NFCONT_CS       (1<<1)
#define NFSTAT_ECCENCDONE   (1<<7)
#define NFSTAT_ECCDECDONE   (1<<6)
#define NFSTAT_RnB      (1<<0)
#define NFESTAT0_ECCBUSY    (1<<31)

/*
 * Interrupt
 */
#define ELFIN_INTERRUPT_BASE    0x4a000000

typedef struct {
    uint32_t SRCPND1;                     // interrupt request status reg
    uint32_t INTMOD1;                     // interrupt mode reg
    uint32_t INTMSK1;                     // interrupt mask reg
    uint32_t PAD0;

    uint32_t INTPND1;                     // interrupt pending reg
    uint32_t INTOFFSET1;                  // interrupt offset reg
    uint32_t SUBSRCPND;                  // SUB source pending reg
    uint32_t INTSUBMSK;                  // interrupt SUB mask reg


    uint32_t PAD1[4];

    uint32_t PRIORITY_MODE1;                   // priority reg
    uint32_t PRIORITY_UPDATE1;                   // priority reg
    uint32_t PAD2[2];


    uint32_t SRCPND2;                     // interrupt request status reg
    uint32_t INTMOD2;                     // interrupt mode reg
    uint32_t INTMSK2;                     // interrupt mask re
    uint32_t PAD3;


    uint32_t INTPND2;                     // interrupt pending reg
    uint32_t INTOFFSET2;                  // interrupt offset reg
    uint32_t PAD4[2];

    uint32_t PAD5[4];


    uint32_t PRIORITY_MODE2;                // priority reg
    uint32_t PRIORITY_UPDATE2;              // priority reg
    uint32_t PAD6[2];
} INTR_TypeDef;

#define INTR_CTRL        ((INTR_TypeDef *) ELFIN_INTERRUPT_BASE)

//#define INTMSK_OFFSET       0x08
//#define INTSUBMSK_OFFSET    0x1c
//#define INTMOD_OFFSET       0x04
//
//#define SRCPND_REG      __REG(0x4a000000)
//#define INTMOD_REG      __REG(0x4a000004)
//#define INTMSK_REG      __REG(0x4a000008)
//#define INTPND_REG      __REG(0x4a000010)
//#define INTOFFSET_REG       __REG(0x4a000014)
//#define SUBSRCPND_REG       __REG(0x4a000018)
//#define INTSUBMSK_REG       __REG(0x4a00001C)
//#define PRIORITY_MODE_REG   __REG(0x4a000030)
//#define PRIORITY_UPDATE_REG __REG(0x4a000034)
//#define SRCPND2_REG         __REG(0x4a000040)
//#define INTMOD2_REG         __REG(0x4a000044)
//#define INTMSK2_REG             __REG(0X4A000048)
//#define INTPND2                 __REG(0X4A000050)
//#define INTOFFSET2          __REG(0X4A000054)
//#define PRIORITY_MODE2      __REG(0x4A000070)
//#define PRIORITY_UPDATE2    __REG(0x4A000074)

/*
 * LCD Controller
 */
#define ELFIN_LCD_BASE  0x4c800000

#define VIDCON0     (0x4c800000)
#define VIDCON1     (0x4c800004)
#define VIDTCON0    (0x4c800008)
#define VIDTCON1    (0x4c80000C)
#define VIDTCON2    (0x4c800010)
#define WINCON0     (0x4c800014)
#define WINCON1     (0x4c800018)
#define VIDOSD0A    (0x4c800028)
#define VIDOSD0B    (0x4c80002C)
#define VIDOSD0C    (0x4c800030)
#define VIDOSD1A    (0x4c800034)
#define VIDOSD1B    (0x4c800038)
#define VIDOSD1C    (0x4c80003C)
#define VIDW00ADD0B0    (0x4c800064)
#define VIDW00ADD0B1    (0x4c800068)
#define VIDW01ADD0  (0x4c80006C)
#define VIDW00ADD1B0    (0x4c80007C)
#define VIDW00ADD1B1    (0x4c800080)
#define VIDW01ADD1  (0x4c800084)
#define VIDW00ADD2B0    (0x4c800094)
#define VIDW00ADD2B1    (0x4c800098)
#define VIDW01ADD2  (0x4c80009C)
#define VIDINTCON   (0x4c8000AC)
#define W1KEYCON0   (0x4c8000B0)
#define W1KEYCON1   (0x4c8000B4)
#define W2KEYCON0   (0x4c8000B8)
#define W2KEYCON1   (0x4c8000BC)
#define W3KEYCON0   (0x4c8000C0)
#define W3KEYCON1   (0x4c8000C4)
#define W4KEYCON0   (0x4c8000C8)
#define W4KEYCON1   (0x4c8000CC)
#define WIN0MAP     (0x4c8000D0)
#define WIN1MAP     (0x4c8000D4)
#define WPALCON     (0x4c8000E4)
#define SYSIFCON0   (0x4c800130)
#define SYSIFCON1   (0x4c800134)
#define DITHMODE1   (0x4c800138)
#define SIFCCON0    (0x4c80013C)
#define SIFCCON1    (0x4c800140)
#define SIFCCON2    (0x4c800144)
#define CPUTRIGCON1 (0x4c80015C)
#define CPUTRIGCON2 (0x4c800160)
#define VIDW00ADD0B1    (0x4c800068)
#define VIDW01ADD0  (0x4c80006C)

//ZhangGQ add 20130401
#define VIDCON0_REG     __REG(0x4c800000)
#define VIDCON1_REG     __REG(0x4c800004)
#define VIDTCON0_REG    __REG(0x4c800008)
#define VIDTCON1_REG    __REG(0x4c80000C)
#define VIDTCON2_REG    __REG(0x4c800010)
#define WINCON0_REG     __REG(0x4c800014)
#define WINCON1_REG     __REG(0x4c800018)
#define VIDOSD0A_REG    __REG(0x4c800028)
#define VIDOSD0B_REG    __REG(0x4c80002C)
#define VIDOSD0C_REG    __REG(0x4c800030)
#define VIDOSD1A_REG    __REG(0x4c800034)
#define VIDOSD1B_REG    __REG(0x4c800038)
#define VIDOSD1C_REG    __REG(0x4c80003C)
#define VIDW00ADD0B0_REG    __REG(0x4c800064)
#define VIDW00ADD0B1_REG    __REG(0x4c800068)
#define VIDW01ADD0_REG      __REG(0x4c80006C)
#define VIDW00ADD1B0_REG    __REG(0x4c80007C)
#define VIDW00ADD1B1_REG    __REG(0x4c800080)
#define VIDW01ADD1_REG      __REG(0x4c800084)
#define VIDW00ADD2B0_REG    __REG(0x4c800094)
#define VIDW00ADD2B1_REG    __REG(0x4c800098)
#define VIDW01ADD2_REG  __REG(0x4c80009C)
#define VIDINTCON_REG   __REG(0x4c8000AC)
#define W1KEYCON0_REG   __REG(0x4c8000B0)
#define W1KEYCON1_REG   __REG(0x4c8000B4)
#define W2KEYCON0_REG   __REG(0x4c8000B8)
#define W2KEYCON1_REG   __REG(0x4c8000BC)
#define W3KEYCON0_REG   __REG(0x4c8000C0)
#define W3KEYCON1_REG   __REG(0x4c8000C4)
#define W4KEYCON0_REG   __REG(0x4c8000C8)
#define W4KEYCON1_REG   __REG(0x4c8000CC)
#define WIN0MAP_REG     __REG(0x4c8000D0)
#define WIN1MAP_REG     __REG(0x4c8000D4)
#define WPALCON_REG     __REG(0x4c8000E4)
#define SYSIFCON0_REG   __REG(0x4c800130)
#define SYSIFCON1_REG   __REG(0x4c800134)
#define DITHMODE1_REG   __REG(0x4c800138)
#define SIFCCON0_REG    __REG(0x4c80013C)
#define SIFCCON1_REG    __REG(0x4c800140)
#define SIFCCON2_REG    __REG(0x4c800144)
#define CPUTRIGCON1_REG __REG(0x4c80015C)
#define CPUTRIGCON2_REG __REG(0x4c800160)
#define VIDW00ADD0B1_REG    __REG(0x4c800068)
#define VIDW01ADD0_REG  __REG(0x4c80006C)

//* VIDCON0
#define VIDCON0_S_RGB_IF                    (0<<22)
#define VIDCON0_S_CPU_IF_MAIN               (2<<22)
#define VIDCON0_S_CPU_IF_SUB                (3<<22)

#define VIDCON0_CPU_16BIT                   (0<<19)
#define VIDCON0_CPU_16plus2                 (1<<19)
#define VIDCON0_CPU_9plus9                  (2<<19)
#define VIDCON0_CPU_16plus8                 (3<<19)
#define VIDCON0_CPU_18BIT                   (4<<19)

#define VIDCON0_S_RGB_PAR                   (0<<13)
#define VIDCON0_S_BGR_PAR                   (1<<13)
#define VIDCON0_S_RGB_SER                   (2<<13)
#define VIDCON0_S_BGR_SER                   (3<<13)
#define VIDCON0_S_CLKVAL_F_AlWAYS_UPDATE    (0<<12)
#define VIDCON0_S_CLKVAL_F_SOF_UPDATE       (1<<12)
#define VIDCON0_S_VCLK_GATING_ON            (0<<5)
#define VIDCON0_S_VCLK_GATING_OFF           (1<<5)
#define VIDCON0_S_CLKDIR_DIRECT             (0<<4)
#define VIDCON0_S_CLKDIR_DIVIDED            (1<<4)
#define VIDCON0_S_CLKSEL_HCLK               (0<<2)
#define VIDCON0_S_CLKSEL_EPLL               (1<<2)
#define VIDCON0_S_ENVID_OFF                 (0<<1)
#define VIDCON0_S_EVVID_ON                  (1<<1)
#define VIDCON0_S_ENVID_F_OFF               (0<<0)
#define VIDCON0_S_ENVID_F_ON                (1<<0)
//bit shift
#define VIDCON0_CLKVAL_F_SHIFT              (6)

//* VIDCON1
#define VIDCON1_S_VCLK_FALL_EDGE_FETCH      (0<<7)
#define VIDCON1_S_VCLK_RISE_EDGE_FETCH      (1<<7)
#define VIDCON1_S_HSYNC_INVERTED            (1<<6)
#define VIDCON1_S_VSYNC_INVERTED            (1<<5)
#define VIDCON1_S_VDEN_INVERTED             (1<<4)

//* VIDTCON0,1
//bit shift
#define VIDTCON0_BPD_S              (16)
#define VIDTCON0_FPD_S              (8)
#define VIDTCON0_SPW_S              (0)

//* VIDTCON2
//bit shift
#define VIDTCON2_LINEVAL_S          (11)
#define VIDTCON2_HOZVAL_S           (0)


//* WINCON1to4
#define WINCONx_BIT_SWAP_ON         (1<<2)  //shift on basis of half-word swap
#define WINCONx_BYTE_SWAP_ON        (1<<1)  //shift on basis of half-word swap
#define WINCONx_HALFW_SWAP_ON       (1<<0)  //shift on basis of half-word swap
#define WINCONx_4WORD_BURST         (2)
#define WINCONx_8WORD_BURST         (1)
#define WINCONx_16WORD_BURST        (0)
#define WINCONx_PLANE_BLENDING      (0)
#define WINCONx_PIXEL_BLENDING      (1)
#define WINCONx_1BPP_PALLET         (0)
#define WINCONx_2BPP_PALLET         (1)
#define WINCONx_4BPP_PALLET         (2)
#define WINCONx_8BPP_PALLET         (3)
#define WINCONx_8BPP_NO_PALLET      (4)
#define WINCONx_16BPP_565           (5)
#define WINCONx_16BPP_A555          (6)
#define WINCONx_16BPP_1555          (7)
#define WINCONx_18BPP_666           (8)
#define WINCONx_18BPP_A665          (9)
#define WINCONx_19BPP_A666          (10)
#define WINCONx_24BPP_888           (11)
#define WINCONx_24BPP_A887          (12)
#define WINCONx_25BPP_A888          (13)
#define WINCONx_ALPHA_MODE_0        (0)
#define WINCONx_ALPHA_MODE_1        (1)

//bit shift
#define WINCON_BUFSEL               (23)
#define WINCON_BUFAUTOEN            (22)
#define WINCON_SWAP_S               (16)
#define WINCON_BURSTLEN_S           (9)
#define WINCON_BLENDING_S           (6)
#define WINCON_BPP_S                (2)
#define WINCON_ALPHA_S              (1)

//* VIDWxADD2
//bit shift
#define VIDWxADD2_OFFSET_SIZE_S     (13)
#define VIDWxADD2_PAGE_WIDTH_S      (0)


//* VIDOSDxA,B,C
//bit shift
#define VIDOSDxAB_HORIZON_X_S       (11)
#define VIDOSDxAB_VERTICAL_Y_S      (0)
#define VIDOSDxC_ALPHA0_S           (12)//* VIDCON0
#define VIDCON0_S_RGB_IF                    (0<<22)
#define VIDCON0_S_CPU_IF_MAIN               (2<<22)
#define VIDCON0_S_CPU_IF_SUB                (3<<22)

#define VIDCON0_CPU_16BIT                   (0<<19)
#define VIDCON0_CPU_16plus2                 (1<<19)
#define VIDCON0_CPU_9plus9                  (2<<19)
#define VIDCON0_CPU_16plus8                 (3<<19)
#define VIDCON0_CPU_18BIT                   (4<<19)

#define VIDCON0_S_RGB_PAR                   (0<<13)
#define VIDCON0_S_BGR_PAR                   (1<<13)
#define VIDCON0_S_RGB_SER                   (2<<13)
#define VIDCON0_S_BGR_SER                   (3<<13)
#define VIDCON0_S_CLKVAL_F_AlWAYS_UPDATE    (0<<12)
#define VIDCON0_S_CLKVAL_F_SOF_UPDATE       (1<<12)
#define VIDCON0_S_VCLK_GATING_ON            (0<<5)
#define VIDCON0_S_VCLK_GATING_OFF           (1<<5)
#define VIDCON0_S_CLKDIR_DIRECT             (0<<4)
#define VIDCON0_S_CLKDIR_DIVIDED            (1<<4)
#define VIDCON0_S_CLKSEL_HCLK               (0<<2)
#define VIDCON0_S_CLKSEL_EPLL               (1<<2)
#define VIDCON0_S_ENVID_OFF                 (0<<1)
#define VIDCON0_S_EVVID_ON                  (1<<1)
#define VIDCON0_S_ENVID_F_OFF               (0<<0)
#define VIDCON0_S_ENVID_F_ON                (1<<0)
//bit shift
#define VIDCON0_CLKVAL_F_SHIFT              (6)

//* VIDCON1
#define VIDCON1_S_VCLK_FALL_EDGE_FETCH      (0<<7)
#define VIDCON1_S_VCLK_RISE_EDGE_FETCH      (1<<7)
#define VIDCON1_S_HSYNC_INVERTED            (1<<6)
#define VIDCON1_S_VSYNC_INVERTED            (1<<5)
#define VIDCON1_S_VDEN_INVERTED             (1<<4)

//* VIDTCON0,1
//bit shift
#define VIDTCON0_BPD_S              (16)
#define VIDTCON0_FPD_S              (8)
#define VIDTCON0_SPW_S              (0)

//* VIDTCON2
//bit shift
#define VIDTCON2_LINEVAL_S          (11)
#define VIDTCON2_HOZVAL_S           (0)


//* WINCON1to4
#define WINCONx_BIT_SWAP_ON         (1<<2)  //shift on basis of half-word swap
#define WINCONx_BYTE_SWAP_ON        (1<<1)  //shift on basis of half-word swap
#define WINCONx_HALFW_SWAP_ON       (1<<0)  //shift on basis of half-word swap
#define WINCONx_4WORD_BURST         (2)
#define WINCONx_8WORD_BURST         (1)
#define WINCONx_16WORD_BURST        (0)
#define WINCONx_PLANE_BLENDING      (0)
#define WINCONx_PIXEL_BLENDING      (1)
#define WINCONx_1BPP_PALLET         (0)
#define WINCONx_2BPP_PALLET         (1)
#define WINCONx_4BPP_PALLET         (2)
#define WINCONx_8BPP_PALLET         (3)
#define WINCONx_8BPP_NO_PALLET      (4)
#define WINCONx_16BPP_565           (5)
#define WINCONx_16BPP_A555          (6)
#define WINCONx_16BPP_1555          (7)
#define WINCONx_18BPP_666           (8)
#define WINCONx_18BPP_A665          (9)
#define WINCONx_19BPP_A666          (10)
#define WINCONx_24BPP_888           (11)
#define WINCONx_24BPP_A887          (12)
#define WINCONx_25BPP_A888          (13)
#define WINCONx_ALPHA_MODE_0        (0)
#define WINCONx_ALPHA_MODE_1        (1)

//bit shift
#define WINCON_BUFSEL               (23)
#define WINCON_BUFAUTOEN            (22)
#define WINCON_SWAP_S               (16)
#define WINCON_BURSTLEN_S           (9)
#define WINCON_BLENDING_S           (6)
#define WINCON_BPP_S                (2)
#define WINCON_ALPHA_S              (1)

//* VIDWxADD2
//bit shift
#define VIDWxADD2_OFFSET_SIZE_S     (13)
#define VIDWxADD2_PAGE_WIDTH_S      (0)


//* VIDOSDxA,B,C
//bit shift
#define VIDOSDxAB_HORIZON_X_S       (11)
#define VIDOSDxAB_VERTICAL_Y_S      (0)
#define VIDOSDxC_ALPHA0_S           (12)


/*
 * Watchdog timer
 */
#define ELFIN_WATCHDOG_BASE 0x53000000

#define WTCON_REG       __REG(0x53000000)
#define WTDAT_REG       __REG(0x53000004)
#define WTCNT_REG       __REG(0x53000008)

/*
 * EBI(External Bus Interface)
 */
#define EBIPR_REG       __REG(0x48800000)
#define BANK_CFG_REG        __REG(0x48800004)
#define EBICON_REG      __REG(0x4E800008)

/*
 * SSMC
 */
#define ELFIN_SSMC_BASE               0x4F000000

typedef struct {
    uint32_t SMBIDCYR0;             // 0x00
    uint32_t SMBWSTRDR0;             // 0x04
    uint32_t SMBWSTWRR0;             // 0x08
    uint32_t SMBWSTOENR0;             // 0x0C
    uint32_t SMBWSTWENR0;             // 0x10
    uint32_t SMBCR0;                  // 0x14
    uint32_t SMBSR0;                  // 0x18
    uint32_t SMBWSTBRDR0;             // 0x1C

    uint32_t SMBIDCYR1;              // 0x20
    uint32_t SMBWSTRDR1;             // 0x24
    uint32_t SMBWSTWRR1;             // 0x28
    uint32_t SMBWSTOENR1;             // 0x2C
    uint32_t SMBWSTWENR1;             // 0x30
    uint32_t SMBCR1;                  // 0x34
    uint32_t SMBSR1;                  // 0x38
    uint32_t SMBWSTBRDR1;             // 0x3C

    uint32_t SMBIDCYR2;              // 0x40
    uint32_t SMBWSTRDR2;             // 0x44
    uint32_t SMBWSTWRR2;             // 0x48
    uint32_t SMBWSTOENR2;             // 0x4C
    uint32_t SMBWSTWENR2;             // 0x50
    uint32_t SMBCR2;                  // 0x54
    uint32_t SMBSR2;                  // 0x58
    uint32_t SMBWSTBRDR2;             // 0x5C

    uint32_t SMBIDCYR3;              // 0x60
    uint32_t SMBWSTRDR3;             // 0x64
    uint32_t SMBWSTWRR3;             // 0x68
    uint32_t SMBWSTOENR3;             // 0x6C
    uint32_t SMBWSTWENR3;             // 0x70
    uint32_t SMBCR3;                  // 0x74
    uint32_t SMBSR3;                  // 0x78
    uint32_t SMBWSTBRDR3;             // 0x7C

    uint32_t SMBIDCYR4;              // 0x80
    uint32_t SMBWSTRDR4;             // 0x84
    uint32_t SMBWSTWRR4;             // 0x88
    uint32_t SMBWSTOENR4;             // 0x8C
    uint32_t SMBWSTWENR4;             // 0x90
    uint32_t SMBCR4;                  // 0x94
    uint32_t SMBSR4;                  // 0x98
    uint32_t SMBWSTBRDR4;             // 0x9C

    uint32_t SMBIDCYR5;              // 0xA0
    uint32_t SMBWSTRDR5;             // 0xA4
    uint32_t SMBWSTWRR5;             // 0xA8
    uint32_t SMBWSTOENR5;             // 0xAC
    uint32_t SMBWSTWENR5;             // 0xB0
    uint32_t SMBCR5;                  // 0xB4
    uint32_t SMBSR5;                  // 0xB8
    uint32_t SMBWSTBRDR5;             // 0xBC

    uint32_t PAD[80];                 // 0xC0 ~ 0x1FC

    uint32_t SSMCSR;                  // 0x200
    uint32_t SSMCCR;                  // 0x204
} SSMC_TypeDef;

#define SSMC_CTRL   ((SSMC_TypeDef *)ELFIN_SSMC_BASE)

#define SMBIDCYR0_REG   __REG(0x4F000000)
#define SMBIDCYR1_REG   __REG(0x4F000020)
#define SMBIDCYR2_REG   __REG(0x4F000040)
#define SMBIDCYR3_REG   __REG(0x4F000060)
#define SMBIDCYR4_REG   __REG(0x4F000080)
#define SMBIDCYR5_REG   __REG(0x4F0000A0)

#define SMBWSTRDR0_REG  __REG(0x4F000004)
#define SMBWSTRDR1_REG  __REG(0x4F000024)
#define SMBWSTRDR2_REG  __REG(0x4F000044)
#define SMBWSTRDR3_REG  __REG(0x4F000064)
#define SMBWSTRDR4_REG  __REG(0x4F000084)
#define SMBWSTRDR5_REG  __REG(0x4F0000A4)

#define SMBWSTWRR0_REG  __REG(0x4F000008)
#define SMBWSTWRR1_REG  __REG(0x4F000028)
#define SMBWSTWRR2_REG  __REG(0x4F000048)
#define SMBWSTWRR3_REG  __REG(0x4F000068)
#define SMBWSTWRR4_REG  __REG(0x4F000088)
#define SMBWSTWRR5_REG  __REG(0x4F0000A8)

#define SMBWSTOENR0_REG __REG(0x4F00000C)
#define SMBWSTOENR1_REG __REG(0x4F00002C)
#define SMBWSTOENR2_REG __REG(0x4F00004C)
#define SMBWSTOENR3_REG __REG(0x4F00006C)
#define SMBWSTOENR4_REG __REG(0x4F00008C)
#define SMBWSTOENR5_REG __REG(0x4F0000AC)

#define SMBWSTWENR0_REG __REG(0x4F000010)
#define SMBWSTWENR1_REG __REG(0x4F000030)
#define SMBWSTWENR2_REG __REG(0x4F000050)
#define SMBWSTWENR3_REG __REG(0x4F000070)
#define SMBWSTWENR4_REG __REG(0x4F000090)
#define SMBWSTWENR5_REG __REG(0x4F0000B0)

#define SMBCR0_REG  __REG(0x4F000014)
#define SMBCR1_REG  __REG(0x4F000034)
#define SMBCR2_REG  __REG(0x4F000054)
#define SMBCR3_REG  __REG(0x4F000074)
#define SMBCR4_REG  __REG(0x4F000094)
#define SMBCR5_REG  __REG(0x4F0000B4)

#define SMBSR0_REG  __REG(0x4F000018)
#define SMBSR1_REG  __REG(0x4F000038)
#define SMBSR2_REG  __REG(0x4F000058)
#define SMBSR3_REG  __REG(0x4F000078)
#define SMBSR4_REG  __REG(0x4F000098)
#define SMBSR5_REG  __REG(0x4F0000B8)

#define SMBWSTBDR0_REG  __REG(0x4F00001C)
#define SMBWSTBDR1_REG  __REG(0x4F00003C)
#define SMBWSTBDR2_REG  __REG(0x4F00005C)
#define SMBWSTBDR3_REG  __REG(0x4F00007C)
#define SMBWSTBDR4_REG  __REG(0x4F00009C)
#define SMBWSTBDR5_REG  __REG(0x4F0000BC)

#define SSMCSR_REG  __REG(0x4F000200)
#define SSMCCR_REG  __REG(0x4F000204)

/*
 * UART
 */
#define ELFIN_UART_BASE 0x50000000

typedef struct {
    uint32_t ULCON;                   // line control reg
    uint32_t UCON;                    // control reg
    uint32_t UFCON;                   // FIFO control reg
    uint32_t UMCON;                   // modem control reg
    uint32_t UTRSTAT;                 // tx/rx status reg
    uint32_t UERSTAT;                 // rx error status reg
    uint32_t UFSTAT;                  // FIFO status reg
    uint32_t UMSTAT;                  // modem status reg
    uint32_t UTXH;                    // tx buffer reg
    uint32_t URXH;                    // rx buffer reg
    uint32_t UBRDIV;                  // baud rate divisor
    uint32_t UDIVSLOT;                // baud rate divisor
} UART_TypeDef, *PUART_TypeDef;

#define UART0_BASE      0x50000000
#define UART1_BASE      0x50004000
#define UART2_BASE      0x50008000
#define UART3_BASE      0x5000C000

#define UART0_CTRL           (((UART_TypeDef *) UART0_BASE))
#define UART1_CTRL           (((UART_TypeDef *) UART1_BASE))
#define UART2_CTRL           (((UART_TypeDef *) UART2_BASE))
#define UART3_CTRL           (((UART_TypeDef *) UART3_BASE))


#define ULCON_INFRAED_NORMAL    (0x00 << 6)
#define ULCON_INFRAED_TXRX      (0x01 << 6)

#define ULCON_PARITY_MSK        (0x07 << 3)
#define ULCON_PARITY_NONE       (0x00 << 3)
#define ULCON_PARITY_ODD        (0x04 << 3)
#define ULCON_PARITY_EVEN       (0x05 << 3)

#define ULCON_STOP_BIT_MSK      (0x01 << 2)
#define ULCON_STOP_BIT_1        (0x00 << 2)
#define ULCON_STOP_BIT_2        (0x01 << 2)

#define ULCON_DAT_BIT_MSK       (0x03 << 0)
#define ULCON_DAT_BIT_5         (0x00 << 0)
#define ULCON_DAT_BIT_6         (0x01 << 0)
#define ULCON_DAT_BIT_7         (0x02 << 0)
#define ULCON_DAT_BIT_8         (0x03 << 0)

#define UCON_CLOCK_PCLK         (0x02 << 10)
#define UCON_CLOCK_EXT          (0x01 << 10)
#define UCON_CLOCK_DIV          (0x03 << 10)

#define UCON_TX_INT_PULSE       (0x00 << 9)
#define UCON_RX_INT_PULSE       (0x00 << 8)

#define UCON_RX_TIME_OUT_DIS    (0x00 << 7)
#define UCON_RX_TIME_OUT_EN     (0x01 << 7)

#define UCON_RX_ERR_INT_DIS     (0x00 << 6)
#define UCON_RX_ERR_INT_EN      (0x01 << 6)

#define UCON_LOOPBACK_DIS       (0x00 << 5)
#define UCON_LOOPBACK_EN        (0x01 << 5)

#define UCON_SEND_BREAK_DIS     (0x00 << 4)
#define UCON_SEND_BREAK_EN      (0x01 << 4)

#define UCON_TX_DIS             (0x00 << 2)
#define UCON_TX_INT_POLL        (0x01 << 2)
#define UCON_TX_DMA_SIG0        (0x02 << 2)
#define UCON_TX_DMA_SIG1        (0x03 << 2)

#define UCON_RX_DIS             (0x00 << 0)
#define UCON_RX_INT_POLL        (0x01 << 0)
#define UCON_RX_DMA_SIG0        (0x02 << 0)
#define UCON_RX_DMA_SIG1        (0x03 << 0)


#define UTRSTAT_TX_EMPTY    (1 << 2)
#define UTRSTAT_RX_READY    (1 << 0)
#define UART_ERR_MASK       0xF

/*
 * PWM timer
 */
#define ELFIN_TIMER_BASE    0x51000000

typedef struct  {
    uint32_t TCFG0;                       //0x00
    uint32_t TCFG1;                       //0x04
    uint32_t TCON;                        //0x08
    uint32_t TCNTB0;                      //0x0C
    uint32_t TCMPB0;                      //0x10
    uint32_t TCNTO0;                      //0x14
    uint32_t TCNTB1;                      //0x18
    uint32_t TCMPB1;                      //0x1C
    uint32_t TCNTO1;                      //0x20
    uint32_t TCNTB2;                      //0x24
    uint32_t TCMPB2;                      //0x28
    uint32_t TCNTO2;                      //0x2C
    uint32_t TCNTB3;                      //0x30
    uint32_t TCMPB3;                      //0x34
    uint32_t TCNTO3;                      //0x38
    uint32_t TCNTB4;                      //0x3C
    uint32_t TCNTO4;                      //0x40

} S3C2450_PWM_REG, *PS3C2450_PWM_REG;

#define PWM_CTRL        ((S3C2450_PWM_REG *)ELFIN_TIMER_BASE)

#define TCFG0_REG       __REG(0x51000000)
#define TCFG1_REG       __REG(0x51000004)
#define TCON_REG        __REG(0x51000008)
#define TCNTB0_REG      __REG(0x5100000C)
#define TCMPB0_REG      __REG(0x51000010)
#define TCNTO0_REG      __REG(0x51000014)
#define TCNTB1_REG      __REG(0x51000018)
#define TCMPB1_REG      __REG(0x5100001C)
#define TCNTO1_REG      __REG(0x51000020)
#define TCNTB2_REG      __REG(0x51000024)
#define TCMPB2_REG      __REG(0x51000028)
#define TCNTO2_REG      __REG(0x5100002C)
#define TCNTB3_REG      __REG(0x51000030)
#define TCMPB3_REG      __REG(0x51000034)
#define TCNTO3_REG      __REG(0x51000038)
#define TCNTB4_REG      __REG(0x5100003C)
#define TCNTO4_REG      __REG(0x51000040)





/*
 * RTC Controller
 */
#define ELFIN_RTC_BASE      0x57000000
#define RTCCON_REG      __REG(0x57000040)
#define TICNT_REG       __REG(0x57000044)
#define RTCALM_REG      __REG(0x57000050)
#define ALMSEC_REG      __REG(0x57000054)
#define ALMMIN_REG      __REG(0x57000058)
#define ALMHOUR_REG     __REG(0x5700005c)
#define ALMDATE_REG     __REG(0x57000060)
#define ALMMON_REG      __REG(0x57000064)
#define ALMYEAR_REG     __REG(0x57000068)
#define BCDSEC_REG      __REG(0x57000070)
#define BCDMIN_REG      __REG(0x57000074)
#define BCDHOUR_REG     __REG(0x57000078)
#define BCDDATE_REG     __REG(0x5700007c)
#define BCDDAY_REG      __REG(0x57000080)
#define BCDMON_REG      __REG(0x57000084)
#define BCDYEAR_REG     __REG(0x57000088)

/*
 * HS MMC Interface (chapter 28)
 */
#define ELFIN_HSMMC_BASE    0x4a800000

#define HM_SYSAD    (ELFIN_HSMMC_BASE+0x00)
#define HM_BLKSIZE  (ELFIN_HSMMC_BASE+0x04)
#define HM_BLKCNT   (ELFIN_HSMMC_BASE+0x06)
#define HM_ARGUMENT (ELFIN_HSMMC_BASE+0x08)
#define HM_TRNMOD   (ELFIN_HSMMC_BASE+0x0c)
#define HM_CMDREG   (ELFIN_HSMMC_BASE+0x0e)
#define HM_RSPREG0  (ELFIN_HSMMC_BASE+0x10)
#define HM_RSPREG1  (ELFIN_HSMMC_BASE+0x14)
#define HM_RSPREG2  (ELFIN_HSMMC_BASE+0x18)
#define HM_RSPREG3  (ELFIN_HSMMC_BASE+0x1c)
#define HM_BDATA    (ELFIN_HSMMC_BASE+0x20)
#define HM_PRNSTS   (ELFIN_HSMMC_BASE+0x24)
#define HM_HOSTCTL  (ELFIN_HSMMC_BASE+0x28)
#define HM_PWRCON   (ELFIN_HSMMC_BASE+0x29)
#define HM_BLKGAP   (ELFIN_HSMMC_BASE+0x2a)
#define HM_WAKCON   (ELFIN_HSMMC_BASE+0x2b)
#define HM_CLKCON   (ELFIN_HSMMC_BASE+0x2c)
#define HM_TIMEOUTCON   (ELFIN_HSMMC_BASE+0x2e)
#define HM_SWRST    (ELFIN_HSMMC_BASE+0x2f)
#define HM_NORINTSTS    (ELFIN_HSMMC_BASE+0x30)
#define HM_ERRINTSTS    (ELFIN_HSMMC_BASE+0x32)
#define HM_NORINTSTSEN  (ELFIN_HSMMC_BASE+0x34)
#define HM_ERRINTSTSEN  (ELFIN_HSMMC_BASE+0x36)
#define HM_NORINTSIGEN  (ELFIN_HSMMC_BASE+0x38)
#define HM_ERRINTSIGEN  (ELFIN_HSMMC_BASE+0x3a)
#define HM_ACMD12ERRSTS (ELFIN_HSMMC_BASE+0x3c)
#define HM_CAPAREG  (ELFIN_HSMMC_BASE+0x40)
#define HM_MAXCURR  (ELFIN_HSMMC_BASE+0x48)
#define HM_CONTROL2 (ELFIN_HSMMC_BASE+0x80)
#define HM_CONTROL3 (ELFIN_HSMMC_BASE+0x84)
#define HM_CONTROL4 (ELFIN_HSMMC_BASE+0x8C)
#define HM_HCVER    (ELFIN_HSMMC_BASE+0xfe)

#define ELFIN_CFCON_BASE    0x4B800000

#define ATA_MUX         (ELFIN_CFCON_BASE+0x1800)
#define ELFIN_ATA_BASE      (ELFIN_CFCON_BASE+0x1900)

/*
 * ATA Register (chapter 8)
 */
#define ATA_CONTROL (ELFIN_ATA_BASE + 0x00)
#define ATA_STATUS  (ELFIN_ATA_BASE + 0x04)
#define ATA_COMMAND (ELFIN_ATA_BASE + 0x08)
#define ATA_SWRST   (ELFIN_ATA_BASE + 0x0c)
#define ATA_IRQ     (ELFIN_ATA_BASE + 0x10)
#define ATA_IRQ_MASK    (ELFIN_ATA_BASE + 0x14)
#define ATA_CFG     (ELFIN_ATA_BASE + 0x18)

#define ATA_PIO_TIME    (ELFIN_ATA_BASE + 0x2c)
#define ATA_UDMA_TIME   (ELFIN_ATA_BASE + 0x30)
#define ATA_XFR_NUM (ELFIN_ATA_BASE + 0x34)
#define ATA_XFR_CNT (ELFIN_ATA_BASE + 0x38)
#define ATA_TBUF_START  (ELFIN_ATA_BASE + 0x3c)
#define ATA_TBUF_SIZE   (ELFIN_ATA_BASE + 0x40)
#define ATA_SBUF_START  (ELFIN_ATA_BASE + 0x44)
#define ATA_SBUF_SIZE   (ELFIN_ATA_BASE + 0x48)
#define ATA_CADR_TBUF   (ELFIN_ATA_BASE + 0x4c)
#define ATA_CADR_SBUF   (ELFIN_ATA_BASE + 0x50)
#define ATA_PIO_DTR (ELFIN_ATA_BASE + 0x54)
#define ATA_PIO_FED (ELFIN_ATA_BASE + 0x58)
#define ATA_PIO_SCR (ELFIN_ATA_BASE + 0x5c)
#define ATA_PIO_LLR (ELFIN_ATA_BASE + 0x60)
#define ATA_PIO_LMR (ELFIN_ATA_BASE + 0x64)
#define ATA_PIO_LHR (ELFIN_ATA_BASE + 0x68)
#define ATA_PIO_DVR (ELFIN_ATA_BASE + 0x6c)
#define ATA_PIO_CSD (ELFIN_ATA_BASE + 0x70)
#define ATA_PIO_DAD (ELFIN_ATA_BASE + 0x74)
#define ATA_PIO_READY   (ELFIN_ATA_BASE + 0x78)
#define ATA_PIO_RDATA   (ELFIN_ATA_BASE + 0x7c)
#define BUS_FIFO_STATUS (ELFIN_ATA_BASE + 0x90)
#define ATA_FIFO_STATUS (ELFIN_ATA_BASE + 0x94)

/*
 * SD/MMC Interface (chapter 27)
 */
#define ELFIN_SDI_BASE      0x5a000000

#define SDICON      (ELFIN_SDI_BASE+0x00)   /* SDI Control */
#define SDIPRE      (ELFIN_SDI_BASE+0x04)   /* SDI baud rate prescaler */
#define SDICARG     (ELFIN_SDI_BASE+0x08)   /* SDI command argument */
#define SDICCON     (ELFIN_SDI_BASE+0x0c)   /* SDI command control */
#define SDICSTA     (ELFIN_SDI_BASE+0x10)   /* SDI command status */
#define SDIRSP0     (ELFIN_SDI_BASE+0x14)   /* SDI response 0 */
#define SDIRSP1     (ELFIN_SDI_BASE+0x18)   /* SDI response 1 */
#define SDIRSP2     (ELFIN_SDI_BASE+0x1c)   /* SDI response 2 */
#define SDIRSP3     (ELFIN_SDI_BASE+0x20)   /* SDI response 3 */
#define SDIDTIMER   (ELFIN_SDI_BASE+0x24)   /* SDI data/busy timer */
#define SDIBSIZE    (ELFIN_SDI_BASE+0x28)   /* SDI block size */
#define SDIDCON     (ELFIN_SDI_BASE+0x2c)   /* SDI data control */
#define SDIDCNT     (ELFIN_SDI_BASE+0x30)   /* SDI data remain counter */
#define SDIDSTA     (ELFIN_SDI_BASE+0x34)   /* SDI data status */
#define SDIFSTA     (ELFIN_SDI_BASE+0x38)   /* SDI FIFO status */
#define SDIIMSK     (ELFIN_SDI_BASE+0x3c)   /* SDI Interrupt Mask */
#define SDIDAT      (ELFIN_SDI_BASE+0x40)   /* SDI Data register */



/*
 * USB Device (Chapter 17)
 */
#define USB_DEVICE_PHYS_ADR 0x49800000
#define bUD(Nb)     __REG(USB_DEVICE_PHYS_ADR + (Nb))

#define UD_INDEX_REG            bUD(0x00) /* Index register */
#define UD_EP_INT_REG           bUD(0x04) /* EP Interrupt pending and clear */
#define UD_EP_INT_EN_REG        bUD(0x08) /* EP Interrupt enable */
#define UD_FUNC_ADDR_REG        bUD(0x0c) /* Function address */
#define UD_FRAME_NUM_REG        bUD(0x10) /* Frame number */
#define UD_EP_DIR_REG           bUD(0x14) /* Endpoint direction */
#define UD_TEST_REG         bUD(0x18) /* Test register */
#define UD_SYS_STATUS_REG       bUD(0x1c) /* System status */
#define UD_SYS_CON_REG          bUD(0x20) /* System control */
#define UD_EP0_STATUS_REG       bUD(0x24) /* Endpoint 0 status */
#define UD_EP0_CON_REG          bUD(0x28) /* Endpoint 0 control */
#define UD_EP0_BUF_REG          bUD(0x60) /* Endpoint 0 Buffer */
#define UD_EP1_BUF_REG          bUD(0x64) /* Endpoint 1 Buffer */
#define UD_EP2_BUF_REG          bUD(0x68) /* Endpoint 2 Buffer */
#define UD_EP3_BUF_REG          bUD(0x6c) /* Endpoint 3 Buffer */
#define UD_EP4_BUF_REG          bUD(0x70) /* Endpoint 4 Buffer */
#define UD_EP5_BUF_REG          bUD(0x74) /* Endpoint 5 Buffer */
#define UD_EP6_BUF_REG          bUD(0x78) /* Endpoint 6 Buffer */
#define UD_EP7_BUF_REG          bUD(0x7c) /* Endpoint 7 Buffer */
#define UD_EP8_BUF_REG          bUD(0x80) /* Endpoint 8 Buffer */
#define UD_FIFO_CON_REG         bUD(0x100) /* Burst FIFO-DMA Control */
#define UD_FIFO_STATUS_REG      bUD(0x104) /* Burst FIFO Status */

#define UD_EP_STATUS_REG        bUD(0x2c) /* Endpoints status */
#define UD_EP_CON_REG           bUD(0x30) /* Endpoints control */
#define UD_BYTE_READ_CNT_REG        bUD(0x34) /* Byte read count */
#define UD_BYTE_WRITE_CNT_REG       bUD(0x38) /* Byte write count */
#define UD_MAX_PKT_REG          bUD(0x3c) /* Max packet size */
#define UD_DMA_CON_REG          bUD(0x40) /* DMA control */
#define UD_DMA_CNT_REG          bUD(0x44) /* DMA count */
#define UD_DMA_FIFO_CNT_REG     bUD(0x48) /* DMA FIFO count */
#define UD_DMA_TOTAL_CNT1_REG       bUD(0x4c) /* DMA Total Transfer count1 */
#define UD_DMA_TOTAL_CNT2_REG       bUD(0x50) /* DMA Total Transfer count2 */
#define UD_DMA_IF_CON_REG       bUD(0x84) /* DMA interface Control */
#define UD_DMA_MEM_BASE_ADDR_REG    bUD(0x88) /* Mem Base Addr */
#define UD_DMA_MEM_CURRENT_ADDR_REG bUD(0x8c) /* Mem current Addr */

/* index register set */
#define UD_INDEX_EP0        0
#define UD_INDEX_EP1        1
#define UD_INDEX_EP2        2
#define UD_INDEX_EP3        3
#define UD_INDEX_EP4        4

/* endpoint interrupt flag */
#define UD_INT_EP4      (1<<4)  // R/C
#define UD_INT_EP3      (1<<3)  // R/C
#define UD_INT_EP2      (1<<2)  // R/C
#define UD_INT_EP1      (1<<1)  // R/C
#define UD_INT_EP0      (1<<0)  // R/C

/* endpoint interrupt enable flag */
#define UD_INT_EN_EP4       (1<<4)
#define UD_INT_EN_EP3       (1<<3)
#define UD_INT_EN_EP2       (1<<2)
#define UD_INT_EN_EP1       (1<<1)
#define UD_INT_EN_EP0       (1<<0)

/* system status register Bits */
#define UD_INT_ERR      (0xff80)
#define UD_INT_VBUSON       (1<<8)
#define UD_INT_HSP      (1<<4) /* Host SPeed */
#define UD_INT_SDE      (1<<3) /* Speed Detection Dnd */
#define UD_INT_RESUME       (1<<2)
#define UD_INT_SUSPEND      (1<<1)
#define UD_INT_RESET        (1<<0)

/* system control register Bits */
#define UD_RRD_EN       (1<<5)
#define UD_SUS_EN       (1<<1)
#define UD_RST_EN       (1<<0)

/* EP0 status register Bits */
#define UD_EP0_SENT_STALL              (0x01<<4)
#define UD_EP0_DATA_END                (0x01<<3)
#define UD_EP0_SETUP_END               (0x03<<2)
#define UD_EP0_TX_SUCCESS              (0x01<<1)
#define UD_EP0_RX_SUCCESS              (0x01<<0)

/* Endpoint Status Register Bits */
#define UD_DMA_TOTAL_COUNT_ZERO        (0x1<<9)
#define UD_SHORT_PKT_RECEIVED          (0x1<<8)
#define UD_EP_FIFO_FLUSH               (0x1<<6)
#define UD_EP_SENT_STALL               (0x1<<5)
#define UD_EP_TX_SUCCESS               (0x1<<1)
#define UD_EP_RX_SUCCESS               (0x1<<0)

// USB Dma Operation
#define UD_DMA_AUTO_RX_DISABLE         (0x1<<5)
#define UD_DMA_FLY_ENABLE              (0x1<<4)
#define UD_DMA_FLY_DISABLE             (0x0<<4)
#define UD_DMA_DEMEND_ENABLE           (0x1<<3)
#define UD_DMA_DEMEND_DISABLE          (0x0<<3)
#define UD_DMA_TX_START                (0x1<<2)
#define UD_DMA_TX_STOP                 (0x0<<2)
#define UD_DMA_RX_START                (0x1<<1)
#define UD_DMA_RX_STOP                 (0x0<<1)
#define UD_USB_DMA_MODE                (0x1<<0)
#define UD_USB_INT_MODE                (0x0<<0)

/* DMA Interface Control Register Bits */
#define UD_MAX_BURST_INCR16            (0x3<<0)
#define UD_MAX_BURST_INCR8             (0x2<<0)
#define UD_MAX_BURST_INCR4             (0x1<<0)

/*Burst FIFO Control Register Bits */
#define UD_DMA_ENABLE                  (0x1<<8)
#define UD_DMA_DISABLE                 (0x0<<8)

/*
 * chapter24 ADC //ZhangGQ add 20130402
 */
#define ELFIN_ADC_BASE      0x58000000

#define ADCCON_REG          __REG(0x58000000)
#define ADCTSC_REG          __REG(0x58000004)
#define ADCDLY_REG          __REG(0x58000008)
#define ADCDAT0_REG         __REG(0x5800000c)
#define ADCDAT1_REG         __REG(0x58000010)
#define ADCUPDN_REG         __REG(0x58000014)
#define ADCMUX_REG          __REG(0x58000018)

/*
 * RTC Controller
 */
#define ELFIN_RTC_BASE      0x57000000
#define RTCCON_REG      __REG(0x57000040)
#define TICNT0_REG      __REG(0x57000044)
#define TICNT1_REG      __REG(0x5700004c)
#define TICNT2_REG      __REG(0x57000048)
#define RTCALM_REG      __REG(0x57000050)
#define ALMSEC_REG      __REG(0x57000054)
#define ALMMIN_REG      __REG(0x57000058)
#define ALMHOUR_REG     __REG(0x5700005c)
#define ALMDATE_REG     __REG(0x57000060)
#define ALMMON_REG      __REG(0x57000064)
#define ALMYEAR_REG     __REG(0x57000068)
#define BCDSEC_REG      __REG(0x57000070)
#define BCDMIN_REG      __REG(0x57000074)
#define BCDHOUR_REG     __REG(0x57000078)
#define BCDDATE_REG     __REG(0x5700007c)
#define BCDDAY_REG      __REG(0x57000080)
#define BCDMON_REG      __REG(0x57000084)
#define BCDYEAR_REG     __REG(0x57000088)


// PENDING BIT
#define INTEINT0      (0)
#define INTEINT1      (1)
#define INTEINT2      (2)
#define INTEINT3      (3)
#define INTEINT4_7    (4)
#define INTEINT8_23   (5)
#define INTNOTUSED6   (6)
#define INTBAT_FLT    (7)
#define INTTICK       (8)
#define INTWDT        (9)
#define INTTIMER0     (10)
#define INTTIMER1     (11)
#define INTTIMER2     (12)
#define INTTIMER3     (13)
#define INTTIMER4     (14)
#define INTUART2      (15)
#define INTLCD        (16)
#define INTDMA0       (17)
#define INTDMA1       (18)
#define INTDMA2       (19)
#define INTDMA3       (20)
#define INTSDI        (21)
#define INTSPI0       (22)
#define INTUART1      (23)
//#define INTNOTUSED24  (24)
#define INTNIC  (24)
#define INTUSBD       (25)
#define INTUSBH       (26)
#define INTIIC        (27)
#define INTUART0      (28)
#define INTSPI1       (29)
#define INTRTC        (30)
#define INTADC        (31)
#define BIT_ALLMSK     (0xffffffff)

#define BIT_SUB_ALLMSK (0x7ff)
#define INTSUB_ADC    (10)
#define INTSUB_TC     (9)
#define INTSUB_ERR2   (8)
#define INTSUB_TXD2   (7)
#define INTSUB_RXD2   (6)
#define INTSUB_ERR1   (5)
#define INTSUB_TXD1   (4)
#define INTSUB_RXD1   (3)
#define INTSUB_ERR0   (2)
#define INTSUB_TXD0   (1)
#define INTSUB_RXD0   (0)

#define BIT_SUB_ADC    (0x1<<10)
#define BIT_SUB_TC     (0x1<<9)
#define BIT_SUB_ERR2   (0x1<<8)
#define BIT_SUB_TXD2   (0x1<<7)
#define BIT_SUB_RXD2   (0x1<<6)
#define BIT_SUB_ERR1   (0x1<<5)
#define BIT_SUB_TXD1   (0x1<<4)
#define BIT_SUB_RXD1   (0x1<<3)
#define BIT_SUB_ERR0   (0x1<<2)
#define BIT_SUB_TXD0   (0x1<<1)
#define BIT_SUB_RXD0   (0x1<<0)


#define ClearPending(bit) {INTR_CTRL->SRCPND1 = bit;INTR_CTRL->INTPND1 = bit;INTR_CTRL->INTPND1 = INTR_CTRL->INTPND1;}
//Wait until INTPND is changed for the case that the ISR is very short.

#define INTGLOBAL       32


struct rt_hw_register
{
    uint32_t r0;
    uint32_t r1;
    uint32_t r2;
    uint32_t r3;
    uint32_t r4;
    uint32_t r5;
    uint32_t r6;
    uint32_t r7;
    uint32_t r8;
    uint32_t r9;
    uint32_t r10;
    uint32_t fp;
    uint32_t ip;
    uint32_t sp;
    uint32_t lr;
    uint32_t pc;
    uint32_t cpsr;
    uint32_t ORIG_r0;
};

extern uint32_t PCLK;
extern uint32_t FCLK;
extern uint32_t HCLK;
extern uint32_t UCLK;

extern void rt_hw_get_clock(void);
#if __cplusplus
}
#endif

#endif 
