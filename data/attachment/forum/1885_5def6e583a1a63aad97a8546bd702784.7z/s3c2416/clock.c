/*
*********************************************************************************************************
*
*
* Filename      : clock.c
* Version       : V1.00.01
* Data          : 2014��7��3��
* Programmer(s) : Urey.U
* Note(s)       : TODO
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                                INCLUDE FILES
*********************************************************************************************************
*/
#include <rtthread.h>
#include "s3c2416.h"



/* input clock of PLL */
#define CONFIG_SYS_CLK_FREQ 12000000    /* the SMDK2416 has 12MHz input clock */


#if CONFIG_SYS_CLK_FREQ == 12000000
    /* MPLL=2*12*100/6=400MHz   */
    #define     MPL_MIDV    92      /* m=MPL_MDIV+8=100 */
    #define     MPL_PDIV    4       /* p=MPL_PDIV+2=6   */
    #define     MPL_SDIV    0       /* s=MPL_SDIV=0 */
    /* UPLL=12*64/8=96MHz */
    #define     UPL_MDIV    56      /* m=UPL_MDIV+8=64 */
    #define     UPL_PDIV    2       /* p=UPL_PDIV+2=4   */
    #define     UPL_SDIV    1       /* s=UPL_SDIV=1 */
    /* System clock divider FCLK:HCLK:PCLK=1:4:8 */
    #define     DIVN_UPLL       0x1     /* UCLK = UPLL clock / 2 */
    #define     HDIVN           0x2     /* HCLK = FCLK / 4 */
    #define     PDIVN           0x1     /* PCLK = HCLK / 2 */
#endif

uint32_t PCLK;
uint32_t FCLK;
uint32_t HCLK;

static uint32_t cpu_get_pll(void)
{
    uint32_t r, m, p, s;

    r = MPLLCON_REG;
    m = ((r >> 14) & 0x3ff);
    p = ((r >> 5) & 0x3f);
    s = r & 0x7;

    return (m * (CONFIG_SYS_CLK_FREQ / (p << s)));
}

void rt_hw_get_clock(void)
{
    uint32_t hclk_div = (CLKDIV0CON_REG & 0x3) + 1;
    uint32_t pre_div = ((CLKDIV0CON_REG >> 4) & 0x3) + 1;

    FCLK = cpu_get_pll();
    HCLK = FCLK / (hclk_div * pre_div);

    if(CLKDIV0CON_REG & 0x4)
        PCLK = HCLK / 2;
    else
        PCLK = HCLK;

}


