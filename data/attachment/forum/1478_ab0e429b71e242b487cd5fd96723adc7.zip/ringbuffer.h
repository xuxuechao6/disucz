/*
 * File       : ringbuffer.h
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2013, RT-Thread Development Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://www.rt-thread.org/license/LICENSE.
 * 
 * Brief      : 
 *
 * Change Logs:
 * Date           Author       Notes
 * 2013/2/13     amwox      first version
 */
#ifndef __ringbuffer_H__
#define __ringbuffer_H__
/* Includes ---------------------------------------------------------------- */
#include <rtthread.h>

/* Public  typedef --------------------------------------------------------- */
struct rt_ring_buffer;
typedef struct rt_ring_buffer *	rt_ring_buffer_t;

/* Public  macros ---------------------------------------------------------- */
#define RING_BUFFER_ALL_ELEMENTS	(0xFFFFFFFF)

/* Public  functions ------------------------------------------------------- */
rt_err_t rt_ring_buffer_init(void *buffer, rt_uint32_t buffer_size, rt_uint32_t element_size, rt_ring_buffer_t *ring_ptr);

rt_ring_buffer_t rt_ring_buffer_create(rt_uint32_t element_number, rt_uint32_t element_size);

void rt_ring_buffer_destory(rt_ring_buffer_t ring);

rt_err_t rt_ring_buffer_read(rt_ring_buffer_t ring, rt_uint32_t num, void *const buffer, rt_uint32_t *readed);

rt_err_t rt_ring_buffer_write(rt_ring_buffer_t ring, rt_uint32_t num, void const *const buffer, rt_uint32_t *writed);

void rt_ring_buffer_reset(rt_ring_buffer_t ring);

rt_uint32_t rt_ring_buffer_couter_get(rt_ring_buffer_t ring);


#endif // __ringbuffer_H__
/* --------------------------------- End Of File --------------------------- */

