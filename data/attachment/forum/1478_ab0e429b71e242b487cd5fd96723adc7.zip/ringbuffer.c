/*
 * File       : ringbuffer.c
 * 
 * This file is part of RT-Thread RTOS
 * COPYRIGHT (C) 2013, RT-Thread Development Team
 *
 * The license and distribution terms for this file may be
 * found in the file LICENSE in this distribution or at
 * http://www.rt-thread.org/license/LICENSE.
 * 
 * Brief      : 
 *
 * Change Logs:
 * Date           Author       Notes
 * 2013/2/13     amwox      first version
 */



/* Includes ---------------------------------------------------------------- */
#include "ringbuffer.h"
#include "rthw.h"

/* Private typedef --------------------------------------------------------- */
struct rt_ring_buffer{
	rt_int32_t lock;				//Can be destroyed
	rt_int32_t element_size;		//The size of a element													
    rt_int32_t element_num;			//The number of elements in buffer
    rt_int32_t cnt;					//The counter of elements in buffer
    rt_int32_t write_vptr;        	//Write virtual pointer
    rt_int32_t read_vptr;         	//Read virtual pointer		
	rt_int32_t dat[];				//data area
};

/* Private macros ---------------------------------------------------------- */
#define RING_INLINE			static inline
#define RING_PRIVATE		static

#define RING_CALLOC			rt_calloc
#define RING_FREE			rt_free

/* Private functions ------------------------------------------------------- */
RING_INLINE void _read_vptr_inc(rt_ring_buffer_t ring, rt_uint32_t num)
{
	ring->read_vptr += num;
	if(ring->read_vptr >= ring->element_num) ring->read_vptr = 0;
}

RING_INLINE void _write_vptr_inc(rt_ring_buffer_t ring, rt_uint32_t num)
{
	ring->write_vptr += num;
	if(ring->write_vptr >= ring->element_num) ring->write_vptr = 0;
}

RING_INLINE void _memcpy(rt_uint8_t * const des, rt_uint8_t const * const src, rt_uint32_t element_num,rt_uint32_t element_size)
{
	rt_memcpy(des,src,element_num * element_size);
}

RING_INLINE rt_uint8_t * _buffer_offset_get(rt_ring_buffer_t ring,rt_uint8_t * buffer,rt_uint32_t offset)
{
	return buffer + ring->element_size * offset;
}

RING_INLINE rt_base_t _buffer_lock(void)
{
	return rt_hw_interrupt_disable();
}

RING_INLINE void _buffer_unlock(rt_base_t lock)
{
	rt_hw_interrupt_enable(lock);
}

/* Public  functions ------------------------------------------------------- */

/**
 * Initialize the buffer to ring buffer 
 * The buffer can not be destroyed by rt_ring_buffer_destory 
 * 
 * @author amwox (2013/2/13)
 * 
 * @param buffer 
 * @param buffer_size 		bytes of the buffer
 * @param element_size 
 * @param ring_ptr 
 * 
 * @return rt_err_t 
 */
rt_err_t rt_ring_buffer_init(void * buffer,rt_uint32_t buffer_size,rt_uint32_t element_size,rt_ring_buffer_t *ring_ptr)
{
	rt_ring_buffer_t tmp;
	*ring_ptr = RT_NULL;
	if((buffer == RT_NULL) || (ring_ptr == RT_NULL) || (element_size == 0)) 
		return RT_ERROR;
	tmp = (rt_ring_buffer_t)(((rt_uint32_t)buffer + 3) & 0xFFFFFFFC);	
	if(buffer_size < ((rt_uint8_t *)tmp->dat - (rt_uint8_t *)buffer)) 
		return RT_ENOMEM;
	tmp->element_num = (buffer_size - ((rt_uint8_t *)tmp->dat - (rt_uint8_t *)buffer)) / element_size;
	tmp->element_size = element_size;
	tmp->cnt = 0;
	tmp->read_vptr = tmp->write_vptr = 0;
	tmp->lock = 0;		// can not be destroyed by rt_ring_buffer_destory
	*ring_ptr = tmp;
	return RT_EOK;
}

/**
 * Create a ring buffer 
 * The buffer can be destroyed by rt_ring_buffer_destory
 * 
 * @author amwox (2013/2/13)
 * 
 * @param element_number 
 * @param element_size 
 * 
 * @return rt_ring_buffer_t 
 */
rt_ring_buffer_t rt_ring_buffer_create(rt_uint32_t element_number, rt_uint32_t element_size) 
{
	rt_ring_buffer_t ring = RING_CALLOC(1, element_size * element_number + sizeof(struct rt_ring_buffer));
	if(ring) {
		ring->element_num = element_number;
		ring->element_size = element_size;
		ring->cnt = 0;
		ring->read_vptr = ring->write_vptr = 0;
		ring->lock = 1;	// Can be destroyed by rt_ring_buffer_destory
	}
	return ring;
}

/**
 * Destroy the ring buffer
 * 
 * @author amwox (2013/2/13)
 * 
 * @param ring 
 */
void rt_ring_buffer_destory(rt_ring_buffer_t ring) 
{
	if(ring) {
		if(ring->lock) {
			RING_FREE(ring);
		}
	}
}

/**
 * Read some elements from the ring buffer
 * 
 * @author amwox (2013/2/13)
 * 
 * @param ring 
 * @param num 		need read number of the elements 
 * @param buffer 	read back buffer
 * @param readed 	read the number of elements
 * 
 * @return rt_err_t 
 */
rt_err_t rt_ring_buffer_read(rt_ring_buffer_t ring, rt_uint32_t num, void * const buffer, rt_uint32_t * readed)
{
	rt_uint32_t read_cnt = 0;
	rt_err_t error = RT_EEMPTY;
	rt_base_t lock;
	if((ring == RT_NULL) || (num == 0)) return RT_ERROR;
	lock = _buffer_lock();
	if(num == RING_BUFFER_ALL_ELEMENTS) num = ring->cnt;
	while ((num > 0) && (ring->cnt > 0)){
		rt_uint32_t tmp_cnt;
		if(ring->write_vptr > ring->read_vptr) {
			tmp_cnt = ring->write_vptr - ring->read_vptr;
		} else {
			tmp_cnt = ring->element_num - ring->read_vptr;
		}
		if(num < tmp_cnt) 
			tmp_cnt = num;	
		error = RT_EOK;
		if(buffer) {	
			rt_uint8_t * src = _buffer_offset_get(ring, (rt_uint8_t *)&ring->dat[0], ring->read_vptr);
			rt_uint8_t * des = _buffer_offset_get(ring, (rt_uint8_t *)buffer, read_cnt);
			_memcpy(des,src,tmp_cnt,ring->element_size);
		}
		_read_vptr_inc(ring, tmp_cnt);
		ring->cnt -= tmp_cnt;
		read_cnt += tmp_cnt;
		num -= tmp_cnt;
	}
	if(readed) 
		*readed = read_cnt;
	_buffer_unlock(lock);
	return error;
}

/**
 * Write some elements to the ring buffer
 * 
 * @author amwox (2013/2/13)
 * 
 * @param ring 
 * @param num 		need write number of the elements
 * @param buffer 	write source buffer
 * @param writed 	write the number of elements
 * 
 * @return rt_err_t 
 */
rt_err_t rt_ring_buffer_write(rt_ring_buffer_t ring, rt_uint32_t num, void const * const buffer, rt_uint32_t * writed)
{
	rt_uint32_t write_cnt;
	rt_err_t error = RT_EFULL;
	rt_base_t lock;
	if((ring == RT_NULL) || (num == 0) || (buffer == RT_NULL)) 
		return RT_ERROR;
	lock = _buffer_lock();
	write_cnt = ring->element_num - ring->cnt;
	if(num > write_cnt) num = write_cnt;
	write_cnt = 0;
	while(num > 0) {
		rt_uint32_t tmp_cnt;
		if(ring->read_vptr > ring->write_vptr) {
			tmp_cnt = ring->read_vptr - ring->write_vptr;
		} else {
			tmp_cnt = ring->element_num - ring->write_vptr;
		}
		if(num < tmp_cnt) 
			tmp_cnt = num;
		error = RT_EOK;
		{
			rt_uint8_t * src = _buffer_offset_get(ring, (rt_uint8_t *)buffer, write_cnt);
			rt_uint8_t * des = _buffer_offset_get(ring, (rt_uint8_t *)&ring->dat[0], ring->write_vptr);
			_memcpy(des, src, tmp_cnt,ring->element_size);
		}
		_write_vptr_inc(ring, tmp_cnt);
		ring->cnt += tmp_cnt;
		write_cnt += tmp_cnt;
		num -= tmp_cnt;
	}
	if(writed) 
		*writed = write_cnt;
	_buffer_unlock(lock);
	return error;
}

void rt_ring_buffer_reset(rt_ring_buffer_t ring)
{
	if(ring) {
		rt_base_t lock;
		lock = _buffer_lock();
		ring->read_vptr = ring->write_vptr = 0;
		ring->cnt = 0;
		_buffer_unlock(lock);
	}
}

rt_uint32_t rt_ring_buffer_couter_get(rt_ring_buffer_t ring)
{
	rt_uint32_t cnt = 0;
	if(ring) {
		rt_base_t lock;
		lock = _buffer_lock();
		cnt = ring->cnt;
		_buffer_unlock(lock);
	}
	return cnt;
}

#if 0
rt_err_t ring_err;
rt_uint8_t tmp_buf[55];
rt_uint8_t tmp_buf2[55];
char tmp_buf3[111];
void ring_test(void)
{
	rt_uint32_t cnt,rd;
	unsigned i;
	rt_ring_buffer_t ring;
	ring_err = rt_ring_buffer_create(tmp_buf,555,1,&ring);
	if(ring_err == RING_ERR_OK) {
		i = 0;
		rd = 0;
		do {
			rt_sprintf(tmp_buf3, " - %d - \0", i);
			ring_err = rt_ring_buffer_write(ring, rt_strlen(tmp_buf3),tmp_buf3,&cnt);
			ring_err = rt_ring_buffer_write(ring,12,"Hello World!",&cnt);
			ring_err = rt_ring_buffer_read(ring, i*5, &tmp_buf2[rd], &cnt);
			rd += cnt;
			i ++;
		} while(i < 100);
	}
}

#endif
/* --------------------------------- End Of File --------------------------- */

