#ifndef APPLICATION_H_H_H_

int rt_application_init();
#endif
