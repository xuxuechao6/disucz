#include "rthw.h"
#include "rtthread.h"
#include "application.h"
extern int printf (__const char *__restrict __format, ...);
#ifdef RT_USING_DEVICE
#if RT_USING_SERIAL==1
#include "serial.h"
extern struct rt_device serial_device;
#endif
#endif

#ifdef RT_USING_FINSH
#include "finsh.h"
#endif
#ifdef RT_USING_DFS
#include "dfs_init.h"
#include "sdcard.h"
#endif
/**
 * This function will startup RT-Thread RTOS.
 */
#define HEAP_SIZE   4096*100
/*分配的内存必须是4096的整数倍，否则，问题会导致rt_malloc()的失败*/
static rt_uint8_t heap[HEAP_SIZE];
void rtthread_startup(void)
{
#ifdef RT_USING_DEVICE
  #if RT_USING_SERIAL==1
  	/* register uart1 */
  	rt_hw_serial_register(&serial_device,"sci0",
  		RT_DEVICE_FLAG_RDWR | RT_DEVICE_FLAG_INT_RX | RT_DEVICE_FLAG_STREAM);
  #endif
	/*init all registed devices */
	rt_device_init_all();
#endif 
#if RT_USING_SERIAL==1
	rt_console_set_device("sci0");
#endif
	/* show version */
	rt_show_version();
	
	/* init tick */
	rt_system_tick_init();

	/* init kernel object */
	rt_system_object_init();

	/* init timer system */
	rt_system_timer_init();

	/* init heap memory system */
	rt_system_heap_init(heap,&heap[HEAP_SIZE-1]);

#ifdef RT_USING_DFS
  rt_hw_sdcard_init();
#if SD_DEBUG==1
  rt_kprintf("rt_hw_sdcard_init(): OK\n");
#endif
/* 初始化设备文件系统 */
  dfs_init();
#if SD_DEBUG==1
  rt_kprintf("dfs_init(): OK\n");
#endif
#endif
	/* init scheduler system */
	rt_system_scheduler_init();
	/* init application */
	rt_application_init();

#ifdef RT_USING_FINSH
	/* init finsh */
	finsh_system_init();
  #ifdef RT_USING_DEVICE
  	finsh_set_device("sci0");
  	//finsh_syscall_append("list_device",list_device);
  #endif    
#endif

	/* init idle thread */
	rt_thread_idle_init();
	/* start scheduler */
	rt_system_scheduler_start();

	/* never reach here */
	return ;
}

int main(void)
{
	rt_uint32_t UNUSED level;
#ifdef _DEBUG
	printf("start the rtThread kernel\n");
#endif
	/* disable interrupt first */
	level = rt_hw_interrupt_disable();
	/* startup RT-Thread RTOS */
	rtthread_startup();
	return 0;
}

