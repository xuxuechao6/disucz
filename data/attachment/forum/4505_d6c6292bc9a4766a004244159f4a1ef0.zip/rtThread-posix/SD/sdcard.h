#ifndef __SDCARD_H
#define __SDCARD_H
#include "rtconfig.h"
#ifdef RT_USING_DFS
 #include "rtdef.h"
#include "diskio.h"
#define SD_DEBUG 1
DRESULT sd_read (
	BYTE drv,			/* Physical drive nmuber (0) */
	BYTE *buff,			/* Pointer to the data buffer to store read data */
	DWORD sector,		/* Start sector number (LBA) */
	BYTE count			/* Sector count (1..255) */
);
#if _READONLY == 0
DRESULT sd_write (
	BYTE drv,			/* Physical drive nmuber (0) */
	const BYTE *buff,	/* Pointer to the data to be written */
	DWORD sector,		/* Start sector number (LBA) */
	BYTE count			/* Sector count (1..255) */
);
#endif
  void rt_hw_sdcard_init(void);
#endif
#endif

