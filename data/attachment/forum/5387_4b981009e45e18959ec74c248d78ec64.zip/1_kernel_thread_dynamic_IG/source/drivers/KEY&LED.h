#ifndef _KEY_LED_H
#define _KEY_LED_H

#include <stdio.h>
#include "stm32f4xx.h"
#include "sys.h"

#define LED0 PBout(5)// PB5
#define LED1 PEout(5)// PE5	

void JOYState_LED_GPIO_Init(void);
uint8_t Read_JOYState(void);
void Led_Toggle(uint8_t key);
void BACK_LED_INIT(void);

#endif /*_KEY_LED_H*/
