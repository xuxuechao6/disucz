#include <rtthread.h>
#include "KEY&LED.h"
#include "nes_main.h"
#include "fc_key.h"

rt_thread_t tid1 = RT_NULL;
rt_thread_t tid2 = RT_NULL;

extern int FrameCnt;
extern JoyPadType JoyPad[2];
int SysTicks = 0;

static void thread1_entry(void* parameter)
{
    rt_kprintf("thread1 dynamicly created ok\n");
	Led_Toggle(0);
	rt_kprintf("thread1 is running\n");
	//LCD_Scan_Dir(3); //����ɨ�跽��	//0
	nes_main();	 //PPU.c����LCD����
    //rt_thread_delay(RT_TICK_PER_SECOND * 4);   
    //rt_thread_delete(tid1);
    rt_kprintf("thread1 deleted ?\n");   
}

static void thread2_entry(void* parameter)
{
	//rt_uint32_t count = 0;
	rt_uint8_t temp;
    rt_kprintf("thread2 dynamicly created ok\n");
    while(1)
    {	    	
		SysTicks++;
		temp=fc_read();	//��ȡ����

		if(SysTicks == 60)
		{
		Led_Toggle(1);
	    rt_kprintf("֡��: %d  ����: %x\n",FrameCnt,temp);
		SysTicks = FrameCnt = 0; 
		}//xx��֡��������
		
		JoyPad[0].value = 1 << 20;
		JoyPad[0].value |= !((temp >> 0) & 0x01) << 7;	//right
		JoyPad[0].value |= !((temp >> 1) & 0x01) << 6;	//left	
		JoyPad[0].value |= !((temp >> 2) & 0x01) << 5; 	//down
		JoyPad[0].value |= !((temp >> 3) & 0x01) << 4; 	//up
		JoyPad[0].value |= !((temp >> 4) & 0x01) << 3;	//start
		JoyPad[0].value |= !((temp >> 5) & 0x01) << 2;	//select
		JoyPad[0].value |= !((temp >> 6) & 0x01) << 1;	//b
		JoyPad[0].value |= !((temp >> 7) & 0x01) << 0;	//a
        rt_thread_delay(RT_TICK_PER_SECOND/61);//��ʱ1/60��
    }	
	
}

int rt_application_init()
{
    rt_thread_t init_thread;
    
    rt_err_t result;

    if (init_thread != RT_NULL)
        rt_thread_startup(init_thread);

    tid1 = rt_thread_create("thread1",
        thread1_entry, 
        RT_NULL,
        512, 6, 10);
    if (tid1 != RT_NULL)
        rt_thread_startup(tid1);

    tid2 = rt_thread_create("thread2",
        thread2_entry, RT_NULL,
        512, 6, 10);
    if (tid2 != RT_NULL)
        rt_thread_startup(tid2);

    return 0;
}

/*@}*/
