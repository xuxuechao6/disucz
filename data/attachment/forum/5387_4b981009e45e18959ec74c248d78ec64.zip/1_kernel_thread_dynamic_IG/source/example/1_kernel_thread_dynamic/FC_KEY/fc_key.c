#include "fc_key.h"

void delay (u32 nCount)
{
	volatile int i;	 	
	for (i=0;i<nCount*100;i++);
}
//-------------------------------------------------------------------------------
void fc_init(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;
 	
 	RCC_APB2PeriphClockCmd(RCC_fc, ENABLE);	 //ʹ��PC�˿�ʱ��
	
 	GPIO_InitStructure.GPIO_Pin = Clock_fc|Latch_fc;				 //
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;  //���ģʽ
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP; //�������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;//�ٶ�
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;//���
 	GPIO_Init(GPIO_fc, &GPIO_InitStructure); //��ʼ��GPIO
 	GPIO_SetBits(GPIO_fc,Clock_fc|Latch_fc);	//����

 	GPIO_InitStructure.GPIO_Pin  = Data_fc;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;//����
	//GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;//�ٶ�
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//����
 	GPIO_Init(GPIO_fc, &GPIO_InitStructure); //��ʼ��GPIO
	GPIO_SetBits(GPIO_fc,Data_fc);	//����
}
//-------------------------------------------------------------------------------
u8 fc_read(void)
{
	u8 count,key=0;	
	GPIO_SetBits(GPIO_fc,Clock_fc);	//Clock=1;
	GPIO_SetBits(GPIO_fc,Latch_fc); //Latch=1;
	delay(5);
	GPIO_ResetBits(GPIO_fc,Latch_fc); //Latch=1;//Latch=0;
	for(count=0;count<8;count++)
	{
		key<<=1;
		GPIO_SetBits(GPIO_fc,Clock_fc);	//Clock=1;
		delay(5);
		GPIO_ResetBits(GPIO_fc,Clock_fc);	//Clock=0;
		if(GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_6))key=key|0x01;
	}
	return key;
}
//-------------------------------------------------------------------------------
