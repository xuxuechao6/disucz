#ifndef _ROM_H_
#define _ROM_H_
extern unsigned char rom_file[40976];
#endif
