LED * 4    ok
USART2+3   ok
TFT        ok
Touch      ok