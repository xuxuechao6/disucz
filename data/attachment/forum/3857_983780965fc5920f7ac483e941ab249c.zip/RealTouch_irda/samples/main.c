#include "stm32f4xx.h"
#include "uart.h"

extern void ir_init(void);
extern void wait_for_keystudy(void);
extern int  ir_readkey(void);

int main(void)
{
    int key;
	
    uart_init();
	
	ir_init();
	wait_for_keystudy();
	
    while (1)
    {
        key = ir_readkey();

        switch (key)
        {
        case 0:
            debug("Key Up\n\r");
            break;

        case 1:
            debug("Key Down\n\r");
            break;

        case 2:
            debug("Key Left\n\r");
            break;

        case 3:
            debug("Key Right\n\r");
            break;

        case 4:
            debug("Key Enter\n\r");
            break;

        case 5:
            debug("Key Back\n\r");
            break;

        }

    }
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{
    /* User can add his own implementation to report the file name and line number,
       ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

    /* Infinite loop */
    while (1)
    {}
}
#endif
